﻿#pragma warning disable IDE0065 // Misplaced using directive
global using System;
global using Zurich.DevOps.CrossCutting;
#pragma warning restore IDE0065 // Misplaced using directive