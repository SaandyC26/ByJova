﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Domain;

    public sealed class TicketBackgroundServiceConfiguration
    {
        #region --- PROPERTIES ---

        public bool Enabled { get; set; }

        public int CreatedMinutes { get; set; }

        public string To { get; set; }

        public IEnumerable<string> ToArray => To.Split(';', StringSplitOptions.RemoveEmptyEntries);

        #endregion
    }

    internal sealed class TicketBackgroundService : BackgroundService
    {
        #region --- REFERENCES ---

        private readonly ILogger<TicketBackgroundService> _logger;

        private readonly TicketBackgroundServiceConfiguration _configuration;

        private readonly IServiceProvider _services;

        private readonly IHostEnvironment _environment;

        #endregion

        #region --- CONSTRUCTORS ---

        internal TicketBackgroundService(IServiceProvider services)
        {
            _services = Guard.Argument(services, nameof(services)).IsNotNull().Value;
            _environment = services.GetRequiredService<IHostEnvironment>();
            _logger = services.GetRequiredService<ILogger<TicketBackgroundService>>();
            _configuration = services.GetRequiredService<IOptions<TicketBackgroundServiceConfiguration>>().Value;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(BackgroundService)} {nameof(TicketBackgroundService)} {nameof(StartAsync)}.");
            return base.StartAsync(cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(BackgroundService)} {nameof(TicketBackgroundService)} {nameof(StopAsync)}.");
            return base.StopAsync(cancellationToken);
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected async override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Enabled
            if (!_configuration.Enabled) await Task.Delay(-1, stoppingToken).ConfigureAwait(false);
            // Static Variables
            var delayMinutes = _configuration.CreatedMinutes / 4;
            // Loop
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    // Scope
                    using var scope = _services.CreateScope();
                    // Ticket Repository
                    var ticketRepository = scope.ServiceProvider.GetRequiredService<ITicketRepository>();
                    // Get Tickets
                    var (ticketsCount, tickets) = await ticketRepository.GetAsync(asNoTracking: false, dataSourceRequest: GetDataSourceRequest(), cancellationToken: stoppingToken).ConfigureAwait(false);
                    if (ticketsCount > 0)
                    {
                        // Body Mail
                        var body = string.Join($"-------------------------{Environment.NewLine}", tickets.Select(x =>
                            $"{nameof(Ticket.Id)}: {x.Id}{Environment.NewLine}" +
                            $"{nameof(Ticket.Summary)}: {x.Summary}{Environment.NewLine}" +
                            $"{nameof(Ticket.Description)}: {x.Description}{Environment.NewLine}" +
                            $"{nameof(Ticket.Type)}: {x.Type}{Environment.NewLine}" +
                            $"{nameof(Ticket.User)}: {x.User.AdAccount.SAMAccountName} ({x.User.Name}){Environment.NewLine}"
                        ));
                        // Mail
                        var mail = new MailDto()
                        {
                            From = new MailAddressDto()
                            {
                                Address = $"{nameof(Zurich)}.{nameof(FinancePortal)}.{_environment.EnvironmentName}@zurich.com",
                                DisplayName = $"Finance Portal - {_environment.EnvironmentName}"
                            },
                            To = _configuration.ToArray.Select(x => new MailAddressDto()
                            {
                                Address = x
                            }),
                            Subject = $"New {nameof(FinancePortal)} {nameof(Ticket)}s.",
                            IsBodyHtml = false,
                            Body = body
                        };
                        // Mail Service
                        var mailService = scope.ServiceProvider.GetRequiredService<IMailService>();
                        // Send Mail Async
                        await mailService.SendMailAsync(mail, cancellationToken: stoppingToken).ConfigureAwait(false);
                        // Update Tickets
                        tickets.ForEach(x => x.UpdateStatus(TicketStatus.Analysis)
                            .UpdateNotifications(x.Notifications | TicketNotifications.Email)
                            .AddComments(new TicketComment[]
                            {
                                new TicketComment(
                                    $"*auto*: Mail notification sent to Product Owners and {nameof(Ticket.Status)} updated to {nameof(TicketStatus.Analysis)}.",
                                    new User(Guid.NewGuid().ToString(), new AdAccount(nameof(FinancePortal)))
                                )
                            }));
                        // DbContext
                        var dbContext = scope.ServiceProvider.GetRequiredService<IApplicationDbContext>();
                        await dbContext.SaveChangesAsync(cancellationToken: stoppingToken).ConfigureAwait(false);
                        // Logger
                        _logger.LogInformation("Sent mails to: {x}.", string.Join(", ", _configuration.ToArray));
                    }
                }
                catch (Exception exception)
                {
                    if (exception is not TaskCanceledException) _logger.LogError(exception, $"{nameof(TicketBackgroundService)} {nameof(Exception)}.");
                }
                // Sleep
                _logger.LogDebug("{x} Sleeping for {y}.", nameof(TicketBackgroundService), (delayMinutes.Equals(0) ? $"{TimeSpan.FromSeconds(10)}s" : $"{delayMinutes}m"));
                await Task.Delay(delayMinutes.Equals(0) ? TimeSpan.FromSeconds(10) : TimeSpan.FromMinutes(delayMinutes), stoppingToken);
            }
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private DataSourceRequest GetDataSourceRequest() =>
            new()
            {
                Filter = new Filter()
                {
                    Logic = FilterLogic.and,
                    Filters = new Filter[]
                    {
                        new Filter()
                        {
                            Field = nameof(Ticket.Status),
                            Value = nameof(TicketStatus.Created),
                            Operator = FilterOperator.eq
                        },
                        new Filter()
                        {
                            Field = nameof(Ticket.Updated),
                            Value = DateTime.UtcNow.Subtract(TimeSpan.FromMinutes(_configuration.CreatedMinutes)),
                            Operator = FilterOperator.lt
                        },
                        new Filter()
                        {
                            Field = nameof(Ticket.Notifications),
                            Value = (int)TicketNotifications.None,
                            Operator = FilterOperator.eq
                        }
                    }
                }
            };

        #endregion
    }
}
