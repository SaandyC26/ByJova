﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using FluentValidation;
    using Newtonsoft.Json;

    public sealed class BaseTicketValidator : AbstractValidator<TicketDto>
    {
        #region --- CONSTRUCTORS ---

        public BaseTicketValidator(bool create = true)
        {
            RuleFor(x => x).NotNull();
            if (create) RuleFor(x => x.Summary).NotEmpty();
            if (create) RuleFor(x => x.Description).NotEmpty();
            if (!create) RuleFor(x => x.Id).GreaterThan(0);
            if (!create) RuleFor(x => x.Status).IsInEnum().NotEqual(TicketStatus.Unknown);
            if (create) RuleFor(x => x.Type).IsInEnum().NotEqual(TicketType.Unknown);
            if (!create) RuleForEach(x => x.Comments).SetValidator(x => new BaseTicketCommentValidator()).Unless(x => x.Comments == null);
        }

        #endregion
    }

    public sealed class BaseTicketCommentValidator : AbstractValidator<TicketCommentDto>
    {
        #region --- CONSTRUCTORS ---

        public BaseTicketCommentValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Text).NotEmpty();
        }

        #endregion
    }

    internal sealed class TicketRequestConfiguration
    {
        #region --- REFERENCES ---

        [JsonProperty]
        internal TicketStatus[] HiddenStatuses { get; set; }

        [JsonProperty]
        internal TicketStatus[] UpdatableStatuses { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static TicketRequestConfiguration CreateDefault() =>
            new()
            {
                HiddenStatuses = new TicketStatus[] { TicketStatus.Completed, TicketStatus.Rejected },
                UpdatableStatuses = new TicketStatus[] { TicketStatus.Created, TicketStatus.Analysis }
            };

        #endregion
    }
}
