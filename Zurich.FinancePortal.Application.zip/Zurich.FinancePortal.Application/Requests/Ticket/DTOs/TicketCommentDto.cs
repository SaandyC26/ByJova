﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using System;
    using System.Collections.Generic;

    public sealed class TicketCommentDto
    {
        #region --- PROPERTIES ---

        public long Id { get; set; }

        [System.Text.Json.Serialization.JsonConverter(typeof(DateTimeFormatConverterRO))]
        [Newtonsoft.Json.JsonConverter(typeof(NewtonsoftDateTimeFormatConverterRO))]
        public DateTime DateTime { get; set; }

        private string _text;
        public string Text { get => _text; set => _text = value?.Trim(Environment.NewLine.ToCharArray())?.Trim(); }

        private string _sAMAccountName;
        public string SAMAccountName { get => _sAMAccountName; set => _sAMAccountName = value?.Trim(); }

        public IEnumerable<LinkDto> Links { get; set; }

        #endregion
    }
}
