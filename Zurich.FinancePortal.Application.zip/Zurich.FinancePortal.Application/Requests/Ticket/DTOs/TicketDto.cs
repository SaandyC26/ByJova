﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Domain;
    using System;
    using System.Collections.Generic;

    public sealed class TicketDto
    {
        #region --- PROPERTIES ---

        public long Id { get; set; }

        public string Summary { get; set; }

        public string Description { get; set; }

        public string Reference { get; set; }

        [System.Text.Json.Serialization.JsonConverter(typeof(DateTimeFormatConverterRO))]
        [Newtonsoft.Json.JsonConverter(typeof(NewtonsoftDateTimeFormatConverterRO))]
        public DateTime Created { get; set; }

        [System.Text.Json.Serialization.JsonConverter(typeof(DateTimeFormatConverterRO))]
        [Newtonsoft.Json.JsonConverter(typeof(NewtonsoftDateTimeFormatConverterRO))]
        public DateTime Updated { get; set; }

        public TicketType Type { get; set; }

        public TicketStatus Status { get; set; }

        public IEnumerable<LinkDto> Links { get; set; }

        #endregion

        #region --- REFERENCES ---

        public string SAMAccountName { get; set; }

        public IEnumerable<TicketCommentDto> Comments { get; set; }

        #endregion
    }
}
