﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Zurich.DevOps.Application;

    public sealed class DeleteTicketCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public long Id { get; set; }

        #endregion
    }

    public sealed class DeleteTicketCommandValidator : AbstractValidator<DeleteTicketCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteTicketCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Id).GreaterThan(0);
        }

        #endregion
    }

    public sealed class DeleteTicketCommandHandler : BaseRequestHandler<DeleteTicketCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteTicketCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        public async override Task<RequestResult<Unit>> Handle(DeleteTicketCommand request, CancellationToken cancellationToken)
        {
            var deleteTicketPermission = await HasPermissions(Constants.Permission_DeleteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Check Permissions
            if (!deleteTicketPermission && !await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Get Ticket
            var ticket = await TicketRepository.GetByIdAsync(request.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ticket == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.Id}\" not found.");
            if (!deleteTicketPermission)
            {
                var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!ticket.User.AdAccount.SAMAccountName.EqualsICIC(currentUser.AdAccount.SAMAccountName) ||
                    !ticket.Status.Equals(TicketStatus.Created)) return RequestResult.FromUnauthorized();
            }
            // Add Ticket
            TicketRepository.Remove(ticket);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }
    }
}
