﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class CreateTicketCommentCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public long TicketId { get; set; }

        public TicketCommentDto TicketComment { get; set; }

        #endregion
    }

    public sealed class CreateTicketCommentCommandValidator : AbstractValidator<CreateTicketCommentCommand>
    {
        #region --- CONSTRUCTORS ---

        public CreateTicketCommentCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.TicketId).GreaterThan(0);
            RuleFor(x => x.TicketComment).SetValidator(x => new BaseTicketCommentValidator()).Unless(x => x == null);
        }

        #endregion
    }

    public sealed class CreateTicketCommentCommandHandler : BaseRequestHandler<CreateTicketCommentCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public CreateTicketCommentCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        public async override Task<RequestResult<Unit>> Handle(CreateTicketCommentCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false) &&
                !await HasPermissions(Constants.Permission_OtherManageTicket, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Get Ticket
            var ticket = await TicketRepository.GetByIdAsync(request.TicketId, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ticket == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.TicketId}\" not found.");
            // Get User
            var user = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Add TicketComment
            ticket.AddComments(new TicketComment[] { new TicketComment(request.TicketComment.Text, user) });
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }
    }
}
