﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Zurich.DevOps.Application;

    public sealed class CreateTicketCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public TicketDto Ticket { get; set; }

        #endregion
    }

    public sealed class CreateTicketCommandValidator : AbstractValidator<CreateTicketCommand>
    {
        #region --- CONSTRUCTORS ---

        public CreateTicketCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Ticket).SetValidator(x => new BaseTicketValidator(create: true)).Unless(x => x == null);
        }

        #endregion
    }

    public sealed class CreateTicketCommandHandler : BaseRequestHandler<CreateTicketCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public CreateTicketCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        public async override Task<RequestResult<Unit>> Handle(CreateTicketCommand request, CancellationToken cancellationToken)
        {
            // Get CurrentUser
            var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_WriteTicket, currentUser: currentUser, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Get User
            var user = await UserRepository.GetUserByIdAsync(currentUser.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Create Ticket
            var ticket = new Ticket(request.Ticket.Summary, request.Ticket.Description, request.Ticket.Type, user);
            // Add Ticket
            TicketRepository.Add(ticket);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }
    }
}
