﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class DeleteTicketCommentCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public long TicketId { get; set; }

        public long Id { get; set; }

        #endregion
    }

    public sealed class DeleteTicketCommentCommandValidator : AbstractValidator<DeleteTicketCommentCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteTicketCommentCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.TicketId).GreaterThan(0);
            RuleFor(x => x.Id).GreaterThan(0);
        }

        #endregion
    }

    public sealed class DeleteTicketCommentCommandHandler : BaseRequestHandler<DeleteTicketCommentCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteTicketCommentCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        public async override Task<RequestResult<Unit>> Handle(DeleteTicketCommentCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var writeTicketPermission = await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var otherManageTicketPermission = await HasPermissions(Constants.Permission_OtherManageTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var deleteTicketPermission = await HasPermissions(Constants.Permission_DeleteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!writeTicketPermission && !otherManageTicketPermission && !deleteTicketPermission) return RequestResult.FromUnauthorized();
            // Get Ticket
            var ticket = await TicketRepository.GetByIdAsync(request.TicketId, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ticket == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.TicketId}\" not found.");
            // Get TicketComment
            var ticketComment = ticket.Comments.SingleOrDefault(x => x.Id.Equals(request.Id));
            if (ticketComment == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(TicketComment)} with {nameof(TicketComment.Id)} \"{request.Id}\" for {nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.TicketId}\" not found.");
            if (!otherManageTicketPermission && !deleteTicketPermission)
            {
                // Get User
                var user = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!ticketComment.SAMAccountName.EqualsICIC(user.AdAccount.SAMAccountName)) return RequestResult.FromUnauthorized();
            }

            ticket.RemoveComment(request.Id);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }
    }
}
