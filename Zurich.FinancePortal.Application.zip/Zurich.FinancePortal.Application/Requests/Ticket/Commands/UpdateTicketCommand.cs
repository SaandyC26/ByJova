﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class UpdateTicketCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public TicketDto Ticket { get; set; }

        #endregion
    }

    public sealed class UpdateTicketCommandValidator : AbstractValidator<UpdateTicketCommand>
    {
        #region --- CONSTRUCTORS ---

        public UpdateTicketCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Ticket).SetValidator(x => new BaseTicketValidator(create: false)).Unless(x => x == null);
        }

        #endregion
    }

    public sealed class UpdateTicketCommandHandler : BaseRequestHandler<UpdateTicketCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public UpdateTicketCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        public async override Task<RequestResult<Unit>> Handle(UpdateTicketCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var writeTicketPermission = await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var otherManageTicketPermission = await HasPermissions(Constants.Permission_OtherManageTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!writeTicketPermission && !otherManageTicketPermission) return RequestResult.FromUnauthorized();
            // Get Ticket
            var ticket = await TicketRepository.GetByIdAsync(request.Ticket.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ticket == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.Ticket.Id}\" not found.");
            // Update Ticket
            if (!otherManageTicketPermission)
            {
                var configuration = await GetOrCreateAndGetApplicationConfigurationByType<TicketRequestConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!configuration.UpdatableStatuses.Contains(ticket.Status)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(Ticket)} can only be modified when status in \"{string.Join(", ", configuration.HiddenStatuses.Select(x => x.ToString()))}\".");
                var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!currentUser.AdAccount.SAMAccountName.EqualsICIC(ticket.User.AdAccount.SAMAccountName)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(Ticket)} can only be modified by \"{ticket.User.AdAccount.SAMAccountName}\" or {nameof(Ticket)}s Managers.");
                ticket.UpdateText(request.Ticket.Summary, request.Ticket.Description);
                if (ticket.Status.Equals(TicketStatus.Created)) ticket.UpdateType(request.Ticket.Type);
            }
            else
            {
                ticket
                    .UpdateText(request.Ticket.Summary, request.Ticket.Description)
                    .UpdateStatus(request.Ticket.Status)
                    .UpdateType(request.Ticket.Type)
                    .UpdateReference(request.Ticket.Reference);
            }
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }
    }
}
