﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetTicketCommentsQuery : BaseRequest<GetTicketCommentsQueryResult>
    {
        #region --- PROPERTIES ---

        public long TicketId { get; set; }

        #endregion
    }

    public sealed class GetTicketCommentsQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<TicketCommentDto> TicketComments { get; set; }

        #endregion
    }

    public sealed class GetTicketCommentsQueryHandler : BaseRequestHandler<GetTicketCommentsQuery, GetTicketCommentsQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetTicketCommentsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetTicketCommentsQueryResult>> Handle(GetTicketCommentsQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var writeTicketPermission = await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var otherManageTicketPermission = await HasPermissions(Constants.Permission_OtherManageTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var deleteTicketPermission = await HasPermissions(Constants.Permission_DeleteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!await HasPermissions(Constants.Permission_ReadTicket, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<GetTicketCommentsQueryResult>();
            // Get User
            var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Get Ticket
            var ticket = await TicketRepository.GetByIdAsync(request.TicketId, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ticket == null) return RequestResult.FromError<GetTicketCommentsQueryResult>(RequestResult.ERROR_NOTFOUND, $"{nameof(Ticket)} with {nameof(Ticket.Id)} \"{request.TicketId}\" not found.");
            // Result
            return RequestResult.FromResult(new GetTicketCommentsQueryResult()
            {
                Count = ticket.Comments.Count,
                TicketComments = Mapper.Map<IEnumerable<TicketComment>, IEnumerable<TicketCommentDto>>(ticket.Comments, opt =>
                {
                    opt.Items.Add(nameof(Constants.Permission_WriteTicket), writeTicketPermission);
                    opt.Items.Add(nameof(Constants.Permission_OtherManageTicket), otherManageTicketPermission);
                    opt.Items.Add(nameof(Constants.Permission_DeleteTicket), deleteTicketPermission);
                    opt.Items.Add(nameof(AdAccount.SAMAccountName), currentUser.AdAccount.SAMAccountName);
                })
            });
        }

        #endregion
    }
}
