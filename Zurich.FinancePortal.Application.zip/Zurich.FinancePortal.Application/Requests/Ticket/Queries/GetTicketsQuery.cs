﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetTicketsQuery : BaseRequest<GetTicketsQueryResult>
    {
        #region --- PROPERTIES ---

        public bool OnlyMines { get; set; }

        public bool IncludeHidden { get; set; }

        #endregion
    }

    public sealed class GetTicketsQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<TicketDto> Tickets { get; set; }

        #endregion
    }

    public sealed class GetTicketsQueryHandler : BaseRequestHandler<GetTicketsQuery, GetTicketsQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetTicketsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetTicketsQueryResult>> Handle(GetTicketsQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var writeTicketPermission = await HasPermissions(Constants.Permission_WriteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var otherManageTicketPermission = await HasPermissions(Constants.Permission_OtherManageTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            var deleteTicketPermission = await HasPermissions(Constants.Permission_DeleteTicket, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!await HasPermissions(Constants.Permission_ReadTicket, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<GetTicketsQueryResult>();
            // Get User
            var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Load Configuration
            var configuration = await GetOrCreateAndGetApplicationConfigurationByType<TicketRequestConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Get Tickets
            var (count, tickets) = await TicketRepository.GetAsync(user: request.OnlyMines ? currentUser : null, hiddenStatuses: !request.IncludeHidden ? configuration?.HiddenStatuses : null, asNoTracking: true, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromResult(new GetTicketsQueryResult()
            {
                Count = count,
                Tickets = Mapper.Map<IEnumerable<Ticket>, IEnumerable<TicketDto>>(tickets, opt =>
                {
                    opt.Items.Add(nameof(TicketRequestConfiguration), configuration);
                    opt.Items.Add(nameof(Constants.Permission_WriteTicket), writeTicketPermission);
                    opt.Items.Add(nameof(Constants.Permission_OtherManageTicket), otherManageTicketPermission);
                    opt.Items.Add(nameof(Constants.Permission_DeleteTicket), deleteTicketPermission);
                    opt.Items.Add(nameof(AdAccount.SAMAccountName), currentUser.AdAccount.SAMAccountName);
                })
            });
        }

        #endregion
    }
}
