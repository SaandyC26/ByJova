﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class DeleteMasterDataCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public int Id { get; set; }

        public string Type { get; set; }

        #endregion
    }

    public sealed class DeleteMasterDataCommandValidator : AbstractValidator<DeleteMasterDataCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteMasterDataCommandValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Type).NotEmpty().Unless(x => x == null);
            RuleFor(x => x.Type).Must(x => MasterData.GetMasterDataTypes().Select(mdt => mdt.Name).Any(mdn => mdn.EqualsICIC(x))).Unless(x => x == null);
            RuleFor(x => x.Id).GreaterThan(0).Unless(x => x == null);
        }

        #endregion
    }

    public sealed class DeleteMasterDataCommandHandler : BaseRequestHandler<DeleteMasterDataCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteMasterDataCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(DeleteMasterDataCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var type = MasterData.GetMasterDataTypes().SingleOrDefault(t => t.Name.EqualsICIC(request.Type));
            if (type.Equals(typeof(CurrencyExchangeRate)) && !await HasPermissions(Constants.Permission_ManageCurrencyExchangeRate, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            else if (!await HasPermissions(Constants.Permission_ManageMasterData, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Get MasterData
            var masterData = await MasterDataRepository.GetMasterDataByIdAsync(type, request.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (masterData == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} with {nameof(MasterData.Id)} {request.Id} not found.");
            // Delete MasterData
            switch (type.Name)
            {
                case nameof(ValueAddedTax):
                case nameof(Currency):
                case nameof(Product):
                    return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(MasterData)} \"{request.Type}\" not allowed.");
                case nameof(ChargingModelType):
                    var chargingModels = await MasterDataRepository.GetMasterDatasByEntityAsync<ChargingModel>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
                    if (chargingModels.Any(x => x.Type.Id.Equals(request.Id))) return RequestResult.FromError(BaseRequestResult.ERROR_REFERENCED, $"{nameof(MasterData)} with {nameof(MasterData.Id)} {request.Id} is being referenced by {nameof(MasterData)} {nameof(ChargingModel)}.");
                    break;
                case nameof(CurrencyExchangeRate):
                    MasterDataRepository.Remove(masterData);
                    // Refresh Revenues
                    var revenues = await RevenueRepository.GetRevenuesByYearAndCurrencyAsync(((CurrencyExchangeRate)masterData).Year, ((CurrencyExchangeRate)masterData).From, exclude: (CurrencyExchangeRate)masterData, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);
                    var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                    revenues.ForEach(r => r.RefreshFyf(currentUser: currentUser, autoCommentText: $"Automatically updated due to {nameof(CurrencyExchangeRate)} deletion."));
                    break;
                case nameof(BusinessUnit):
                case nameof(ChargingModel):
                case nameof(CostCenter):
                case nameof(Customer):
                case nameof(LineOfBusiness):
                case nameof(Project):
                case nameof(TestingTool):
                case nameof(TypeOfService):
                case nameof(CustomerFunction):
                    if (await MasterDataRepository.IsMasterDataBeingUsedAsync(type, masterData, cancellationToken: cancellationToken).ConfigureAwait(false))
                    {
                        return RequestResult.FromError(BaseRequestResult.ERROR_REFERENCED, $"{nameof(MasterData)} with {nameof(MasterData.Id)} {request.Id} is being referenced.");
                    }

                    MasterDataRepository.Remove(masterData);
                    break;
                default:
                    throw new NotImplementedException($"MasterData \"{type.Name}\" not implemented.");
            }
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
