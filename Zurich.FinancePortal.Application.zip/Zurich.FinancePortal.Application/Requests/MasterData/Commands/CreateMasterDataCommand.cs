﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class CreateMasterDataCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public string Type { get; set; }

    public MasterDataDto MasterData { get; set; }

    #endregion
}

public sealed class CreateMasterDataCommandValidator : AbstractValidator<CreateMasterDataCommand>
{
    #region --- CONSTRUCTORS ---

    public CreateMasterDataCommandValidator()
    {
        RuleFor(x => x).NotNull();
        RuleFor(x => x.Type).NotEmpty().Unless(x => x == null);
        RuleFor(x => x.Type).Must(x => MasterData.GetMasterDataTypes().Select(mdt => mdt.Name).Any(mdn => mdn.EqualsICIC(x))).Unless(x => x == null);
        RuleFor(x => x.MasterData).NotNull().Unless(x => x == null);
        RuleFor(x => x.MasterData).SetValidator(x => new BaseMasterDataValidator(x.Type)).Unless(x => x == null || x.MasterData == null);
    }

    #endregion
}

public sealed class CreateMasterDataCommandHandler : BaseRequestHandler<CreateMasterDataCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public CreateMasterDataCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<Unit>> Handle(CreateMasterDataCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        var type = MasterData.GetMasterDataTypes().SingleOrDefault(t => t.Name.EqualsICIC(request.Type));
        if (type.Equals(typeof(CurrencyExchangeRate)) && !await HasPermissions(Constants.Permission_ManageCurrencyExchangeRate, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        else if (!await HasPermissions(Constants.Permission_ManageMasterData, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Get MasterData
        var masterDatas = await MasterDataRepository.GetMasterDatasByEntityAsync(type, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Update MasterData
        switch (type.Name)
        {
            case nameof(BusinessUnit):
                var buDto = (BusinessUnitDto)request.MasterData;
                if (masterDatas.Any(md => ((BusinessUnit)md).Code.EqualsICIC(buDto.Code))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var bu = new BusinessUnit(buDto.Name, buDto.Code);
                MasterDataRepository.Add(bu);
                break;
            case nameof(ChargingModelType):
                var cmtDto = (ChargingModelTypeDto)request.MasterData;
                if (masterDatas.Any(md => ((ChargingModelType)md).Type.EqualsICIC(cmtDto.Type))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var cmt = new ChargingModelType(cmtDto.Type);
                MasterDataRepository.Add(cmt);
                break;
            case nameof(ChargingModel):
                var cmDto = (ChargingModelDto)request.MasterData;
                if (masterDatas.Any(md => ((ChargingModel)md).Code.EqualsICIC(cmDto.Code))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var chargingModelType = await MasterDataRepository.GetMasterDataByIdAsync<ChargingModelType>(cmDto.Type.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
                if (chargingModelType == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} \"{nameof(ChargingModelType)}\" with {nameof(ChargingModelType.Id)} \"{cmDto.Type.Id}\" not found.");
                var cm = new ChargingModel(cmDto.Name, cmDto.Code, chargingModelType);
                MasterDataRepository.Add(cm);
                break;
            case nameof(CostCenter):
                var ccDto = (CostCenterDto)request.MasterData;
                if (masterDatas.Any(md => ((CostCenter)md).Code.EqualsICIC(ccDto.Code))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var cc = new CostCenter(ccDto.Code, ccDto.Types);
                MasterDataRepository.Add(cc);
                break;
            case nameof(CurrencyExchangeRate):
                var cerDto = (CurrencyExchangeRateDto)request.MasterData;
                var currencies = await MasterDataRepository.GetMasterDatasByEntityAsync<Currency>(cancellationToken: cancellationToken).ConfigureAwait(false);
                var from = currencies.SingleOrDefault(c => c.Id.Equals(cerDto.From.Id));
                if (from == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} \"{nameof(Currency)}\" with {nameof(Currency.Id)} \"{cerDto.From.Id}\" not found.");
                var to = currencies.SingleOrDefault(c => c.Id.Equals(cerDto.To.Id));
                if (to == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} \"{nameof(Currency)}\" with {nameof(Currency.Id)} \"{cerDto.To.Id}\" not found.");
                var month = Month.None;
                if (!string.IsNullOrWhiteSpace(cerDto.Month) && !Enum.TryParse(cerDto.Month, out month)) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Month)} \"{cerDto.Month}\" not found.");
                if (masterDatas.Any(md => ((CurrencyExchangeRate)md).Year.Equals(cerDto.Year) && ((CurrencyExchangeRate)md).From.Equals(from) && ((CurrencyExchangeRate)md).To.Equals(to) && ((CurrencyExchangeRate)md).Month.Equals(month))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var cer = new CurrencyExchangeRate(cerDto.Year, cerDto.Rate, from, to, month: month);
                MasterDataRepository.Add(cer);
                // Refresh Revenues
                var revenues = await RevenueRepository.GetRevenuesByYearAndCurrencyAsync(cer.Year, from, include: cer, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);
                var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                revenues.ForEach(r => r.RefreshFyf(currentUser: currentUser, autoCommentText: $"Automatically updated due to {nameof(CurrencyExchangeRate)} creation."));
                break;
            case nameof(Customer):
                var customerDto = (CustomerDto)request.MasterData;
                if (masterDatas.Any(md => ((Customer)md).Name.EqualsICIC(customerDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var cu = new Customer(customerDto.Name);
                if (customerDto.Function != null)
                {
                    var cf = await MasterDataRepository.GetMasterDataByIdAsync<CustomerFunction>(customerDto.Function.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
                    if (cf == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} \"{nameof(CustomerFunction)}\" with {nameof(CustomerFunction.Id)} \"{customerDto.Function.Id}\" not found.");
                    cu.UpdateFunction(cf);
                }

                MasterDataRepository.Add(cu);
                break;
            case nameof(LineOfBusiness):
                var lobDto = (LineOfBusinessDto)request.MasterData;
                if (masterDatas.Any(md => ((LineOfBusiness)md).Name.EqualsICIC(lobDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var lob = new LineOfBusiness(lobDto.Name, icon: lobDto.Icon);
                MasterDataRepository.Add(lob);
                break;
            case nameof(Project):
                var pDto = (ProjectDto)request.MasterData;
                if (masterDatas.Any(md => ((Project)md).Name.EqualsICIC(pDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var planningItApps = pDto.PlanningItApps?.Select(x => new PlanningItApp(x.Prefix, x.Id, x.Name)) ?? Array.Empty<PlanningItApp>();
                var p = new Project(pDto.Name, pDto.Type, planningItApps: planningItApps);
                MasterDataRepository.Add(p);
                break;
            case nameof(TypeOfService):
                var tosDto = (TypeOfServiceDto)request.MasterData;
                if (masterDatas.Any(md => ((TypeOfService)md).Name.EqualsICIC(tosDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var tos = new TypeOfService(tosDto.Name);
                MasterDataRepository.Add(tos);
                break;
            case nameof(TestingTool):
                var ttDto = (TestingToolDto)request.MasterData;
                if (masterDatas.Any(md => ((TestingTool)md).Name.EqualsICIC(ttDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var tt = new TypeOfService(ttDto.Name);
                MasterDataRepository.Add(tt);
                break;
            case nameof(CustomerFunction):
                var fDto = (CustomerFunctionDto)request.MasterData;
                if (masterDatas.Any(md => ((CustomerFunction)md).Name.EqualsICIC(fDto.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(MasterData)} \"{request.Type}\" already exists.");
                var f = new CustomerFunction(fDto.Name);
                MasterDataRepository.Add(f);
                break;
            case nameof(Product):
            case nameof(ValueAddedTax):
            case nameof(Currency):
            default:
                return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(MasterData)} \"{request.Type}\" not allowed.");
        }
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
