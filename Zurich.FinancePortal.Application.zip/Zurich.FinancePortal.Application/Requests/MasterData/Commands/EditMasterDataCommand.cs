﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class EditMasterDataCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public int Id { get; set; }

    public string Type { get; set; }

    public MasterDataDto MasterData { get; set; }

    #endregion
}

public sealed class EditMasterDataCommandValidator : AbstractValidator<EditMasterDataCommand>
{
    #region --- CONSTRUCTORS ---

    public EditMasterDataCommandValidator()
    {
        RuleFor(x => x).NotNull();
        RuleFor(x => x.Type).NotEmpty().Unless(x => x == null);
        RuleFor(x => x.Type).Must(x => MasterData.GetMasterDataTypes().Select(mdt => mdt.Name).Any(mdn => mdn.EqualsICIC(x))).Unless(x => x == null);
        RuleFor(x => x.MasterData).NotNull().Unless(x => x == null);
        RuleFor(x => x.MasterData.Id).GreaterThan(0).Unless(x => x == null || x.MasterData == null);
        RuleFor(x => x.MasterData).SetValidator(x => new BaseMasterDataValidator(x.Type)).Unless(x => x == null || x.MasterData == null);
    }

    #endregion
}

public sealed class EditMasterDataCommandHandler : BaseRequestHandler<EditMasterDataCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public EditMasterDataCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<Unit>> Handle(EditMasterDataCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        var type = MasterData.GetMasterDataTypes().SingleOrDefault(t => t.Name.EqualsICIC(request.Type));
        if (type.Equals(typeof(CurrencyExchangeRate)) && !await HasPermissions(Constants.Permission_ManageCurrencyExchangeRate, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        else if (!await HasPermissions(Constants.Permission_ManageMasterData, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Get MasterData
        var masterData = await MasterDataRepository.GetMasterDataByIdAsync(type, request.MasterData.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (masterData == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(MasterData)} with {nameof(MasterData.Id)} not found.");
        // Update MasterData
        switch (type.Name)
        {
            case nameof(BusinessUnit):
                var buDto = (BusinessUnitDto)request.MasterData;
                ((BusinessUnit)masterData).UpdateName(buDto.Name).UpdateCode(buDto.Code);
                break;
            case nameof(ChargingModelType):
                var cmtDto = (ChargingModelTypeDto)request.MasterData;
                ((ChargingModelType)masterData).UpdateType(cmtDto.Type);
                break;
            case nameof(ChargingModel):
                var cmDto = (ChargingModelDto)request.MasterData;
                var chargingModelType = await MasterDataRepository.GetMasterDataByIdAsync<ChargingModelType>(cmDto.Type.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
                if (chargingModelType == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"MasterData \"{nameof(ChargingModelType)}\" with {nameof(ChargingModelType.Id)} \"{cmDto.Type.Id}\" not found.");
                ((ChargingModel)masterData).UpdateName(cmDto.Name).UpdateCode(cmDto.Code).UpdateType(chargingModelType);
                break;
            case nameof(CostCenter):
                var ccDto = (CostCenterDto)request.MasterData;
                ((CostCenter)masterData).UpdateCode(ccDto.Code).UpdateTypes(ccDto.Types);
                break;
            case nameof(CurrencyExchangeRate):
                var cerDto = (CurrencyExchangeRateDto)request.MasterData;
                var from = ((CurrencyExchangeRate)masterData).From;
                var to = ((CurrencyExchangeRate)masterData).To;
                var currencies = default(IEnumerable<Currency>);
                if (cerDto.From != null && !from.Id.Equals(cerDto.From.Id))
                {
                    currencies = await MasterDataRepository.GetMasterDatasByEntityAsync<Currency>(cancellationToken: cancellationToken).ConfigureAwait(false);
                    from = currencies.SingleOrDefault(c => c.Id.Equals(cerDto.From.Id));
                    if (from == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"MasterData \"{nameof(Currency)}\" with {nameof(Currency.Id)} \"{cerDto.From.Id}\" not found.");
                }

                if (cerDto.To != null && !to.Id.Equals(cerDto.To.Id))
                {
                    currencies ??= await MasterDataRepository.GetMasterDatasByEntityAsync<Currency>(cancellationToken: cancellationToken).ConfigureAwait(false);
                    to = currencies.SingleOrDefault(c => c.Id.Equals(cerDto.To.Id));
                    if (to == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"MasterData \"{nameof(Currency)}\" with {nameof(Currency.Id)} \"{cerDto.To.Id}\" not found.");
                }

                var month = Month.None;
                if (!string.IsNullOrWhiteSpace(cerDto.Month) && !Enum.TryParse(cerDto.Month, out month)) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Month)} \"{cerDto.Month}\" not found.");
                ((CurrencyExchangeRate)masterData).UpdateYear(cerDto.Year).UpdateMonth(month).UpdateRate(cerDto.Rate).UpdateFrom(from).UpdateTo(to);
                // Refresh Revenues
                var revenues = await RevenueRepository.GetRevenuesByYearAndCurrencyAsync(cerDto.Year, ((CurrencyExchangeRate)masterData).From, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);
                var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                revenues.ForEach(r => r.RefreshFyf(currentUser: currentUser, autoCommentText: $"Automatically updated due to {nameof(CurrencyExchangeRate)} edition."));
                break;
            case nameof(Customer):
                var customerDto = (CustomerDto)request.MasterData;
                ((Customer)masterData).UpdateName(customerDto.Name);
                var customerFunction = customerDto.Function != null ? await MasterDataRepository.GetMasterDataByIdAsync<CustomerFunction>(customerDto.Function.Id, cancellationToken: cancellationToken).ConfigureAwait(false) : null;
                if (customerDto.Function != null && customerFunction == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"MasterData \"{nameof(CustomerFunction)}\" with {nameof(CustomerFunction.Id)} \"{customerDto.Function.Id}\" not found.");
                ((Customer)masterData).UpdateFunction(customerFunction);

                break;
            case nameof(TestingTool):
                var testingToolDto = (TestingToolDto)request.MasterData;
                ((TestingTool)masterData).UpdateName(testingToolDto.Name);
                break;
            case nameof(LineOfBusiness):
                var lobDto = (LineOfBusinessDto)request.MasterData;
                ((LineOfBusiness)masterData).UpdateName(lobDto.Name).UpdateIcon(lobDto.Icon);
                break;
            case nameof(Project):
                var pDto = (ProjectDto)request.MasterData;
                var planningItApps = pDto.PlanningItApps?.Select(x => new PlanningItApp(x.Prefix, x.Id, x.Name)) ?? Array.Empty<PlanningItApp>();
                ((Project)masterData).Update(pDto.Name, pDto.Type, planningItApps: planningItApps);
                break;
            case nameof(TypeOfService):
                var tosDto = (TypeOfServiceDto)request.MasterData;
                ((TypeOfService)masterData).UpdateName(tosDto.Name);
                break;
            case nameof(CustomerFunction):
                var fDto = (CustomerFunctionDto)request.MasterData;
                ((CustomerFunction)masterData).UpdateName(fDto.Name);
                break;
            case nameof(ValueAddedTax):
            case nameof(Currency):
            case nameof(Product):
            default:
                return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(MasterData)} \"{request.Type}\" not allowed.");
        }
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
