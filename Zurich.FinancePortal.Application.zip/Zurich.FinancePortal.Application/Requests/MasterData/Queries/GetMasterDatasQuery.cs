﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetMasterDatasQuery : BaseRequest<GetMasterDatasQueryResult>
    {
        #region --- PROPERTIES ---

        public string Type { get; set; }

        #endregion
    }

    public sealed class GetMasterDatasQueryValidator : AbstractValidator<GetMasterDatasQuery>
    {
        #region --- CONSTRUCTORS ---

        public GetMasterDatasQueryValidator()
        {
            RuleFor(x => x.Type).NotNull().NotEmpty();
            RuleFor(x => x.Type).Must(x => MasterData.GetMasterDataTypes().Select(mdt => mdt.Name).Any(mdn => mdn.EqualsICIC(x)));
        }

        #endregion
    }

    public sealed class GetMasterDatasQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        public IEnumerable<object> MasterDatas { get; set; }

        public IEnumerable<string> Fields { get; set; }

        #endregion
    }

    public sealed class GetMasterDatasQueryHandler : BaseRequestHandler<GetMasterDatasQuery, GetMasterDatasQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetMasterDatasQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetMasterDatasQueryResult>> Handle(GetMasterDatasQuery request, CancellationToken cancellationToken)
        {
            var dtoType = Assembly.GetAssembly(typeof(MasterDataDto)).GetTypes().Where(t => !t.Equals(typeof(MasterDataDto)) && typeof(MasterDataDto).IsAssignableFrom(t)).SingleOrDefault(t => t.Name.EqualsICIC($"{request.Type}Dto"));
            var entityType = MasterData.GetMasterDataTypes().SingleOrDefault(t => t.Name.EqualsICIC(request.Type));
            var (count, result) = await MasterDataFrontEndRepository.GetMasterDatasByEntityAsync(dtoType, entityType, dtos: request.Dtos, dataSourceRequest: request.DataSourceRequest, includeCount: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromResult(new GetMasterDatasQueryResult() { Count = count, MasterDatas = result, Fields = GetMasterDataFields(entityType) });
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static IEnumerable<string> GetMasterDataFields(Type type)
        {
            return type.Name switch
            {
                nameof(BusinessUnit) => new string[] { nameof(BusinessUnitDto.Name), nameof(BusinessUnitDto.Code) },
                nameof(ChargingModelType) => new string[] { nameof(ChargingModelTypeDto.Type) },
                nameof(ChargingModel) => new string[] { nameof(ChargingModelDto.Name), nameof(ChargingModelDto.Code), nameof(ChargingModelDto.Type) },
                nameof(CostCenter) => new string[] { nameof(CostCenterDto.Code), nameof(CostCenterDto.Types) },
                nameof(CurrencyExchangeRate) => new string[] { nameof(CurrencyExchangeRate.Year), nameof(CurrencyExchangeRateDto.Month), nameof(CurrencyExchangeRateDto.From), nameof(CurrencyExchangeRateDto.To), nameof(CurrencyExchangeRateDto.Rate) },
                nameof(Customer) => new string[] { nameof(CustomerDto.Name), nameof(Customer.Function) },
                nameof(LineOfBusiness) => new string[] { nameof(LineOfBusinessDto.Name) },
                nameof(Project) => new string[] { nameof(ProjectDto.Name), nameof(ProjectDto.Type), nameof(ProjectDto.PlanningItAppsIds) },
                nameof(TypeOfService) => new string[] { nameof(TypeOfServiceDto.Name) },
                nameof(Product) => new string[] { nameof(ProductDto.Name) },
                nameof(TestingTool) => new string[] { nameof(TestingToolDto.Name) },
                nameof(CustomerFunction) => new string[] { nameof(CustomerFunction.Name) },
                _ => Array.Empty<string>()
            };
        }

        #endregion
    }
}
