﻿namespace Zurich.FinancePortal.Application;

using Domain;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using System;
using System.Linq;

public abstract class BaseMasterDataCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public int Id { get; set; }

    public string Type { get; set; }

    public MasterDataDto MasterData { get; set; }

    #endregion
}

public sealed class BaseMasterDataValidator : AbstractValidator<MasterDataDto>
{
    #region --- CONSTRUCTORS ---

    public BaseMasterDataValidator(string type = default)
    {
        RuleFor(x => x).Custom((md, vc) =>
        {
            switch (type)
            {
                case nameof(BusinessUnit):
                    var businessUnit = (BusinessUnitDto)md;
                    ValidateProperty(nameof(BusinessUnit.Name), businessUnit.Name, vc);
                    ValidateProperty(nameof(BusinessUnit.Code), businessUnit.Code, vc);
                    break;
                case nameof(ChargingModelType):
                    var chargingModelType = (ChargingModelTypeDto)md;
                    ValidateProperty(nameof(ChargingModel.Type), chargingModelType.Type, vc);
                    break;
                case nameof(ChargingModel):
                    var chargingModel = (ChargingModelDto)md;
                    ValidateProperty(nameof(ChargingModel.Name), chargingModel.Name, vc);
                    ValidateProperty(nameof(ChargingModel.Code), chargingModel.Code, vc);
                    ValidateProperty(nameof(ChargingModel.Type), chargingModel.Type, vc, isObject: true);
                    break;
                case nameof(CostCenter):
                    var costCenter = (CostCenterDto)md;
                    ValidateProperty(nameof(CostCenter.Code), costCenter.Code, vc);
                    ValidateProperty(nameof(CostCenter.Types), costCenter.Types, vc, isIenumerable: true);
                    break;
                case nameof(CurrencyExchangeRate):
                    var currencyExchangeRate = (CurrencyExchangeRateDto)md;
                    ValidateProperty(nameof(CurrencyExchangeRate.From), currencyExchangeRate.From, vc, isObject: true);
                    if (currencyExchangeRate.From != null) ValidateProperty(nameof(Currency.Id), currencyExchangeRate.From.Id, vc, isIntegerId: true);
                    ValidateProperty(nameof(CurrencyExchangeRate.To), currencyExchangeRate.To, vc, isObject: true);
                    if (currencyExchangeRate.To != null) ValidateProperty(nameof(Currency.Id), currencyExchangeRate.To.Id, vc, isIntegerId: true);
                    break;
                case nameof(Customer):
                    var customer = (CustomerDto)md;
                    ValidateProperty(nameof(Customer.Name), customer.Name, vc);
                    if (customer.Function != null) ValidateProperty(nameof(CustomerFunction.Id), customer.Function.Id, vc, isIntegerId: true);
                    break;
                case nameof(LineOfBusiness):
                    var lineOfBusiness = (LineOfBusinessDto)md;
                    ValidateProperty(nameof(LineOfBusiness.Name), lineOfBusiness.Name, vc);
                    break;
                case nameof(Project):
                    var project = (ProjectDto)md;
                    ValidateProperty(nameof(Project.Name), project.Name, vc);
                    ValidateProperty(nameof(Project.Type), project.Type, vc, isEnum: true, enumType: typeof(ProjectType));
                    if (project.PlanningItApps != null && project.PlanningItApps.Any())
                    {
                        project.PlanningItApps.Where(x => string.IsNullOrWhiteSpace(x.Id) || PlanningItAppPrefix.UNKNOWN.Equals(x.Prefix)).ForEach((x, i) => vc.AddFailure(new ValidationFailure(nameof(Project.PlanningItApps), $"Invalid {nameof(PlanningItApp)} {i + 1}: '{x.Prefix}{x.Id}' / '{x.Name}'.")));
                    }

                    break;
                case nameof(TypeOfService):
                    var typeOfService = (TypeOfServiceDto)md;
                    ValidateProperty(nameof(TypeOfService.Name), typeOfService.Name, vc);
                    break;
                case nameof(TestingTool):
                    var testingTool = (TestingToolDto)md;
                    ValidateProperty(nameof(TestingTool.Name), testingTool.Name, vc);
                    break;
                case nameof(CustomerFunction):
                    var customerFunction = (CustomerFunctionDto)md;
                    ValidateProperty(nameof(CustomerFunction.Name), customerFunction.Name, vc);
                    break;
                case nameof(Product):
                case nameof(ValueAddedTax):
                case nameof(Currency):
                    break;
                default:
                    throw new NotImplementedException();
            }
        });
    }

    #endregion

    #region --- PRIVATE METHODS ---

    private static void ValidateProperty(string name, object value, ValidationContext<MasterDataDto> validationContext, bool isObject = false, bool isIntegerId = false, bool isIenumerable = false, bool isEnum = false, Type enumType = default)
    {
        if (isIntegerId)
        {
            var v = (int?)value;
            if (!v.HasValue || v.Value <= 0) validationContext.AddFailure(new ValidationFailure(name, "Must be greater than 0."));
        }
        else if (isObject)
        {
            if (value == null) validationContext.AddFailure(new ValidationFailure(name, "Cannot be null."));
        }
        else if (isIenumerable)
        {
            if (value == null || ((int)value.GetType().GetProperty(nameof(Enumerable.Count)).GetValue(value)).Equals(0)) validationContext.AddFailure(new ValidationFailure(name, "Cannot be null or empty."));
        }
        else if (isEnum)
        {
            if (!Enum.GetNames(enumType).Any(x => x.EqualsICIC(value?.ToString()))) validationContext.AddFailure(new ValidationFailure(name, $"Must exists in {nameof(Enum)} {enumType.Name}."));
        }
        else
        {
            if (string.IsNullOrWhiteSpace(value?.ToString())) validationContext.AddFailure(new ValidationFailure(name, "Cannot be null or empty."));
        }
    }

    #endregion
}
