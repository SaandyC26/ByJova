﻿namespace Zurich.FinancePortal.Application
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System;

    public abstract class MasterDataDto
    {
        #region --- PROPERTIES ---

        public int Id { get; set; }

        #endregion
    }

    public class MasterDataDtoConverter : CustomCreationConverter<MasterDataDto>
    {
        #region -- PROPERTIES ---

        private readonly string _content;

        #endregion

        #region --- CONSTRUCTORS ---

        public MasterDataDtoConverter(string content)
        {
            _content = content;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public override MasterDataDto Create(Type objectType)
        {
            if (objectType.Equals(typeof(MasterDataDto)))
            {
                var type = Type.GetType($"{nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Application)}.{JsonConvert.DeserializeAnonymousType(_content, new { Type = string.Empty }).Type}Dto", true, true);
                if (type == null) return null;
                return (MasterDataDto)Activator.CreateInstance(type);
            }

            return Activator.CreateInstance(objectType) as MasterDataDto;
        }

        #endregion
    }
}
