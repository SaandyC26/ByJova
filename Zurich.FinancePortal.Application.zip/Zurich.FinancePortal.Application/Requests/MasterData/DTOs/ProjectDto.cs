﻿namespace Zurich.FinancePortal.Application;

using Domain;
using System.Collections.Generic;
using System.Linq;

public sealed class ProjectDto : MasterDataDto
{
    #region --- PROPERTIES ---

    private string _name;
    public string Name { get => _name; set => _name = value?.Trim(); }

    public ProjectType Type { get; set; }

    public IEnumerable<PlanningItAppDto> PlanningItApps { get; set; }

    public string PlanningItAppsIds => string.Join(", ", PlanningItApps?.Select(x => $"{x.Prefix}{BasePlanningItAppPrefixJsonConverter.PrefixSeparator}{x.Id}") ?? Array.Empty<string>());

    public string PlanningItAppsNames => string.Join(", ", PlanningItApps?.Select(x => x.Name) ?? Array.Empty<string>());

    #endregion
}
