﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using System.Collections.Generic;

    public sealed class CostCenterDto : MasterDataDto
    {
        #region --- PROPERTIES ---

        private string _code;
        public string Code { get => _code; set => _code = value?.Trim(); }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<CostCenterType> Types { get; set; }

        #endregion
    }
}
