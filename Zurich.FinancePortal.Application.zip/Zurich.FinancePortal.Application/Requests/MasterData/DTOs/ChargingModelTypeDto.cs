﻿namespace Zurich.FinancePortal.Application
{
    public sealed class ChargingModelTypeDto : MasterDataDto
    {
        #region --- PROPERTIES ---

        private string _type;
        public string Type { get => _type; set => _type = value?.Trim(); }

        #endregion
    }
}
