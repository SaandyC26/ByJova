﻿namespace Zurich.FinancePortal.Application
{
    public class ValueAddedTaxDto : MasterDataDto
    {
        #region --- PROPERTIES ---

        private string _country;
        public string Country { get => _country; set => _country = value?.Trim(); }

        public decimal PercentageAmount { get; set; }

        #endregion
    }
}
