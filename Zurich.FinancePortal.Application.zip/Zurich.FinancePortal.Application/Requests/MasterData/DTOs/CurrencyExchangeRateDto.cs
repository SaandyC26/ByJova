﻿namespace Zurich.FinancePortal.Application;

public sealed class CurrencyExchangeRateDto : MasterDataDto
{
    #region --- PROPERTIES ---

    public decimal Rate { get; set; }

    public int Year { get; set; }

    public string Month { get; set; }

    #endregion

    #region --- REFERENCES ---

    public CurrencyDto From { get; set; }

    public CurrencyDto To { get; set; }

    #endregion
}
