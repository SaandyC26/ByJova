﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetCurrentUserProfileQuery : BaseRequest<GetCurrentUserProfileQueryResult>
    { }

    public sealed class GetCurrentUserProfileQueryResult
    {
        #region --- REFERENCES ---

        public UserDto User { get; set; }

        #endregion
    }

    public sealed class GetCurrentUserProfileQueryHandler : BaseRequestHandler<GetCurrentUserProfileQuery, GetCurrentUserProfileQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetCurrentUserProfileQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetCurrentUserProfileQueryResult>> Handle(GetCurrentUserProfileQuery request, CancellationToken cancellationToken)
        {
            var user = await UserRepository.GetUserBySAMAccountNameAsync(CurrentUserService.Username, asNoTracking: true, includeRoles: true, includeGridPreferences: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (user == null) return RequestResult.FromError<GetCurrentUserProfileQueryResult>(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.AdAccount.SAMAccountName)} \"{CurrentUserService.Username}\" not found.");
            var releaseNotes = await UserRepository.GetLastReleaseNotesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            var UserDto = Mapper.Map(user, UserAutoMapper.GetMapperParameters<User, UserDto>(dtos: new string[] { nameof(Role), nameof(Permission) }));
            UserDto.DisplayName = CurrentUserService.DisplayName;
            UserDto.EmployeeId = CurrentUserService.EmployeeId;
            UserDto.Mail = CurrentUserService.Mail;
            UserDto.Domain = CurrentUserService.Domain;
            if (string.IsNullOrWhiteSpace(UserDto.LastSeenVersion) || !UserDto.LastSeenVersion.Equals(releaseNotes.Version)) UserDto.ReleaseNotes = releaseNotes.Changes;
            return RequestResult.FromResult(new GetCurrentUserProfileQueryResult() { User = UserDto });
        }

        #endregion
    }
}
