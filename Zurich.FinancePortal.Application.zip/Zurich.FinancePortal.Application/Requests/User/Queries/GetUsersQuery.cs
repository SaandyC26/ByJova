﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetUsersQuery : BaseRequest<GetUsersQueryResult>
    { }

    public sealed class GetUsersQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<UserDto> Users { get; set; }

        #endregion
    }

    public sealed class GetUsersQueryHandler : BaseRequestHandler<GetUsersQuery, GetUsersQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetUsersQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetUsersQueryResult>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
        {
            var (count, users) = await UserRepository.GetUsersAsync(asNoTracking: true, includeRoles: request.Dtos?.Any(x => x.EqualsICIC(nameof(Role))) ?? false, includeGroups: request.Dtos?.Any(x => x.EqualsICIC(nameof(Group))) ?? false, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromResult(new GetUsersQueryResult() { Count = count, Users = Mapper.Map(users, UserAutoMapper.GetMapperParameters<IEnumerable<User>, IEnumerable<UserDto>>(dtos: request.Dtos)) });
        }

        #endregion
    }
}
