﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetReleasesNotesQuery : BaseRequest<GetReleasesNotesQueryResult>
    { }

    public sealed class GetReleasesNotesQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<ReleaseNotesDto> Results { get; set; }

        #endregion
    }

    public sealed class GetReleasesNotesQueryHandler : BaseRequestHandler<GetReleasesNotesQuery, GetReleasesNotesQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetReleasesNotesQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetReleasesNotesQueryResult>> Handle(GetReleasesNotesQuery request, CancellationToken cancellationToken)
        {
            var (count, results) = await UserRepository.GetReleasesNotesAsync(asNoTracking: true, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromResult(new GetReleasesNotesQueryResult() { Count = count, Results = Mapper.Map<IEnumerable<ReleaseNotes>, IEnumerable<ReleaseNotesDto>>(results) });
        }

        #endregion
    }
}
