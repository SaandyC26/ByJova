﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class CreateUserCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public UserDto User { get; set; }

    #endregion
}

public sealed class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
{
    #region --- CONSTRUCTORS ---

    public CreateUserCommandValidator()
    {
        RuleFor(x => x.User).NotNull();
        RuleFor(x => x.User).SetValidator(new BaseUserRequestValidator()).Unless(x => x.User == null);
    }

    #endregion
}

public sealed class CreateUserCommandHandler : BaseRequestHandler<CreateUserCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public CreateUserCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    [SuppressMessage("Critical Code Smell", "S3776: Refactor this method to reduce its Cognitive Complexity from 21 to the 15 allowed.", Justification = "N/A")]
    public async override Task<RequestResult<Unit>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ManageUser, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Check SAMAccountName
        var user = await UserRepository.GetUserBySAMAccountNameAsync(request.User.SAMAccountName, includeDeleted: true, includeRoles: true, includeGroups: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (user != null && !user.IsDeleted) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(User)} with {nameof(User.AdAccount.SAMAccountName)} \"{request.User.SAMAccountName}\" already exists.");
        // Check Name
        var users = (await UserRepository.GetUsersAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
        if (users.Any(u => u.Name.EqualsICIC(request.User.Name))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(User)} with {nameof(User.Name)} \"{request.User.Name}\" already exists.");
        // Create User
        user = user != null ? user.SetUnDeleted().UpdateName(request.User.Name).UpdateAdAccount(new AdAccount(request.User.SAMAccountName)) : new User(request.User.Name, new AdAccount(request.User.SAMAccountName));
        // Update Roles
        if (request.User.Roles != null)
        {
            var roles = (await RoleRepository.GetRolesAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            // Add
            foreach (var roleId in request.User.Roles.Select(y => y.Id))
            {
                var role = roles.SingleOrDefault(r => r.Id.Equals(roleId));
                if (role == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Role)} with {nameof(Role.Id)} \"{roleId}\" not found.");
                if (role.Name.EqualsICIC(Role.SuperAdminName)) continue;
                user.AddRole(role);
            }
            // Remove
            foreach (var role in user.Roles.Where(r => r.Name.Equals(Role.SuperAdminName) && !request.User.Roles.Any(r2 => r2.Id.Equals(r.Id))))
            {
                user.RemoveRole(role.Id);
            }
        }
        // Update Groups
        if (request.User.Groups != null)
        {
            var groups = (await GroupRepository.GetGroupsAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            // Add
            foreach (var groupId in request.User.Groups.Select(y => y.Id))
            {
                var group = groups.SingleOrDefault(x => x.Id.Equals(groupId));
                if (group == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Group)} with {nameof(Group.Id)} \"{groupId}\" not found.");
                user.AddGroup(group);
            }
        }
        // Add User
        if (user.Id.Equals(0)) UserRepository.AddUser(user);
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
