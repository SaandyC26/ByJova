﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class EditCurrentUserProfileCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public UserGridPreferencesDto GridPreferences { get; set; }

        #endregion
    }

    public sealed class EditCurrentUserProfileCommandHandler : BaseRequestHandler<EditCurrentUserProfileCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public EditCurrentUserProfileCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(EditCurrentUserProfileCommand request, CancellationToken cancellationToken)
        {
            if (request.GridPreferences == null) return RequestResult.FromSuccess();
            // Get User
            var user = await UserRepository.GetUserBySAMAccountNameAsync(CurrentUserService.Username, includeGridPreferences: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.AdAccount.SAMAccountName)} \"{CurrentUserService.Username}\" not found.");
            // Update User GridPreferences
            user.SetGridPreferences(new UserGridPreferences(revenues: request.GridPreferences.Revenues));
            // Save Changes
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
