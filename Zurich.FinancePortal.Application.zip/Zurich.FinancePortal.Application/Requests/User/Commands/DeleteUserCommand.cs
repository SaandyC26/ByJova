﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class DeleteUserCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public int Id { get; set; }

        #endregion
    }

    public sealed class DeleteUserCommandValidator : AbstractValidator<DeleteUserCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteUserCommandValidator()
        {
            RuleFor(x => x.Id).GreaterThan(0);
        }

        #endregion
    }

    public sealed class DeleteUserCommandHandler : BaseRequestHandler<DeleteUserCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteUserCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            var cu = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!await HasPermissions(Constants.Permission_ManageUser, currentUser: cu, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Check Id
            var user = await UserRepository.GetUserByIdAsync(request.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{request.Id}\" not found.");
            // Check Current User
            if (user.Id.Equals(cu.Id)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"Cannot delete your own {nameof(User)} with {nameof(User.Id)} \"{request.Id}\".");
            // Remove Roles
            foreach (var role in user.Roles) user.RemoveRole(role.Id);
            // Remove User
            user.SetDeleted();
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
