﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class EditUserCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public UserDto User { get; set; }

    #endregion
}

public sealed class EditUserCommandValidator : AbstractValidator<EditUserCommand>
{
    #region --- CONSTRUCTORS ---

    public EditUserCommandValidator()
    {
        RuleFor(x => x.User).NotNull();
        RuleFor(x => x.User.Id).GreaterThan(0).Unless(x => x.User == null);
        RuleFor(x => x.User).SetValidator(new BaseUserRequestValidator(false, false)).Unless(x => x.User == null);
    }

    #endregion
}

public sealed class EditUserCommandHandler : BaseRequestHandler<EditUserCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public EditUserCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    [SuppressMessage("Critical Code Smell", "S3776: Refactor this method to reduce its Cognitive Complexity from 21 to the 15 allowed.", Justification = "N/A")]
    public async override Task<RequestResult<Unit>> Handle(EditUserCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        var cu = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        if (!await HasPermissions(Constants.Permission_ManageUser, currentUser: cu, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Get User
        var user = await UserRepository.GetUserByIdAsync(request.User.Id, includeRoles: true, includeGroups: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{request.User.Id}\" not found.");
        // Check Current User
        if (cu.Id.Equals(request.User.Id) && !user.AdAccount.SAMAccountName.EqualsICIC(request.User.SAMAccountName))
        {
            return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"Cannot edit the {nameof(User.AdAccount.SAMAccountName)} of your own {nameof(User)} with {nameof(User.Id)} \"{request.User.Id}\".");
        }
        // Check SAMAccountName
        if (!string.IsNullOrWhiteSpace(request.User.SAMAccountName))
        {
            var userAux = await UserRepository.GetUserBySAMAccountNameAsync(request.User.SAMAccountName, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (userAux != null && !userAux.Id.Equals(request.User.Id)) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(User)} with {nameof(User.AdAccount.SAMAccountName)} \"{request.User.SAMAccountName}\" already exists.");
            // Update AdAccount Property
            user.UpdateAdAccount(new AdAccount(request.User.SAMAccountName));
        }
        // Check Name
        if (!string.IsNullOrWhiteSpace(request.User.Name))
        {
            var users = (await UserRepository.GetUsersAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            if (users.Any(u => u.Name.EqualsICIC(request.User.Name) && !u.Id.Equals(request.User.Id))) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(User)} with {nameof(User.Name)} \"{request.User.Name}\" already exists.");
            // Update AdAccount Property
            user.UpdateName(request.User.Name);
        }
        // Update Roles
        if (request.User.Roles != null)
        {
            var roles = (await RoleRepository.GetRolesAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            // Add
            foreach (var roleId in request.User.Roles.Select(x => x.Id))
            {
                var role = roles.SingleOrDefault(x => x.Id.Equals(roleId));
                if (role == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Role)} with {nameof(Role.Id)} \"{roleId}\" not found.");
                if (role.Name.EqualsICIC(Role.SuperAdminName)) continue;
                user.AddRole(role);
            }
            // Remove
            foreach (var roleId in user.Roles.Where(x => !x.Name.EqualsICIC(Role.SuperAdminName) && !request.User.Roles.Any(y => y.Id.Equals(x.Id))).Select(x => x.Id))
            {
                user.RemoveRole(roleId);
            }
        }
        // Update Users
        if (request.User.Groups != null)
        {
            var groups = (await GroupRepository.GetGroupsAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            // Add
            foreach (var groupId in request.User.Groups.Select(x => x.Id))
            {
                var group = groups.SingleOrDefault(x => x.Id.Equals(groupId));
                if (group == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Group)} with {nameof(Group.Id)} \"{groupId}\" not found.");
                user.AddGroup(group);
            }
            // Remove
            foreach (var groupId in user.Groups.Where(x => !request.User.Groups.Any(y => y.Id.Equals(x.Id))).Select(x => x.Id))
            {
                user.RemoveGroup(groupId);
            }
        }
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
