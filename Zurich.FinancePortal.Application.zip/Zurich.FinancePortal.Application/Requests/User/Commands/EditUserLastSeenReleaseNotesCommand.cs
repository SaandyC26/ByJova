﻿namespace Zurich.FinancePortal.Application
{
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using DevOps.Application;

    public sealed class EditUserLastSeenReleaseNotesCommand : BaseRequest<Unit>
    { }

    public sealed class EditUserLastSeenReleaseNotesCommandHandler : BaseRequestHandler<EditUserLastSeenReleaseNotesCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public EditUserLastSeenReleaseNotesCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(EditUserLastSeenReleaseNotesCommand request, CancellationToken cancellationToken)
        {
            var releaseNotes = await UserRepository.GetLastReleaseNotesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            var user = await UserRepository.GetUserBySAMAccountNameAsync(CurrentUserService.Username, cancellationToken: cancellationToken).ConfigureAwait(false);
            user.SetLastSeenReleaseNotes(releaseNotes);
            await DbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}