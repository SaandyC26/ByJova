﻿namespace Zurich.FinancePortal.Application;

using FluentValidation;

public sealed class BaseUserRequestValidator : AbstractValidator<UserDto>
{
    #region --- CONSTRUCTORS ---

    public BaseUserRequestValidator() : this(true, true) { }

    public BaseUserRequestValidator(bool sAMAccountName, bool name)
    {
        RuleFor(u => u).NotNull();
        if (sAMAccountName) RuleFor(u => u.SAMAccountName).NotEmpty().Unless(u => u == null);
        if (name) RuleFor(u => u.Name).NotEmpty().Unless(u => u == null);
        RuleForEach(u => u.Roles).ChildRules(users =>
        {
            users.RuleFor(r => r).NotNull();
            users.RuleFor(r => r.Id).NotEqual(0);
        }).Unless(u => u == null || u.Roles == null);
        RuleForEach(u => u.Groups).ChildRules(users =>
        {
            users.RuleFor(x => x).NotNull();
            users.RuleFor(x => x.Id).NotEqual(0);
        }).Unless(u => u == null || u.Groups == null);
    }

    #endregion
}
