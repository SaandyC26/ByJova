﻿namespace Zurich.FinancePortal.Application
{
    public sealed class UserGridPreferencesDto
    {
        #region --- PROPERTIES ---

        public string Revenues { get; set; }

        #endregion
    }
}
