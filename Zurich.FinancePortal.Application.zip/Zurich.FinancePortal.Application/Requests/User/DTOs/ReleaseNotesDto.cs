﻿namespace Zurich.FinancePortal.Application
{
    public sealed class ReleaseNotesDto
    {
        #region --- PROPERTIES ---

        public int Major { get; set; }

        public int Minor { get; set; }

        public int Revision { get; set; }

        public string Version => $"{Major}.{Minor}.{Revision}";

        public string Changes { get; set; }

        #endregion
    }
}
