﻿namespace Zurich.FinancePortal.Application;

using System;
using System.Collections.Generic;

public sealed class UserDto
{
    #region --- PROPERTIES ---

    public int Id { get; set; }

    private string _name;
    public string Name { get => _name; set => _name = value?.Trim(); }

    private string _sAMAccountName;
    public string SAMAccountName { get => _sAMAccountName; set => _sAMAccountName = value?.Trim(); }

    private string _displayName;
    public string DisplayName { get => _displayName; set => _displayName = value?.Trim(); }

    private string _mail;
    public string Mail { get => _mail; set => _mail = value?.Trim(); }

    private string _domain;
    public string Domain { get => _domain; set => _domain = value?.Trim(); }

    private string _employeeId;
    public string EmployeeId { get => _employeeId; set => _employeeId = value?.Trim(); }

    public string LastSeenVersion { get; set; }

    public string ReleaseNotes { get; set; }

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<RoleDto> Roles { get; set; } = Array.Empty<RoleDto>();

    public IEnumerable<GroupDto> Groups { get; set; } = Array.Empty<GroupDto>();

    public IEnumerable<PermissionDto> Permissions { get; set; } = Array.Empty<PermissionDto>();

    public UserGridPreferencesDto GridPreferences { get; set; }

    #endregion
}
