﻿namespace Zurich.FinancePortal.Application
{
    public sealed class PermissionDto
    {
        #region --- PROPERTIES ---

        public int Id { get; set; }

        private string _name;
        public string Name { get => _name; set => _name = value?.Trim(); }

        private string _description;
        public string Description { get => _description; set => _description = value?.Trim(); }

        #endregion
    }
}
