﻿namespace Zurich.FinancePortal.Application
{
    using System;
    using System.Collections.Generic;

    public sealed class RoleDto
    {
        #region --- PROPERTIES ---

        public int Id { get; set; }

        private string _name;
        public string Name { get => _name; set => _name = value?.Trim(); }

        private string _description;
        public string Description { get => _description; set => _description = value?.Trim(); }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<UserDto> Users { get; set; } = Array.Empty<UserDto>();

        public IEnumerable<PermissionDto> Permissions { get; set; } = Array.Empty<PermissionDto>();

        #endregion
    }
}
