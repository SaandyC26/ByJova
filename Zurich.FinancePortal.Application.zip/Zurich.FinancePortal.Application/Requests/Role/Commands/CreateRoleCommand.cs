﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class CreateRoleCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public RoleDto Role { get; set; }

        #endregion
    }

    public sealed class CreateRoleCommandValidator : AbstractValidator<CreateRoleCommand>
    {
        #region --- CONSTRUCTORS ---

        public CreateRoleCommandValidator()
        {
            RuleFor(x => x.Role).NotNull();
            RuleFor(x => x.Role).SetValidator(new BaseRoleRequestValidator()).Unless(x => x.Role == null);
        }

        #endregion
    }

    public sealed class CreateRoleCommandHandler : BaseRequestHandler<CreateRoleCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public CreateRoleCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_ManageRole, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Check Name
            var role = (await RoleRepository.GetRolesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefault(r => r.Name.EqualsICIC(request.Role.Name));
            if (role != null) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(Role)} with {nameof(Role.Name)} \"{request.Role.Name}\" already exists.");
            // Create Role
            role = new Role(request.Role.Name, description: request.Role.Description);
            //// Add Users
            //if (request.Role.Users != null)
            //{
            //    var users = (await UserRepository.GetUsersAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            //    foreach (var x in request.Role.Users.Select(y => y.Id))
            //    {
            //        var user = users.SingleOrDefault(u => u.Id.Equals(x));
            //        if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{x}\" not found.");
            //        role.AddUser(user);
            //    }
            //}
            // Add Permissions
            if (request.Role.Permissions != null)
            {
                var permissions = (await RoleRepository.GetPermissionsAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
                foreach (var x in request.Role.Permissions.Select(y => y.Id))
                {
                    var permission = permissions.SingleOrDefault(p => p.Id.Equals(x));
                    if (permission == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Permission)} with {nameof(Permission.Id)} \"{x}\" not found.");
                    role.AddPermission(permission);
                }
            }
            // Add Role
            RoleRepository.AddRole(role);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
