﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class DeleteRoleCommand : BaseRequest<Unit>
    {
        #region --- PROPERTIES ---

        public int Id { get; set; }

        #endregion
    }

    public sealed class DeleteRoleCommandValidator : AbstractValidator<DeleteRoleCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteRoleCommandValidator()
        {
            RuleFor(x => x.Id).GreaterThan(0);
        }

        #endregion
    }

    public sealed class DeleteRoleCommandHandler : BaseRequestHandler<DeleteRoleCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteRoleCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(DeleteRoleCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_ManageRole, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Check Id
            var role = await RoleRepository.GetRoleByIdAsync(request.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (role == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Role)} with {nameof(Role.Id)} \"{request.Id}\" not found.");
            if (role.Name.EqualsICIC(Role.SuperAdminName)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(Role)} with {nameof(Role.Name)} \"{Role.SuperAdminName}\" cannot be deleted.");
            // Remove Role
            RoleRepository.RemoveRole(role);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
