﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class EditRoleCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public RoleDto Role { get; set; }

        #endregion
    }

    public sealed class EditRoleCommandValidator : AbstractValidator<EditRoleCommand>
    {
        #region --- CONSTRUCTORS ---

        public EditRoleCommandValidator()
        {
            RuleFor(x => x.Role).NotNull();
            RuleFor(x => x.Role.Id).GreaterThan(0).Unless(x => x.Role == null);
            RuleFor(x => x.Role).SetValidator(new BaseRoleRequestValidator()).Unless(x => x.Role == null);
        }

        #endregion
    }

    public sealed class EditRoleCommandHandler : BaseRequestHandler<EditRoleCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public EditRoleCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        [SuppressMessage("Critical Code Smell", "S3776: Refactor this method to reduce its Cognitive Complexity from 21 to the 15 allowed.", Justification = "N/A")]
        public async override Task<RequestResult<Unit>> Handle(EditRoleCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_ManageRole, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Get Role
            var role = await RoleRepository.GetRoleByIdAsync(request.Role.Id, includeUsers: true, includePermissions: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (role == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Role)} with {nameof(Role.Id)} \"{request.Role.Id}\" not found.");
            if (role.Name.EqualsICIC(Role.SuperAdminName)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{nameof(Role)} with {nameof(Role.Name)} \"{Role.SuperAdminName}\" cannot be edited.");
            // Check Name
            var newRole = (await RoleRepository.GetRolesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefault(r => r.Name.EqualsICIC(request.Role.Name));
            if (newRole != null && !newRole.Id.Equals(request.Role.Id)) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(Role)} with {nameof(Role.Name)} \"{request.Role.Name}\" already exists.");
            // Update Properties
            role.UpdateName(request.Role.Name);
            role.Description = request.Role.Description;
            //// Update Users
            //if (request.Role.Users != null)
            //{
            //    var users = (await UserRepository.GetUsersAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            //    // Add
            //    foreach (var x in request.Role.Users.Select(y => y.Id))
            //    {
            //        var user = users.SingleOrDefault(u => u.Id.Equals(x));
            //        if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{x}\" not found.");
            //        role.AddUser(user);
            //    }
            //    // Remove
            //    foreach (var user in role.Users.Where(u => !request.Role.Users.Any(u2 => u2.Id.Equals(u.Id))))
            //    {
            //        role.RemoveUser(user.Id);
            //    }
            //}
            // Update Permissions
            if (request.Role.Permissions != null)
            {
                var permissions = (await RoleRepository.GetPermissionsAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
                // Add
                foreach (var x in request.Role.Permissions.Select(y => y.Id))
                {
                    var permission = permissions.SingleOrDefault(p => p.Id.Equals(x));
                    if (permission == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Permission)} with {nameof(Permission.Id)} \"{x}\" not found.");
                    role.AddPermission(permission);
                }
                // Remove
                foreach (var permission in role.Permissions.Where(p => !request.Role.Permissions.Any(p2 => p2.Id.Equals(p.Id))))
                {
                    role.RemovePermission(permission.Id);
                }
            }
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
