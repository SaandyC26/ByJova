﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using FluentValidation;
    using System;

    public sealed class BaseRoleRequestValidator : AbstractValidator<RoleDto>
    {
        #region --- CONSTRUCTORS ---

        public BaseRoleRequestValidator()
        {
            RuleFor(r => r).NotNull();
            RuleFor(r => r.Name).NotNull().NotEmpty().NotEqual(Role.SuperAdminName, StringComparer.InvariantCultureIgnoreCase).Unless(r => r == null);
            RuleForEach(r => r.Users).ChildRules(users =>
            {
                users.RuleFor(u => u).NotNull();
                users.RuleFor(u => u.Id).NotEqual(0);
            }).Unless(r => r == null || r.Users == null);
            RuleForEach(r => r.Permissions).ChildRules(users =>
            {
                users.RuleFor(p => p).NotNull();
                users.RuleFor(p => p.Id).NotEqual(0);
            }).Unless(r => r == null || r.Permissions == null);
        }

        #endregion
    }
}
