﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetRolesQuery : BaseRequest<GetRolesQueryResult>
    { }

    public sealed class GetRolesQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<RoleDto> Roles { get; set; }

        #endregion
    }

    public sealed class GetRolesQueryHandler : BaseRequestHandler<GetRolesQuery, GetRolesQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetRolesQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetRolesQueryResult>> Handle(GetRolesQuery request, CancellationToken cancellationToken)
        {
            // Add !IsSuperAdmin Filter
            if (request.DataSourceRequest == null) request.DataSourceRequest = new DataSourceRequest();
            if (request.DataSourceRequest.Filter == null) request.DataSourceRequest.Filter = new Filter() { Logic = FilterLogic.and, Filters = Array.Empty<Filter>() };
            request.DataSourceRequest.Filter.Filters = request.DataSourceRequest.Filter.Filters.Concat(new Filter[] { new Filter() { Field = nameof(Role.IsSuperAdmin), Logic = FilterLogic.and, Operator = FilterOperator.eq, Value = false } }).ToArray();
            // Query
            var (count, roles) = await RoleRepository.GetRolesAsync(asNoTracking: true, includeUsers: request.Dtos?.Any(x => x.EqualsICIC(nameof(User))) ?? false, includePermissions: request.Dtos?.Any(x => x.EqualsICIC(nameof(Permission))) ?? false, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromResult(new GetRolesQueryResult() { Count = count, Roles = Mapper.Map(roles, RoleAutoMapper.GetMapperParameters<IEnumerable<Role>, IEnumerable<RoleDto>>(request.Dtos)) });
        }

        #endregion
    }
}
