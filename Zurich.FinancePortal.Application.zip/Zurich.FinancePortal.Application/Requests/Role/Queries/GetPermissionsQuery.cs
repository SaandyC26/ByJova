﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetPermissionsQuery : BaseRequest<GetPermissionsQueryResult>
    { }

    public sealed class GetPermissionsQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<PermissionDto> Permissions { get; set; }

        #endregion
    }

    public sealed class GetPermissionsQueryHandler : BaseRequestHandler<GetPermissionsQuery, GetPermissionsQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetPermissionsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetPermissionsQueryResult>> Handle(GetPermissionsQuery request, CancellationToken cancellationToken)
        {
            var (count, permissions) = await RoleRepository.GetPermissionsAsync(asNoTracking: true, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromResult(new GetPermissionsQueryResult() { Count = count, Permissions = Mapper.Map<IEnumerable<Permission>, IEnumerable<PermissionDto>>(permissions) });
        }

        #endregion
    }
}
