﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Domain;

public class GetEnumValuesQuery : BaseRequest<GetEnumValuesQueryResult>
{
    #region --- PROPERTIES ---

    public string Type { get; set; }

    internal Type EnumType { get; set; }

    #endregion

    #region --- METHODS ---

    internal Type SetEnumType()
    {
        EnumType ??= System.Type.GetType($"{nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Domain)}.{Type}, {nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Domain)}", throwOnError: false, ignoreCase: true);

        return EnumType;
    }

    #endregion
}

public sealed class GetEnumValuesQueryValidator : AbstractValidator<GetEnumValuesQuery>
{
    #region --- CONSTRUCTORS ---

    public GetEnumValuesQueryValidator()
    {
        RuleFor(x => x.Type).NotNull().NotEmpty();
        RuleFor(x => x.Type).Must((x, y) =>
        {
            return x.SetEnumType() is not null;
        });
    }

    #endregion
}

public sealed class GetEnumValuesQueryResult
{
    #region --- PROPERTIES ---

    public int Count { get; set; }

    public IEnumerable<string> Values { get; set; }

    #endregion
}

public sealed class GetEnumValuesQueryHandler : BaseRequestHandler<GetEnumValuesQuery, GetEnumValuesQueryResult>
{
    #region --- CONSTRUCTORS ---

    public GetEnumValuesQueryHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public override Task<RequestResult<GetEnumValuesQueryResult>> Handle(GetEnumValuesQuery request, CancellationToken cancellationToken)
    {
        var result = new List<string>();
        foreach (var x in Enum.GetValues(request.SetEnumType()))
        {
            if ((int)x >= 0)
            {
                switch (request.Type)
                {
                    case nameof(PlanningItAppPrefix):
                        result.Add($"{x}{BasePlanningItAppPrefixJsonConverter.PrefixSeparator}");
                        break;
                    default:
                        result.Add(x.ToString());
                        break;
                }
            }
        }

        return Task.FromResult(RequestResult.FromResult(new GetEnumValuesQueryResult() { Count = result.Count, Values = result }));
    }

    #endregion
}
