﻿namespace Zurich.FinancePortal.Application;

using Domain;

public sealed class PlanningItAppDto
{
    #region --- PROPERTIES ---

    [System.Text.Json.Serialization.JsonConverter(typeof(SystemPlanningItAppPrefixJsonConverter))]
    [Newtonsoft.Json.JsonConverter(typeof(NewtonsoftPlanningItAppPrefixJsonConverter))]
    public PlanningItAppPrefix Prefix { get; set; }

    public string Id { get; set; }

    public string Name { get; set; }

    #endregion
}