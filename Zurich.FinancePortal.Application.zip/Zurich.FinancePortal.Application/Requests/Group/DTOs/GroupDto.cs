﻿namespace Zurich.FinancePortal.Application;

using System;
using System.Collections.Generic;

public sealed class GroupDto
{
    #region --- PROPERTIES ---

    public int Id { get; set; }

    private string _name;
    public string Name { get => _name?.Trim(); set => _name = value?.Trim(); }

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<UserDto> Users { get; set; } = Array.Empty<UserDto>();

    #endregion
}