﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

public sealed class DeleteGroupCommand : BaseRequest<Unit>
{
    #region --- PROPERTIES ---

    public int Id { get; set; }

    #endregion
}

public sealed class DeleteGroupCommandValidator : AbstractValidator<DeleteGroupCommand>
{
    #region --- CONSTRUCTORS ---

    public DeleteGroupCommandValidator()
    {
        RuleFor(x => x.Id).GreaterThan(0);
    }

    #endregion
}

public sealed class DeleteGroupCommandHandler : BaseRequestHandler<DeleteGroupCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public DeleteGroupCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<Unit>> Handle(DeleteGroupCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ManageGroup, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Check Id
        var group = await GroupRepository.GetGroupByIdAsync(request.Id, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (group == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Group)} with {nameof(Group.Id)} \"{request.Id}\" not found.");
        // Check being used
        if (await GroupRepository.IsBeingUsedAsync(group, cancellationToken: cancellationToken).ConfigureAwait(false))
        {
            return RequestResult.FromError(BaseRequestResult.ERROR_REFERENCED, $"{nameof(Group)} with {nameof(Group.Id)} {request.Id} is being referenced.");
        }
        // Remove Group
        GroupRepository.RemoveGroup(group);
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
