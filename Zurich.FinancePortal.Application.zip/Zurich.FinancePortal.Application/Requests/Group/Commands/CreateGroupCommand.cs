﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class CreateGroupCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public GroupDto Group { get; set; }

    #endregion
}

public sealed class CreateGroupCommandValidator : AbstractValidator<CreateGroupCommand>
{
    #region --- CONSTRUCTORS ---

    public CreateGroupCommandValidator()
    {
        RuleFor(x => x.Group).NotNull();
        RuleFor(x => x.Group).SetValidator(new BaseGroupRequestValidator()).Unless(x => x.Group == null);
    }

    #endregion
}

public sealed class CreateGroupCommandHandler : BaseRequestHandler<CreateGroupCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public CreateGroupCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<Unit>> Handle(CreateGroupCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ManageGroup, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Check Name Group
        var group = await GroupRepository.GetGroupByNameAsync(request.Group.Name, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (group != null) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(Group)} with {nameof(Group.Name)} \"{request.Group.Name}\" already exists.");
        // Create Group
        group = new Group(request.Group.Name);
        // Add Users
        if (request.Group.Users != null)
        {
            var users = (await UserRepository.GetUsersAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            foreach (var x in request.Group.Users.Select(y => y.Id))
            {
                var user = users.SingleOrDefault(u => u.Id.Equals(x));
                if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{x}\" not found.");
                group.AddUser(user);
            }
        }

        // Add Group
        GroupRepository.AddGroup(group);
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
