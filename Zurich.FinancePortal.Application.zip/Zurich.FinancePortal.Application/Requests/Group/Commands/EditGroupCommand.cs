﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class EditGroupCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public GroupDto Group { get; set; }

    #endregion
}

public sealed class EditGroupCommandValidator : AbstractValidator<EditGroupCommand>
{
    #region --- CONSTRUCTORS ---

    public EditGroupCommandValidator()
    {
        RuleFor(x => x.Group).NotNull();
        RuleFor(x => x.Group.Id).GreaterThan(0).Unless(x => x.Group == null);
        RuleFor(x => x.Group).SetValidator(new BaseGroupRequestValidator()).Unless(x => x.Group == null);
    }

    #endregion
}

public sealed class EditGroupCommandHandler : BaseRequestHandler<EditGroupCommand, Unit>
{
    #region --- CONSTRUCTORS ---

    public EditGroupCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    [SuppressMessage("Critical Code Smell", "S3776: Refactor this method to reduce its Cognitive Complexity from 21 to the 15 allowed.", Justification = "N/A")]
    public async override Task<RequestResult<Unit>> Handle(EditGroupCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ManageGroup, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Get Group
        var group = await GroupRepository.GetGroupByIdAsync(request.Group.Id, includeUsers: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (group == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(Group)} with {nameof(Group.Id)} \"{request.Group.Id}\" not found.");
        // Check Name
        var newGroup = await GroupRepository.GetGroupByNameAsync(request.Group.Name, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (newGroup != null && !newGroup.Id.Equals(request.Group.Id)) return RequestResult.FromError(RequestResult.ERROR_ALREADYEXISTS, $"{nameof(Group)} with {nameof(Group.Name)} \"{request.Group.Name}\" already exists.");
        // Update Name
        group.UpdateName(request.Group.Name);
        // Update Users
        if (request.Group.Users != null)
        {
            var users = (await UserRepository.GetUsersAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
            // Add
            foreach (var x in request.Group.Users.Select(y => y.Id))
            {
                var user = users.SingleOrDefault(u => u.Id.Equals(x));
                if (user == null) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, $"{nameof(User)} with {nameof(User.Id)} \"{x}\" not found.");
                group.AddUser(user);
            }
            // Remove
            foreach (var userId in group.Users.Where(x => !request.Group.Users.Any(y => y.Id.Equals(x.Id))).Select(x => x.Id))
            {
                group.RemoveUser(userId);
            }
        }
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion
}
