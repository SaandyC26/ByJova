﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class GetGroupsQuery : BaseRequest<GetGroupsQueryResult>
{ }

public sealed class GetGroupsQueryResult
{
    #region --- PROPERTIES ---

    public int Count { get; set; }

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<GroupDto> Groups { get; set; }

    #endregion
}

public sealed class GetGroupsQueryHandler : BaseRequestHandler<GetGroupsQuery, GetGroupsQueryResult>
{
    #region --- CONSTRUCTORS ---

    public GetGroupsQueryHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<GetGroupsQueryResult>> Handle(GetGroupsQuery request, CancellationToken cancellationToken)
    {
        var (count, groups) = await GroupRepository.GetGroupsAsync(asNoTracking: true, includeUsers: request.Dtos?.Any(x => x.EqualsICIC(nameof(User))) ?? false, dataSourceRequest: request.DataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
        return RequestResult.FromResult(new GetGroupsQueryResult() { Count = count, Groups = Mapper.Map(groups, GroupAutoMapper.GetMapperParameters<IEnumerable<Group>, IEnumerable<GroupDto>>(request.Dtos)) });
    }

    #endregion
}