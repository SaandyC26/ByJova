﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;

    public abstract class BaseRequest<T> : Request<T>
    {
        #region --- REFERENCES ---

        public DataSourceRequest DataSourceRequest { get; set; }

        public string[] Dtos { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        protected BaseRequest()
        {
            Dtos = System.Array.Empty<string>();
        }

        #endregion
    }
}
