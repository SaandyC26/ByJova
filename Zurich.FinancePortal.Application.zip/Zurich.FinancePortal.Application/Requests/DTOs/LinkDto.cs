﻿namespace Zurich.FinancePortal.Application
{
    using System.Collections.Generic;

    public sealed class LinkDto
    {
        #region --- PROPERTIES ---

        internal const string Ref_Base = "/";

        internal const string Rel_Delete = "delete";

        internal const string Rel_Update = "update";

        internal const string Rel_Create = "create";

        public string Ref { get; set; }

        public string Rel { get; set; }

        public IEnumerable<string> Properties { get; set; }

        #endregion
    }
}
