﻿namespace Zurich.FinancePortal.Application
{
    using System.Collections.Generic;

    public sealed class RestrictionDto
    {
        #region --- PROPERTIES ---

        public string Field { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<FilterDto> Filters { get; set; }

        #endregion
    }

    public sealed class FilterDto
    {
        #region --- PROPERTIES ---

        public string Field { get; set; }

        public IEnumerable<ValueDto> Values { get; set; }

        #endregion
    }

    public sealed class ValueDto
    {
        #region --- PROPERTIES ---

        public string Name { get; set; }

        public IEnumerable<string> Options { get; set; }

        #endregion
    }
}
