﻿namespace Zurich.FinancePortal.Application
{
    public class FileDto
    {
        #region --- PROPERTIES ---

        public byte[] Content { get; set; }

        public string Name { get; set; }

        public string ContentType { get; set; }

        #endregion
    }
}
