﻿namespace Zurich.FinancePortal.Application;

using FluentValidation;

public sealed class BaseGroupRequestValidator : AbstractValidator<GroupDto>
{
    #region --- CONSTRUCTORS ---

    public BaseGroupRequestValidator()
    {
        RuleFor(g => g).NotNull();
        RuleFor(g => g.Name).NotNull().NotEmpty().Unless(g => g == null);
        RuleForEach(g => g.Users).ChildRules(users =>
        {
            users.RuleFor(u => u).NotNull();
            users.RuleFor(u => u.Id).NotEqual(0);
        }).Unless(g => g == null);
    }

    #endregion
}