﻿namespace Zurich.FinancePortal.Application
{
    public sealed class BaseRequestResult
    {
        #region --- PROPERTIES ---

        public const string ERROR_REFERENCED = "Referenced";

        #endregion

        #region --- CONSTRUCTORS ---

        private BaseRequestResult() { }

        #endregion
    }
}
