﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using DevOps.Application;
using Domain;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

public abstract class BaseRequestHandler<TRequest, TResponse> : RequestHandler<TRequest, TResponse> where TRequest : Request<TResponse>
{
    #region --- REFERENCES ---

    #region --- BASE ---

    protected private readonly ILogger<TRequest> Logger;

    protected private readonly IMapper Mapper;

    private MediatR.IMediator _mediator;
    protected private MediatR.IMediator Mediator => _mediator ??= Services.GetRequiredService<MediatR.IMediator>();

    private IApplicationDbContext _dbContext;
    protected private IApplicationDbContext DbContext => _dbContext ??= Services.GetRequiredService<IApplicationDbContext>();

    #endregion

    #region --- REPOSITORIES ---

    // Role
    private IRoleRepository _roleRepository;
    protected private IRoleRepository RoleRepository => _roleRepository ??= Services.GetRequiredService<IRoleRepository>();

    // User
    private IUserRepository _userRepository;
    protected private IUserRepository UserRepository => _userRepository ??= Services.GetRequiredService<IUserRepository>();

    // Master Data
    private IMasterDataRepository _masterDataRepository;
    protected private IMasterDataRepository MasterDataRepository => _masterDataRepository ??= Services.GetRequiredService<IMasterDataRepository>();

    private IMasterDataFrontEndRepository _masterDataFrontEndRepository;
    protected private IMasterDataFrontEndRepository MasterDataFrontEndRepository => _masterDataFrontEndRepository ??= Services.GetRequiredService<IMasterDataFrontEndRepository>();

    // File
    private IFileRepository _fileRepository;
    protected private IFileRepository FileRepository => _fileRepository ??= Services.GetRequiredService<IFileRepository>();

    // Field
    private IFieldRepository _fieldRepository;
    protected private IFieldRepository FieldRepository => _fieldRepository ??= Services.GetRequiredService<IFieldRepository>();

    // Application Configuration
    private IApplicationConfigurationRepository _applicationConfigurationRepository;
    protected private IApplicationConfigurationRepository ApplicationConfigurationRepository => _applicationConfigurationRepository ??= Services.GetRequiredService<IApplicationConfigurationRepository>();

    // Revenue
    private IRevenueRepository _revenueRepository;
    protected private IRevenueRepository RevenueRepository => _revenueRepository ??= Services.GetRequiredService<IRevenueRepository>();

    private IRevenueFrontEndRepository _revenueFrontEndRepository;
    protected private IRevenueFrontEndRepository RevenueFrontEndRepository => _revenueFrontEndRepository ??= Services.GetRequiredService<IRevenueFrontEndRepository>();

    // Role
    private ITicketRepository _ticketRepository;
    protected private ITicketRepository TicketRepository => _ticketRepository ??= Services.GetRequiredService<ITicketRepository>();

    //Group
    private IGroupRepository _groupRepository;
    protected private IGroupRepository GroupRepository => _groupRepository ??= Services.GetRequiredService<IGroupRepository>();

    #endregion

    #region --- SERVICES ---

    // User
    private ICurrentUserService<User> _currentUserService;
    protected private ICurrentUserService<User> CurrentUserService => _currentUserService ??= Services.GetRequiredService<ICurrentUserService<User>>();

    // Revenue
    private IRevenueService _revenueService;
    protected private IRevenueService RevenueService => _revenueService ??= Services.GetRequiredService<IRevenueService>();

    #endregion

    #endregion

    #region --- CONSTRUCTORS ---

    protected BaseRequestHandler(IServiceProvider services) : base(services)
    {
        Logger = Services.GetRequiredService<ILogger<TRequest>>();
        Mapper = Services.GetRequiredService<IMapper>();
    }

    #endregion

    #region --- PROTECTED PRIVATE METHODS ---

    protected private async Task<bool> HasPermissions(Permission permission, User currentUser = default, CancellationToken cancellationToken = default) =>
        (currentUser ?? await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).HasPermission(permission);

    [SuppressMessage("Major Code Smell", "S3011: Reflection should not be used to increase accessibility of classes, methods, or fields", Justification = "Reflection")]
    protected private async Task<TApplicationConfiguration> GetOrCreateAndGetApplicationConfigurationByType<TApplicationConfiguration>(CancellationToken cancellationToken = default)
    {
        const string createDefaultMethodName = "CreateDefault";
        // Load Configuration
        var ac = await ApplicationConfigurationRepository.GetApplicationConfigurationByTypeAsync<TApplicationConfiguration>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (ac == null)
        {
            var createDefaultMethod = typeof(TApplicationConfiguration).GetMethod(createDefaultMethodName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (createDefaultMethod == null) throw new NotImplementedException($"{nameof(ApplicationConfiguration)} \"{typeof(TApplicationConfiguration).Name}\" must implement \"{createDefaultMethodName}\" method.");
            ac = (TApplicationConfiguration)createDefaultMethod.Invoke(null, null);
            await ApplicationConfigurationRepository.CreateApplicationConfigurationAsync(ac, cancellationToken: cancellationToken).ConfigureAwait(false);
        }
        // Result
        return ac;
    }

    #endregion
}

internal class MyField
{
    #region --- PROPERTIES ---

    [JsonProperty]
    internal string Field { get; set; }

    [JsonProperty]
    internal string ExcelWorksheetCellText { get; set; }

    [JsonProperty]
    internal string Formula { get; set; }

    [JsonProperty]
    internal int ExcelWorksheetColumn { get; set; }

    [JsonProperty]
    internal int ExcelWorksheetRow { get; set; }

    #endregion
}
