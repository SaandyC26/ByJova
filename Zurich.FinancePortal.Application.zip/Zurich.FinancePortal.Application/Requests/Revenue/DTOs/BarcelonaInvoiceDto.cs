﻿namespace Zurich.FinancePortal.Application;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using Domain;

public sealed class BarcelonaInvoiceDto
{
    #region --- PROPERTIES ---

    private string _shortMonth;
    public string ShortMonth { get => _shortMonth; set => _shortMonth = value?.Trim(); }

    private string _chargingModelCode;
    public string ChargingModelCode { get => _chargingModelCode; set => _chargingModelCode = value?.Trim(); }

    private string _internalCostCenterPerCostCode;
    public string InternalCostCenterPerCostCode { get => _internalCostCenterPerCostCode; set => _internalCostCenterPerCostCode = value?.Trim(); }

    private string _businessUnitCode;
    public string BusinessUnitCode { get => _businessUnitCode; set => _businessUnitCode = value?.Trim(); }

    private string _projectName;
    public string ProjectName { get => _projectName; set => _projectName = value?.Trim(); }

    public string Description
    {
        get
        {
            if (_descriptionProperties is null || !_descriptionProperties.Any()) return $"{_shortMonth}{((ServicesDescriptions == null || !ServicesDescriptions.Any()) ? string.Empty : $" - {string.Join(" / ", ServicesDescriptions)}")}";
            var stringBuilder = new StringBuilder(_shortMonth);
            _descriptionProperties.ForEach(x =>
            {
                var p = GetType().GetProperty(x);
                var v = p.GetValue(this, null);
                if (v is null) return;
                if (v is IEnumerable<string> e) { if (e.Any()) stringBuilder.Append($" - {string.Join(_separator, e)}"); }
                else stringBuilder.Append($" - {v}");
            });

            return stringBuilder.ToString();
        }
    }

    private string _customerCostCenterCode;
    public string CustomerCostCenterCode { get => _customerCostCenterCode; set => _customerCostCenterCode = value?.Trim(); }

    public decimal TotalEur { get; set; }

    public IDictionary<Month, decimal> PastFutureTotalEur { get; set; }

    private readonly string _separator;

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<string> ServicesDescriptions { get; set; }

    private readonly IEnumerable<string> _descriptionProperties;

    #endregion

    #region --- CONSTRUCTORS ---

    public BarcelonaInvoiceDto(string separator = default, IEnumerable<string> descriptionProperties = default)
    {
        _separator = !string.IsNullOrWhiteSpace(separator) ? separator : " / ";
        _descriptionProperties = descriptionProperties;
    }

    #endregion
}
