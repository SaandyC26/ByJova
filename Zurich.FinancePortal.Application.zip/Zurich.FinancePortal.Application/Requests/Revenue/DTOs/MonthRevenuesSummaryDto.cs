﻿namespace Zurich.FinancePortal.Application
{
    public sealed class MonthRevenuesSummaryDto
    {
        #region --- PROPERTIES ---

        public bool Locked { get; set; }

        #endregion
    }
}
