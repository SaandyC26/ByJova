﻿namespace Zurich.FinancePortal.Application
{
    public class MonthRevenueDto
    {
        #region --- PROPERTIES ---

        public decimal? Amount { get; set; }

        public bool Locked { get; set; }

        #endregion
    }
}
