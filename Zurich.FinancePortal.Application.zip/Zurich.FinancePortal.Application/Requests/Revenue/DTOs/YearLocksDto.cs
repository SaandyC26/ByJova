﻿namespace Zurich.FinancePortal.Application
{
    public sealed class YearLocksDto
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public bool January { get; set; }

        public bool February { get; set; }

        public bool March { get; set; }

        public bool April { get; set; }

        public bool May { get; set; }

        public bool June { get; set; }

        public bool July { get; set; }

        public bool August { get; set; }

        public bool September { get; set; }

        public bool October { get; set; }

        public bool November { get; set; }

        public bool December { get; set; }

        #endregion

        #region --- REFERENCES ---

        public ChargingModelTypeDto ChargingModelType { get; set; }

        #endregion
    }
}
