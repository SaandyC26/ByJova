﻿namespace Zurich.FinancePortal.Application;

using System.Collections.Generic;
using System.Linq;
using System.Text;

public sealed class RebookingDto
{
    #region --- PROPERTIES ---

    private string _chargingModelCode;
    public string ChargingModelCode { get => _chargingModelCode; set => _chargingModelCode = value?.Trim(); }

    private string _customerCostCenterCode;
    public string CustomerCostCenterCode { get => _customerCostCenterCode; set => _customerCostCenterCode = value?.Trim(); }

    private string _customerName;
    public string CustomeName { get => _customerName; set => _customerName = value?.Trim(); }

    private string _projectName;
    public string ProjectName { get => _projectName; set => _projectName = value?.Trim(); }

    private string _shortMonth;
    public string ShortMonth { get => _shortMonth; set => _shortMonth = value?.Trim(); }

    private string _revenueOrCostElement;
    public string RevenueOrCostElement { get => _revenueOrCostElement; set => _revenueOrCostElement = value?.Trim(); }

    public decimal DebitValueChf { get; set; }

    public decimal CreditValueChf { get; set; }

    private readonly string _description;
    public string Description
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(_description)) return _description;
            if (_descriptionProperties is null || !_descriptionProperties.Any()) return $"{_shortMonth} - {_projectName}";
            var stringBuilder = new StringBuilder(_shortMonth);
            _descriptionProperties.ForEach(x =>
            {
                var p = GetType().GetProperty(x);
                var v = p.GetValue(this, null);
                if (v is null) return;
                if (v is IEnumerable<string> e) { if (e.Any()) stringBuilder.Append($" - {string.Join(_separator, e)}"); }
                else stringBuilder.Append($" - {v}");
            });

            return stringBuilder.ToString();
        }
    }

    private readonly string _separator;

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<string> ServicesDescriptions { get; set; }

    private readonly IEnumerable<string> _descriptionProperties;

    #endregion

    #region --- CONSTRUCTORS ---

    public RebookingDto(string separator = default, string description = default, IEnumerable<string> descriptionProperties = default)
    {
        _separator = !string.IsNullOrWhiteSpace(separator) ? separator : " / ";
        _description = description;
        _descriptionProperties = descriptionProperties;
    }

    #endregion
}
