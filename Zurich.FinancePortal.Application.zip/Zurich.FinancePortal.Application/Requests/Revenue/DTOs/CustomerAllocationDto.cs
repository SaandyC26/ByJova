﻿namespace Zurich.FinancePortal.Application;

using System.Collections.Generic;
using System.Linq;

public sealed class CustomerAllocationDto
{
    #region --- PROPERTIES ---

    private string _chargingModelCode;
    public string ChargingModelCode { get => _chargingModelCode; set => _chargingModelCode = value?.Trim(); }

    private string _lineOfBusinessName;
    public string LineOfBusinessName { get => _lineOfBusinessName; set => _lineOfBusinessName = value?.Trim(); }

    private string _internalCostCenterPerCostCode;
    public string InternalCostCenterPerCostCode { get => _internalCostCenterPerCostCode; set => _internalCostCenterPerCostCode = value?.Trim(); }

    private string _businessUnitCode;
    public string BusinessUnitCode { get => _businessUnitCode; set => _businessUnitCode = value?.Trim(); }

    private string _shortMonth;
    public string ShortMonth { get => _shortMonth; set => _shortMonth = value?.Trim(); }

    public decimal Percentage { get; set; }

    public decimal TotalChf { get; set; }

    public decimal TotalChfVat { get; set; }

    public string ServiceDescription => $"{((ServicesDescriptions == null || !ServicesDescriptions.Any()) ? string.Empty : $"{string.Join(_separator, ServicesDescriptions)}")}";

    public string CustomerName => $"{((CustomersNames == null || !CustomersNames.Any()) ? string.Empty : $"{string.Join(_separator, CustomersNames)}")}";

    private readonly string _separator;

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<string> ServicesDescriptions { get; set; }

    public IEnumerable<string> CustomersNames { get; set; }

    #endregion

    #region --- CONSTRUCTORS ---

    public CustomerAllocationDto(string separator = default)
    {
        _separator = !string.IsNullOrWhiteSpace(separator) ? separator : " / ";
    }

    #endregion
}
