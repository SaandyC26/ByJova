﻿namespace Zurich.FinancePortal.Application;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public sealed class RevenueDto : BaseRevenueDto
{
    #region --- PROPERTIES ---

    public bool Editable { get; set; }

    public bool Commentable { get; set; }

    public bool Deletable { get; set; }

    #endregion

    #region --- REFERENCES ---

    public MonthRevenueDto January { get; set; }

    public MonthRevenueDto February { get; set; }

    public MonthRevenueDto March { get; set; }

    public MonthRevenueDto April { get; set; }

    public MonthRevenueDto May { get; set; }

    public MonthRevenueDto June { get; set; }

    public MonthRevenueDto July { get; set; }

    public MonthRevenueDto August { get; set; }

    public MonthRevenueDto September { get; set; }

    public MonthRevenueDto October { get; set; }

    public MonthRevenueDto November { get; set; }

    public MonthRevenueDto December { get; set; }

    public IEnumerable<RevenueCommentDto> Comments { get; set; }

    #endregion

    #region --- CONSTRUCTORS ---

    public RevenueDto()
    {
        Comments = Array.Empty<RevenueCommentDto>();
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public IEnumerable<PropertyInfo> GetMonthsRevenuesProperties() =>
        GetType().GetProperties().Where(p => p.PropertyType.Equals(typeof(MonthRevenueDto)));

    #endregion
}
