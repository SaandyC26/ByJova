﻿namespace Zurich.FinancePortal.Application;

public abstract class BaseRevenueDto
{
    #region --- PROPERTIES ---

    public long Id { get; set; }

    public int Year { get; set; }

    private string _lineOfBusinessName;
    public string LineOfBusinessName { get => _lineOfBusinessName; set => _lineOfBusinessName = value?.Trim(); }

    private string _customerName;
    public string CustomerName { get => _customerName; set => _customerName = value?.Trim(); }

    private string _projectName;
    public string ProjectName { get => _projectName; set => _projectName = value?.Trim(); }

    private string _projectType;
    public string ProjectType { get => _projectType; set => _projectType = value?.Trim(); }

    public string ProjectPlanningItAppsIds { get; set; }

    public string ProjectPlanningItAppsNames { get; set; }

    private string _typeOfServiceName;
    public string TypeOfServiceName { get => _typeOfServiceName; set => _typeOfServiceName = value?.Trim(); }

    private string _serviceDescription;
    public string ServiceDescription { get => _serviceDescription; set => _serviceDescription = value?.Trim(); }

    private string _ownerProjectManagerName;
    public string OwnerProjectManagerName { get => _ownerProjectManagerName; set => _ownerProjectManagerName = value?.Trim(); }

    private string _groupOwnerName;
    public string GroupOwnerName { get => _groupOwnerName; set => _groupOwnerName = value?.Trim(); }

    private string _businessUnitCode;
    public string BusinessUnitCode { get => _businessUnitCode; set => _businessUnitCode = value?.Trim(); }

    private string _customerCostCenterCode;
    public string CustomerCostCenterCode { get => _customerCostCenterCode; set => _customerCostCenterCode = value?.Trim(); }

    private string _chargingModelCode;
    public string ChargingModelCode { get => _chargingModelCode; set => _chargingModelCode = value?.Trim(); }

    private string _chargingModelType;
    public string ChargingModelType { get => _chargingModelType; set => _chargingModelType = value?.Trim(); }

    private string _internalCostCenterPerCostCode;
    public string InternalCostCenterPerCostCode { get => _internalCostCenterPerCostCode; set => _internalCostCenterPerCostCode = value?.Trim(); }

    private string _internalCode;
    public string InternalCode { get => _internalCode; set => _internalCode = value?.Trim(); }

    private string _currencyCode;
    public string CurrencyCode { get => _currencyCode; set => _currencyCode = value?.Trim(); }

    private string _productName;
    public string ProductName { get => _productName; set => _productName = value?.Trim(); }

    private string _testingToolName;
    public string TestingToolName { get => _testingToolName; set => _testingToolName = value?.Trim(); }

    private string _testingToolProjectName;
    public string TestingToolProjectName { get => _testingToolProjectName; set => _testingToolProjectName = value?.Trim(); }

    private string _testingToolDetailedInfo;
    public string TestingToolDetailedInfo { get => _testingToolDetailedInfo; set => _testingToolDetailedInfo = value?.Trim(); }

    private string _customerFunctionName;
    public string CustomerFunctionName { get => _customerFunctionName; set => _customerFunctionName = value?.Trim(); }

    public decimal? FYFCLC { get; set; }

    public decimal? FYFCCHF { get; set; }

    public decimal? FYFCCHFVAT { get; set; }

    public decimal? PlanLC { get; set; }

    public decimal? TransferLC { get; set; }

    public decimal? DifferenceLC { get; set; }

    public DateTime PlannedStartDate { get; set; }

    public DateTime PlannedEndDate { get; set; }

    #endregion

    #region --- CONSTRUCTORS ---

    protected private BaseRevenueDto() { }

    #endregion
}