﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class ExportRevenuesTemplateQuery : BaseRequest<FileDto>
{
    #region --- PROPERTIES ---

    internal bool Empty { get; set; } = false;

    #endregion
}

public sealed class ExportRevenuesTemplateQueryHandler : BaseRequestHandler<ExportRevenuesTemplateQuery, FileDto>
{
    #region --- REFERENCES ---

    private readonly IDictionary<string, int> _headersColumns;

    private IDictionary<string, IEnumerable<MasterData>> _masterDatas;

    #endregion

    #region --- CONSTRUCTORS ---

    public ExportRevenuesTemplateQueryHandler(IServiceProvider services) : base(services)
    {
        _headersColumns = new Dictionary<string, int>();
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<FileDto>> Handle(ExportRevenuesTemplateQuery request, CancellationToken cancellationToken)
    {
        // Load Configuration
        var configuration = (await GetOrCreateAndGetApplicationConfigurationByType<ExportRevenuesTemplateQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false));
        //  Load Fields
        var fields = await FieldRepository.GetFieldsByEntityAsync<Revenue>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Load Excel Template
        var templateName = configuration.TemplateName.ReplaceICIC(configuration.TemplateExtension, string.Empty);
        var file = await FileRepository.ReadFileAsync(FileType.RevenuesTemplate, $"{templateName}{configuration.TemplateExtension}", cancellationToken: cancellationToken).ConfigureAwait(false);
        if (file == null) return RequestResult.FromError<FileDto>(RequestResult.ERROR_NOTFOUND, $"Invalid Template Name: \"{templateName}\".");
        // Revenues
        var (_, revenues) = request.Empty ? (0, Array.Empty<RevenueDto>()) : await RevenueService.GetRevenuesAsync(dataSourceRequest: request.DataSourceRequest, maxCount: configuration.MaxRows, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (revenues == null) return RequestResult.FromError<FileDto>(RequestResult.ERROR_BADREQUEST, $"Max Rows: {configuration.MaxRows}.");
        // Excel
        using var memoryStream = new MemoryStream(file);
        using var excelPackage = new ExcelPackage(memoryStream);
        // Set the calculation mode to manual
        excelPackage.Workbook.CalcMode = ExcelCalcMode.Manual;
        // Prepare Revenues Worksheet
        PrepareRevenuesWorksheet(excelPackage, configuration, revenues, request.Empty);
        // Export Master Data
        await ExportMasterDatas(excelPackage, configuration, fields, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Export Revenues
        await ExportRevenues(excelPackage, configuration, fields, revenues, request.Empty, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Set the calculation mode to automatic
        excelPackage.Workbook.CalcMode = ExcelCalcMode.Automatic;
        // Result
        return RequestResult.FromResult(new FileDto() { Content = excelPackage.GetAsByteArray(), Name = $"{templateName}{(configuration.AppendDateTime ? $"_{DateTime.UtcNow:yyyy-MM-dd}_{DateTime.UtcNow:HH-mm-ss}" : string.Empty)}{configuration.TemplateExtension}", ContentType = configuration.ExcelContentType });
    }

    #endregion

    #region --- PRIVATE METHODS ---

    private async Task ExportMasterDatas(ExcelPackage excelPackage, ExportRevenuesTemplateQueryConfiguration configuration, IEnumerable<Field> fields, CancellationToken cancellationToken = default)
    {
        _masterDatas = new Dictionary<string, IEnumerable<MasterData>>();
        // Exchange Rate Excel Worksheet
        var exchangeRateWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.ExchangeRateWorksheetName));
        // Line of Business
        await SetMasterDatas<LineOfBusiness>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.LineOfBusiness))), nameof(LineOfBusiness.Name)).ConfigureAwait(false);
        // Customer
        await SetMasterDatas<Customer>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.Customer))), nameof(Customer.Name)).ConfigureAwait(false);
        // Project
        await SetMasterDatas<Project>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.Project))), nameof(Project.Name)).ConfigureAwait(false);
        // Type of Services
        await SetMasterDatas<TypeOfService>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.TypeOfService))), nameof(TypeOfService.Name)).ConfigureAwait(false);
        // Users
        var users = (await UserRepository.GetUsersAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
        SetOthers(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.OwnerProjectManager))), nameof(User.Name), objects: users);
        // Groups
        var groups = (await GroupRepository.GetGroupsAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
        SetOthers(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.GroupOwner))), nameof(Group.Name), objects: groups);
        // BU Code
        await SetMasterDatas<BusinessUnit>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.BusinessUnit))), nameof(BusinessUnit.Code)).ConfigureAwait(false);
        // Product
        await SetMasterDatas<Product>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.Product))), nameof(Product.Name)).ConfigureAwait(false);
        // Testing Tool
        await SetMasterDatas<TestingTool>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.TestingTool))), nameof(TestingTool.Name)).ConfigureAwait(false);
        // CC Customer
        await SetMasterDatas<CostCenter>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.CustomerCostCenter))), nameof(CostCenter.Code), where: x => x.Types.Contains(CostCenterType.Customer)).ConfigureAwait(false);
        // Charging Model
        await SetMasterDatas<ChargingModel>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.ChargingModel))), nameof(ChargingModel.Code)).ConfigureAwait(false);
        // Internal CC per Cost
        await SetMasterDatas<CostCenter>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.InternalCostCenterPerCost))), nameof(CostCenter.Code), where: x => x.Types.Contains(CostCenterType.Internal)).ConfigureAwait(false);
        // Currency
        await SetMasterDatas<Currency>(fields.Single(f => f.EntityReference.Equals(nameof(Revenue.Currency))), nameof(Currency.Code)).ConfigureAwait(false);
        // CurrenciesExchangeRates
        var cers = (await MasterDataRepository.GetCurrenciesExchangeRatesByToAsync(Currency.ChiefsCode, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).OrderByDescending(cer => cer.Year).ThenBy(cer => Revenue.GetMonthOrder(cer.Month)).ThenBy(cer => cer.From.Id);
        for (var i = 0; i < cers.Count(); i++)
        {
            var cer = cers.ElementAt(i);
            exchangeRateWorksheet.Cells[$"A{configuration.ExchangeRateHeaderRowIndex + 1 + i}"].Value = $"{cer.From.Code} / {cer.To.Code}";
            exchangeRateWorksheet.Cells[$"B{configuration.ExchangeRateHeaderRowIndex + 1 + i}"].Value = cer.Year;
            if (!Month.None.Equals(cer.Month)) exchangeRateWorksheet.Cells[$"C{configuration.ExchangeRateHeaderRowIndex + 1 + i}"].Value = Revenue.GetShortMonthName(cer.Month);
            exchangeRateWorksheet.Cells[$"D{configuration.ExchangeRateHeaderRowIndex + 1 + i}"].Value = cer.Rate;
        }

        #region --- NESTED METHODS ---

        void SetOthers<T>(Field field, string propertyName, IEnumerable<T> objects)
        {
            // Static Data Excel Worksheet
            var staticDataWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.StaticDataWorksheetName));
            // Get Headers Cells
            var staticDataHeaderCells = staticDataWorksheet.Cells[$"A{configuration.HeaderRowIndex}:{ExcelHelper.ToExcelColum(staticDataWorksheet.Dimension.End.Column)}{configuration.HeaderRowIndex}"];
            var staticColumn = staticDataHeaderCells.Single(c => c?.Value?.ToString()?.EqualsICIC(field.LabelOnFile.Replace(" *", string.Empty)) ?? false).Start.Column;
            for (var i = 0; i < objects.Count(); i++)
            {
                var masterData = objects.ElementAt(i);
                staticDataWorksheet.Cells[configuration.HeaderRowIndex + 1 + i, staticColumn].Value = masterData.GetType().GetProperty(propertyName).GetValue(masterData);
            }

            staticDataWorksheet.Tables[$"Table_{field.EntityReference}"].TableXml.DocumentElement.Attributes["ref"].Value = $"{ExcelHelper.ToExcelColum(staticColumn)}1:{ExcelHelper.ToExcelColum(staticColumn)}{(objects.Any() ? objects.Count() + 1 : 2)}";
            excelPackage.Workbook.Names.Remove(field.EntityReference);
            excelPackage.Workbook.Names.Add(field.EntityReference, staticDataWorksheet.Cells[$"{ExcelHelper.ToExcelColum(staticColumn)}2:{ExcelHelper.ToExcelColum(staticColumn)}{(objects.Any() ? objects.Count() + 1 : 2)}"]);
        }

        async Task SetMasterDatas<T>(Field field, string propertyName, Func<T, bool> where = null) where T : MasterData
        {
            // Static Data Excel Worksheet
            var staticDataWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.StaticDataWorksheetName));
            // Get Headers Cells
            var staticDataHeaderCells = staticDataWorksheet.Cells[$"A{configuration.HeaderRowIndex}:{ExcelHelper.ToExcelColum(staticDataWorksheet.Dimension.End.Column)}{configuration.HeaderRowIndex}"];
            if (!_masterDatas.TryGetValue(typeof(T).Name, out var masterDatas))
            {
                masterDatas = (await MasterDataRepository.GetMasterDatasByEntityAsync<T>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false));
                _masterDatas.Add(typeof(T).Name, masterDatas);
            }

            if (where != null) masterDatas = ((IEnumerable<T>)masterDatas).Where(where);
            var staticColumn = staticDataHeaderCells.Single(c => c?.Value?.ToString()?.ReplaceICIC(Environment.NewLine, " ")?.ReplaceICIC("\n", " ")?.ReplaceICIC("  ", " ")?.EqualsICIC(field.LabelOnFile.Replace(" *", string.Empty)) ?? false).Start.Column;
            for (var i = 0; i < masterDatas.Count(); i++)
            {
                var masterData = masterDatas.ElementAt(i);
                staticDataWorksheet.Cells[configuration.HeaderRowIndex + 1 + i, staticColumn].Value = masterData.GetType().GetProperty(propertyName).GetValue(masterData);
            }

            var endColumn = (masterDatas.Any() ? masterDatas.Count() : 0) + 1;
            staticDataWorksheet.Tables[$"Table_{field.EntityReference}"].TableXml.DocumentElement.Attributes["ref"].Value = $"{ExcelHelper.ToExcelColum(staticColumn)}1:{ExcelHelper.ToExcelColum(staticColumn)}{endColumn}";
            excelPackage.Workbook.Names.Remove(field.EntityReference);
            excelPackage.Workbook.Names.Add(field.EntityReference, staticDataWorksheet.Cells[$"{ExcelHelper.ToExcelColum(staticColumn)}2:{ExcelHelper.ToExcelColum(staticColumn)}{endColumn}"]);
        }

        #endregion
    }

    private static void PrepareRevenuesWorksheet(ExcelPackage excelPackage, ExportRevenuesTemplateQueryConfiguration configuration, IEnumerable<RevenueDto> revenues, bool empty)
    {
        // Revenues Excel Worksheet
        var revenuesWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.RevenuesWorksheetName));
        revenuesWorksheet.InsertRow(configuration.RevenuesWorksheetHeaderRowIndex + 2, revenues.Count() + configuration.ExtraRowsValidation - 1);
        // Revenues Multi Currency Excel Worksheet
        var revenuesMultiCurrencyWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.RevenuesMultiCurrencyWorksheetName));
        if (empty)
        {
            excelPackage.Workbook.Worksheets.Delete(revenuesMultiCurrencyWorksheet);
        }
        else
        {
            revenuesMultiCurrencyWorksheet.InsertRow(configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 2, revenues.Count() + configuration.ExtraRowsValidation - 1);
        }
    }

    private async Task ExportRevenues(ExcelPackage excelPackage, ExportRevenuesTemplateQueryConfiguration configuration, IEnumerable<Field> fields, IEnumerable<RevenueDto> revenues, bool empty, CancellationToken cancellationToken = default)
    {
        // Revenues Excel Worksheet
        var revenuesWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.RevenuesWorksheetName));
        // Revenues - Muli Currency Worksheet
        var revenuesMultiCurrencyWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.RevenuesMultiCurrencyWorksheetName));
        // Get Headers Cells
        var revenuesHeaderCells = revenuesWorksheet.Cells[$"A{configuration.RevenuesWorksheetHeaderRowIndex}:{ExcelHelper.ToExcelColum(revenuesWorksheet.Dimension.End.Column)}{configuration.RevenuesWorksheetHeaderRowIndex}"];
        // Set Headers
        foreach (var field in fields.Where(f => (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false)))
        {
            // Get Headers
            if (!string.IsNullOrWhiteSpace(field.LabelOnFile)) _headersColumns.Add(field.EntityReference, revenuesHeaderCells.Single(c => c?.Value?.ToString()?.ReplaceICIC(" *", string.Empty)?.EqualsICIC(field.LabelOnFile) ?? false).Start.Column);
        }
        // Data
        var fLob = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.LineOfBusiness)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fC = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Customer)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fF = fields.Single(f => f.EntityReference.EqualsICIC($"{nameof(Revenue.Customer)}{nameof(Customer.Function)}") && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fP = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Project)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fPT = fields.Single(x => x.EntityReference.EqualsICIC($"{nameof(Revenue.Project)}{nameof(Project.Type)}") && (x.Entity?.Equals(nameof(Revenue)) ?? false) && (x.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fieldProjectPlanningItAppsIds = fields.Single(x => x.EntityReference.EqualsICIC($"{nameof(Revenue.Project)}{nameof(Project.PlanningItApps)}{nameof(PlanningItApp.Id)}") && (x.Entity?.Equals(nameof(Revenue)) ?? false) && (x.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fieldProjectPlanningItAppsNames = fields.Single(x => x.EntityReference.EqualsICIC($"{nameof(Revenue.Project)}{nameof(Project.PlanningItApps)}{nameof(PlanningItApp.Name)}") && (x.Entity?.Equals(nameof(Revenue)) ?? false) && (x.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fToS = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TypeOfService)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fSD = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.ServiceDescription)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fOPM = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.OwnerProjectManager)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fG = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.GroupOwner)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fBU = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.BusinessUnit)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fProduct = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Product)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fTestingTool = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingTool)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fTestingToolProjectName = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingToolProjectName)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fTestingToolDetailedInfo = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingToolDetailedInfo)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fCCC = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.CustomerCostCenter)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fCM = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.ChargingModel)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fICCC = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.InternalCostCenterPerCost)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fCurr = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Currency)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fIc = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.InternalCode)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fYear = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Year)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fPlannedStartDate = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.PlannedStartDate)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fPlannedEndDate = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.PlannedEndDate)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fPlan = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.PlanLC)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fTransfer = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TransferLC)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fComments = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Comments)) && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        var fAutoComments = fields.Single(f => f.EntityReference.EqualsICIC($"{nameof(Revenue.Comments)}{nameof(Revenue.Comments)}") && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false));
        // Loop Revenues
        for (var i = 0; i < revenues.Count(); i++)
        {
            // Get Revenue
            var revenue = revenues.ElementAt(i);
            var revenueProperties = revenue.GetType().GetProperties();
            // Line of Business
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fLob.EntityReference]].Value = revenue.LineOfBusinessName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 1].Value = revenue.LineOfBusinessName;
            // Customer
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fC.EntityReference]].Value = revenue.CustomerName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 2].Value = revenue.CustomerName;
            // Function
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fF.EntityReference]].Value = revenue.CustomerFunctionName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 3].Value = revenue.CustomerFunctionName;
            // Project
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fP.EntityReference]].Value = revenue.ProjectName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 4].Value = revenue.ProjectName;
            // Project Type
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fPT.EntityReference]].Value = revenue.ProjectType;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 5].Value = revenue.ProjectType;
            // Project Planning IT Apps Ids
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fieldProjectPlanningItAppsIds.EntityReference]].Value = revenue.ProjectPlanningItAppsIds;
            // Project Planning IT Apps Names
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fieldProjectPlanningItAppsNames.EntityReference]].Value = revenue.ProjectPlanningItAppsNames;
            // Type of Service
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fToS.EntityReference]].Value = revenue.TypeOfServiceName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 6].Value = revenue.TypeOfServiceName;
            // ServiceDescription
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fSD.EntityReference]].Value = revenue.ServiceDescription;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 7].Value = revenue.ServiceDescription;
            // Owner Project Manager
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fOPM.EntityReference]].Value = revenue.OwnerProjectManagerName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 8].Value = revenue.OwnerProjectManagerName;
            // Group
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fG.EntityReference]].Value = revenue.GroupOwnerName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 9].Value = revenue.GroupOwnerName;
            // Business Unit Code
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fBU.EntityReference]].Value = revenue.BusinessUnitCode;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 10].Value = revenue.BusinessUnitCode;
            // Product
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fProduct.EntityReference]].Value = revenue.ProductName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 15].Value = revenue.ProductName;
            // Testing Tool
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fTestingTool.EntityReference]].Value = revenue.TestingToolName;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 16].Value = revenue.TestingToolName;
            // Testing Tool Project Name
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fTestingToolProjectName.EntityReference]].Value = revenue.TestingToolProjectName;
            // Testing Tool Detailed Info
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fTestingToolDetailedInfo.EntityReference]].Value = revenue.TestingToolDetailedInfo;
            // Cost Center Customer
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fCCC.EntityReference]].Value = revenue.CustomerCostCenterCode;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 11].Value = revenue.CustomerCostCenterCode;
            // Charging Model
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fCM.EntityReference]].Value = revenue.ChargingModelCode;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 12].Value = revenue.ChargingModelCode;
            // Internal Cost Center per Cost
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fICCC.EntityReference]].Value = revenue.InternalCostCenterPerCostCode;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 13].Value = revenue.InternalCostCenterPerCostCode;
            // Currency
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fCurr.EntityReference]].Value = revenue.CurrencyCode;
            // Internal Code
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fIc.EntityReference]].Value = revenue.InternalCode;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 14].Value = revenue.InternalCode;
            // Year
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fYear.EntityReference]].Value = revenue.Year;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 19].Value = revenue.Year;
            // PlannedStartDate
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fPlannedStartDate.EntityReference]].Value = revenue.PlannedStartDate;
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 17].Value = revenue.PlannedStartDate;
            // PlannedEndDate
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fPlannedEndDate.EntityReference]].Value = new DateTime(revenue.PlannedEndDate.Year, revenue.PlannedEndDate.Month, revenue.PlannedEndDate.Day, 0, 0, 0, DateTimeKind.Utc);
            if (!empty) revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 18].Value = new DateTime(revenue.PlannedEndDate.Year, revenue.PlannedEndDate.Month, revenue.PlannedEndDate.Day, 0, 0, 0, DateTimeKind.Utc);
            // Plan
            var currencyExchangeRates = empty ? null : (await MasterDataRepository.GetCurrenciesExchangeRatesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).ToArray();
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fPlan.EntityReference]].Value = revenue.PlanLC;
            if (!empty)
            {
                // CHF
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 34].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.ChiefsCode, currencyExchangeRates) ?? decimal.One) * revenue.PlanLC);
                // EUR
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 34 + 17].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.EuroCode, currencyExchangeRates) ?? decimal.One) * revenue.PlanLC);
                // USD
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 34 + 34].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.DollarCode, currencyExchangeRates) ?? decimal.One) * revenue.PlanLC);
            }
            // Transfer
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fTransfer.EntityReference]].Value = revenue.TransferLC;
            if (!empty)
            {
                // CHF
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 35].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.ChiefsCode, currencyExchangeRates) ?? decimal.One) * revenue.TransferLC);
                // EUR
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 35 + 17].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.EuroCode, currencyExchangeRates) ?? decimal.One) * revenue.TransferLC);
                // USD
                revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 35 + 34].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Month.None, revenue.CurrencyCode, Currency.DollarCode, currencyExchangeRates) ?? decimal.One) * revenue.TransferLC);
            }
            // Comments
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fComments.EntityReference]].Value = string.Join(Environment.NewLine, revenue.Comments.Where(rc => !rc.AutoGenerated).Select(rc => $"{rc.DateTime:yyyy-MM-dd HH:mm:ss}{(string.IsNullOrWhiteSpace(rc.UserName) ? string.Empty : $" - {rc.UserName}")}: {rc.Text}"));
            revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[fAutoComments.EntityReference]].Value = string.Join(Environment.NewLine, revenue.Comments.Where(rc => rc.AutoGenerated).Select(rc => $"{rc.DateTime:yyyy-MM-dd HH:mm:ss}{(string.IsNullOrWhiteSpace(rc.UserName) ? string.Empty : $" - {rc.UserName}")}: {rc.Text}"));
            // Months
            var j = 0;
            foreach (var entityReference in fields.Where(f => f.EntityReference.ContainsICIC(".") && (f.Entity?.Equals(nameof(Revenue)) ?? false) && (f.WorksheetOnFile?.EqualsICIC(configuration.RevenuesWorksheetName) ?? false)).Select(x => x.EntityReference))
            {
                var split = entityReference.Split(".", StringSplitOptions.RemoveEmptyEntries);
                var monthRevenue = revenueProperties.Single(p => p.Name.EqualsICIC(split[0])).GetValue(revenue);
                var value = (decimal?)monthRevenue.GetType().GetProperty(split[1]).GetValue(monthRevenue);
                revenuesWorksheet.Cells[configuration.RevenuesWorksheetHeaderRowIndex + 1 + i, _headersColumns[entityReference]].Value = value;
                if (!empty)
                {
                    // CHF
                    revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 20 + j].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Enum.Parse<Month>(split[0], true), revenue.CurrencyCode, Currency.ChiefsCode, currencyExchangeRates) ?? decimal.One) * value);
                    // EUR
                    revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 20 + j + 17].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Enum.Parse<Month>(split[0], true), revenue.CurrencyCode, Currency.EuroCode, currencyExchangeRates) ?? decimal.One) * value);
                    // USD
                    revenuesMultiCurrencyWorksheet.Cells[configuration.RevenuesMultiCurrencyWorksheetHeaderRowIndex + 1 + i, 20 + j + 34].Value = Domain.RevenueService.Round((Domain.RevenueService.GetCurrencyExchangeRate(revenue.Year, Enum.Parse<Month>(split[0], true), revenue.CurrencyCode, Currency.DollarCode, currencyExchangeRates) ?? decimal.One) * value);
                }

                j++;
            }
        }
    }

    #endregion

    internal sealed class ExportRevenuesTemplateQueryConfiguration
    {
        #region --- PROPERTIES ---

        public string TemplateName { get; set; }

        public int HeaderRowIndex { get; set; }

        public int ExchangeRateHeaderRowIndex { get; set; }

        public string DetailsWorksheetName { get; set; }

        public string StaticDataWorksheetName { get; set; }

        public string ExchangeRateWorksheetName { get; set; }

        public string ExcelContentType { get; set; }

        public int ExtraRowsValidation { get; set; }

        public int MaxRows { get; set; }

        public string TemplateExtension { get; set; }

        public bool AppendDateTime { get; set; }

        public string RevenuesWorksheetName { get; set; }

        public int RevenuesWorksheetHeaderRowIndex { get; set; }

        public string RevenuesMultiCurrencyWorksheetName { get; set; }

        public int RevenuesMultiCurrencyWorksheetHeaderRowIndex { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static ExportRevenuesTemplateQueryConfiguration CreateDefault() =>
            new()
            {
                TemplateName = "Revenues_Default",
                HeaderRowIndex = 1,
                RevenuesMultiCurrencyWorksheetHeaderRowIndex = 2,
                RevenuesWorksheetHeaderRowIndex = 1,
                ExchangeRateHeaderRowIndex = 2,
                DetailsWorksheetName = "DETAILS",
                StaticDataWorksheetName = "STATIC DATA",
                ExchangeRateWorksheetName = "EXCHANGE RATE",
                ExcelContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ExtraRowsValidation = 100,
                MaxRows = 1000,
                TemplateExtension = ".xlsx",
                AppendDateTime = true,
                RevenuesWorksheetName = "DETAILS",
                RevenuesMultiCurrencyWorksheetName = "DETAILS - MULTI CURRENCY"
            };

        #endregion
    }
}
