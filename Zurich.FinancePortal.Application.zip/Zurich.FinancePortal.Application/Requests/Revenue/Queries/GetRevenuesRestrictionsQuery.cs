﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetRevenuesRestrictionsQuery : BaseRequest<IEnumerable<RestrictionDto>>
    { }

    public sealed class GetRevenuesRestrictionsQueryHandler : BaseRequestHandler<GetRevenuesRestrictionsQuery, IEnumerable<RestrictionDto>>
    {
        #region --- CONSTRUCTORS ---

        public GetRevenuesRestrictionsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<IEnumerable<RestrictionDto>>> Handle(GetRevenuesRestrictionsQuery request, CancellationToken cancellationToken)
        {
            // Get Configuratiuon
            var revenuesConfiguration = await GetOrCreateAndGetApplicationConfigurationByType<RevenuesConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            var result = Mapper.Map<IEnumerable<Restriction>, IEnumerable<RestrictionDto>>(revenuesConfiguration.Restrictions);
            return RequestResult.FromResult(result);
        }

        #endregion
    }
}
