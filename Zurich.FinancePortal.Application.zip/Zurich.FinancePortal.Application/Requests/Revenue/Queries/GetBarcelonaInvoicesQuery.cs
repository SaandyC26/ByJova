﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetBarcelonaInvoicesQuery : BaseRequest<GetBarcelonaInvoicesQueryResult>
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public bool IncludePastFuture { get; set; }

        public Month Month { get; set; }

        public string[] LinesOfBusinessNames { get; set; }

        internal IEnumerable<LineOfBusiness> LinesOfBusiness { get; set; }

        #endregion
    }

    public sealed class GetBarcelonaInvoicesQueryValidator : AbstractValidator<GetBarcelonaInvoicesQuery>
    {
        #region --- CONSTRUCTORS ---

        public GetBarcelonaInvoicesQueryValidator(IMasterDataRepository masterDataRepository)
        {
            RuleFor(x => x.Year).GreaterThan(0);
            RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
            RuleFor(x => x.LinesOfBusinessNames).MustAsync(async (x, linesOfBusinessNames, cancellationToken) =>
            {
                x.LinesOfBusiness = await GetBarcelonaInvoicesQueryHandler.GetLinesOfBusinessAsync(masterDataRepository, linesOfBusinessNames, cancellationToken: cancellationToken).ConfigureAwait(false);
                return x.LinesOfBusiness.Count().Equals(linesOfBusinessNames.Length);
            }).When(x => x.LinesOfBusinessNames != null && x.LinesOfBusinessNames.Any());
        }

        #endregion
    }

    public sealed class GetBarcelonaInvoicesQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<BarcelonaInvoiceDto> Results { get; set; }

        #endregion
    }

    public sealed class GetBarcelonaInvoicesQueryHandler : BaseRequestHandler<GetBarcelonaInvoicesQuery, GetBarcelonaInvoicesQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetBarcelonaInvoicesQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetBarcelonaInvoicesQueryResult>> Handle(GetBarcelonaInvoicesQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_BarcelonaInvoices, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<GetBarcelonaInvoicesQueryResult>();
            // Load Configuration
            var configuration = (await GetOrCreateAndGetApplicationConfigurationByType<GetBarcelonaInvoicesQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false));
            // Get ChargingModels
            var chargingModels = (await MasterDataRepository.GetChargingModelsAsync(cancellationToken: cancellationToken).ConfigureAwait(false))
                .Where(cm => configuration.ChargingModelsCodes.ContainsICIC(cm.Code));
            // Get Invoices
            var linesOfBusinessNames = (request.LinesOfBusinessNames != null && request.LinesOfBusinessNames.Any()) ?
                (request.LinesOfBusiness ?? await GetLinesOfBusinessAsync(MasterDataRepository, request.LinesOfBusinessNames, cancellationToken: cancellationToken).ConfigureAwait(false)).Select(lob => lob.Name) :
                null;

            var (count, invoices) = await RevenueFrontEndRepository.GetBarcelonaInvoicesAsync(request.Year, request.Month, linesOfBusinessNames, chargingModels, dataSourceRequest: request.DataSourceRequest, includeCount: true, includePastFuture: request.IncludePastFuture, separator: configuration.Separator, descriptionProperties: configuration.DescriptionProperties, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromResult(new GetBarcelonaInvoicesQueryResult() { Count = count, Results = invoices });
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal async static Task<IEnumerable<LineOfBusiness>> GetLinesOfBusinessAsync(IMasterDataRepository masterDataRepository, IEnumerable<string> names, CancellationToken cancellationToken = default) =>
            (await masterDataRepository.GetMasterDatasByEntityAsync<LineOfBusiness>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false))
                .Where(lob => names.Any(n => lob.Name.EqualsICIC(n)));

        #endregion
    }

    internal sealed class GetBarcelonaInvoicesQueryConfiguration
    {
        #region --- PROPERTIES ---

        public string Separator { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<string> ChargingModelsCodes { get; set; }

        public IEnumerable<string> DescriptionProperties { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static GetBarcelonaInvoicesQueryConfiguration CreateDefault() =>
            new()
            {
                Separator = " / ",
                ChargingModelsCodes = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode }
            };

        #endregion
    }
}
