﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetRevenuesQuery : BaseRequest<GetRevenuesQueryResult>
    { }

    public sealed class GetRevenuesQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public RevenueDto[] Revenues { get; set; }

        #endregion
    }

    public sealed class GetRevenuesQueryHandler : BaseRequestHandler<GetRevenuesQuery, GetRevenuesQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetRevenuesQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetRevenuesQueryResult>> Handle(GetRevenuesQuery request, CancellationToken cancellationToken)
        {
            var (count, revenues) = await RevenueService.GetRevenuesAsync(dtos: request.Dtos, dataSourceRequest: request.DataSourceRequest, includeCount: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            return RequestResult.FromResult(new GetRevenuesQueryResult() { Count = count, Revenues = revenues.ToArray() });
        }

        #endregion
    }
}
