﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class ExportRebookingsQuery : BaseRequest<FileDto>
{
    #region --- PROPERTIES ---

    public int Year { get; set; }

    public Month Month { get; set; }

    public string InternalCostCenterCode { get; set; }

    internal CostCenter CostCenter { get; set; }

    #endregion
}

public sealed class ExportRebookingsQueryValidator : AbstractValidator<ExportRebookingsQuery>
{
    #region --- CONSTRUCTORS ---

    public ExportRebookingsQueryValidator(IMasterDataRepository masterDataRepository)
    {
        RuleFor(x => x.Year).GreaterThan(0);
        RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
        RuleFor(x => x.InternalCostCenterCode).NotEmpty().MustAsync(async (query, x, cancellationToken) =>
        {
            query.CostCenter = await GetRebookingsQueryHandler.GetCostCenterAsync(masterDataRepository, x, cancellationToken: cancellationToken).ConfigureAwait(false);
            return query.CostCenter != null;
        });
    }

    #endregion
}

public sealed class ExportRebookingsQueryHandler : BaseRequestHandler<ExportRebookingsQuery, FileDto>
{
    #region --- CONSTRUCTORS ---

    public ExportRebookingsQueryHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<FileDto>> Handle(ExportRebookingsQuery request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_Rebookings, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<FileDto>();
        // Load Configuration
        var configuration = await GetOrCreateAndGetApplicationConfigurationByType<ExportRebookingsQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Load Excel Template
        var templateName = configuration.TemplateName.ReplaceICIC(configuration.TemplateExtension, string.Empty);
        var file = await FileRepository.ReadFileAsync(FileType.RevenuesTemplate, $"{templateName}{configuration.TemplateExtension}", cancellationToken: cancellationToken).ConfigureAwait(false);
        if (file == null) return RequestResult.FromError<FileDto>(RequestResult.ERROR_NOTFOUND, $"Invalid Template Name: \"{templateName}\".");
        // Get Rebookings
        var query = new GetRebookingsQuery()
        {
            Year = request.Year,
            Month = request.Month,
            DataSourceRequest = request.DataSourceRequest,
            Dtos = request.Dtos,
            InternalCostCenterCode = request.InternalCostCenterCode,
            CostCenter = request.CostCenter
        };

        var queryResult = await Mediator.Send(query, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (!queryResult.Success) return RequestResult.FromError<FileDto>(queryResult.ErrorType, queryResult.Message);
        // Excel
        using var memoryStream = new MemoryStream(file);
        using var excelPackage = new ExcelPackage(memoryStream);
        var rebookings = queryResult.Result.Results.ToArray();
        // Prepare Worksheet
        PrepareWorksheet(excelPackage, configuration, rebookings);
        // Export Rebookings
        ExportRebookings(excelPackage, configuration, rebookings);
        // Update Worksheet
        UpdateWorksheet(excelPackage, request.Month, request.Year, configuration);
        // Result
        return RequestResult.FromResult(new FileDto() { Content = excelPackage.GetAsByteArray(), Name = $"{configuration.FileName.ReplaceICIC("{year}", request.Year.ToString()).ReplaceICIC("{month}", request.Month.ToString())}{configuration.TemplateExtension}", ContentType = configuration.ExcelContentType });
    }

    #endregion

    #region --- PRIVATE METHODS ---

    private static void PrepareWorksheet(ExcelPackage excelPackage, ExportRebookingsQueryConfiguration configuration, RebookingDto[] rebookings)
    {
        // Set the calculation mode to manual
        excelPackage.Workbook.CalcMode = ExcelCalcMode.Manual;
        // Year Worksheet
        var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
        // Get Refresh Formulas
        if (configuration.RefreshFormulas != null) configuration.RefreshFormulas.ForEach(f =>
        {
            f.ExcelWorksheetCellText = worksheet.Cells[f.ExcelWorksheetRow, f.ExcelWorksheetColumn].Formula;
        });
        // Copy Base Row to Rows
        var rowsCount = rebookings.Length - configuration.TableDefaultSize;
        if (rowsCount > 0) worksheet.InsertRow(configuration.HeaderRowIndex + configuration.TableDefaultSize, rowsCount, configuration.HeaderRowIndex + configuration.TableDefaultSize - 1);
        // Set Dates
        if (configuration.DocumentDate != null)
        {
            worksheet.Cells[configuration.DocumentDate.ExcelWorksheetRow, configuration.DocumentDate.ExcelWorksheetColumn].Value = DateTime.UtcNow.ToString(configuration.DocumentDate.ExcelWorksheetCellText);
        }
    }

    private static void UpdateWorksheet(ExcelPackage excelPackage, Month month, int year, ExportRebookingsQueryConfiguration configuration)
    {
        // Set the calculation mode to automatic
        excelPackage.Workbook.CalcMode = ExcelCalcMode.Automatic;
        // Rename Worksheet
        var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
        worksheet.Name = configuration.GetReplacedNewShotName(month, year);
    }

    private static void ExportRebookings(ExcelPackage excelPackage, ExportRebookingsQueryConfiguration configuration, RebookingDto[] rebookings)
    {
        var rCount = rebookings.Length;
        // Worksheet
        var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
        // Loop Rebookings
        for (var i = 0; i < rCount; i++)
        {
            var rebooking = rebookings.ElementAt(i);
            configuration.Fields.ForEach(f =>
            {
                if (f.Field.EqualsICIC("index")) worksheet.Cells[configuration.HeaderRowIndex + 1 + i, f.ExcelWorksheetColumn].Value = i + 1;
                else worksheet.Cells[configuration.HeaderRowIndex + 1 + i, f.ExcelWorksheetColumn].Value = rebooking.GetType().GetProperty(f.Field).GetValue(rebooking);
            });
        }
        // Set Refresh Formulas
        if (configuration.RefreshFormulas != null) configuration.RefreshFormulas.ForEach(f =>
        {
            worksheet.Cells[f.ExcelWorksheetRow + ((rCount - configuration.TableDefaultSize) > 0 ? (rCount - configuration.TableDefaultSize) : 0), f.ExcelWorksheetColumn].Formula = f.ExcelWorksheetCellText;
        });
    }

    #endregion
}

internal sealed class ExportRebookingsQueryConfiguration
{
    #region --- PROPERTIES ---

    [JsonProperty]
    internal string TemplateName { get; set; }

    [JsonProperty]
    internal string TemplateExtension { get; set; }

    [JsonProperty]
    internal string SheetName { get; set; }

    [JsonProperty]
    internal string NewSheetName { get; set; }

    [JsonProperty]
    internal int TableDefaultSize { get; set; }

    [JsonProperty]
    internal int HeaderRowIndex { get; set; }

    [JsonProperty]
    internal string FileName { get; set; }

    [JsonProperty]
    internal string ExcelContentType { get; set; }

    #endregion

    #region --- REFERENCES ---

    [JsonProperty]
    internal MyField[] Fields { get; set; }

    [JsonProperty]
    internal MyField[] RefreshFormulas { get; set; }

    [JsonProperty]
    internal MyField DocumentDate { get; set; }

    #endregion

    #region --- INTERNAL METHODS ---

    internal string GetReplacedNewShotName(Month month, int year) => NewSheetName.ReplaceICIC("{shortmonth}", Revenue.GetShortMonthName(month)).ReplaceICIC("{yy}", year.ToString());

    internal static ExportRebookingsQueryConfiguration CreateDefault() =>
        new()
        {
            TemplateName = "Rebookings_Default",
            TemplateExtension = ".xlsx",
            SheetName = "Journal",
            NewSheetName = "Journal {shortmonth}{yy}",
            FileName = "Rebooking - {year} - {month}",
            ExcelContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            TableDefaultSize = 2,
            HeaderRowIndex = 10,
            DocumentDate = new MyField() { ExcelWorksheetRow = 4, ExcelWorksheetColumn = 9, ExcelWorksheetCellText = "dd/MM/yyyy" },
            Fields = new MyField[]
            {
                new MyField() { Field = nameof(RebookingDto.ChargingModelCode), ExcelWorksheetColumn = 1, ExcelWorksheetCellText = "Cost Center or Internal Order" },
                new MyField() { Field = "index", ExcelWorksheetColumn = 2, ExcelWorksheetCellText = "Item" },
                new MyField() { Field = nameof(RebookingDto.CustomerCostCenterCode), ExcelWorksheetColumn = 4, ExcelWorksheetCellText = "Cost Center or Internal Order" },
                new MyField() { Field = nameof(RebookingDto.DebitValueChf), ExcelWorksheetColumn = 5, ExcelWorksheetCellText = "Debit Value" },
                new MyField() { Field = nameof(RebookingDto.CreditValueChf), ExcelWorksheetColumn = 6, ExcelWorksheetCellText = "Credit Value" },
                new MyField() { Field = nameof(RebookingDto.Description), ExcelWorksheetColumn = 8, ExcelWorksheetCellText = "Text" }
            },
            RefreshFormulas = new MyField[]
            {
                new MyField() { ExcelWorksheetRow = 13, ExcelWorksheetColumn = 5 },
                new MyField() { ExcelWorksheetRow = 13, ExcelWorksheetColumn = 6 }
            }
        };

    #endregion
}
