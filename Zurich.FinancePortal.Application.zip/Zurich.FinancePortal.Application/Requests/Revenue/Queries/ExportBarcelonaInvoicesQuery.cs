﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using Newtonsoft.Json;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class ExportBarcelonaInvoicesQuery : BaseRequest<FileDto>
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public bool IncludePastFuture { get; set; }

        public Month Month { get; set; }

        public string[] LinesOfBusinessNames { get; set; }

        internal IEnumerable<LineOfBusiness> LinesOfBusiness { get; set; }

        #endregion
    }

    public sealed class ExportBarcelonaInvoicesQueryValidator : AbstractValidator<ExportBarcelonaInvoicesQuery>
    {
        #region --- CONSTRUCTORS ---

        public ExportBarcelonaInvoicesQueryValidator(IMasterDataRepository masterDataRepository)
        {
            RuleFor(x => x.Year).GreaterThan(0);
            RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
            RuleFor(x => x.LinesOfBusinessNames).MustAsync(async (x, linesOfBusinessNames, cancellationToken) =>
            {
                x.LinesOfBusiness = await GetBarcelonaInvoicesQueryHandler.GetLinesOfBusinessAsync(masterDataRepository, linesOfBusinessNames, cancellationToken: cancellationToken).ConfigureAwait(false);
                return x.LinesOfBusiness.Count().Equals(linesOfBusinessNames.Length);
            }).When(x => x.LinesOfBusinessNames != null && x.LinesOfBusinessNames.Any());
        }

        #endregion
    }

    public sealed class ExportBarcelonaInvoicesQueryHandler : BaseRequestHandler<ExportBarcelonaInvoicesQuery, FileDto>
    {
        #region --- CONSTRUCTORS ---

        public ExportBarcelonaInvoicesQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<FileDto>> Handle(ExportBarcelonaInvoicesQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_BarcelonaInvoices, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<FileDto>();
            // Load Configuration
            var configuration = (await GetOrCreateAndGetApplicationConfigurationByType<ExportBarcelonaInvoicesQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false));
            // Load Excel Template
            var templateName = configuration.TemplateName.ReplaceICIC(configuration.TemplateExtension, string.Empty);
            var file = await FileRepository.ReadFileAsync(FileType.RevenuesTemplate, $"{templateName}{configuration.TemplateExtension}", cancellationToken: cancellationToken).ConfigureAwait(false);
            if (file == null) return RequestResult.FromError<FileDto>(RequestResult.ERROR_NOTFOUND, $"Invalid Template Name: \"{templateName}\".");
            // Barcelona Invoices
            var query = new GetBarcelonaInvoicesQuery()
            {
                Year = request.Year,
                Month = request.Month,
                DataSourceRequest = request.DataSourceRequest,
                Dtos = request.Dtos,
                LinesOfBusiness = request.LinesOfBusiness,
                LinesOfBusinessNames = request.LinesOfBusinessNames,
                IncludePastFuture = request.IncludePastFuture
            };

            var queryResult = await Mediator.Send(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!queryResult.Success) return RequestResult.FromError<FileDto>(queryResult.ErrorType, queryResult.Message);
            var barcelonaInvoices = queryResult.Result.Results.ToArray();
            // Excel
            using var memoryStream = new MemoryStream(file);
            using var excelPackage = new ExcelPackage(memoryStream);
            // Prepare Worksheet
            PrepareWorksheet(excelPackage, configuration, request.Year, request.Month, request.IncludePastFuture, barcelonaInvoices);
            // Export Barcelona Invoices
            ExportBarcelonaInvoices(excelPackage, configuration, request.Year, barcelonaInvoices);
            // Update Worksheet
            UpdateWorksheet(excelPackage);
            // Result
            return RequestResult.FromResult(new FileDto() { Content = excelPackage.GetAsByteArray(), Name = $"{configuration.FileName.ReplaceICIC("{year}", request.Year.ToString()).ReplaceICIC("{month}", request.Month.ToString())}{configuration.TemplateExtension}", ContentType = configuration.ExcelContentType });
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static void PrepareWorksheet(ExcelPackage excelPackage, ExportBarcelonaInvoicesQueryConfiguration configuration, int year, Month month, bool includePastFuture, BarcelonaInvoiceDto[] barcelonaInvoices)
        {
            // Set the calculation mode to manual
            excelPackage.Workbook.CalcMode = ExcelCalcMode.Manual;
            // Year Worksheet
            var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
            // Get Refresh Formulas
            if (configuration.RefreshFormulas != null) configuration.RefreshFormulas.ForEach(x =>
            {
                x.Formula = worksheet.Cells[x.ExcelWorksheetRow, x.ExcelWorksheetColumn].Formula;
            });

            if (includePastFuture)
            {
                configuration.PastFutureFields?.ForEach(x =>
                {
                    var thisMonth = Enum.Parse<Month>(x.ExcelWorksheetCellText, true);
                    var column = worksheet.Cells[$"A{configuration.HeaderRowIndex}:{ExcelHelper.ToExcelColum(worksheet.Dimension.End.Column)}{configuration.HeaderRowIndex}"].Single(y => y.Text.EqualsICIC(x.ExcelWorksheetCellText)).Start.Column;
                    if (thisMonth.Equals(month - 1)) x.Formula = worksheet.Cells[x.ExcelWorksheetRow, column].Formula.ReplaceICIC(thisMonth.ToString(), configuration.PastString.Replace($"{{{nameof(Month)}}}", thisMonth.ToString()));
                    else x.Formula = worksheet.Cells[x.ExcelWorksheetRow, column].Formula.ReplaceICIC(thisMonth.ToString(), configuration.FutureString.Replace($"{{{nameof(Month)}}}", thisMonth.ToString()));
                });
            }
            // Past and Future
            configuration.PastFutureFields?.ForEach(x =>
            {
                var thisMonth = Enum.Parse<Month>(x.ExcelWorksheetCellText, true);
                var column = worksheet.Cells[$"A{configuration.HeaderRowIndex}:{ExcelHelper.ToExcelColum(worksheet.Dimension.End.Column)}{configuration.HeaderRowIndex}"].Single(y => y.Text.EqualsICIC(x.ExcelWorksheetCellText)).Start.Column;
                if (includePastFuture && (thisMonth.Equals(month - 1) || (thisMonth > month)))
                {
                    x.ExcelWorksheetColumn = column;
                    if (thisMonth.Equals(month - 1)) worksheet.Cells[configuration.HeaderRowIndex, column].Value = configuration.PastString.Replace($"{{{nameof(Month)}}}", thisMonth.ToString());
                    else worksheet.Cells[configuration.HeaderRowIndex, column].Value = configuration.FutureString.Replace($"{{{nameof(Month)}}}", thisMonth.ToString());
                }
                // Delete
                else
                {
                    worksheet.DeleteColumn(column);
                }
            });
            // Rename Worksheet
            worksheet.Name = year.ToString();
            // Copy Base Row to Rows
            var rowsCount = barcelonaInvoices.Length - configuration.TableDefaultSize;
            if (rowsCount > 0) worksheet.InsertRow(configuration.HeaderRowIndex + configuration.TableDefaultSize, rowsCount);
        }

        private static void ExportBarcelonaInvoices(ExcelPackage excelPackage, ExportBarcelonaInvoicesQueryConfiguration configuration, int year, BarcelonaInvoiceDto[] barcelonaInvoices)
        {
            var biCount = barcelonaInvoices.Length;
            // Year Worksheet
            var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(year.ToString()));
            // Get Headers Cells
            var revenuesHeaderCells = worksheet.Cells[$"A{configuration.HeaderRowIndex}:{ExcelHelper.ToExcelColum(worksheet.Dimension.End.Column)}{configuration.HeaderRowIndex}"];
            // Set Headers
            configuration.Fields.ForEach(f =>
            {
                f.ExcelWorksheetColumn = revenuesHeaderCells.Single(c => c?.Value?.ToString()?.EqualsICIC(f.ExcelWorksheetCellText) ?? false).Start.Column;
            });
            // Loop Barcelona Invoices
            for (var i = 0; i < biCount; i++)
            {
                var barcelonaInvoice = barcelonaInvoices.ElementAt(i);
                configuration.Fields.ForEach(x =>
                {
                    worksheet.Cells[configuration.HeaderRowIndex + 1 + i, x.ExcelWorksheetColumn].Value = barcelonaInvoice.GetType().GetProperty(x.Field).GetValue(barcelonaInvoice);
                });

                configuration.PastFutureFields?.Where(x => x.ExcelWorksheetColumn > 0)?.ForEach(x =>
                {
                    worksheet.Cells[configuration.HeaderRowIndex + 1 + i, x.ExcelWorksheetColumn].Value = ((IDictionary<Month, decimal>)barcelonaInvoice.GetType().GetProperty(nameof(BarcelonaInvoiceDto.PastFutureTotalEur)).GetValue(barcelonaInvoice))[Enum.Parse<Month>(x.ExcelWorksheetCellText, true)];
                });
            }
            // Refresh Formulas
            configuration.RefreshFormulas?.ForEach(x =>
            {
                worksheet.Cells[x.ExcelWorksheetRow + ((biCount - configuration.TableDefaultSize) > 0 ? (biCount - configuration.TableDefaultSize) : 0), x.ExcelWorksheetColumn].Formula = x.Formula;
            });

            configuration.PastFutureFields?.Where(x => x.ExcelWorksheetColumn > 0)?.ForEach(x =>
            {
                worksheet.Cells[x.ExcelWorksheetRow + ((biCount - configuration.TableDefaultSize) > 0 ? (biCount - configuration.TableDefaultSize) : 0), x.ExcelWorksheetColumn].Formula = x.Formula;
            });
        }

        private static void UpdateWorksheet(ExcelPackage excelPackage) =>
            // Set the calculation mode to automatic
            excelPackage.Workbook.CalcMode = ExcelCalcMode.Automatic;

        #endregion

        internal sealed class ExportBarcelonaInvoicesQueryConfiguration
        {
            #region --- PROPERTIES ---

            [JsonProperty]
            internal string TemplateName { get; set; }

            [JsonProperty]
            internal string TemplateExtension { get; set; }

            [JsonProperty]
            internal string SheetName { get; set; }

            [JsonProperty]
            internal int HeaderRowIndex { get; set; }

            [JsonProperty]
            internal int TableDefaultSize { get; set; }

            [JsonProperty]
            internal string FileName { get; set; }

            [JsonProperty]
            internal string ExcelContentType { get; set; }

            [JsonProperty]
            internal string PastString { get; set; }

            [JsonProperty]
            internal string FutureString { get; set; }

            #endregion

            #region --- REFERENCES ---

            [JsonProperty]
            internal string[] ChargingModelsCodes { get; set; }

            [JsonProperty]
            internal MyField[] Fields { get; set; }

            [JsonProperty]
            internal MyField[] PastFutureFields { get; set; }

            [JsonProperty]
            internal MyField[] RefreshFormulas { get; set; }

            #endregion

            #region --- INTERNAL METHODS ---

            internal static ExportBarcelonaInvoicesQueryConfiguration CreateDefault() =>
                new()
                {
                    ChargingModelsCodes = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode },
                    TemplateName = "BarcelonaInvoices_Default",
                    FileName = "Servizurich Intercompany Charges-Out- {year} - {month}",
                    TemplateExtension = ".xlsx",
                    SheetName = "Year",
                    ExcelContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    HeaderRowIndex = 1,
                    TableDefaultSize = 2,
                    PastString = $"Past {{{nameof(Month)}}}",
                    FutureString = $"Future {{{nameof(Month)}}}",
                    Fields = new MyField[]
                    {
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.InternalCostCenterPerCostCode), ExcelWorksheetCellText = "Cost Center" },
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.BusinessUnitCode), ExcelWorksheetCellText = "BU Code" },
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.ProjectName), ExcelWorksheetCellText = "Project" },
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.Description), ExcelWorksheetCellText = "Description" },
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.CustomerCostCenterCode), ExcelWorksheetCellText = "CC Customer" },
                        new MyField(){ Field = nameof(BarcelonaInvoiceDto.TotalEur), ExcelWorksheetCellText = "EUR NO VAT" }
                    },
                    RefreshFormulas = new MyField[]
                    {
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetColumn = 7 },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetColumn = 8 },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetColumn = 9 }
                    },
                    PastFutureFields = new MyField[]
                    {
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.January) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.February) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.March) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.April) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.May) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.June) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.July) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.August) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.September) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.October) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.November) },
                        new MyField() { ExcelWorksheetRow = 5, ExcelWorksheetCellText = nameof(Month.December) }
                    }
                };

            #endregion
        }
    }
}
