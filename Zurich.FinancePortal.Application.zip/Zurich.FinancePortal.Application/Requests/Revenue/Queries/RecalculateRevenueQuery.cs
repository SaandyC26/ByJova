﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public class RecalculateRevenueQuery : BaseRequest<RecalculateRevenueQueryResult>
    {
        #region --- REFERENCES ---

        public RevenueDto Revenue { get; set; }

        #endregion
    }

    public sealed class RecalculateRevenueQueryResult
    {
        #region --- PROPERTIES ---

        public decimal? FYFCLC { get; set; }

        public decimal? FYFCCHF { get; set; }

        public decimal? FYFCCHFVAT { get; set; }

        #endregion
    }

    public sealed class RecalculateRevenueQueryValidator : AbstractValidator<RecalculateRevenueQuery>
    {
        #region --- CONSTRUCTORS ---

        public RecalculateRevenueQueryValidator()
        {
            RuleFor(x => x.Revenue).NotNull();
            RuleFor(x => x.Revenue.CurrencyCode).NotNull().NotEmpty().When(x => x.Revenue != null);
            RuleFor(x => x.Revenue.Year).GreaterThan(0).When(x => x.Revenue != null);
        }

        #endregion
    }

    public sealed class RecalculateRevenueQueryHandler : BaseRequestHandler<RecalculateRevenueQuery, RecalculateRevenueQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public RecalculateRevenueQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<RecalculateRevenueQueryResult>> Handle(RecalculateRevenueQuery request, CancellationToken cancellationToken)
        {
            // Get Currencies
            var currencies = await MasterDataRepository.GetMasterDatasByEntityAsync<Currency>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            var currency = currencies.SingleOrDefault(c => c.Code.EqualsICIC(request.Revenue.CurrencyCode));
            if (currency == null) return RequestResult.FromError<RecalculateRevenueQueryResult>(RequestResult.ERROR_NOTFOUND, $"{nameof(Currency)} with {nameof(Currency.Code)} \"{request.Revenue.CurrencyCode}\" not found.");
            // Get CurrencyExchangeRatess
            var currencyExchangeRages = await MasterDataRepository.GetCurrenciesExchangeRatesByFromAndYearAsync(request.Revenue.Year, request.Revenue.CurrencyCode, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Get ValueAddedTaxes
            var valueAddedTax = (await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).SingleOrDefault(vat => vat.Country.Equals(ValueAddedTax.SwitzerlandCountry, StringComparison.InvariantCultureIgnoreCase));
            var valueAddedTax2024 = (await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false)).SingleOrDefault(vat => vat.Country.Equals(ValueAddedTax.SwitzerlandCountry2024, StringComparison.InvariantCultureIgnoreCase));
            if (valueAddedTax == null && valueAddedTax2024 == null) return RequestResult.FromError<RecalculateRevenueQueryResult>(RequestResult.ERROR_NOTFOUND, $"{nameof(ValueAddedTax)} with {nameof(ValueAddedTax.Country)} \"{ValueAddedTax.SwitzerlandCountry}\" not found.");
            // Recalculate
            var monthRevenues = request.Revenue.GetMonthsRevenuesProperties().Select(p => (Enum.Parse<Month>(p.Name, true), ((MonthRevenueDto)p.GetValue(request.Revenue))?.Amount));
            request.Revenue.FYFCLC = Revenue.GetFYFCLC(monthRevenues);
            request.Revenue.FYFCCHF = Revenue.GetFYFCCHF(request.Revenue.Year, monthRevenues, currency, currencyExchangeRages);
            if (request.Revenue.Year == 2024)
            {
                request.Revenue.FYFCCHFVAT = Revenue.GetFYFCCHFVAT(request.Revenue.FYFCCHF, valueAddedTax2024);
            }
            else
            {
                request.Revenue.FYFCCHFVAT = Revenue.GetFYFCCHFVAT(request.Revenue.FYFCCHF, valueAddedTax);
            }
            return RequestResult.FromResult(new RecalculateRevenueQueryResult() { FYFCLC = request.Revenue.FYFCLC, FYFCCHF = request.Revenue.FYFCCHF, FYFCCHFVAT = request.Revenue.FYFCCHFVAT });
        }

        #endregion
    }
}
