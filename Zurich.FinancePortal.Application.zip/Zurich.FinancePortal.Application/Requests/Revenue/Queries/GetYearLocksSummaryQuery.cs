﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using DevOps.Application;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetYearLocksSummaryQuery : BaseRequest<GetYearLocksSummaryQueryResult>
    {
        #region --- REFERENCES ---

        public int[] Years { get; set; }

        #endregion
    }

    public sealed class GetYearLocksSummaryQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<YearLocksDto> Summaries { get; set; }

        #endregion
    }

    public sealed class GetYearLocksSummaryHandler : BaseRequestHandler<GetYearLocksSummaryQuery, GetYearLocksSummaryQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetYearLocksSummaryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetYearLocksSummaryQueryResult>> Handle(GetYearLocksSummaryQuery request, CancellationToken cancellationToken)
        {
            var lockedRevenuesYearsSummary = await RevenueRepository.GetYearLocksAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            var years = await RevenueRepository.GetRevenuesYearsAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            var chargingModelsTypes = await MasterDataRepository.GetMasterDatasByEntityAsync<ChargingModelType>(cancellationToken: cancellationToken).ConfigureAwait(false);
            var dtos = Mapper.Map<IEnumerable<YearLocks>, IEnumerable<YearLocksDto>>(lockedRevenuesYearsSummary);
            var extraDtos = new List<YearLocksDto>();
            foreach (var year in years) foreach (var chargingModelType in chargingModelsTypes) if (!dtos.Any(x => !x.Year.Equals(year) && !x.ChargingModelType.Type.EqualsICIC(chargingModelType.Type))) extraDtos.Add(new YearLocksDto() { Year = year, ChargingModelType = new ChargingModelTypeDto() { Id = chargingModelType.Id, Type = chargingModelType.Type } });
            dtos = dtos.Concat(extraDtos);
            var result = new GetYearLocksSummaryQueryResult()
            {
                Summaries = dtos.OrderBy(x => x.Year).ThenBy(x => x.ChargingModelType.Type),
                Count = dtos.Count()
            };

            return RequestResult.FromResult(result);
        }

        #endregion
    }
}
