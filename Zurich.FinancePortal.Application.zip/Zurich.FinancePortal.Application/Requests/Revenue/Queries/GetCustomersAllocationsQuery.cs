﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetCustomersAllocationsQuery : BaseRequest<GetCustomersAllocationsQueryResult>
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public Month Month { get; set; }

        #endregion
    }

    public sealed class GetCustomersAllocationsQueryValidator : AbstractValidator<GetCustomersAllocationsQuery>
    {
        #region --- CONSTRUCTORS ---

        public GetCustomersAllocationsQueryValidator()
        {
            RuleFor(x => x.Year).GreaterThan(0);
            RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
        }

        #endregion
    }

    public sealed class GetCustomersAllocationsQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<CustomerAllocationDto> Results { get; set; }

        #endregion
    }

    public sealed class GetCustomersAllocationsQueryHandler : BaseRequestHandler<GetCustomersAllocationsQuery, GetCustomersAllocationsQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetCustomersAllocationsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetCustomersAllocationsQueryResult>> Handle(GetCustomersAllocationsQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_CustomersAllocations, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<GetCustomersAllocationsQueryResult>();
            // Load Configuration
            var configuration = (await GetOrCreateAndGetApplicationConfigurationByType<GetCustomersAllocationsQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false));
            // Get ChargingModels
            var chargingModels = (await MasterDataRepository.GetChargingModelsAsync(cancellationToken: cancellationToken).ConfigureAwait(false))
                .Where(cm => configuration.ChargingModelsCodes.ContainsICIC(cm.Code));
            // Get Invoices
            var (count, customersAllocations) = await RevenueFrontEndRepository.GetCustomersAllocationsAsync(request.Year, request.Month, chargingModels, dataSourceRequest: request.DataSourceRequest, includeCount: true, separator: configuration.Separator, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromResult(new GetCustomersAllocationsQueryResult() { Count = count, Results = customersAllocations });
        }

        #endregion
    }

    internal sealed class GetCustomersAllocationsQueryConfiguration
    {
        #region --- PROPERTIES ---

        public string Separator { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<string> ChargingModelsCodes { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static GetCustomersAllocationsQueryConfiguration CreateDefault() =>
            new()
            {
                Separator = " / ",
                ChargingModelsCodes = new string[] { ChargingModel.CaChargingModelCode },
            };

        #endregion
    }
}
