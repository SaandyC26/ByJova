﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetRevenuesTemplateQuery : BaseRequest<FileDto>
    { }

    public sealed class GetRevenuesTemplateQueryHandler : BaseRequestHandler<GetRevenuesTemplateQuery, FileDto>
    {
        #region --- CONSTRUCTORS ---

        public GetRevenuesTemplateQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<FileDto>> Handle(GetRevenuesTemplateQuery request, CancellationToken cancellationToken)
        {
            var query = new ExportRevenuesTemplateQuery()
            {
                Empty = true
            };

            return await Mediator.Send(query, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        #endregion
    }
}
