﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using Newtonsoft.Json;
    using OfficeOpenXml;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class ExportCustomersAllocationsQuery : BaseRequest<FileDto>
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public Month Month { get; set; }

        #endregion
    }

    public sealed class ExportCustomersAllocationsQueryValidator : AbstractValidator<ExportCustomersAllocationsQuery>
    {
        #region --- CONSTRUCTORS ---

        public ExportCustomersAllocationsQueryValidator()
        {
            RuleFor(x => x.Year).GreaterThan(0);
            RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
        }

        #endregion
    }

    public sealed class ExportCustomersAllocationsQueryHandler : BaseRequestHandler<ExportCustomersAllocationsQuery, FileDto>
    {
        #region --- CONSTRUCTORS ---

        public ExportCustomersAllocationsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<FileDto>> Handle(ExportCustomersAllocationsQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_CustomersAllocations, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<FileDto>();
            // Load Configuration
            var configuration = await GetOrCreateAndGetApplicationConfigurationByType<ExportCustomersAllocationsQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Load Excel Template
            var templateName = configuration.TemplateName.ReplaceICIC(configuration.TemplateExtension, string.Empty);
            var file = await FileRepository.ReadFileAsync(FileType.RevenuesTemplate, $"{templateName}{configuration.TemplateExtension}", cancellationToken: cancellationToken).ConfigureAwait(false);
            if (file == null) return RequestResult.FromError<FileDto>(RequestResult.ERROR_NOTFOUND, $"Invalid Template Name: \"{templateName}\".");
            // Get Customers Allocations
            var query = new GetCustomersAllocationsQuery()
            {
                Year = request.Year,
                Month = request.Month,
                DataSourceRequest = request.DataSourceRequest,
                Dtos = request.Dtos
            };

            var queryResult = await Mediator.Send(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (!queryResult.Success) return RequestResult.FromError<FileDto>(queryResult.ErrorType, queryResult.Message);
            configuration.DuplicatedInternalCostCenterPerCostCodes?.Split(";;", StringSplitOptions.RemoveEmptyEntries)?.ForEach(d =>
            {
                var first = d.Split(";", StringSplitOptions.RemoveEmptyEntries).First();
                var last = d.Split(";", StringSplitOptions.RemoveEmptyEntries).Last();
                var firsts = queryResult.Result.Results.Where(ca => ca.InternalCostCenterPerCostCode.EqualsICIC(first));
                var duplicates = new List<CustomerAllocationDto>();
                foreach (var f in firsts)
                {
                    var ca = new CustomerAllocationDto(separator: configuration.Separator)
                    {
                        InternalCostCenterPerCostCode = last
                    };

                    f.GetType().GetProperties().Where(p => p.SetMethod is not null && !p.Name.EqualsICIC(nameof(CustomerAllocationDto.InternalCostCenterPerCostCode))).ForEach(p => p.SetValue(ca, p.GetValue(f)));
                    duplicates.Add(ca);
                }

                queryResult.Result.Results = queryResult.Result.Results.Concat(duplicates).ToArray();
            });
            // Excel
            using var memoryStream = new MemoryStream(file);
            using var excelPackage = new ExcelPackage(memoryStream);
            var customersAllocations = queryResult.Result.Results.ToArray();
            // Prepare Worksheet
            PrepareWorksheet(excelPackage, configuration, customersAllocations);
            // Export Rebookings
            ExportCustomersAllocations(excelPackage, configuration, customersAllocations);
            // Update Worksheet
            UpdateWorksheet(excelPackage);
            // Result
            return RequestResult.FromResult(new FileDto() { Content = excelPackage.GetAsByteArray(), Name = $"{configuration.FileName.ReplaceICIC("{year}", request.Year.ToString()).ReplaceICIC("{month}", request.Month.ToString())}{configuration.TemplateExtension}", ContentType = configuration.ExcelContentType });
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static void PrepareWorksheet(ExcelPackage excelPackage, ExportCustomersAllocationsQueryConfiguration configuration, CustomerAllocationDto[] customersAllocations)
        {
            // Set the calculation mode to manual
            excelPackage.Workbook.CalcMode = ExcelCalcMode.Manual;
            // Worksheet
            var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
            // Copy Base Row to Rows
            var rowsCount = customersAllocations.Length - configuration.TableDefaultSize;
            if (rowsCount > 0) worksheet.InsertRow(configuration.HeaderRowIndex + configuration.TableDefaultSize, rowsCount, configuration.HeaderRowIndex + configuration.TableDefaultSize - 1);
        }

        private static void ExportCustomersAllocations(ExcelPackage excelPackage, ExportCustomersAllocationsQueryConfiguration configuration, CustomerAllocationDto[] customersAllocations)
        {
            var caCount = customersAllocations.Length;
            // Worksheet
            var worksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(configuration.SheetName));
            // Loop Customers Allocations
            for (var i = 0; i < caCount; i++)
            {
                var customerAllocation = customersAllocations.ElementAt(i);
                configuration.Fields.ForEach(f =>
                {
                    worksheet.Cells[configuration.HeaderRowIndex + 1 + i, f.ExcelWorksheetColumn].Value = customerAllocation.GetType().GetProperty(f.Field).GetValue(customerAllocation);
                });
            }
        }

        private static void UpdateWorksheet(ExcelPackage excelPackage) =>
            // Set the calculation mode to automatic
            excelPackage.Workbook.CalcMode = ExcelCalcMode.Automatic;

        #endregion
    }

    internal sealed class ExportCustomersAllocationsQueryConfiguration
    {
        #region --- PROPERTIES ---

        public string Separator { get; set; }

        [JsonProperty]
        internal string TemplateName { get; set; }

        [JsonProperty]
        internal string TemplateExtension { get; set; }

        [JsonProperty]
        internal string SheetName { get; set; }

        [JsonProperty]
        internal int TableDefaultSize { get; set; }

        [JsonProperty]
        internal int HeaderRowIndex { get; set; }

        [JsonProperty]
        internal string FileName { get; set; }

        [JsonProperty]
        internal string ExcelContentType { get; set; }

        [JsonProperty]
        internal string DuplicatedInternalCostCenterPerCostCodes { get; set; }

        #endregion

        #region --- REFERENCES ---

        [JsonProperty]
        internal MyField[] Fields { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static ExportCustomersAllocationsQueryConfiguration CreateDefault() =>
            new()
            {
                Separator = " / ",
                TemplateName = "CustomersAllocations_Default",
                TemplateExtension = ".xlsx",
                SheetName = "Template",
                FileName = "S2C Allocation - {year} - {month}",
                ExcelContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                TableDefaultSize = 2,
                HeaderRowIndex = 1,
                DuplicatedInternalCostCenterPerCostCodes = "C500045001;C500044000;;",
                Fields = new MyField[]
                {
                    new MyField() { Field = nameof(CustomerAllocationDto.ChargingModelCode), ExcelWorksheetColumn = 1, ExcelWorksheetCellText = "Charging Model" },
                    new MyField() { Field = nameof(CustomerAllocationDto.LineOfBusinessName), ExcelWorksheetColumn = 2, ExcelWorksheetCellText = "Line of Business" },
                    new MyField() { Field = nameof(CustomerAllocationDto.CustomerName), ExcelWorksheetColumn = 3, ExcelWorksheetCellText = "Customer" },
                    new MyField() { Field = nameof(CustomerAllocationDto.ServiceDescription), ExcelWorksheetColumn = 4, ExcelWorksheetCellText = "Service Description" },
                    new MyField() { Field = nameof(CustomerAllocationDto.InternalCostCenterPerCostCode), ExcelWorksheetColumn = 5, ExcelWorksheetCellText = $"Internal Cost Center{Environment.NewLine}(COST CENTER CODE)" },
                    new MyField() { Field = nameof(CustomerAllocationDto.BusinessUnitCode), ExcelWorksheetColumn = 6, ExcelWorksheetCellText = $"BU Code{Environment.NewLine}(CD1 Code)" },
                    new MyField() { Field = nameof(CustomerAllocationDto.Percentage), ExcelWorksheetColumn = 7, ExcelWorksheetCellText = "Alloc %" },
                    new MyField() { Field = nameof(CustomerAllocationDto.TotalChf), ExcelWorksheetColumn = 8, ExcelWorksheetCellText = "Total CHF" },
                    new MyField() { Field = nameof(CustomerAllocationDto.TotalChfVat), ExcelWorksheetColumn = 9, ExcelWorksheetCellText = "Total CHF VAT" }
                }
            };

        #endregion
    }
}
