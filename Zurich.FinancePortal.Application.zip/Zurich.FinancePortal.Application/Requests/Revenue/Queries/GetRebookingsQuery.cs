﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class GetRebookingsQuery : BaseRequest<GetRebookingsQueryResult>
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public Month Month { get; set; }

        public string InternalCostCenterCode { get; set; }

        internal CostCenter CostCenter { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        public GetRebookingsQuery() { }

        internal GetRebookingsQuery(int year, Month month, string internalCostCenterCode, CostCenter costCenter)
        {
            Year = year;
            Month = month;
            InternalCostCenterCode = internalCostCenterCode;
            CostCenter = costCenter;
        }

        #endregion
    }

    public sealed class GetRebookingsQueryValidator : AbstractValidator<GetRebookingsQuery>
    {
        #region --- CONSTRUCTORS ---

        public GetRebookingsQueryValidator(IMasterDataRepository masterDataRepository)
        {
            RuleFor(x => x.Year).GreaterThan(0);
            RuleFor(x => x.Month).IsInEnum().NotEqual(Month.None);
            RuleFor(x => x.InternalCostCenterCode).NotEmpty().MustAsync(async (query, x, cancellationToken) =>
            {
                query.CostCenter = await GetRebookingsQueryHandler.GetCostCenterAsync(masterDataRepository, x, cancellationToken: cancellationToken).ConfigureAwait(false);
                return query.CostCenter != null;
            });
        }

        #endregion
    }

    public sealed class GetRebookingsQueryResult
    {
        #region --- PROPERTIES ---

        public int Count { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<RebookingDto> Results { get; set; }

        #endregion
    }

    public sealed class GetRebookingsQueryHandler : BaseRequestHandler<GetRebookingsQuery, GetRebookingsQueryResult>
    {
        #region --- CONSTRUCTORS ---

        public GetRebookingsQueryHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<GetRebookingsQueryResult>> Handle(GetRebookingsQuery request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_Rebookings, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<GetRebookingsQueryResult>();
            // Get Configuration
            var configuration = await GetOrCreateAndGetApplicationConfigurationByType<GetRebookingsQueryConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Get ChargingModels
            var chargingModels = (await MasterDataRepository.GetChargingModelsAsync(cancellationToken: cancellationToken).ConfigureAwait(false))
                .Where(cm => configuration.ChargingModelsCodes.ContainsICIC(cm.Code));
            // Get Rebookings
            var (count, rebookings) = await RevenueFrontEndRepository.GetRebookingsAsync(request.Year, request.Month, request.CostCenter ?? await GetCostCenterAsync(MasterDataRepository, request.InternalCostCenterCode, cancellationToken: cancellationToken).ConfigureAwait(false), chargingModels, dataSourceRequest: request.DataSourceRequest, includeCount: true, separator: configuration.Separator, descriptionProperties: configuration.DescriptionProperties, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Extra Rebookings Rows
            var extraRebookings = Array.Empty<RebookingDto>();
            if (rebookings.Any())
            {
                var rbiAmmounts = rebookings.Where(r => r.ChargingModelCode.EqualsICIC(ChargingModel.RbiChargingModelCode)).Select(r => r.DebitValueChf);
                var rbdAmmounts = rebookings.Where(r => r.ChargingModelCode.EqualsICIC(ChargingModel.RbdChargingModelCode)).Select(r => r.DebitValueChf);
                extraRebookings = new RebookingDto[]
                {
                    new RebookingDto(separator: configuration.Separator, description: configuration.RbiDescription.ReplaceICIC("{month}", request.Month.ToString()).ReplaceICIC("{year}", request.Year.ToString()), descriptionProperties: configuration.DescriptionProperties)
                    {
                        ChargingModelCode = ChargingModel.RbiChargingModelCode,
                        CustomerCostCenterCode = request.InternalCostCenterCode,
                        CreditValueChf = rbiAmmounts.Sum()
                    },
                    new RebookingDto(configuration.Separator, description: configuration.RbdDescription.ReplaceICIC("{month}", request.Month.ToString()).ReplaceICIC("{year}", request.Year.ToString()), descriptionProperties: configuration.DescriptionProperties)
                    {
                        ChargingModelCode = ChargingModel.RbdChargingModelCode,
                        CustomerCostCenterCode = request.InternalCostCenterCode,
                        CreditValueChf = rbdAmmounts.Sum()
                    }
                };
            }
            // Result
            return RequestResult.FromResult(new GetRebookingsQueryResult() { Count = count, Results = extraRebookings.Concat(rebookings) });
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal async static Task<CostCenter> GetCostCenterAsync(IMasterDataRepository masterDataRepository, string code, CancellationToken cancellationToken = default) =>
            (await masterDataRepository.GetMasterDatasByEntityAsync<CostCenter>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false))
                .SingleOrDefault(cc => cc.IsInternal() && cc.Code.EqualsICIC(code));

        #endregion
    }

    internal sealed class GetRebookingsQueryConfiguration
    {
        #region --- PROPERTIES ---

        public string RbiDescription { get; set; }

        public string RbdDescription { get; set; }

        public string Separator { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<string> ChargingModelsCodes { get; set; }

        public IEnumerable<string> DescriptionProperties { get; set; }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static GetRebookingsQueryConfiguration CreateDefault() =>
            new()
            {
                Separator = " / ",
                RbiDescription = "Services {month} {year}",
                RbdDescription = "Services {month} {year}",
                ChargingModelsCodes = new string[] { ChargingModel.RbiChargingModelCode, ChargingModel.RbdChargingModelCode }
            };

        #endregion
    }
}
