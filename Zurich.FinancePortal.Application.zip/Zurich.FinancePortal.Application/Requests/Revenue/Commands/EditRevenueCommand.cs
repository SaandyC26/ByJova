﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using FluentValidation;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class EditRevenueCommand : BaseRequest<EditRevenueCommandResult>
    {
        #region --- REFERENCES ---

        public RevenueDto Revenue { get; set; }

        #endregion
    }

    public sealed class EditRevenueCommandValidator : AbstractValidator<EditRevenueCommand>
    {
        #region --- CONSTRUCTORS ---

        public EditRevenueCommandValidator()
        {
            RuleFor(x => x.Revenue).NotNull();
            RuleFor(x => x.Revenue.Id).GreaterThan(0).When(x => x.Revenue != null);
        }

        #endregion
    }

    public sealed class EditRevenueCommandResult
    {
        #region --- PROPERTIES ---

        public RevenueDto Revenue { get; set; }

        #endregion
    }

    public sealed class EditRevenueCommandHandler : BaseRequestHandler<EditRevenueCommand, EditRevenueCommandResult>
    {
        #region --- CONSTRUCTORS ---

        public EditRevenueCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<EditRevenueCommandResult>> Handle(EditRevenueCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_ManageRevenue, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<EditRevenueCommandResult>();
            // Get Revenue
            var revenuesConfiguration = await GetOrCreateAndGetApplicationConfigurationByType<RevenuesConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
            var (_, errors) = await RevenueService.CreateUpdateRevenuesFromDtoAsync(revenuesConfiguration, new RevenueDto[] { request.Revenue }, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Check Errors
            if (errors.Single().Any()) return RequestResult.FromError<EditRevenueCommandResult>(RequestResult.ERROR_BADREQUEST, string.Join(Environment.NewLine, errors.Single()));
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Revenue
            var revenue = await RevenueService.GetRevenueByIdAsync(request.Revenue.Id, dtos: request.Dtos, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromResult(new EditRevenueCommandResult() { Revenue = revenue });
        }

        #endregion
    }
}
