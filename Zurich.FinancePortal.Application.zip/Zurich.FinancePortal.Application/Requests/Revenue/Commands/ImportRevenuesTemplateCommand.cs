﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public sealed class ImportRevenuesTemplateCommand : BaseRequest<Unit>
{
    #region --- REFERENCES ---

    public IFormFile File { get; set; }

    #endregion
}

public sealed class ImportRevenuesTemplateCommandValidator : AbstractValidator<ImportRevenuesTemplateCommand>
{
    #region --- CONSTRUCTORS ---

    public ImportRevenuesTemplateCommandValidator()
    {
        RuleFor(x => x.File).NotNull();
    }

    #endregion
}

public sealed class ImportRevenuesTemplateCommandHandler : BaseRequestHandler<ImportRevenuesTemplateCommand, Unit>
{
    #region --- PROPERTIES ---

    private readonly string _invalidFile = $"Invalid File:{Environment.NewLine}";

    #endregion

    #region --- REFERENCES ---

    private readonly IDictionary<string, int> _headersColumns;

    #endregion

    #region --- CONSTRUCTORS ---

    public ImportRevenuesTemplateCommandHandler(IServiceProvider services) : base(services)
    {
        _headersColumns = new Dictionary<string, int>();
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<Unit>> Handle(ImportRevenuesTemplateCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ImportRevenues, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
        // Check File Length
        if (request.File.Length.Equals(0)) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{_invalidFile}File length is 0.");
        // Load Configuration
        var configuration = (await GetOrCreateAndGetApplicationConfigurationByType<ImportRevenuesTemplateCommandConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false));
        // Check File Extension
        var fileExtension = Path.GetExtension(request.File.FileName);
        if (!configuration.SupportedFileExtensions.Contains(fileExtension, StringComparer.InvariantCultureIgnoreCase))
        {
            return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{_invalidFile}Invalid file extension. Expected \"{string.Join(", ", configuration.SupportedFileExtensions)}\" but was \"{fileExtension}\".");
        }
        //  Load Fields
        var fields = await FieldRepository.GetFieldsByEntityAsync<Revenue>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Read ExcelPackage
        using var file = request.File.OpenReadStream();
        using var excelPackage = new ExcelPackage(file);
        // Validate File Structure
        var validateFileStructureResult = ValidateFileStructure(excelPackage, configuration, fields);
        if (!validateFileStructureResult.Success) return validateFileStructureResult;
        // Extract File Data
        var (result, revenues) = ExtractFileData(excelPackage, configuration, fields);
        if (!result.Success) return result;
        // Create or Update Revenues
        var revenuesConfiguration = await GetOrCreateAndGetApplicationConfigurationByType<RevenuesConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
        var (_, errors) = await RevenueService.CreateUpdateRevenuesFromDtoAsync(revenuesConfiguration, revenues, isExcelImport: true, initialLine: configuration.HeaderRowIndex + 1, refreshRevenues: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        if (errors.Any(e => e.Any()))
        {
            return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, string.Join(Environment.NewLine, errors.SelectMany(e => e)));
        }
        else
        {
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        }
        // Result
        return RequestResult.FromSuccess();
    }

    #endregion

    #region --- PRIVATE METHODS ---

    private RequestResult<Unit> ValidateFileStructure(ExcelPackage excelPackage, ImportRevenuesTemplateCommandConfiguration configuration, IEnumerable<Field> fields)
    {
        try
        {
            var errors = new StringBuilder();
            // Revenues Excel Worksheet
            var revenuesWorksheetName = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Project))).WorksheetOnFile;
            var revenuesWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(revenuesWorksheetName));
            if (revenuesWorksheet == null)
            {
                return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{_invalidFile}{nameof(ExcelWorksheet)} \"{revenuesWorksheetName}\" does not exists.");
            }
            // Verify Excel File Structure
            var revenuesHeaderCells = revenuesWorksheet.Cells[$"A{configuration.HeaderRowIndex}:{revenuesWorksheet.Dimension.End.Column.ToExcelColum()}{configuration.HeaderRowIndex}"];
            foreach (var field in fields.Where(f => !string.IsNullOrWhiteSpace(f.WorksheetOnFile) && !string.IsNullOrWhiteSpace(f.LabelOnFile)))
            {
                if (field.WorksheetOnFile.EqualsICIC(revenuesWorksheetName))
                {
                    if (!revenuesHeaderCells.Any(c => c.Value?.ToString()?.ReplaceICIC(" *", string.Empty)?.EqualsICIC(field.LabelOnFile) ?? false))
                    {
                        _ = errors.AppendLine($"Column with header \"{field.LabelOnFile}\" is required but was not found in the file.");
                    }
                    else
                    {
                        _headersColumns.Add(field.EntityReference, revenuesHeaderCells.Single(c => c.Value?.ToString()?.Replace(" *", string.Empty)?.EqualsICIC(field.LabelOnFile) ?? false).Start.Column);
                    }
                }
                else
                {
                    throw new InvalidDataException($"Invalid {nameof(Field)} {nameof(Field.WorksheetOnFile)} \"{field.WorksheetOnFile}\" for {nameof(Field)} \"{field.Entity} - {field.EntityReference}\".");
                }
            }
            // Result
            if (errors.Length > 0) return RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{_invalidFile}{errors}");
            return RequestResult.FromSuccess();
        }
        catch (Exception exception)
        {
            Logger.LogWarning(exception, $"Exception while {nameof(ValidateFileStructure)}.");
            return RequestResult.FromError(RequestResult.ERROR_UNKNOWN, $"{_invalidFile}{exception.Message}");
        }
    }

    [SuppressMessage("Major Code Smell", "S3358: Ternary operators should not be nested", Justification = "N/A")]
    private (RequestResult<Unit> Result, IEnumerable<RevenueDto> Revenues) ExtractFileData(ExcelPackage excelPackage, ImportRevenuesTemplateCommandConfiguration configuration, IEnumerable<Field> fields)
    {
        var errors = new StringBuilder();
        var revenues = new List<RevenueDto>();
        // Revenues Excel Worksheet
        var revenuesWorksheetName = fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Project))).WorksheetOnFile;
        var revenuesWorksheet = excelPackage.Workbook.Worksheets.SingleOrDefault(ws => ws.Name.EqualsICIC(revenuesWorksheetName));
        try
        {
            // Dynamic Data Excel Worksheet
            var endRowIndex = revenuesWorksheet
                .Cells[revenuesWorksheet.Dimension.Start.Row, revenuesWorksheet.Dimension.Start.Column, revenuesWorksheet.Dimension.Rows, revenuesWorksheet.Dimension.Columns]
                .Where(cell => !(cell.Text?.Equals("0") ?? false) && !string.IsNullOrWhiteSpace(cell.Value?.ToString()))
                .Select(erb => erb.End.Row)
                .LastOrDefault();

            if ((endRowIndex - configuration.HeaderRowIndex) > configuration.MaxRows) return (RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"Max Rows: {configuration.MaxRows}."), null);
            for (var i = configuration.HeaderRowIndex + 1; i <= endRowIndex; i++)
            {
                // Revenue
                var revenue = new RevenueDto()
                {
                    Id = 0,
                    LineOfBusinessName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.LineOfBusiness))).EntityReference]].Value?.ToString(),
                    CustomerName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Customer))).EntityReference]].Value?.ToString(),
                    ProjectName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Project))).EntityReference]].Value?.ToString(),
                    TypeOfServiceName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TypeOfService))).EntityReference]].Value?.ToString(),
                    ServiceDescription = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.ServiceDescription))).EntityReference]].Value?.ToString(),
                    OwnerProjectManagerName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.OwnerProjectManager))).EntityReference]].Value?.ToString(),
                    GroupOwnerName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.GroupOwner))).EntityReference]].Value?.ToString(),
                    BusinessUnitCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.BusinessUnit))).EntityReference]].Value?.ToString(),
                    CustomerCostCenterCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.CustomerCostCenter))).EntityReference]].Value?.ToString(),
                    ChargingModelCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.ChargingModel))).EntityReference]].Value?.ToString(),
                    InternalCostCenterPerCostCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.InternalCostCenterPerCost))).EntityReference]].Value?.ToString(),
                    InternalCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.InternalCode))).EntityReference]].Value?.ToString(),
                    CurrencyCode = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Currency))).EntityReference]].Value?.ToString(),
                    ProductName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Product))).EntityReference]].Value?.ToString(),
                    Year = int.TryParse(revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.Year))).EntityReference]].Value?.ToString(), out var year) ? year : -1,
                    PlannedStartDate = GetDateTime(i, nameof(Revenue.PlannedStartDate)),
                    PlannedEndDate = GetDateTime(i, nameof(Revenue.PlannedEndDate)),
                    TestingToolName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingTool))).EntityReference]].Value?.ToString(),
                    TestingToolProjectName = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingToolProjectName))).EntityReference]].Value?.ToString(),
                    TestingToolDetailedInfo = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TestingToolDetailedInfo))).EntityReference]].Value?.ToString(),
                    PlanLC = decimal.TryParse(revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.PlanLC))).EntityReference]].Value?.ToString(), out var plan) ? plan : decimal.MinusOne,
                    TransferLC = decimal.TryParse(revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(nameof(Revenue.TransferLC))).EntityReference]].Value?.ToString(), out var transfer) ? transfer : decimal.MinusOne,
                };
                // Comments
                var newComment = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC($"_{nameof(Revenue.Comments)}")).EntityReference]].Value?.ToString()?.Trim();
                if (!string.IsNullOrWhiteSpace(newComment)) revenue.Comments = new RevenueCommentDto[] { new RevenueCommentDto() { Text = newComment } };
                // Months
                foreach (var mrP in revenue.GetMonthsRevenuesProperties())
                {
                    var excelValue = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC($"{mrP.Name}.{nameof(MonthRevenueDto.Amount)}")).EntityReference]].Value;
                    var value = (excelValue == null || string.IsNullOrWhiteSpace(excelValue?.ToString())) ? null : decimal.TryParse(excelValue.ToString(), out var amount) ? amount : (decimal?)decimal.MinValue;
                    mrP.SetValue(revenue, new MonthRevenueDto() { Amount = value });
                }
                // Add Dto to Result
                revenues.Add(revenue);
            }
        }
        catch (Exception exception)
        {
            Logger.LogWarning(exception, $"Exception while {nameof(ExtractFileData)}.");
            return (RequestResult.FromError(RequestResult.ERROR_UNKNOWN, $"{_invalidFile}{exception.Message}"), null);
        }
        // Result
        if (errors.Length > 0) return (RequestResult.FromError(RequestResult.ERROR_BADREQUEST, $"{_invalidFile}{errors}"), null);
        return (RequestResult.FromSuccess(), revenues);

        #region --- NESTED METHODS ---

        DateTime GetDateTime(int i, string entityReference)
        {
            var cell = revenuesWorksheet.Cells[i, _headersColumns[fields.Single(f => f.EntityReference.EqualsICIC(entityReference)).EntityReference]];
            if (cell?.Value?.GetType()?.Equals(typeof(DateTime)) ?? false) return (DateTime)cell.Value;
            if (DateTime.TryParseExact(cell.Text, NewtonsoftDateFormatConverter.Formats, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var dte)) return DateTime.SpecifyKind(dte, DateTimeKind.Utc);
            if (DateTime.TryParse(cell.Text, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var dt)) return dt;
            return default;
        }

        #endregion
    }

    #endregion
}

internal sealed class ImportRevenuesTemplateCommandConfiguration
{
    #region --- PROPERTIES ---

    public int HeaderRowIndex { get; set; }

    public int MaxRows { get; set; }

    #endregion

    #region --- REFERENCES ---

    public IEnumerable<string> SupportedFileExtensions { get; set; }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static ImportRevenuesTemplateCommandConfiguration CreateDefault() =>
        new()
        {
            SupportedFileExtensions = new string[] { ".xlsx" },
            HeaderRowIndex = 1,
            MaxRows = 1000
        };

    #endregion
}
