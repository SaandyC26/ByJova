﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using FluentValidation.Results;
    using MediatR;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class CreateRevenueCommentsCommand : BaseRequest<Unit>
    {
        #region --- PROPERTIES ---

        public long Id { get; set; }

        public IEnumerable<string> Comments { get; set; }

        #endregion

        #region --- REFERENCES ---

        internal Revenue Revenue { get; set; }

        #endregion
    }

    public sealed class CreateRevenueCommentsCommandValidator : AbstractValidator<CreateRevenueCommentsCommand>
    {
        #region --- CONSTRUCTORS ---

        public CreateRevenueCommentsCommandValidator(IRevenueRepository revenueRepository)
        {
            RuleFor(x => x.Comments).NotEmpty();
            RuleFor(x => x.Id).GreaterThan(0);
            RuleFor(x => x).CustomAsync(async (c, vc, ct) =>
            {
                await InitCommand(c, revenueRepository, ct).ConfigureAwait(false);
                if (c.Revenue == null) vc.AddFailure(new ValidationFailure(nameof(c.Id), $"{nameof(Revenue)} with {nameof(Revenue.Id)} {c.Id} not found."));
            }).Unless(x => x.Id <= 0);
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal async static Task InitCommand(CreateRevenueCommentsCommand c, IRevenueRepository revenueRepository, CancellationToken cancellationToken = default) =>
            c.Revenue ??= await revenueRepository.GetRevenueByIdAsync(c.Id, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);

        #endregion
    }

    public sealed class CreateRevenueCommentsCommandHandler : BaseRequestHandler<CreateRevenueCommentsCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public CreateRevenueCommentsCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(CreateRevenueCommentsCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_ManageRevenue, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            // Init
            await CreateRevenueCommentsCommandValidator.InitCommand(request, RevenueRepository, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Create RevenueComments
            await request.Comments.ForEachAsync(async (rc, ct) =>
            {
                request.Revenue.AddComment(rc, user: await CurrentUserService.GetUserAsync(cancellationToken: ct).ConfigureAwait(false));
            }, cancellationToken: cancellationToken).ConfigureAwait(false);
            // Save Changes
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
