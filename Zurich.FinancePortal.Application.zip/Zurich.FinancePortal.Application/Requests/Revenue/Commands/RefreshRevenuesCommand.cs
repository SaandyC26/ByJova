﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class RefreshRevenuesCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public IEnumerable<int> Years { get; set; }

        #endregion
    }

    public sealed class RefreshRevenuesCommandHandler : BaseRequestHandler<RefreshRevenuesCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public RefreshRevenuesCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(RefreshRevenuesCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!(await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Roles.Any(r => r.IsSuperAdmin)) return RequestResult.FromUnauthorized<Unit>();
            await (request.Years ?? new int[] { -1 }).ForEachAsync(async (y, ct) =>
            {
                var revenues = await RevenueRepository.GetRevenuesAsync(year: y, cancellationToken: ct).ConfigureAwait(false);
                revenues.ForEach(r => r.RefreshFyf(autoComment: false));
            }, cancellationToken: cancellationToken).ConfigureAwait(false);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
