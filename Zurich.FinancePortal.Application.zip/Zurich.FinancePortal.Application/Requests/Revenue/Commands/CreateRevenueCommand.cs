﻿namespace Zurich.FinancePortal.Application;

using DevOps.Application;
using FluentValidation;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public sealed class CreateRevenueCommand : BaseRequest<CreateRevenueCommandResult>
{
    #region --- REFERENCES ---

    public RevenueDto Revenue { get; set; }

    #endregion
}

public sealed class CreateRevenueCommandValidator : AbstractValidator<CreateRevenueCommand>
{
    #region --- CONSTRUCTORS ---

    public CreateRevenueCommandValidator()
    {
        RuleFor(x => x.Revenue).NotNull();
    }

    #endregion
}

public sealed class CreateRevenueCommandResult
{
    #region --- REFERENCES ---

    public RevenueDto Revenue { get; set; }

    #endregion
}

public sealed class CreateRevenueCommandHandler : BaseRequestHandler<CreateRevenueCommand, CreateRevenueCommandResult>
{
    #region --- CONSTRUCTORS ---

    public CreateRevenueCommandHandler(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public async override Task<RequestResult<CreateRevenueCommandResult>> Handle(CreateRevenueCommand request, CancellationToken cancellationToken)
    {
        // Check Permissions
        if (!await HasPermissions(Constants.Permission_ManageRevenue, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<CreateRevenueCommandResult>();
        // Get Revenue
        var revenuesConfiguration = await GetOrCreateAndGetApplicationConfigurationByType<RevenuesConfiguration>(cancellationToken: cancellationToken).ConfigureAwait(false);
        var (revenues, errors) = await RevenueService.CreateUpdateRevenuesFromDtoAsync(revenuesConfiguration, new RevenueDto[] { request.Revenue }, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Check Errors
        if (errors.Single().Any()) return RequestResult.FromError<CreateRevenueCommandResult>(RequestResult.ERROR_BADREQUEST, string.Join(Environment.NewLine, errors.Single()));
        // SaveChanges
        await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Revenue
        var revenue = await RevenueService.GetRevenueByIdAsync(revenues.Single().Id, dtos: request.Dtos, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Result
        return RequestResult.FromResult(new CreateRevenueCommandResult() { Revenue = revenue });
    }

    #endregion
}
