﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class EditYearLocksCommand : BaseRequest<Unit>
    {
        #region --- REFERENCES ---

        public YearLocksDto[] YearLocks { get; set; }

        #endregion
    }

    public sealed class EditYearLocksCommandValidator : AbstractValidator<EditYearLocksCommand>
    {
        #region --- CONSTRUCTORS ---

        public EditYearLocksCommandValidator()
        {
            RuleFor(x => x.YearLocks).NotNull();
            RuleForEach(x => x.YearLocks).SetValidator(new YearLocksValidator()).Unless(x => x == null);
        }

        #endregion
    }

    public sealed class YearLocksValidator : AbstractValidator<YearLocksDto>
    {
        #region --- CONSTRUCTORS ---

        public YearLocksValidator()
        {
            RuleFor(x => x).NotNull();
            RuleFor(x => x.Year).GreaterThan(0).Unless(x => x == null);
            RuleFor(x => x.ChargingModelType).NotNull().NotEmpty().Unless(x => x == null);
        }

        #endregion
    }

    public sealed class EditYearLocksCommandHandler : BaseRequestHandler<EditYearLocksCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public EditYearLocksCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(EditYearLocksCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_EditLockedRevenuesYears, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized();
            var errors = new List<string>();
            // Get Years Locks
            var yearsLocks = await RevenueRepository.GetYearLocksAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Get Charging Models Types
            var chargingModelsTypes = await MasterDataRepository.GetMasterDatasByEntityAsync<ChargingModelType>(cancellationToken: cancellationToken).ConfigureAwait(false);
            // For each Years Locks in Command
            foreach(var yl in request.YearLocks)
            {
                // Build Months Dictionary
                var months = yl.GetType().GetProperties().Where(x => Revenue.GetMonths().Select(y => y.ToString()).ContainsICIC(x.Name)).ToDictionary(x => Enum.Parse<Month>(x.Name, true), x => (bool)x.GetValue(yl));
                // Get Charging Model
                var chargingModelType = chargingModelsTypes.SingleOrDefault(x => x.Id.Equals(yl.ChargingModelType.Id));
                if (chargingModelType == null)
                {
                    errors.Add($"MasterData \"{nameof(ChargingModel)}\" with {nameof(ChargingModel.Id)} \"{yl.ChargingModelType.Id}\" not found.");
                    continue;
                }
                // Get Year Locks
                var yearLock = yearsLocks.SingleOrDefault(x => x.Year.Equals(yl.Year) && yl.ChargingModelType.Id.Equals(x.ChargingModelType.Id));
                // Add
                if (yearLock == null) RevenueRepository.AddYearLock(new YearLocks(yl.Year, chargingModelType, months: months));
                // Update
                else yearLock.UpdateMonths(months: months);
            }
            // Check Errors
            if (errors.Any()) return RequestResult.FromError(RequestResult.ERROR_NOTFOUND, string.Join(Environment.NewLine, errors));
            // Save Changes
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
