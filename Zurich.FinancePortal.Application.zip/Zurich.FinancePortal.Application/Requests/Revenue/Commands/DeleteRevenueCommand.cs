﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using Domain;
    using FluentValidation;
    using MediatR;
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class DeleteRevenueCommand : BaseRequest<Unit>
    {
        #region --- PROPERTIES ---

        public long Id { get; set; }

        #endregion
    }

    public sealed class DeleteRevenueCommandValidator : AbstractValidator<DeleteRevenueCommand>
    {
        #region --- CONSTRUCTORS ---

        public DeleteRevenueCommandValidator()
        {
            RuleFor(x => x.Id).GreaterThan(0);
        }

        #endregion
    }

    public sealed class DeleteRevenueCommandHandler : BaseRequestHandler<DeleteRevenueCommand, Unit>
    {
        #region --- CONSTRUCTORS ---

        public DeleteRevenueCommandHandler(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async override Task<RequestResult<Unit>> Handle(DeleteRevenueCommand request, CancellationToken cancellationToken)
        {
            // Check Permissions
            if (!await HasPermissions(Constants.Permission_DeleteRevenue, cancellationToken: cancellationToken).ConfigureAwait(false)) return RequestResult.FromUnauthorized<Unit>();
            // Get Revenue
            var revenue = await RevenueRepository.GetRevenueByIdAsync(request.Id, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            if (revenue == null) return RequestResult.FromError<Unit>(RequestResult.ERROR_NOTFOUND, $"{nameof(Revenue)} with {nameof(Revenue.Id)} {request.Id} not found.");
            // Remove
            RevenueRepository.RemoveRevenue(revenue);
            // SaveChanges
            await DbContext.SaveChangesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            // Result
            return RequestResult.FromSuccess();
        }

        #endregion
    }
}
