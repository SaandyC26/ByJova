﻿namespace Zurich.FinancePortal.Application
{
    using System;
    using System.Reflection;
    using Domain;
    using System.Diagnostics.CodeAnalysis;

    internal interface IBaseApplicationConfiguration<out T>
    {
        #region --- METHODS ---

        [SuppressMessage("Major Code Smell", "S3011: Reflection should not be used to increase accessibility of classes, methods, or fields", Justification = "Reflection")]
        static T CreateDefault()
        {
            var method = typeof(T).GetMethod(nameof(CreateDefault), BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (method == null) throw new NotImplementedException($"{nameof(ApplicationConfiguration)} \"{typeof(T).Name}\" must implement \"{method}\" method.");
            return (T)method.Invoke(null, null);
        }

        #endregion
    }
}
