﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using System.Collections.Generic;

    public sealed class RevenuesConfiguration : IBaseApplicationConfiguration<RevenuesConfiguration>
    {
        #region --- PROPERTIES ---

        public bool TrueUpMustSumZeroEnabled { get; set; }

        #endregion

        #region --- REFERENCES ---

        public IEnumerable<string> ChargingModelsCodesWithoutVat { get; set; }

        public Restriction[] Restrictions { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        private RevenuesConfiguration() { }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static RevenuesConfiguration CreateDefault() =>
            new()
            {
                TrueUpMustSumZeroEnabled = true,
                ChargingModelsCodesWithoutVat = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode },
                Restrictions = new Restriction[]
                {
                    new Restriction()
                    {
                        Property = nameof(Revenue.ChargingModel),
                        PropertyProperty = nameof(ChargingModel.Code),
                        Values = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode },
                        RestrictedProperty = nameof(Revenue.InternalCostCenterPerCost),
                        RestrictedPropertyProperty = nameof(CostCenter.Code),
                        RestrictedValues = new string[] { "ES00XGIT09", "ES00XGIT10", "ES00XGIT11", "ES00XGIT12" }
                    },
                    new Restriction()
                    {
                        Property = nameof(Revenue.ChargingModel),
                        PropertyProperty = nameof(ChargingModel.Code),
                        Values = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode },
                        RestrictedProperty = nameof(Revenue.ValueAddedTax),
                        RestrictedPropertyProperty = nameof(ValueAddedTax.Country),
                        RestrictedValues = new string[] { ValueAddedTax.None }
                    },
                    new Restriction()
                    {
                        Property = nameof(Revenue.InternalCostCenterPerCost),
                        PropertyProperty = nameof(CostCenter.Code),
                        Values = new string[] { "ES00XGIT09", "ES00XGIT10", "ES00XGIT11", "ES00XGIT12" },
                        RestrictedProperty = nameof(Revenue.ChargingModel),
                        RestrictedPropertyProperty = nameof(ChargingModel.Code),
                        RestrictedValues = new string[] { ChargingModel.BicChargingModelCode, ChargingModel.BieChargingModelCode }
                    }
                }
            };

        #endregion
    }

    public sealed class Restriction
    {
        #region --- PROPERTIES ---

        public string Property { get; set; }

        public string PropertyProperty { get; set; }

        public string[] Values { get; set; }

        public string RestrictedProperty { get; set; }

        public string RestrictedPropertyProperty { get; set; }

        public string[] RestrictedValues { get; set; }

        #endregion
    }
}
