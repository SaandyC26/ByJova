﻿namespace Zurich.FinancePortal.Application
{
    internal sealed class RequestsConfiguration
    {
        #region --- PROPERTIES ---

        internal bool ApplicationConfigurationRefreshed { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        internal RequestsConfiguration()
        {
            ApplicationConfigurationRefreshed = false;
        }

        #endregion
    }
}
