﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using Domain;

public sealed class YearLocksAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public YearLocksAutoMapper()
    {
        // Entity -> Dto
        CreateMap<YearLocks, YearLocksDto>();
    }

    #endregion
}
