﻿namespace Zurich.FinancePortal.Application
{
    using AutoMapper;
    using DevOps.CrossCutting;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;

    public sealed class RestrictionAutoMapper : Profile
    {
        #region --- CONSTRUCTORS ---

        [SuppressMessage("Style", "IDE0057: Use range operator", Justification = "Expression Tree")]
        public RestrictionAutoMapper()
        {
            // Entity -> Dto
            CreateMap<IEnumerable<Restriction>, IEnumerable<RestrictionDto>>()
                .ConvertUsing(src =>
                    src.GroupBy(r => r.Property).Select(rpg => new RestrictionDto()
                    {
                        Field = $"{char.ToLowerInvariant(rpg.Key[0])}{rpg.Key.Substring(1, rpg.Key.Length - 1)}{rpg.First().PropertyProperty}",
                        Filters = rpg.GroupBy(r => r.RestrictedProperty).Select(rrpg => new FilterDto()
                        {
                            Field = $"{char.ToLowerInvariant(rrpg.Key[0])}{rrpg.Key.Substring(1, rrpg.Key.Length - 1)}{rrpg.First().RestrictedPropertyProperty}",
                            Values = rrpg.SelectMany(x => x.RestrictedValues).Select(x => new ValueDto()
                            {
                                Name = x,
                                Options = rrpg.Single(y => y.RestrictedValues.Any(z => z.EqualsICIC(x))).Values
                            })
                        })
                    }));
        }

        #endregion
    }
}
