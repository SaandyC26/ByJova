﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using DevOps.CrossCutting;
using Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

public sealed class TicketAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    [SuppressMessage("Critical Code Smell", "S3776: Cognitive Complexity of methods should not be too high", Justification = "N/A")]
    public TicketAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Ticket, TicketDto>()
            .ForMember(x => x.SAMAccountName, opt => opt.MapFrom(x => x.User.AdAccount.SAMAccountName))
            .ForMember(x => x.Links, opt => opt.MapFrom((src, dest, x, context) =>
            {
                var result = new List<LinkDto>();
                //// Create = Permission_WriteTicket
                if (context.Options.Items.TryGetValue(nameof(Constants.Permission_WriteTicket), out var c1) && bool.Parse(c1.ToString()))
                {
                    result.Add(new LinkDto() { Ref = LinkDto.Ref_Base, Rel = LinkDto.Rel_Create });
                }
                //// Create TicketComment = Permission_OtherManageTicket || Permission_WriteTicket
                if ((context.Options.Items.TryGetValue(nameof(Constants.Permission_OtherManageTicket), out var ctc1) && bool.Parse(ctc1.ToString())) ||
                    (context.Options.Items.TryGetValue(nameof(Constants.Permission_WriteTicket), out var ctc2) && bool.Parse(ctc2.ToString())))
                {
                    result.Add(new LinkDto() { Ref = $"{LinkDto.Ref_Base}{nameof(TicketComment)}", Rel = LinkDto.Rel_Create });
                }
                //// Update = Permission_OtherManageTicket || (Permission_WriteTicket && t.Status in UpdatableStatuses && CurrentUser)
                if ((context.Options.Items.TryGetValue(nameof(Constants.Permission_OtherManageTicket), out var u1) && bool.Parse(u1.ToString())) ||
                    (context.Options.Items.TryGetValue(nameof(Constants.Permission_WriteTicket), out var u2) && bool.Parse(u2.ToString()) &&
                        context.Options.Items.TryGetValue(nameof(TicketRequestConfiguration), out var u3) && ((TicketRequestConfiguration)u3).UpdatableStatuses.Contains(src.Status) &&
                        context.Options.Items.TryGetValue(nameof(AdAccount.SAMAccountName), out var u4) && u4.ToString().EqualsICIC(src.User.AdAccount.SAMAccountName)))
                {
                    result.Add(new LinkDto() { Ref = LinkDto.Ref_Base, Rel = LinkDto.Rel_Update, Properties = GetUpdateProperties(src, u1) });
                }
                //// Delete = Permission_DeleteTicket || (Permission_WriteTicket && t.Status eq "Created" && CurrentUser)
                if ((context.Options.Items.TryGetValue(nameof(Constants.Permission_DeleteTicket), out var d1) && bool.Parse(d1.ToString())) ||
                    (context.Options.Items.TryGetValue(nameof(Constants.Permission_WriteTicket), out var d2) && bool.Parse(d2.ToString()) &&
                        src.Status.Equals(TicketStatus.Created) &&
                        context.Options.Items.TryGetValue(nameof(AdAccount.SAMAccountName), out var d3) && d3.ToString().EqualsICIC(src.User.AdAccount.SAMAccountName)))
                {
                    result.Add(new LinkDto() { Ref = LinkDto.Ref_Base, Rel = LinkDto.Rel_Delete });
                }
                // Result
                return result;
            }));
    }

    #endregion

    #region --- PRIVATE METHODS ---

    [SuppressMessage("Major Code Smell", "S1168: Empty arrays and collections should be returned instead of null", Justification = "N/A")]
    private static string[] GetUpdateProperties(Ticket ticket, object otherManageTicket)
    {
        if (bool.Parse(otherManageTicket.ToString())) return null;
        var properties = new string[] { nameof(Ticket.Summary), nameof(Ticket.Description) };
        if (ticket.Status.Equals(TicketStatus.Created)) properties = properties.Append(nameof(Ticket.Type)).ToArray();
        return properties;
    }

    #endregion
}

public sealed class TicketCommentAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public TicketCommentAutoMapper()
    {
        // Entity -> Dto
        CreateMap<TicketComment, TicketCommentDto>()
            .ForMember(x => x.Links, opt => opt.MapFrom((src, dest, x, context) =>
            {
                var result = new List<LinkDto>();
                //// Delete = Permission_DeleteTicket || Permission_OtherManageTicket || (Permission_WriteTicket && CurrentUser)
                if (context.Options.Items.TryGetValue(nameof(Constants.Permission_DeleteTicket), out var a) && bool.Parse(a.ToString()) ||
                    context.Options.Items.TryGetValue(nameof(Constants.Permission_OtherManageTicket), out var b) && bool.Parse(b.ToString()) ||
                    (context.Options.Items.TryGetValue(nameof(Constants.Permission_WriteTicket), out var c) && bool.Parse(c.ToString()) &&
                        context.Options.Items.TryGetValue(nameof(AdAccount.SAMAccountName), out var d) && d.ToString().EqualsICIC(src.SAMAccountName)))
                {
                    result.Add(new LinkDto() { Ref = LinkDto.Ref_Base, Rel = LinkDto.Rel_Delete });
                }

                return result;
            }));
    }

    #endregion
}
