﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using DevOps.CrossCutting;
using Domain;
using System;
using System.Linq;

public sealed class GroupAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public GroupAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Group, GroupDto>()
            .ForMember(r => r.Users, opt =>
            {
                opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(User), out var u) && (bool)u);
                opt.MapFrom((src, dest, x, context) => src.Users);
            });
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Action<IMappingOperationOptions<TSource, TDestination>> GetMapperParameters<TSource, TDestination>(string[] dtos = default) =>
        (IMappingOperationOptions<TSource, TDestination> opts) =>
        {
            if (dtos != null)
            {
                opts.Items.Add(nameof(User), dtos.Any(dto => dto.EqualsICIC(nameof(User))));
            }
        };

    #endregion
}
