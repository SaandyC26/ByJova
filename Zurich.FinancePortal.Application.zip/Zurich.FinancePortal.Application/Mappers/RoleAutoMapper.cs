﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using DevOps.CrossCutting;
using Domain;
using System;
using System.Linq;

public sealed class RoleAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public RoleAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Role, RoleDto>()
            .ForMember(r => r.Users, opt => opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(User), out var u) && (bool)u))
            .ForMember(r => r.Permissions, opt => opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(Permission), out var p) && (bool)p));
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Action<IMappingOperationOptions<TSource, TDestination>> GetMapperParameters<TSource, TDestination>(string[] dtos = default) =>
        (IMappingOperationOptions<TSource, TDestination> opts) =>
        {
            if (dtos != null)
            {
                opts.Items.Add(nameof(Permission), dtos.Any(dto => dto.EqualsICIC(nameof(Permission))));
                opts.Items.Add(nameof(User), dtos.Any(dto => dto.EqualsICIC(nameof(User))));
            }
        };

    #endregion
}

public sealed class PermissionAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public PermissionAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Permission, PermissionDto>();
    }

    #endregion
}
