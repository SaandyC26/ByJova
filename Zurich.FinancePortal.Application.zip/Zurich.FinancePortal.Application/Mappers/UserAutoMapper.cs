﻿namespace Zurich.FinancePortal.Application;

using AutoMapper;
using DevOps.CrossCutting;
using Domain;
using System;
using System.Linq;

public sealed class UserAutoMapper : Profile
{
    #region --- PROPERTIES ---

    internal const string LastSeenReleaseNotes = "LastSeenReleaseNotes";

    #endregion

    #region --- CONSTRUCTORS ---

    public UserAutoMapper()
    {
        // Entity -> Dto
        CreateMap<User, UserDto>()
            .ForMember(u => u.Roles, opt =>
            {
                opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(Role), out var r) && (bool)r);
                opt.MapFrom((src, dest, x, context) => src.Roles.Where(r => !r.IsSuperAdmin));
            })
            .ForMember(u => u.Groups, opt =>
            {
                opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(Group), out var r) && (bool)r);
                opt.MapFrom((src, dest, x, context) => src.Groups);
            })
            .ForMember(u => u.Permissions, opt =>
            {
                opt.Condition((src, dest, x, y, context) => context.Options.Items.TryGetValue(nameof(Role), out var r) && (bool)r);
                opt.MapFrom(u => u.Roles.Any(r => r.IsSuperAdmin) ? Constants.AllPermissions : u.Roles.SelectMany(r => r.Permissions).Distinct().ToArray());
            })
            .ForMember(u => u.SAMAccountName, opt => opt.MapFrom(u => u.AdAccount.SAMAccountName))
            .ForMember(u => u.LastSeenVersion, opt => opt.MapFrom(LastSeenReleaseNotes));
}

#endregion

#region --- INTERNAL METHODS ---

internal static Action<IMappingOperationOptions<TSource, TDestination>> GetMapperParameters<TSource, TDestination>(string[] dtos = default) =>
    (IMappingOperationOptions<TSource, TDestination> opts) =>
    {
        if (dtos != null)
        {
            opts.Items.Add(nameof(Role), dtos.Any(dto => dto.EqualsICIC(nameof(Role))));
            opts.Items.Add(nameof(Group), dtos.Any(dto => dto.EqualsICIC(nameof(Group))));
            opts.Items.Add(nameof(Permission), dtos.Any(dto => dto.EqualsICIC(nameof(Permission))));
        }
    };

    #endregion
}

public sealed class UserGridPreferencesAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public UserGridPreferencesAutoMapper()
    {
        // Entity -> Dto
        CreateMap<UserGridPreferences, UserGridPreferencesDto>();
    }

    #endregion
}

public sealed class ReleaseNotesAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ReleaseNotesAutoMapper()
    {
        // Entity -> Dto
        CreateMap<ReleaseNotes, ReleaseNotesDto>();
    }

    #endregion
}
