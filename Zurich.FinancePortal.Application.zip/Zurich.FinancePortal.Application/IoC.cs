﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Zurich.FinancePortal.Application.Test")]
namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using MediatR;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    public static class IoC
    {
        #region --- PUBLIC METHODS ---

        public static IServiceCollection AddApplication(this IServiceCollection services, ICurrentUserService<User> currentUserService = default, IConfiguration folderFileRepositoryConfiguration = default)
        {
            if (folderFileRepositoryConfiguration == null) services.AddTransient(_ => new FolderFileRepositoryConfiguration());
            else services.Configure<FolderFileRepositoryConfiguration>(folderFileRepositoryConfiguration);
            // Configurations
            services.AddSingleton(_ => new RequestsConfiguration());
            // AutoMapper
            services.AddAutoMapper(typeof(IoC));
            // Services
            services
                // Mediatr
                .AddMediatR(typeof(BaseRequestResult).Assembly, typeof(Request<>).Assembly)
                // Services
                .AddTransient<IFileRepository, FolderFileRepository>(s => new FolderFileRepository(s))
                .AddTransient<IRevenueService, RevenueService>(s => new RevenueService(s));
            // ICurrentUserService
            if (currentUserService != null) services.AddScoped(_ => currentUserService);
            else services.AddScoped<ICurrentUserService<User>, CurrentHttpUserService>();
            // Behavious
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(AuthorizationBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(PerformanceAndLoggingBehavior<,>));
            // Return services
            return services;
        }

        public static IServiceCollection AddTicketBackgroundService(this IServiceCollection services, IConfiguration mailServiceConfiguration, IConfiguration ticketBackgroundServiceConfiguration)
        {
            // Configurations
            services.Configure<TicketBackgroundServiceConfiguration>(ticketBackgroundServiceConfiguration);
            services.Configure<MailServiceConfiguration>(mailServiceConfiguration);
            // Services
            services.AddMailService(mailServiceConfiguration);
            // BackgroundService
            services.AddHostedService(s => new TicketBackgroundService(s));
            // Return services
            return services;
        }

        #endregion
    }
}
