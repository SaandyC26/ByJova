﻿namespace Zurich.FinancePortal.Application;

using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public static class Constants
{
    #region --- REFERENCES ---

    public static IEnumerable<Permission> AllPermissions =>
        Type.GetType($"{nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Application)}.{nameof(Constants)}, {nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Application)}", true, true)
        .GetFields(BindingFlags.Public | BindingFlags.Static)
        .Where(f => f.FieldType.Equals(typeof(Permission)))
        .Select(f => (Permission)f.GetValue(null));

    // MasterData
    public static readonly Permission Permission_ManageMasterData = new("Manage Master Data", description: "Allows to create, edit and deleate a master data of any type.");
    public static readonly Permission Permission_ManageCurrencyExchangeRate = new("Manage Currency Exchange Rate", description: "Allows to create, edit and delete Currency Exchange Rate master data.");

    // Revenue
    public static readonly Permission Permission_ManageRevenue = new("Manage Revenue", description: "Allows to create and edit a revenue.");
    public static readonly Permission Permission_ImportRevenues = new("Import Revenues", description: "Allows to import revenues from an .xlsx file.");
    public static readonly Permission Permission_EditLockedRevenuesYears = new("Edit Locked Revenues Years", description: "Allows to edit the months locks of revenues.");
    public static readonly Permission Permission_BypassLockedRevenues = new("Bypass Locked Revenues", description: "Allows to edit the revenues with locked months.");
    public static readonly Permission Permission_DeleteRevenue = new("Delete Revenue", description: "Allows to delete a revenue.");
    public static readonly Permission Permission_BypassOwnedRevenues = new("Bypass Owned Revenues", description: "Allows to create and edit revenues with a different 'Owner / Project Manager'.");
    public static readonly Permission Permission_BypassPreviouslyBilledRevenues = new("Bypass Previously Billed Revenues", description: "Allows to edit revenues previously billed (locked months).");
    public static readonly Permission Permission_BypassPlannedDatesRevenues = new("Bypass Planned Dates Revenues", description: "Allows to create and edit revenues with an expired 'Planned End Date'.");
    public static readonly Permission Permission_RevenuesUpdatePlan = new("Update Revenue Plan LC", description: "Allows to edit revenues 'Plan LC' field.");
    public static readonly Permission Permission_RevenuesCreateUpdateTransfer = new("Create Update Revenue Transfer LC", description: "Allows to create/edit revenues 'Transfer LC' field.");

    // Financial Management
    public static readonly Permission Permission_BarcelonaInvoices = new("Barcelona Invoices", description: "Allows to read Barcelona invoices.");
    public static readonly Permission Permission_Rebookings = new("Rebookings", description: "Allows to read Rebookings.");
    public static readonly Permission Permission_CustomersAllocations = new("Customers Allocations", description: "Allows to read Customers Allocations.");

    // Role
    public static readonly Permission Permission_ManageRole = new("Manage Role", description: "Allows to create, edit and delete a role.");

    // User
    public static readonly Permission Permission_ManageUser = new("Manage User", description: "Allows to create, edit and delete an user.");

    // Ticket
    public static readonly Permission Permission_ReadTicket = new("Read Ticket", description: "Allows to read tickets.");
    public static readonly Permission Permission_WriteTicket = new("Write Ticket", description: "Allows to read, create, edit and delete (own) tickets.");
    public static readonly Permission Permission_DeleteTicket = new("Delete Ticket", description: "Allows to delete any ticket.");
    public static readonly Permission Permission_OtherManageTicket = new("Other Manage Ticket", description: "Allows to read and manage any ticket lyfe cycle.");

    // Group
    public static readonly Permission Permission_ManageGroup = new("Manage Group", description: "Allows to create, edit and delete a group.");

    #endregion
}
