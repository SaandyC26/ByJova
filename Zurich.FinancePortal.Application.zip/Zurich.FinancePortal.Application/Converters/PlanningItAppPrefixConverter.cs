﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using Newtonsoft.Json;
    using System;

    public static class BasePlanningItAppPrefixJsonConverter
    {
        #region --- PROPERTIES ---

        internal const string PrefixSeparator = "-";

        #endregion
    }

    public class NewtonsoftPlanningItAppPrefixJsonConverter : JsonConverter<PlanningItAppPrefix>
    {
        #region --- PUBLIC METHODS ---

        public override PlanningItAppPrefix ReadJson(JsonReader reader, Type objectType, PlanningItAppPrefix existingValue, bool hasExistingValue, JsonSerializer serializer) => Enum.TryParse<PlanningItAppPrefix>(reader.Value?.ToString()?.Replace(BasePlanningItAppPrefixJsonConverter.PrefixSeparator, string.Empty), true, out var result) ? result : PlanningItAppPrefix.UNKNOWN;

        public override void WriteJson(JsonWriter writer, PlanningItAppPrefix value, JsonSerializer serializer) => writer.WriteValue($"{value}{BasePlanningItAppPrefixJsonConverter.PrefixSeparator}");

        #endregion
    }

    public class SystemPlanningItAppPrefixJsonConverter : System.Text.Json.Serialization.JsonConverter<PlanningItAppPrefix>
    {
        #region --- PUBLIC METHODS ---

        public override PlanningItAppPrefix Read(ref System.Text.Json.Utf8JsonReader reader, Type typeToConvert, System.Text.Json.JsonSerializerOptions options) => Enum.TryParse<PlanningItAppPrefix>(reader.GetString()?.Replace(BasePlanningItAppPrefixJsonConverter.PrefixSeparator, string.Empty), true, out var result) ? result : PlanningItAppPrefix.UNKNOWN;

        public override void Write(System.Text.Json.Utf8JsonWriter writer, PlanningItAppPrefix value, System.Text.Json.JsonSerializerOptions options) => writer.WriteStringValue($"{value}{BasePlanningItAppPrefixJsonConverter.PrefixSeparator}");

        #endregion
    }
}
