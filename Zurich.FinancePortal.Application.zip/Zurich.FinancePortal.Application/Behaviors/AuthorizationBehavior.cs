﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using MediatR;
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Reflection;
    using System.Threading;
    using System.Threading.Tasks;

    public sealed class AuthorizationBehavior<TRequest, TResponse> : BasePipelineBehavior<AuthorizationBehavior<TRequest, TResponse>>, IPipelineBehavior<TRequest, TResponse>
    {
        #region --- REFERENCES ---

        [SuppressMessage("Major Code Smell", "S2743: Static fields should not be used in generic types", Justification = "Cache")]
        private static MethodInfo _privateFromUnauthorizedMethod;

        [SuppressMessage("Major Code Smell", "S2743: Static fields should not be used in generic types", Justification = "Cache")]
        [SuppressMessage("Style", "IDE1006: Naming Styles", Justification = "Private")]
        private static MethodInfo _fromUnauthorizedMethod
        {
            get
            {
                if (_privateFromUnauthorizedMethod == null)
                {
                    _privateFromUnauthorizedMethod = typeof(RequestResult).GetMethods().Single(c => c.Name.Equals(nameof(RequestResult.FromUnauthorized)) && c.IsGenericMethod);
                }

                return _privateFromUnauthorizedMethod;
            }
        }

        #endregion

        #region --- CONSTRUCTORS ---

        public AuthorizationBehavior(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            // Current User
            var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            if (currentUser == null || currentUser.IsDeleted)
            {
                var method = _fromUnauthorizedMethod.MakeGenericMethod(typeof(TResponse).GetGenericArguments().Single());
                return (TResponse)method.Invoke(null, null);
            }
            // IRequest Execution
            return await next().ConfigureAwait(false);
        }

        #endregion
    }
}
