﻿namespace Zurich.FinancePortal.Application
{
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using DevOps.Application;
    using System;
    using DevOps.CrossCutting;
    using Domain;

    public abstract class BaseBasePipelineBehavior
    {
        #region --- CONSTRUCTORS ---

        protected private BaseBasePipelineBehavior() { }

        #endregion

        #region --- REFERENCES ---

        protected private static readonly Type[] SkipRequestLoggingScope = Array.Empty<Type>();

        #endregion
    }

    public abstract class BasePipelineBehavior<T> : BaseBasePipelineBehavior
    {
        #region --- REFERENCES ---

        private readonly IServiceProvider _services;

        protected private readonly ILogger<T> Logger;

        private ICurrentUserService<User> _currentUserService;
        protected private ICurrentUserService<User> CurrentUserService => _currentUserService ??= _services.GetRequiredService<ICurrentUserService<User>>();

        #endregion

        #region --- CONSTRUCTORS ---

        protected private BasePipelineBehavior(IServiceProvider services)
        {
            _services = Guard.Argument(services, nameof(services)).IsNotNull().Value;
            Logger = _services.GetRequiredService<ILogger<T>>();
        }

        #endregion
    }
}
