﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Domain;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public interface IRoleRepository
    {
        #region --- METHODS ---

        void AddRole(Role role);

        void RemoveRole(Role role);

        Task<Role> GetRoleByIdAsync(int id, bool asNoTracking = false, bool includeUsers = false, bool includePermissions = false, CancellationToken cancellationToken = default);

        Task<(int Count, IEnumerable<Role> Result)> GetRolesAsync(bool asNoTracking = false, bool includeUsers = false, bool includePermissions = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

        Task<(int Count, IEnumerable<Permission> Result)> GetPermissionsAsync(bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

        #endregion
    }
}
