﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Domain;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public interface IPrivateRevenueFrontEndRepository
    {
        #region --- METHODS ---

        Task<(int Count, IEnumerable<RevenueDto> Result)> GetRevenuesAsync(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, int maxCount = -1, CancellationToken cancellationToken = default);

        Task<RevenueDto> GetRevenueByIdAsync(long id, string[] dtos = default, CancellationToken cancellationToken = default);

        #endregion
    }

    public interface IRevenueFrontEndRepository
    {
        #region --- METHODS ---

        // Financial Management
        Task<(int Count, IEnumerable<BarcelonaInvoiceDto> Result)> GetBarcelonaInvoicesAsync(int year, Month month, IEnumerable<string> linesOfBusinessNames, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, bool includePastFuture = false, string separator = default, IEnumerable<string> descriptionProperties = default, CancellationToken cancellationToken = default);

        Task<(int Count, IEnumerable<RebookingDto> Result)> GetRebookingsAsync(int year, Month month, CostCenter internalCostCenter, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, string separator = default, IEnumerable<string> descriptionProperties = default, CancellationToken cancellationToken = default);

        Task<(int Count, IEnumerable<CustomerAllocationDto> Result)> GetCustomersAllocationsAsync(int year, Month month, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, string separator = default, CancellationToken cancellationToken = default);

        #endregion
    }
}
