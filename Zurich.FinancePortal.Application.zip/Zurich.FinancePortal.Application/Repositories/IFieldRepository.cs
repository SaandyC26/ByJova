﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public interface IFieldRepository
    {
        #region --- METHODS ---

        Task<IEnumerable<Field>> GetFieldsByEntityAsync<T>(bool asNoTracking = false, CancellationToken cancellationToken = default);

        #endregion
    }
}
