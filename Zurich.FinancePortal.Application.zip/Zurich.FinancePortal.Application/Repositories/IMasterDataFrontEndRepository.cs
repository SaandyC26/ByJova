﻿namespace Zurich.FinancePortal.Application;

using DevOps.CrossCutting;
using Domain;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IMasterDataFrontEndRepository
{
    #region --- METHODS ---

    // MasterData Generic
    Task<(int Count, IEnumerable<TDto> MasterDatas)> GetMasterDatasByEntityAsync<TDto, TEntity>(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, CancellationToken cancellationToken = default) where TDto : MasterDataDto where TEntity : MasterData;

    Task<(int Count, IEnumerable<object> MasterDatas)> GetMasterDatasByEntityAsync(Type dtoType, Type entityType, string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, CancellationToken cancellationToken = default);

    #endregion
}
