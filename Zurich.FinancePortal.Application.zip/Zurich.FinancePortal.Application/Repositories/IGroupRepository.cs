﻿namespace Zurich.FinancePortal.Application;

using DevOps.CrossCutting;
using Domain;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IGroupRepository
{
    #region --- METHODS ---

    void AddGroup(Group group);

    void RemoveGroup(Group group);

    Task<Group> GetGroupByIdAsync(int id, bool asNoTracking = false, bool includeUsers = false, CancellationToken cancellationToken = default);

    Task<Group> GetGroupByNameAsync(string name, bool asNoTracking = false, bool includeUsers = false, CancellationToken cancellationToken = default);

    Task<(int Count, IEnumerable<Group> Result)> GetGroupsAsync(bool asNoTracking = false, bool includeUsers = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

    Task<bool> IsBeingUsedAsync(Group group, CancellationToken cancellationToken = default);

    #endregion
}