﻿namespace Zurich.FinancePortal.Application
{
    using System.Linq;

    public interface IRevenueODataRepository
    {
        #region --- METHODS ---

        IQueryable<RevenueODataDto> GetQueryable();

        #endregion
    }
}
