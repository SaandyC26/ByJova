﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using Microsoft.Extensions.Logging;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public enum SeedMode
    {
        Production = 0,
        Staging = 1,
        Development = 2,
        UnitTesting = 3
    }

    public interface IApplicationDbContext
    {
        #region --- METHODS ---

        Task<int> SaveChangesAsync(bool changeTracking = true, User user = default, IEnumerable<object> cacheKeysCleanup = default, CancellationToken cancellationToken = default);

        Task MigrateAsync(ILogger logger = default, CancellationToken cancellationToken = default);

        Task SeedDatabase(SeedMode seedMode, CancellationToken cancellationToken = default);

        #endregion
    }
}
