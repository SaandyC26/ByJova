﻿namespace Zurich.FinancePortal.Application
{
    using Domain;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public interface IRevenueRepository
    {
        #region --- METHODS ---

        // Revenue
        void AddRevenue(Revenue revenue);

        void RemoveRevenue(Revenue revenue);

        Task<IEnumerable<Revenue>> GetRevenuesAsync(int year = -1, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default);

        Task<Revenue> GetRevenueByIdAsync(long id, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default);

        Task<IEnumerable<Revenue>> GetRevenuesByYearAndUniqueIndexAsync(int year, (string LineOfBusinessName, string CustomerName, string ProjectName, string TypeOfServiceName, string ServiceDescription)[] uniques, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default);

        Task<IEnumerable<Revenue>> GetRevenuesByYearAndCurrencyAsync(int year, Currency currency, CurrencyExchangeRate exclude = default, CurrencyExchangeRate include = default, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default);

        Task<IEnumerable<int>> GetRevenuesYearsAsync(CancellationToken cancellationToken = default);

        // Year Lock
        void AddYearLock(YearLocks yearLock);

        void RemoveYearLock(YearLocks yearLock);

        Task<IEnumerable<YearLocks>> GetYearLocksAsync(bool asNoTracking = false, CancellationToken cancellationToken = default);

        #endregion
    }
}
