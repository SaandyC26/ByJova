﻿namespace Zurich.FinancePortal.Application;

using Domain;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IMasterDataRepository
{
    #region --- METHODS ---

    // CurrencyExchangeRate
    Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesAsync(bool asNoTracking = false, CancellationToken cancellationToken = default);

    Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesByFromAndYearAsync(int year, string currencyCodeFrom, bool asNoTracking = false, CancellationToken cancellationToken = default);

    Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesByToAsync(string currencyCodeTo, bool asNoTracking = false, CancellationToken cancellationToken = default);

    // ChargingModel
    Task<IEnumerable<ChargingModel>> GetChargingModelsAsync(bool asNoTracking = true, CancellationToken cancellationToken = default);

    // MasterData Generic
    void Add(MasterData masterData);

    void Remove(MasterData masterData);

    Task<IEnumerable<TEntity>> GetMasterDatasByEntityAsync<TEntity>(bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default) where TEntity : MasterData;

    Task<IEnumerable<object>> GetMasterDatasByEntityAsync(Type type, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default);

    Task<MasterData> GetMasterDataByIdAsync(Type type, int id, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default);

    Task<T> GetMasterDataByIdAsync<T>(int id, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default) where T : MasterData;

    Task<bool> IsMasterDataBeingUsedAsync(Type type, MasterData masterData, CancellationToken cancellationToken = default);

    #endregion
}
