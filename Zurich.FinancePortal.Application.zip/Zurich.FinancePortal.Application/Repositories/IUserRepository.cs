﻿namespace Zurich.FinancePortal.Application;

using DevOps.CrossCutting;
using Domain;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public interface IUserRepository
{
    #region --- METHODS ---

    void AddUser(User user);

    Task<User> GetUserBySAMAccountNameAsync(string sAMAccountName, bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, bool includeGridPreferences = false, CancellationToken cancellationToken = default);

    Task<User> GetUserByIdAsync(int id, bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, CancellationToken cancellationToken = default);

    Task<(int Count, IEnumerable<User> Result)> GetUsersAsync(bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, bool includeGridPreferences = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

    // ReleaseNotes
    Task<(int Count, IEnumerable<ReleaseNotes> Result)> GetReleasesNotesAsync(bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

    Task<ReleaseNotes> GetLastReleaseNotesAsync(bool asNoTracking = false, CancellationToken cancellationToken = default);

    #endregion
}
