﻿namespace Zurich.FinancePortal.Application
{
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Options;
    using System;
    using System.IO;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Threading.Tasks;
    using DevOps.CrossCutting;

    public class FolderFileRepositoryConfiguration
    {
        #region --- PROPERTIES ---

        public string BasePath { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        public FolderFileRepositoryConfiguration()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux)) BasePath = Path.Combine(Environment.CurrentDirectory, "ExternalFiles");
            else BasePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ExternalFiles");
        }

        #endregion
    }

    public sealed class FolderFileRepository : IFileRepository
    {
        #region --- REFERENCES ---

        private readonly FolderFileRepositoryConfiguration _configuration;

        #endregion

        #region --- CONSTRUCTORS ---

        internal FolderFileRepository(IServiceProvider services)
        {
            _configuration = Guard.Argument(services, nameof(services)).IsNotNull().Value.GetRequiredService<IOptions<FolderFileRepositoryConfiguration>>().Value;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<byte[]> ReadFileAsync(FileType fileType, string fileName, CancellationToken cancellationToken = default)
        {
            var filePath = Path.Combine(_configuration.BasePath, fileType.ToString(), fileName);
            if (!File.Exists(filePath)) return null;
            return await File.ReadAllBytesAsync(filePath, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        public async Task WriteFileAsync(FileType fileType, string fileName, byte[] bytes, CancellationToken cancellationToken = default)
        {
            var path = Path.Combine(_configuration.BasePath, fileType.ToString());
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            await File.WriteAllBytesAsync(Path.Combine(path, fileName), bytes, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        #endregion
    }
}
