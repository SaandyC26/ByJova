﻿namespace Zurich.FinancePortal.Application
{
    using System.Threading;
    using System.Threading.Tasks;

    public interface IApplicationConfigurationRepository
    {
        #region --- METHODS ---

        Task<T> GetApplicationConfigurationByTypeAsync<T>(bool asNoTracking = true, CancellationToken cancellationToken = default);

        Task CreateApplicationConfigurationAsync<T>(T applicationConfiguration, CancellationToken cancellationToken = default);

        #endregion
    }
}
