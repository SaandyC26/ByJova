﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.CrossCutting;
    using Domain;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    public interface ITicketRepository
    {
        #region --- METHODS ---

        void Add(Ticket ticket);

        void Remove(Ticket ticket);

        Task<(int Count, IEnumerable<Ticket> Result)> GetAsync(User user = default, IEnumerable<TicketStatus> hiddenStatuses = default, bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default);

        Task<Ticket> GetByIdAsync(long id, bool asNoTracking = false, CancellationToken cancellationToken = default);

        #endregion
    }
}
