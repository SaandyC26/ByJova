﻿namespace Zurich.FinancePortal.Application
{
    using System.Threading;
    using System.Threading.Tasks;

    public enum FileType
    {
        RevenuesTemplate = 0
    }

    public interface IFileRepository
    {
        #region --- METHODS ---

        Task<byte[]> ReadFileAsync(FileType fileType, string fileName, CancellationToken cancellationToken = default);

        Task WriteFileAsync(FileType fileType, string fileName, byte[] bytes, CancellationToken cancellationToken = default);

        #endregion
    }
}
