﻿namespace Zurich.FinancePortal.Application;

using Domain;
using System.Collections.Generic;
using System.Linq;

public static class ConstantsMessages
{
    #region --- CLASSES ---

    public static class Revenue
    {
        #region --- PUBLIC METHODS ---

        public static string ExpiredPlannedEndDate(DateTime plannedEndDate) => $"Cannot be modified due to expired '{Domain.Revenue.PlannedEndDateDescription}': {plannedEndDate.ToString(NewtonsoftDateFormatConverter.Format)}.";

        public static string PreviouslyBilled(IEnumerable<Month> billedMonths) => $"Cannot modify '{Domain.Revenue.BusinessUnitDescription}' nor '{Domain.Revenue.CustomerCostCenterDescription}' because there are already billed months: {string.Join(", ", billedMonths.Select(m => $"\"{m}\""))}.";

        public static string TrueUpFyfclc(decimal? fyfclc) => $"Has invalid month values. True-Up {nameof(Domain.Revenue)} '{nameof(Domain.Revenue.FYFCLC)}' mut be equals to 0 but is \"{fyfclc}\".";

        #endregion
    }

    #endregion
}
