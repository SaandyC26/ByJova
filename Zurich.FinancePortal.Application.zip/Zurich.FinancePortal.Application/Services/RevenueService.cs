﻿namespace Zurich.FinancePortal.Application;

using DevOps.CrossCutting;
using Domain;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public interface IRevenueService
{
    #region --- METHODS ---

    Task<(int Count, IEnumerable<RevenueDto> Result)> GetRevenuesAsync(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, int maxCount = -1, CancellationToken cancellationToken = default);

    Task<RevenueDto> GetRevenueByIdAsync(long id, string[] dtos = default, CancellationToken cancellationToken = default);

    Task<(IEnumerable<Revenue> Revenues, IEnumerable<IEnumerable<string>> Errors)> CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration revenuesConfiguration, IEnumerable<RevenueDto> dtos, bool isExcelImport = false, int initialLine = 0, bool refreshRevenues = false, CancellationToken cancellationToken = default);

    #endregion
}

public sealed class Unique
{
    #region --- PROPERTIES ---

    public int Year { get; set; }

    public string LineOfBusinessName { get; set; }

    public string CustomerName { get; set; }

    public string ProjectName { get; set; }

    public string TypeOfServiceName { get; set; }

    public string ServiceDescription { get; set; }

    #endregion

    #region --- CONSTRUCTORS ---

    public Unique() { }

    public Unique(RevenueDto r)
    {
        Year = r.Year;
        LineOfBusinessName = r.LineOfBusinessName;
        CustomerName = r.CustomerName;
        ProjectName = r.ProjectName;
        TypeOfServiceName = r.TypeOfServiceName;
        ServiceDescription = r.ServiceDescription;
    }

    #endregion

    #region --- INTERNAL METHODS ---

    public override string ToString() =>
        $"{nameof(Revenue.Year)}: {Year}, " +
        $"{nameof(Revenue.LineOfBusiness)}: {LineOfBusinessName}, " +
        $"{nameof(Revenue.Customer)}: {CustomerName}, " +
        $"{nameof(Revenue.Project)}: {ProjectName}, " +
        $"{nameof(Revenue.TypeOfService)}: {TypeOfServiceName}, " +
        $"{nameof(Revenue.ServiceDescription)}: {ServiceDescription}";

    #endregion

    #region --- PUBLIC METHODS ---

    public override bool Equals(object obj)
    {
        if (obj == null || obj.GetType() != GetType()) return false;
        var other = (Unique)obj;
        return Year.Equals(other.Year) &&
            LineOfBusinessName.EqualsICIC(other.LineOfBusinessName) &&
            CustomerName.EqualsICIC(other.CustomerName) &&
            ProjectName.EqualsICIC(other.ProjectName) &&
            TypeOfServiceName.EqualsICIC(other.TypeOfServiceName) &&
            StringExtensions.EqualsICIC(ServiceDescription, other.ServiceDescription);
    }

    public override int GetHashCode() => 0;

    #endregion
}

public sealed class RevenueService : BaseService, IRevenueService
{
    #region --- REFERENCES ---

    private readonly IPrivateRevenueFrontEndRepository _privateFrontEndRepository;

    private readonly IRevenueRepository _repository;

    #endregion

    #region --- CONSTRUCTORS ---

    internal RevenueService(IServiceProvider services) : base(services)
    {
        _privateFrontEndRepository = Guard.Argument(services, nameof(services)).IsNotNull().Value.GetRequiredService<IPrivateRevenueFrontEndRepository>();
        _repository = Guard.Argument(services, nameof(services)).IsNotNull().Value.GetRequiredService<IRevenueRepository>();
    }

    #endregion

    #region --- PUBLIC METHODS ---

    #region --- HELPERS ---

    public static Func<RevenueDto, Unique> UniqueGroupByDto() => r => new Unique(r);

    #endregion

    public async Task<(int Count, IEnumerable<RevenueDto> Result)> GetRevenuesAsync(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, int maxCount = -1, CancellationToken cancellationToken = default)
    {
        var result = await _privateFrontEndRepository.GetRevenuesAsync(dtos: dtos, dataSourceRequest: dataSourceRequest, includeCount: includeCount, maxCount: maxCount, cancellationToken: cancellationToken).ConfigureAwait(false);
        await CompleteRevenues(result.Result, cancellationToken: cancellationToken).ConfigureAwait(false);
        return result;
    }

    public async Task<RevenueDto> GetRevenueByIdAsync(long id, string[] dtos = default, CancellationToken cancellationToken = default)
    {
        var result = await _privateFrontEndRepository.GetRevenueByIdAsync(id, dtos: dtos, cancellationToken: cancellationToken).ConfigureAwait(false);
        await CompleteRevenues(new RevenueDto[] { result }, cancellationToken: cancellationToken).ConfigureAwait(false);
        return result;
    }

    public async Task<(IEnumerable<Revenue> Revenues, IEnumerable<IEnumerable<string>> Errors)> CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration revenuesConfiguration, IEnumerable<RevenueDto> dtos, bool isExcelImport = false, int initialLine = 0, bool refreshRevenues = false, CancellationToken cancellationToken = default)
    {
        // Check Inputs
        if (dtos == null) return (Array.Empty<Revenue>(), new string[][] { new string[] { "Empty array." } });
        // Initialize
        var errors = new List<IEnumerable<string>>();
        // Check Duplicates
        var duplicates = dtos.GroupBy(UniqueGroupByDto());
        foreach (var x in duplicates.Where(d => d.Count() > 1).Select(y => y.Key))
        {
            var rows = dtos.Select((r, i) => new { r, i }).Where(z => new Unique(z.r).Equals(x)).Select(w => w.i + initialLine);
            errors.Add(new string[] { $"Duplicated {nameof(Revenue)}s in rows [{string.Join(", ", rows)}] with values: {{" +
                $"{nameof(Revenue.Year)}: {x.Year}, " +
                $"{nameof(Revenue.LineOfBusiness)}: {x.LineOfBusinessName}, " +
                $"{nameof(Revenue.Customer)}: {x.CustomerName}, " +
                $"{nameof(Revenue.Project)}: {x.ProjectName}, " +
                $"{nameof(Revenue.TypeOfService)}: {x.TypeOfServiceName}, " +
                $"{nameof(Revenue.ServiceDescription)}: {x.ServiceDescription} }}" });
        }

        if (errors.Any()) return (null, errors);
        // Initialize
        var revenues = new List<Revenue>();
        var masterDatasDictionary = await GetMasterDatasDictionary(cancellationToken: cancellationToken).ConfigureAwait(false);
        var fields = await FieldRepository.GetFieldsByEntityAsync<Revenue>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var yearsLocks = await RevenueRepository.GetYearLocksAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        // ForEach
        foreach (var dtoGrouping in dtos.GroupBy(r => r.Year))
        {
            var revenuesDb = (await RevenueRepository.GetRevenuesByYearAndUniqueIndexAsync(dtoGrouping.Key, dtoGrouping.Select(dto => (dto.LineOfBusinessName, dto.CustomerName, dto.ProjectName, dto.TypeOfServiceName, dto.ServiceDescription)).ToArray(), includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false)).ToArray();
            foreach (var dto in dtoGrouping)
            {
                var errorPrefix = isExcelImport ? $"Line {initialLine++}: " : string.Empty;
                // Get Revenue by Fields
                var revenue = revenuesDb.SingleOrDefault(r =>
                    r.Year.Equals(dtoGrouping.Key)
                    && r.LineOfBusiness.Name.EqualsICIC(dto.LineOfBusinessName)
                    && r.Customer.Name.EqualsICIC(dto.CustomerName)
                    && r.Project.Name.EqualsICIC(dto.ProjectName)
                    && r.TypeOfService.Name.EqualsICIC(dto.TypeOfServiceName)
                    && StringExtensions.EqualsICIC(r.ServiceDescription, dto.ServiceDescription));
                // Revenue already exists
                if (revenue != null && (dto.Id.Equals(0) || !dto.Id.Equals(revenue.Id)) && !isExcelImport)
                {
                    AddResult(
                        null,
                        new string[]
                        {
                                $"{nameof(Revenue)} {{ " +
                                $"{nameof(Revenue.Year)}: {dto.Year}, "+
                                $"{nameof(Revenue.LineOfBusiness)}: {dto.LineOfBusinessName}, "+
                                $"{nameof(Revenue.Customer)}: {dto.CustomerName}, "+
                                $"{nameof(Revenue.Project)}: {dto.ProjectName}, "+
                                $"{nameof(Revenue.TypeOfService)}: {dto.TypeOfServiceName}, "+
                                $"{nameof(Revenue.ServiceDescription)}: {dto.ServiceDescription}"+
                                $" }} already exists."
                        });

                    continue;
                }
                // Update - Get Revenue by Id
                if (!dto.Id.Equals(0) && revenue == null)
                {
                    revenue = await RevenueRepository.GetRevenueByIdAsync(dto.Id, includeComments: true, cancellationToken: cancellationToken).ConfigureAwait(false);
                    // Update Revenue not Found
                    if (revenue == null)
                    {
                        AddResult(null, new string[] { $"{nameof(Revenue)} with {nameof(Revenue.Id)} \"{dto.Id}\" not found." });
                        continue;
                    }
                }

                dto.Id = revenue?.Id ?? 0;
                // Validate Dto
                var (revenueProperties, dtoErrors) = ValidateDtoAsync(dto, revenuesConfiguration, fields.Select(f => (f, f.Deconstruct())), masterDatasDictionary, errorPrefix);
                // Dto with Errors
                if (dtoErrors.Any()) AddResult(null, dtoErrors);
                // Dto without Errors
                else
                {
                    var partialErrors = new List<string>();
                    // Validations - Owner/PM
                    ValidateRevenueOwnership(revenue, currentUser, partialErrors, errorPrefix: errorPrefix);
                    if (!partialErrors.Any())
                    {
                        // Create Revenue
                        if (dto.Id <= 0)
                        {
                            try
                            {
                                revenue = new Revenue(
                                    (int)revenueProperties[nameof(Revenue.Year)],
                                    (LineOfBusiness)revenueProperties[nameof(Revenue.LineOfBusiness)],
                                    (Project)revenueProperties[nameof(Revenue.Project)],
                                    (Customer)revenueProperties[nameof(Revenue.Customer)],
                                    (TypeOfService)revenueProperties[nameof(Revenue.TypeOfService)],
                                    ((BusinessUnit)revenueProperties[nameof(Revenue.BusinessUnit)], (CostCenter)revenueProperties[nameof(Revenue.CustomerCostCenter)]),
                                    (ChargingModel)revenueProperties[nameof(Revenue.ChargingModel)],
                                    (CostCenter)revenueProperties[nameof(Revenue.InternalCostCenterPerCost)],
                                    (Currency)revenueProperties[nameof(Revenue.Currency)],
                                    (ValueAddedTax)revenueProperties[nameof(Revenue.ValueAddedTax)],
                                    (User)revenueProperties[nameof(Revenue.OwnerProjectManager)],
                                    (Product)revenueProperties[nameof(Revenue.Product)],
                                    (DateTime)revenueProperties[nameof(Revenue.PlannedStartDate)],
                                    (DateTime)revenueProperties[nameof(Revenue.PlannedEndDate)],
                                    currencyExchangeRates: (IEnumerable<CurrencyExchangeRate>)revenueProperties[nameof(Revenue.CurrencyExchangeRates)],
                                    internalCode: (string)revenueProperties[nameof(Revenue.InternalCode)],
                                    serviceDescription: (string)revenueProperties[nameof(Revenue.ServiceDescription)],
                                    testingTool: (TestingTool)revenueProperties[nameof(Revenue.TestingTool)],
                                    testingToolProjectName: (string)revenueProperties[nameof(Revenue.TestingToolProjectName)],
                                    testingToolDetailedInfo: (string)revenueProperties[nameof(Revenue.TestingToolDetailedInfo)],
                                    groupOwner: (Group)revenueProperties[nameof(Revenue.GroupOwner)],
                                    currentUser: currentUser);
                            }
                            catch (Exception e)
                            {
                                AddResult(null, new string[] { e.Message });
                                continue;
                            }
                        }
                        // Update Revenue
                        else
                        {
                            try
                            {
                                revenue
                                    .UpdateYearAndPlannedDates((int)revenueProperties[nameof(Revenue.Year)], (DateTime)revenueProperties[nameof(Revenue.PlannedStartDate)], (DateTime)revenueProperties[nameof(Revenue.PlannedEndDate)], currentUser: currentUser)
                                    .UpdateLineOfBusiness((LineOfBusiness)revenueProperties[nameof(Revenue.LineOfBusiness)], currentUser: currentUser)
                                    .UpdateCustomer((Customer)revenueProperties[nameof(Revenue.Customer)], currentUser: currentUser)
                                    .UpdateProject((Project)revenueProperties[nameof(Revenue.Project)], currentUser: currentUser)
                                    .UpdateTypeOfService((TypeOfService)revenueProperties[nameof(Revenue.TypeOfService)], currentUser: currentUser)
                                    .UpdateServiceDescription((string)revenueProperties[nameof(Revenue.ServiceDescription)], currentUser: currentUser)
                                    .UpdateOwnerProjectManager((User)revenueProperties[nameof(Revenue.OwnerProjectManager)], currentUser: currentUser)
                                    .UpdateBusinessUnitAndCustomerCostCenter((BusinessUnit)revenueProperties[nameof(Revenue.BusinessUnit)], (CostCenter)revenueProperties[nameof(Revenue.CustomerCostCenter)], currentUser: currentUser)
                                    .UpdateChargingModel((ChargingModel)revenueProperties[nameof(Revenue.ChargingModel)], currentUser: currentUser)
                                    .UpdateInternalCostCenterPerCost((CostCenter)revenueProperties[nameof(Revenue.InternalCostCenterPerCost)], currentUser: currentUser)
                                    .UpdateInternalCode((string)revenueProperties[nameof(Revenue.InternalCode)], currentUser: currentUser)
                                    .UpdateCurrency((Currency)revenueProperties[nameof(Revenue.Currency)], currentUser: currentUser)
                                    .UpdateValueAddedTax((ValueAddedTax)revenueProperties[nameof(Revenue.ValueAddedTax)])
                                    .UpdateProduct((Product)revenueProperties[nameof(Revenue.Product)], currentUser: currentUser)
                                    .UpdateTestingTool((TestingTool)revenueProperties[nameof(Revenue.TestingTool)], (string)revenueProperties[nameof(Revenue.TestingToolProjectName)], (string)revenueProperties[nameof(Revenue.TestingToolDetailedInfo)], currentUser: currentUser)
                                    .UpdateGroupOwner((Group)revenueProperties[nameof(Revenue.GroupOwner)], currentUser: currentUser)
                                    .SetCurrencyExchangeRates((IEnumerable<CurrencyExchangeRate>)revenueProperties[nameof(Revenue.CurrencyExchangeRates)]);
                            }
                            catch (Exception e)
                            {
                                AddResult(null, new string[] { e.Message });
                                continue;
                            }
                        }
                        // Update Revenue Comments
                        dto.Comments?.Where(rc => rc != null && rc.Id <= 0 && !string.IsNullOrWhiteSpace(rc.Text))?.ForEach(rc => revenue.AddComment(rc.Text, currentUser));
                        // Update Revenue Months
                        var bypassLockedRevenues = currentUser.HasPermission(Constants.Permission_BypassLockedRevenues);
                        var monthsRevenues = new Dictionary<Month, MonthRevenue>();
                        Revenue.GetMonths().ForEach(m =>
                        {
                            var newMonthRevenue = (MonthRevenue)revenueProperties[m.ToString()];
                            var monthRevenue = revenue.GetMonthsRevenues().Single(mr => mr.Month.Equals(m)).Value;
                            var locked = yearsLocks.SingleOrDefault(x => x.Year.Equals(revenue.Year) && x.ChargingModelType.Id.Equals(revenue.ChargingModel.Type.Id))?.GetLock(m) ?? false;
                            // Unlocked, No Amount, Equals or Bypass
                            if (!locked || AmountsEquals(monthRevenue.Amount, newMonthRevenue.Amount) || bypassLockedRevenues) monthsRevenues.Add(m, new MonthRevenue(newMonthRevenue.Amount));
                            else partialErrors.Add($"{errorPrefix}Month {m} cannot be modified due to the Month is locked.");
                        });

                        revenue.UpdateMonthsRevenues(monthsRevenues, currentUser: currentUser);
                        revenue.UpdatePlanAndTransfer(plan: (decimal?)revenueProperties[nameof(Revenue.PlanLC)], transfer: (decimal?)revenueProperties[nameof(Revenue.TransferLC)], currentUser: currentUser);
                        // Refresh
                        if (refreshRevenues) revenue.RefreshFyf(currentUser: currentUser);
                        // Validations - Plan && Transfer
                        ValidateRevenuePlanTransfer(revenue, dto, currentUser, partialErrors, errorPrefix: errorPrefix);
                        // Validations - Check True-Up
                        ValidateRevenueTrueUp(revenuesConfiguration, revenue, partialErrors, errorPrefix: errorPrefix);
                        // Validations - Restrictions
                        ValidateRevenueRestrictions(revenuesConfiguration, revenue, partialErrors, errorPrefix: errorPrefix);
                        // Validations - Previously Billed
                        ValidateRevenuesPreviouslyBilled(revenue, currentUser, yearsLocks, partialErrors, errorPrefix: errorPrefix);
                        // Validations - Planned Dates
                        ValidateRevenuePlannedDates(revenue, currentUser, dto.Year, dto.PlannedStartDate, dto.PlannedEndDate, partialErrors, errorPrefix: errorPrefix);
                    }
                    // Partial Result
                    if (partialErrors.Any()) AddResult(null, partialErrors);
                    else AddResult(revenue);
                }
            }
        }
        // Result
        return (revenues, errors);

        #region --- NESTED METHODS ---

        void AddResult(Revenue r, IEnumerable<string> e = default)
        {
            if (r != null && r.Id.Equals(0)) RevenueRepository.AddRevenue(r);
            revenues.Add(r);
            errors.Add(e ?? Array.Empty<string>());
        }

        bool AmountsEquals(decimal? a, decimal? b)
        {
            if (a.HasValue && a.Equals((decimal)0)) a = null;
            if (b.HasValue && b.Equals((decimal)0)) b = null;
            return Equals(a, b);
        }

        #endregion
    }

    #endregion

    #region --- PRIVATE METHODS ---

    private static (IDictionary<string, object> RevenueProperties, IEnumerable<string> Errors) ValidateDtoAsync(RevenueDto dto, RevenuesConfiguration revenuesConfiguration, IEnumerable<(Field Value, (bool IsMasterData, string Type, Type MasterDataType, string Reference) Deconstruction)> fields, IDictionary<Type, IEnumerable<object>> masterDatas, string errorPrefix)
    {
        // Initialize
        var errors = new List<string>();
        var revenueProperties = new Dictionary<string, object>();
        // Year
        var yearField = fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.Year)));
        ValidateFreeField(yearField, dto.Year, errors, revenueProperties, validation: new Func<object, (bool R, string E)>(x => ((int)x) < 0 ? (false, $"Invalid {nameof(Field)} \"{yearField.Value.LabelOnFile ?? yearField.Value.EntityReference}\". Must be greater than 0.") : (true, null)));
        // Internal Code
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.InternalCode))), dto.InternalCode, errors, revenueProperties);
        // Service Description
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.ServiceDescription))), dto.ServiceDescription, errors, revenueProperties);
        // Project
        ValidateMasterDataField<Project>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.Project))), dto.ProjectName, masterDatas, errors, revenueProperties);
        // Customer
        ValidateMasterDataField<Customer>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.Customer))), dto.CustomerName, masterDatas, errors, revenueProperties);
        // Line of Business
        ValidateMasterDataField<LineOfBusiness>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.LineOfBusiness))), dto.LineOfBusinessName, masterDatas, errors, revenueProperties);
        // Type of Service
        ValidateMasterDataField<TypeOfService>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.TypeOfService))), dto.TypeOfServiceName, masterDatas, errors, revenueProperties);
        // Product
        ValidateMasterDataField<Product>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.Product))), dto.ProductName, masterDatas, errors, revenueProperties);
        // PlannedStartDate
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.PlannedStartDate))), dto.PlannedStartDate, errors, revenueProperties);
        // PlannedEndDate
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.PlannedEndDate))), dto.PlannedEndDate, errors, revenueProperties);
        // Owner/PM
        var oPmField = fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.OwnerProjectManager)));
        var (validOPm, valueOPm) = ValidateField(oPmField, dto.OwnerProjectManagerName);
        if (!validOPm && oPmField.Value.Required)
        {
            errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{oPmField.Value.LabelOnFile ?? oPmField.Value.EntityReference}\". Current value: \"{dto.OwnerProjectManagerName}\".");
        }
        else
        {
            var users = (IEnumerable<User>)masterDatas[typeof(User)];
            var user = users.SingleOrDefault(u => u.Name.EqualsICIC(dto.OwnerProjectManagerName));
            if (user == null && (oPmField.Value.Required || !string.IsNullOrWhiteSpace(valueOPm?.ToString()))) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{oPmField.Value.LabelOnFile ?? oPmField.Value.EntityReference}\". Current value: \"{dto.OwnerProjectManagerName}\" does not exists as \"{typeof(User).Name}\".");
            else revenueProperties.Add(nameof(Revenue.OwnerProjectManager), user);
        }
        // Group
        var gField = fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.GroupOwner)));
        var (validG, valueG) = ValidateField(gField, dto.GroupOwnerName);
        if (!validG && gField.Value.Required)
        {
            errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{gField.Value.LabelOnFile ?? gField.Value.EntityReference}\". Current value: \"{dto.GroupOwnerName}\".");
        }
        else
        {
            var groups = (IEnumerable<Group>)masterDatas[typeof(Group)];
            var group = groups.SingleOrDefault(u => u.Name.EqualsICIC(dto.GroupOwnerName));
            if (group == null && (gField.Value.Required || !string.IsNullOrWhiteSpace(valueG?.ToString()))) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{gField.Value.LabelOnFile ?? gField.Value.EntityReference}\". Current value: \"{dto.GroupOwnerName}\" does not exists as \"{typeof(Group).Name}\".");
            else revenueProperties.Add(nameof(Revenue.GroupOwner), group);
        }
        // BU Code
        var buField = fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.BusinessUnit)));
        ValidateMasterDataField<BusinessUnit>(buField, dto.BusinessUnitCode, masterDatas, errors, revenueProperties);
        // CC Customer
        var cccField = fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.CustomerCostCenter)));
        ValidateMasterDataField(cccField, dto.CustomerCostCenterCode, masterDatas, errors, revenueProperties, where: new Func<CostCenter, bool>(cc => cc.Types.Any(t => t.Equals(CostCenterType.Customer))));
        if (!revenueProperties.ContainsKey(nameof(Revenue.BusinessUnit)) && !revenueProperties.ContainsKey(nameof(Revenue.CustomerCostCenter))) errors.Add($"{nameof(Field)} \"{buField.Value.LabelOnFile ?? buField.Value.EntityReference}\" or \"{cccField.Value.LabelOnFile ?? cccField.Value.EntityReference}\" is required.");
        // Currency
        ValidateMasterDataField<Currency>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.Currency))), dto.CurrencyCode, masterDatas, errors, revenueProperties);
        // Charging Model
        ValidateMasterDataField<ChargingModel>(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.ChargingModel))), dto.ChargingModelCode, masterDatas, errors, revenueProperties);
        // Testing Tool
        ValidateMasterDataField<TestingTool>(fields.Single(x => x.Value.EntityReference.EqualsICIC(nameof(Revenue.TestingTool))), dto.TestingToolName, masterDatas, errors, revenueProperties);
        // Testing Tool Project Name
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.TestingToolProjectName))), dto.TestingToolProjectName, errors, revenueProperties);
        // Testing Tool Detailed Info
        ValidateFreeField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.TestingToolDetailedInfo))), dto.TestingToolDetailedInfo, errors, revenueProperties);
        // Internal CC Per Cost
        ValidateMasterDataField(fields.Single(f => f.Value.EntityReference.EqualsICIC(nameof(Revenue.InternalCostCenterPerCost))), dto.InternalCostCenterPerCostCode, masterDatas, errors, revenueProperties, where: new Func<CostCenter, bool>(cc => cc.Types.Any(t => t.Equals(CostCenterType.Internal))));
        // Plan
        ValidateFreeField(fields.Single(x => x.Value.EntityReference.EqualsICIC(nameof(Revenue.PlanLC))), dto.PlanLC, errors, revenueProperties);
        // Transfer
        ValidateFreeField(fields.Single(x => x.Value.EntityReference.EqualsICIC(nameof(Revenue.TransferLC))), dto.TransferLC, errors, revenueProperties);
        // Month Revenues
        foreach (var m in Revenue.GetMonths())
        {
            // Ammount
            var monthRevenueAmmountField = fields.Single(f => f.Value.EntityReference.EqualsICIC($"{m}.{nameof(MonthRevenue.Amount)}"));
            var mrAmount = ((MonthRevenueDto)dto.GetType().GetProperty(m.ToString()).GetValue(dto))?.Amount;
            if (mrAmount.HasValue && mrAmount.Equals((decimal?)0)) mrAmount = null;
            var (validAmount, valueAmount) = ValidateField(monthRevenueAmmountField, mrAmount);
            if (valueAmount?.Equals(decimal.MinValue) ?? false) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{monthRevenueAmmountField.Value.LabelOnFile ?? monthRevenueAmmountField.Value.EntityReference}\".");
            if (!validAmount && monthRevenueAmmountField.Value.Required) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{monthRevenueAmmountField.Value.LabelOnFile ?? monthRevenueAmmountField.Value.EntityReference}\". Current value: \"{mrAmount}\".");
            else revenueProperties.Add(m.ToString(), new MonthRevenue((decimal?)valueAmount));
        }
        // Exchange Rates
        if (revenueProperties.ContainsKey(nameof(Revenue.Currency)) && revenueProperties.ContainsKey(nameof(Revenue.Year)))
        {
            revenueProperties.Add(nameof(Revenue.CurrencyExchangeRates), masterDatas[typeof(CurrencyExchangeRate)]);
        }
        // VAT
        var vats = (IEnumerable<ValueAddedTax>)masterDatas[typeof(ValueAddedTax)];
        if (revenuesConfiguration.ChargingModelsCodesWithoutVat.Any(cc => cc.EqualsICIC(dto.ChargingModelCode))) revenueProperties.Add(nameof(Revenue.ValueAddedTax), vats.Single(vat => vat.Country.EqualsICIC(ValueAddedTax.None)));
        else if (dto.Year == 2024)
        {
            revenueProperties.Add(nameof(Revenue.ValueAddedTax), vats.Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry2024)));
        }
        else
        {
            revenueProperties.Add(nameof(Revenue.ValueAddedTax), vats.Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry)));
        } // Result
        return (revenueProperties, errors);

        #region --- NESTED METHODS ---

        void ValidateFreeField((Field Value, (bool IsMasterData, string Type, Type MasterDataType, string Reference) Deconstruction) field, object @object, IList<string> errors, Dictionary<string, object> revenueProperties, Func<object, (bool R, string E)> validation = default)
        {
            var (valid, value) = ValidateField(field, @object);
            var (r, e) = validation != null ? validation(@object) : (true, null);
            if (!valid && field.Value.Required) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{field.Value.LabelOnFile ?? field.Value.EntityReference}\". Current value: \"{@object}\".");
            else if (validation != null && !r) errors.Add($"{errorPrefix}{e}");
            else revenueProperties.Add(field.Value.EntityReference, value);
        }

        void ValidateMasterDataField<T>((Field Value, (bool IsMasterData, string Type, Type MasterDataType, string Reference) Deconstruction) field, object @object, IDictionary<Type, IEnumerable<object>> masterDatas, IList<string> errors, Dictionary<string, object> revenueProperties, Func<T, bool> where = null) where T : MasterData
        {
            var (valid, value) = ValidateField(field, @object);
            if (!valid && field.Value.Required)
            {
                errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{field.Value.LabelOnFile ?? field.Value.EntityReference}\". Current value: \"{@object}\".");
            }
            else
            {
                var mds = masterDatas[typeof(T)];
                if (where != null) mds = ((IEnumerable<T>)mds).Where(where);
                var mdAux = mds.SingleOrDefault(md => md.GetType().GetProperty(field.Deconstruction.Reference).GetValue(md).ToString().EqualsICIC(value?.ToString()));
                if (mdAux == null && (field.Value.Required || !string.IsNullOrWhiteSpace(value?.ToString()))) errors.Add($"{errorPrefix}Invalid {nameof(Field)} \"{field.Value.LabelOnFile ?? field.Value.EntityReference}\". Current value: \"{value}\" does not exists as \"{typeof(T).Name}\" MasterData.");
                else revenueProperties.Add(field.Value.EntityReference, mdAux);
            }
        }

        #endregion
    }

    private async Task<IDictionary<Type, IEnumerable<object>>> GetMasterDatasDictionary(CancellationToken cancellationToken = default) =>
        new Dictionary<Type, IEnumerable<object>>
        {
            { typeof(User), (await UserRepository.GetUsersAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Result },
            { typeof(BusinessUnit), await MasterDataRepository.GetMasterDatasByEntityAsync<BusinessUnit>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(Group), (await GroupRepository.GetGroupsAsync(includeUsers: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result },
            { typeof(ChargingModel), await MasterDataRepository.GetMasterDatasByEntityAsync<ChargingModel>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(CostCenter), await MasterDataRepository.GetMasterDatasByEntityAsync<CostCenter>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(Currency), await MasterDataRepository.GetMasterDatasByEntityAsync<Currency>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(CurrencyExchangeRate), await MasterDataRepository.GetCurrenciesExchangeRatesAsync(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(Customer), await MasterDataRepository.GetMasterDatasByEntityAsync<Customer>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(LineOfBusiness), await MasterDataRepository.GetMasterDatasByEntityAsync<LineOfBusiness>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(Project), await MasterDataRepository.GetMasterDatasByEntityAsync<Project>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(TypeOfService), await MasterDataRepository.GetMasterDatasByEntityAsync<TypeOfService>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(ValueAddedTax), await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(Product), await MasterDataRepository.GetMasterDatasByEntityAsync<Product>(cancellationToken: cancellationToken).ConfigureAwait(false) },
            { typeof(TestingTool), await MasterDataRepository.GetMasterDatasByEntityAsync<TestingTool>(cancellationToken: cancellationToken).ConfigureAwait(false) }
        };

    [SuppressMessage("Usage", "CA2208: Instantiate argument exceptions correctly.", Justification = "Object argument")]
    [SuppressMessage("Major Code Smell", "S3928:P arameter names used into ArgumentException constructors should match an existing one ", Justification = "Object argument")]
    private static (bool Valid, object Value) ValidateField((Field Value, (bool IsMasterData, string Type, Type MasterDataType, string Reference) Deconstruction) field, object value)
    {
        // long
        if (field.Deconstruction.Type.EqualsICIC(typeof(long).Name))
        {
            if (string.IsNullOrWhiteSpace(value?.ToString()))
            {
                if (field.Value.Required) return (false, 0);
                return (true, (long?)null);
            }

            if (value.GetType().Equals(typeof(long))) return (true, (long)value);
            if (long.TryParse(value?.ToString(), out var @long)) return (true, @long);
            return (false, value);
        }
        // int
        if (field.Deconstruction.Type.EqualsICIC(typeof(int).Name))
        {
            if (string.IsNullOrWhiteSpace(value?.ToString()))
            {
                if (field.Value.Required) return (false, 0);
                return (true, (int?)null);
            }

            if (value.GetType().Equals(typeof(int))) return (true, (int)value);
            if (int.TryParse(value?.ToString(), out var @int)) return (true, @int);
            return (false, value);
        }
        // decimal
        else if (field.Deconstruction.Type.EqualsICIC(typeof(decimal).Name))
        {
            if (string.IsNullOrWhiteSpace(value?.ToString()))
            {
                if (field.Value.Required) return (false, 0.0m);
                return (true, (decimal?)null);
            }

            if (value.GetType().Equals(typeof(decimal))) return (true, (decimal)value);
            if (decimal.TryParse(value?.ToString(), out var @decimal)) return (true, @decimal);
            return (false, value);
        }
        // string
        else if (field.Deconstruction.Type.EqualsICIC(typeof(string).Name))
        {
            if (string.IsNullOrWhiteSpace(value?.ToString()) && field.Value.Required) return (false, null);
            return (true, (value?.ToString())?.Trim());
        }
        // bool
        else if (field.Deconstruction.Type.EqualsICIC(typeof(bool).Name))
        {
            if (string.IsNullOrEmpty(value?.ToString()) && field.Value.Required) return (false, null);
            return (bool.TryParse(value?.ToString(), out var @bool), @bool);
        }
        // Date
        else if (field.Deconstruction.Type.EqualsICIC("date"))
        {
            var isDateTime = value?.GetType()?.Equals(typeof(DateTime)) ?? false;
            if (isDateTime)
            {
                var d = (DateTime)value;
                return (!d.Equals(default), d);
            }
            else
            {
                var d = (DateTime?)value;
                return ((field.Value.Required && value != null && !d.Value.Equals(default)) || !field.Value.Required, d);
            }
        }
        // Exception
        else
        {
            throw new ArgumentOutOfRangeException(nameof(field.Deconstruction.Type), $"Must be \"{typeof(int).Name.ToLower()}, \"{typeof(long).Name.ToLower()}, {typeof(decimal).Name.ToLower()}, {typeof(bool).Name.ToLower()} or {typeof(string).Name.ToLower()}\".");
        }
    }

    private async Task CompleteRevenues(IEnumerable<RevenueDto> revenues, CancellationToken cancellationToken = default)
    {
        if (revenues == null || !revenues.Any()) return;
        var currentUser = await CurrentUserService.GetUserAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var permissionBypassOwnedRevenues = currentUser.HasPermission(Constants.Permission_BypassOwnedRevenues);
        var permissionManageRevenues = currentUser.HasPermission(Constants.Permission_ManageRevenue);
        var permissionDeleteRevenue = currentUser.HasPermission(Constants.Permission_DeleteRevenue);
        var permissionBypassPlannedDatesRevenues = currentUser.HasPermission(Constants.Permission_BypassPlannedDatesRevenues);
        var permissionBypassLockedRevenues = currentUser.HasPermission(Constants.Permission_BypassLockedRevenues);
        var yearsLocks = permissionBypassLockedRevenues ? Array.Empty<YearLocks>() : await _repository.GetYearLocksAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        var groups = (await GroupRepository.GetGroupsAsync(asNoTracking: true, includeUsers: true, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
        revenues.ForEach(r =>
        {
            r.Editable = permissionManageRevenues && (permissionBypassOwnedRevenues || r.OwnerProjectManagerName.EqualsICIC(currentUser.Name) || (!string.IsNullOrWhiteSpace(r.GroupOwnerName) && (groups.SingleOrDefault(g => g.Name.EqualsICIC(r.GroupOwnerName))?.Users?.Any(u => u.Id.Equals(currentUser.Id)) ?? false))) && (permissionBypassPlannedDatesRevenues || r.PlannedEndDate >= DateTime.UtcNow);
            r.Deletable = permissionDeleteRevenue;
            r.Commentable = permissionManageRevenues;
            var lockYear = permissionBypassLockedRevenues ? null : yearsLocks.SingleOrDefault(x => x.Year.Equals(r.Year) && x.ChargingModelType.Type.EqualsICIC(r.ChargingModelType));
            Revenue.GetMonths().ForEach(m =>
            {
                var p = r.GetType().GetProperty(m.ToString());
                p.PropertyType.GetProperty(nameof(MonthRevenueDto.Locked)).SetValue(p.GetValue(r), !permissionBypassLockedRevenues && (lockYear?.GetLock(m) ?? false));
            });
        });
    }

    private static void ValidateRevenueOwnership(Revenue revenue, User currentUser, IList<string> errors, string errorPrefix = default)
    {
        if (!currentUser.HasPermission(Constants.Permission_BypassOwnedRevenues) && revenue != null && !currentUser.Id.Equals(revenue.OwnerProjectManager.Id) && (revenue.GroupOwner == null || !revenue.GroupOwner.Users.Any(x => x.Id.Equals(currentUser.Id))))
        {
            errors.Add($"{errorPrefix}Cannot be modified due to you are not the '{Revenue.OwnerProjectManagerDescription}' or '{Revenue.GroupOwnerDescription}'.");
        }
    }

    private static void ValidateRevenueTrueUp(RevenuesConfiguration revenuesConfiguration, Revenue revenue, IList<string> errors, string errorPrefix = default)
    {
        if (revenuesConfiguration == null) return;
        if (revenuesConfiguration.TrueUpMustSumZeroEnabled && revenue.TypeOfService.IsTrueUp)
        {
            if (revenue.FYFCLC.HasValue && !revenue.FYFCLC.Equals(decimal.Zero))
            {
                errors.Add($"{errorPrefix}{ConstantsMessages.Revenue.TrueUpFyfclc(revenue.FYFCLC)}");
            }

            if (revenue.FYFCCHF.HasValue && !revenue.FYFCCHF.Equals(decimal.Zero))
            {
                errors.Add($"{errorPrefix}Has invalid month values. True-Up {nameof(Revenue)} {nameof(Revenue.FYFCCHF)} mut be equals to 0 but is {revenue.FYFCCHF}.");
            }
        }
    }

    private static void ValidateRevenueRestrictions(RevenuesConfiguration revenuesConfiguration, Revenue revenue, IList<string> errors, string errorPrefix = default)
    {
        if (revenuesConfiguration == null || revenuesConfiguration.Restrictions == null) return;
        revenuesConfiguration.Restrictions.ForEach(r =>
        {
            // Get Property Values
            var propertyValue = revenue.GetType().GetProperty(r.Property).GetValue(revenue);
            if (!string.IsNullOrEmpty(r.PropertyProperty))
            {
                propertyValue = propertyValue.GetType().GetProperty(r.PropertyProperty).GetValue(propertyValue);
            }
            // Property Value Match
            if (r.Values.Any(v => v.EqualsICIC(propertyValue?.ToString())))
            {
                // Get Dependant Property Values
                var dependantPropertyValue = revenue.GetType().GetProperty(r.RestrictedProperty).GetValue(revenue);
                if (!string.IsNullOrEmpty(r.RestrictedPropertyProperty))
                {
                    dependantPropertyValue = dependantPropertyValue.GetType().GetProperty(r.RestrictedPropertyProperty).GetValue(dependantPropertyValue);
                }
                // Dependant Property Value Match
                if (!r.RestrictedValues.Any(v => v.EqualsICIC(dependantPropertyValue?.ToString())))
                {
                    errors.Add($"{errorPrefix}Has invalid \"{r.RestrictedProperty}\" value. Restricted values when \"{r.Property}\" equals [ {string.Join(", ", r.Values.Select(x => $"'{x}'"))} ] are [ {string.Join(", ", r.RestrictedValues.Select(x => $"'{x}'"))} ].");
                }
            }
        });
    }

    private static void ValidateRevenuesPreviouslyBilled(Revenue revenue, User currentUser, IEnumerable<YearLocks> yearsLocks, IList<string> errors, string errorPrefix = default)
    {
        if (!currentUser.HasPermission(Constants.Permission_BypassPreviouslyBilledRevenues) &&
            !revenue.Id.Equals(0) &&
            revenue.Updates.Any(u => u.Key.EqualsICIC(nameof(Revenue.BusinessUnit)) || u.Key.Equals(nameof(Revenue.CustomerCostCenter))))
        {
            var billedMonths = revenue.GetMonthsRevenues().Where(m => m.Value.Amount.HasValue && !m.Value.Amount.Value.Equals(decimal.Zero)).Select(m => m.Month);
            if (yearsLocks.Any(x => x.Year.Equals(revenue.Year) && x.ChargingModelType.Id.Equals(revenue.ChargingModel.Type.Id) && billedMonths.Any(y => x.GetLock(y))))
            {
                errors.Add($"{errorPrefix}{ConstantsMessages.Revenue.PreviouslyBilled(billedMonths)}");
            }
        }
    }

    private static void ValidateRevenuePlannedDates(Revenue revenue, User currentUser, int year, DateTime plannedStartDate, DateTime plannedEndDate, IList<string> errors, string errorPrefix = default)
    {
        if (plannedEndDate < plannedStartDate) errors.Add($"'{Revenue.PlannedStartDateDescription}' cannot be greater than '{Revenue.PlannedEndDateDescription}'.");
        if (!year.Equals(plannedStartDate.Year)) errors.Add($"{Revenue.PlannedStartDateDescription} {nameof(Revenue.Year)} cannot be different than {nameof(Revenue.Year)} '{year}'.");
        if (!year.Equals(plannedEndDate.Year)) errors.Add($"{Revenue.PlannedEndDateDescription} {nameof(Revenue.Year)} cannot be different than {nameof(Revenue.Year)}: '{year}'.");
        if (!currentUser.HasPermission(Constants.Permission_BypassPlannedDatesRevenues) && revenue != null && revenue.PlannedEndDate < DateTime.UtcNow && revenue.Updates.Any())
        {
            errors.Add($"{errorPrefix}{ConstantsMessages.Revenue.ExpiredPlannedEndDate(revenue.PlannedEndDate)}");
        }
    }

    private static void ValidateRevenuePlanTransfer(Revenue revenue, RevenueDto dto, User currentUser, IList<string> errors, string errorPrefix = default)
    {
        // Plan
        if (!AmountsEquals(revenue.PlanLC, dto.PlanLC) && !revenue.Id.Equals(0) && !currentUser.HasPermission(Constants.Permission_RevenuesUpdatePlan) && revenue.Updates.Any(x => x.Key.EqualsICIC(nameof(Revenue.PlanLC))))
        {
            errors.Add($"{errorPrefix}Plan cannot be modified.");
        }
        // Transfer
        if (!AmountsEquals(revenue.TransferLC, dto.TransferLC) && !currentUser.HasPermission(Constants.Permission_RevenuesCreateUpdateTransfer) && revenue.Updates.Any(x => x.Key.EqualsICIC(nameof(Revenue.TransferLC))))
        {
            errors.Add($"{errorPrefix}Transfer cannot be created nor modified.");
        }

        #region --- NESTED METHODS ---

        static bool AmountsEquals(decimal? a, decimal? b)
        {
            if (a.HasValue && a.Equals((decimal)0)) a = null;
            if (b.HasValue && b.Equals((decimal)0)) b = null;
            return Equals(a, b);
        }

        #endregion
    }
}

#endregion
