﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.AspNetCore.Http;
    using System.Security.Claims;
    using System.Threading;
    using System.Threading.Tasks;

    public class CurrentHttpUserService : ICurrentUserService<User>
    {
        #region --- PROPERTIES ---

        private const string _unauthenticated = "Unauthenticated";

        private const string _unidentified = "Unidentified";

        public string Username => _httpContextAccessor.GetUsername(unauthenticated: _unauthenticated, unidentified: _unidentified);

        public string Mail => _httpContextAccessor?.HttpContext?.User?.FindFirst(ClaimTypes.Email)?.Value;

        public string DisplayName => _httpContextAccessor?.HttpContext?.User?.FindFirst(ClaimTypes.GivenName)?.Value;

        public string EmployeeId => _httpContextAccessor?.HttpContext?.User?.FindFirst(nameof(EmployeeId))?.Value;

        public string Domain => _httpContextAccessor?.HttpContext?.User?.FindFirst(nameof(Domain))?.Value;

        #endregion

        #region --- REFERENCES ---

        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IUserRepository _userRepository;

        private User _user;

        #endregion

        #region --- CONSTRUCTORS ---

        public CurrentHttpUserService(IUserRepository userRepository, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = Guard.Argument(httpContextAccessor, nameof(httpContextAccessor)).IsNotNull().Value;
            _userRepository = Guard.Argument(userRepository, nameof(userRepository)).IsNotNull().Value;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<User> GetUserAsync(CancellationToken cancellationToken = default)
        {
            if (_user == null && !string.IsNullOrWhiteSpace(Username) && !Username.EqualsICIC(_unidentified) && !Username.EqualsICIC(_unauthenticated))
            {
                _user = await _userRepository.GetUserBySAMAccountNameAsync(Username, includeRoles: true, asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
            }

            return _user;
        }

        #endregion
    }
}
