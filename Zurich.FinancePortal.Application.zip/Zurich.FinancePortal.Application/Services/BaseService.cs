﻿namespace Zurich.FinancePortal.Application
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.Extensions.DependencyInjection;
    using System;

    public abstract class BaseService
    {
        #region --- REFERENCES ---

        private readonly IServiceProvider _services;

        private IApplicationDbContext _bbContext;

        protected private IApplicationDbContext DbContext { get => _bbContext ??= _services.GetRequiredService<IApplicationDbContext>(); }

        #endregion

        #region --- REPOSITORIES ---

        // Role
        private IRoleRepository _roleRepository;
        protected private IRoleRepository RoleRepository { get => _roleRepository ??= _services.GetRequiredService<IRoleRepository>(); }

        // Revenue
        private IRevenueRepository _revenueRepository;
        protected private IRevenueRepository RevenueRepository { get => _revenueRepository ??= _services.GetRequiredService<IRevenueRepository>(); }

        private IMasterDataRepository _masterDataRepository;
        protected private IMasterDataRepository MasterDataRepository { get => _masterDataRepository ??= _services.GetRequiredService<IMasterDataRepository>(); }

        private IUserRepository _userRepository;
        protected private IUserRepository UserRepository { get => _userRepository ??= _services.GetRequiredService<IUserRepository>(); }

        private IGroupRepository _groupRepository;
        protected private IGroupRepository GroupRepository { get => _groupRepository ??= _services.GetRequiredService<IGroupRepository>(); }

        private IFieldRepository _fieldRepository;
        protected private IFieldRepository FieldRepository { get => _fieldRepository ??= _services.GetRequiredService<IFieldRepository>(); }

        private ICurrentUserService<User> _currentUserService;
        protected private ICurrentUserService<User> CurrentUserService { get => _currentUserService ??= _services.GetRequiredService<ICurrentUserService<User>>(); }

        #endregion

        #region --- CONSTRUCTORS ---

        protected private BaseService(IServiceProvider services)
        {
            _services = Guard.Argument(services, nameof(services)).IsNotNull().Value;
        }

        #endregion
    }
}
