﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public abstract class MasterData : Entity<int>
    {
        public static IEnumerable<Type> GetMasterDataTypes() =>
            Assembly.GetAssembly(typeof(MasterData)).GetTypes().Where(t => !t.Equals(typeof(MasterData)) && typeof(MasterData).IsAssignableFrom(t));
    }
}
