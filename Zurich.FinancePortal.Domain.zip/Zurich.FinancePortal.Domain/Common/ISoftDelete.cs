﻿namespace Zurich.FinancePortal.Domain
{
    public interface ISoftDelete
    {
        #region --- PROPERTIES ---

        bool IsDeleted { get; }

        #endregion
    }
}
