﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;

    public abstract class Entity<T>
    {
        #region --- PROPERTIES ---

        public T Id { get; protected set; }

        #endregion

        #region --- PUBLIC METHODS ---

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != GetType()) return false;
            var other = (Entity<T>)obj;
            var thisValues = GetAtomicValues().GetEnumerator();
            var otherValues = other.GetAtomicValues().GetEnumerator();
            while (thisValues.MoveNext() && otherValues.MoveNext())
            {
                if (thisValues.Current is null ^ otherValues.Current is null) return false;
                if (thisValues.Current != null)
                {
                    if (thisValues.Current.GetType().Equals(typeof(string)))
                    {
                        if (!((string)thisValues.Current).EqualsICIC((string)otherValues.Current)) return false;
                    }
                    else
                    {
                        if (!thisValues.Current.Equals(otherValues.Current)) return false;
                    }
                }
            }

            return !thisValues.MoveNext() && !otherValues.MoveNext();
        }

        public override int GetHashCode()
        {
            return GetAtomicValues()
                .Select(x => x != null ? x.GetHashCode() : 0)
                .Aggregate((x, y) => x ^ y);
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private abstract IEnumerable<object> GetAtomicValues();

        #endregion
    }
}
