﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class UserGridPreferences : ValueObject
    {
        #region --- PROPERTIES ---

        public string Revenues { get; set; }

        #endregion

        #region --- PREFERENCES ---

        #endregion

        #region --- CONSTRUCTORS ---

        public UserGridPreferences(string revenues = default)
        {
            Revenues = revenues;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        protected private override IEnumerable<object> GetAtomicValues()
        {
            return new object[]
            {
                Revenues
            };
        }

        #endregion
    }
}
