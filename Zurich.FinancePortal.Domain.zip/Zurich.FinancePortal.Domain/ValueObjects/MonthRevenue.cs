﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;

public class MonthRevenue : ValueObject
{
    #region --- PROPERTIES ---

    public decimal? Amount { get; }

    #endregion

    #region --- CONSTRUCTORS ---

    public MonthRevenue(decimal? amount)
    {
        Amount = RevenueService.Round(amount);
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues()
    {
        return new object[]
        {
            Amount
        };
    }

    #endregion
}
