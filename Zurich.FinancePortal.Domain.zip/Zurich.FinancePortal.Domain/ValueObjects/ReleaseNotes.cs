﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;

    public sealed class ReleaseNotes : ValueObject
    {
        #region --- PROPERTIES ---

        public int Major { get; private set; }

        public int Minor { get; private set; }

        public int Revision { get; private set; }

        [SuppressMessage("Blocker Code Smell", "S3237: \"value\" parameters should be used", Justification = "EF Core")]
        [SuppressMessage("Major Code Smell", "S108: Nested blocks of code should not be left empty", Justification = "EF Core")]
        public string Version { get => $"{Major}.{Minor}.{Revision}"; private set { } }

        public DateTime CreatedOn { get; private set; }

        public string Changes { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        public ReleaseNotes(int major, int minor, int revision, string changes)
        {
            Major = Guard.Argument(major, nameof(major)).IsGreaterThanOrEquals(0).Value;
            Minor = Guard.Argument(minor, nameof(minor)).IsGreaterThanOrEquals(0).Value;
            Revision = Guard.Argument(revision, nameof(revision)).IsGreaterThanOrEquals(0).Value;
            CreatedOn = DateTime.UtcNow;
            Changes = Guard.Argument(changes, nameof(changes)).IsNotNullOrWhiteSpace().Value;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues()
        {
            return new object[]
            {
                Major,
                Minor,
                Revision
            };
        }

        #endregion
    }
}
