﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class AdAccount : ValueObject
    {
        #region --- PROPERTIES ---

        private string _sAMAccountName;
        public string SAMAccountName { get => _sAMAccountName; set => _sAMAccountName = value?.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        public AdAccount(string sAMAccountName)
        {
            SAMAccountName = Guard.Argument(sAMAccountName, nameof(sAMAccountName)).IsNotNullOrWhiteSpace().Value;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        protected private override IEnumerable<object> GetAtomicValues()
        {
            return new object[]
            {
                SAMAccountName
            };
        }

        #endregion
    }
}
