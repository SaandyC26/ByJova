﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;

public sealed class YearLocks : ValueObject
{
    #region --- PROPERTIES ---

    public int Year { get; private set; }

    public bool January { get; private set; }

    public bool February { get; private set; }

    public bool March { get; private set; }

    public bool April { get; private set; }

    public bool May { get; private set; }

    public bool June { get; private set; }

    public bool July { get; private set; }

    public bool August { get; private set; }

    public bool September { get; private set; }

    public bool October { get; private set; }

    public bool November { get; private set; }

    public bool December { get; private set; }

    #endregion

    #region --- REFERENCES ---

    public ChargingModelType ChargingModelType { get; private set; }

    #endregion

    #region --- CONSTRUCTORS ---

    private YearLocks() { }

    public YearLocks(int year, ChargingModelType chargingModelType, IDictionary<Month, bool> months = null)
    {
        Year = Guard.Argument(year, nameof(year)).IsGreaterThan(0).Value;
        UpdateMonths(months: months);
        UpdateChargingModelType(chargingModelType);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public bool GetLock(Month month) => (bool)GetType().GetProperty(month.ToString()).GetValue(this);

    public YearLocks UpdateMonths(IDictionary<Month, bool> months = null)
    {
        foreach (var month in Revenue.GetMonths()) GetType().GetProperty(month.ToString()).SetValue(this, months.TryGetValue(month, out var x) && x);
        return this;
    }

    public YearLocks UpdateChargingModelType(ChargingModelType chargingModelType)
    {
        ChargingModelType = Guard.Argument(chargingModelType, nameof(chargingModelType)).IsNotNull().Value;
        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() => GetType().GetProperties().Select(x => x.GetValue(this));

    #endregion
}
