﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public sealed class PropertyChange : ValueObject
    {
        #region --- PROPERTIES ---

        internal string PropertyName { get; set; }

        internal string OldValue { get; set; }

        internal string CurrentValue { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        internal PropertyChange(string propertyName, string oldValue, string currentValue)
        {
            PropertyName = propertyName;
            OldValue = oldValue;
            CurrentValue = currentValue;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues()
        {
            return new object[]
            {
                PropertyName,
                OldValue,
                CurrentValue
            };
        }

        #endregion
    }
}
