﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;
using DevOps.CrossCutting;

public enum PlanningItAppPrefix
{
    UNKNOWN = -1,
    APP = 0,
    COM = 1
}

public sealed class PlanningItApp : ValueObject
{
    #region --- PROPERTIES ---

    public PlanningItAppPrefix Prefix { get; private set; }

    public string Id { get; private set; }

    public string Name { get; private set; }

    #endregion

    #region --- CONSTRUCTORS ---

    private PlanningItApp() { }

    public PlanningItApp(PlanningItAppPrefix prefix, string id, string name)
    {
        Prefix = Guard.Argument(prefix, nameof(prefix)).IsContainedInEnum().Value;
        Id = Guard.Argument(id, nameof(id)).IsNotNullOrWhiteSpace().Value;
        Name = name;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    public override bool Equals(object obj)
    {
        if (obj == null || obj.GetType() != GetType()) return false;
        var other = (PlanningItApp)obj;
        return other.Prefix.Equals(Prefix) && StringExtensions.EqualsICIC(Id, other.Id) && StringExtensions.EqualsICIC(Name, other.Name);
    }

    public override int GetHashCode() => HashCode.Combine(Prefix, Id, Name);

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Prefix,
            Id,
            Name
        };

    #endregion
}
