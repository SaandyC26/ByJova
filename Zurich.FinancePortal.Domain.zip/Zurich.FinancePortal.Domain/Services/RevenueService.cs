﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;
using System.Linq;

public static class RevenueService
{
    #region --- PUBLIC METHODS ---

    public static decimal? Round(decimal? value, int decimals = 2, MidpointRounding mode = MidpointRounding.AwayFromZero) =>
        value.HasValue ? decimal.Round(value.Value, decimals, mode) : value;

    public static decimal? AddVat(decimal? value, ValueAddedTax valueAddedTax) =>
        (value.HasValue && valueAddedTax != null) ? value.Value * (1 + (valueAddedTax.PercentageAmount / 100)) : null;

    public static decimal? GetCurrencyExchangeRate(int year, Month month, string fromCurrencyCode, string toCurrencyCode, IEnumerable<CurrencyExchangeRate> currencyExchangeRates)
    {
        var isReverseConvertion = false;
        // Get CurrencyExchangeRate by Month
        var cer = currencyExchangeRates.FirstOrDefault(cer => cer.Year.Equals(year) && cer.From.Code.EqualsICIC(fromCurrencyCode) && cer.To.Code.EqualsICIC(toCurrencyCode) && month.Equals(cer.Month));
        // Get Reverse CurrencyExchangeRate by Month
        if (cer == null)
        {
            cer = currencyExchangeRates.FirstOrDefault(cer => cer.Year.Equals(year) && cer.From.Code.EqualsICIC(toCurrencyCode) && cer.To.Code.EqualsICIC(fromCurrencyCode) && month.Equals(cer.Month));
            if (cer != null) isReverseConvertion = true;
        }
        // Get CurrencyExchangeRate by Year
        if (cer == null) cer = currencyExchangeRates.FirstOrDefault(cer => cer.Year.Equals(year) && cer.From.Code.EqualsICIC(fromCurrencyCode) && cer.To.Code.EqualsICIC(toCurrencyCode) && Month.None.Equals(cer.Month));
        // Get Reverse CurrencyExchangeRate by Year
        if (cer == null)
        {
            cer = currencyExchangeRates.FirstOrDefault(cer => cer.Year.Equals(year) && cer.From.Code.EqualsICIC(toCurrencyCode) && cer.To.Code.EqualsICIC(fromCurrencyCode) && Month.None.Equals(cer.Month));
            if (cer != null) isReverseConvertion = true;
        }
        // Result
        if (cer != null) return isReverseConvertion ? (1 / cer.Rate) : cer.Rate;
        return null;
    }

    #endregion
}
