﻿namespace Zurich.FinancePortal.Domain;

using System.Security.Cryptography;
using System.Threading;

internal static class IdService
{
    #region --- PROPERTIES ---

    private static int _privateIdIncrement = -1;

    private static byte IdIncrement => Convert.ToByte(Interlocked.Increment(ref _privateIdIncrement) % byte.MaxValue + 1);

    private static readonly byte _idRandom = Convert.ToByte(RandomNumberGenerator.GetInt32(1, 10));

    #endregion

    #region --- PROTECTED METHODS ---

    internal static long GetUniqueId() => long.Parse($"{DateTime.UtcNow:yyyyMMddHHmmssf}{_idRandom:0}{IdIncrement:000}");

    #endregion
}

