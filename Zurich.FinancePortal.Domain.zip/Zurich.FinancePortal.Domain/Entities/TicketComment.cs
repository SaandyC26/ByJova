﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public sealed class TicketComment : Entity<long>
    {
        #region --- PROPERTIES ---

        public readonly DateTime DateTime;

        private string _text;
        public string Text { get => _text; set => _text = value?.Trim(Environment.NewLine.ToCharArray())?.Trim(); }

        private string _sAMAccountName;
        public string SAMAccountName { get => _sAMAccountName; set => _sAMAccountName = value?.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        private TicketComment() { }

        public TicketComment(string text, User user)
        {
            Id = IdService.GetUniqueId();
            Text = Guard.Argument(text, nameof(text)).IsNotNullOrWhiteSpace().Value;
            DateTime = DateTime.UtcNow;
            SAMAccountName = Guard.Argument(user, nameof(user)).Value.AdAccount.SAMAccountName;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues()
        {
            return new object[]
            {
                Id,
                DateTime,
                Text,
                SAMAccountName
            };
        }

        #endregion
    }
}
