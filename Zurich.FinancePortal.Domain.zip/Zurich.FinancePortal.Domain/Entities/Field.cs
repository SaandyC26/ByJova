﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public sealed class Field : Entity<int>
    {
        #region --- PROPERTIES ---

        public string Type { get; set; }

        public string Entity { get; set; }

        public bool Required { get; set; }

        public string EntityReference { get; set; }

        public string LabelOnFile { get; set; }

        public string WorksheetOnFile { get; set; }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Id,
                Type,
                Entity,
                EntityReference,
                LabelOnFile,
                WorksheetOnFile
            };

        #endregion

        #region --- PUBLIC METHODS ---

        public (bool IsMasterData, string Type, Type MasterDataType, string Reference) Deconstruct()
        {
            if (!Type.StartsWithICIC(nameof(MasterData))) return (false, Type, null, EntityReference);
            var split = Type.ReplaceICIC($"{nameof(MasterData)}=", string.Empty).Split(";");
            var splitAux = split[1].Split("_");
            return (true, split[0], System.Type.GetType($"{nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Domain)}.{splitAux[0]}"), splitAux[1]);
        }

        #endregion
    }
}
