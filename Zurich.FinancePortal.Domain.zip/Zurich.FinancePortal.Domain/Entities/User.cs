﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;
using System.Linq;

public class User : Entity<int>, ISoftDelete
{
    #region --- PROPERTIES ---

    internal const string Description = "Owner / Project Manager";

    private string _name;
    public string Name { get => _name; set => _name = value?.Trim(); }

    public bool IsDeleted { get; private set; }

    public string LastSeenReleaseNotes { get; private set; }

    #endregion

    #region --- REFERENCES ---

    private readonly HashSet<Role> _roles = new();
    public IEnumerable<Role> Roles => _roles;

    private readonly HashSet<Group> _groups = new();
    public IReadOnlyCollection<Group> Groups => _groups;

    public AdAccount AdAccount { get; private set; }

    public UserGridPreferences GridPreferences { get; private set; }

    #endregion

    #region --- CONSTRUCTORS ---

    private User()
    { }

    public User(string name, AdAccount adAccount, UserGridPreferences gridPreferences = default, IEnumerable<Role> roles = default, IEnumerable<Group> groups = null) : this()
    {
        UpdateName(name);
        UpdateAdAccount(adAccount);
        GridPreferences = gridPreferences ?? new UserGridPreferences();
        if (roles != null) foreach (var role in roles) _roles.Add(role);
        if (groups != null) foreach (var group in groups) _groups.Add(group);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public bool HasPermission(Permission permission) => _roles.Any(r => r.IsSuperAdmin) || _roles.Any(r => r.HasPermission(permission));

    public User SetGridPreferences(UserGridPreferences gridPreferences)
    {
        Guard.Argument(gridPreferences, nameof(gridPreferences)).IsNotNull();
        if (!string.Equals(GridPreferences.Revenues, gridPreferences.Revenues, StringComparison.InvariantCultureIgnoreCase)) GridPreferences.Revenues = gridPreferences.Revenues;
        return this;
    }

    public User UpdateName(string name)
    {
        Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace();
        if (!name.EqualsICIC(Name)) Name = name;
        return this;
    }

    public User UpdateAdAccount(AdAccount adAccount)
    {
        Guard.Argument(adAccount, nameof(adAccount)).IsNotNull();
        if (!adAccount.Equals(AdAccount)) AdAccount = adAccount;
        return this;
    }

    public User SetDeleted()
    {
        IsDeleted = true;
        return this;
    }

    public User SetUnDeleted()
    {
        IsDeleted = false;
        return this;
    }

    public User AddRole(Role role)
    {
        if (!_roles.Any(r => r.Id.Equals(role.Id))) _roles.Add(role);
        return this;
    }

    public User RemoveRole(int roleId)
    {
        if (_roles.Any(r => r.Id.Equals(roleId))) _roles.RemoveWhere(r => r.Id.Equals(roleId));
        return this;
    }

    public User AddGroup(Group group)
    {
        if (!_groups.Any(x => x.Id.Equals(group.Id))) _groups.Add(group);
        return this;
    }

    public User RemoveGroup(int groupId)
    {
        if (_groups.Any(x => x.Id.Equals(groupId))) _groups.RemoveWhere(x => x.Id.Equals(groupId));
        return this;
    }

    public User SetLastSeenReleaseNotes(ReleaseNotes releaseNotes)
    {
        LastSeenReleaseNotes = Guard.Argument(releaseNotes, nameof(releaseNotes)).IsNotNull().Value.Version;
        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Name
        };

    #endregion
}
