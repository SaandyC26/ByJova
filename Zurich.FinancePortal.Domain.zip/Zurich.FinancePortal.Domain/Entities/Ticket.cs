﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Linq;

    public enum TicketType
    {
        Unknown = -1,
        Suggestion = 0,
        Improvement = 1,
        Incident = 2
    }

    public enum TicketStatus
    {
        Unknown = -1,
        Created = 0,
        Analysis = 1,
        Backlog = 2,
        Implementation = 3,
        Rejected = 4,
        Completed = 5
    }

    [Flags]
    public enum TicketNotifications
    {
        None = 0,
        Email = 1,
        Teams = 2
    }

    public sealed class Ticket : Entity<long>
    {
        #region --- PROPERTIES ---

        public string Summary { get; private set; }

        public string Description { get; private set; }

        public string Reference { get; private set; }

        public readonly DateTime Created;

        public DateTime Updated { get; private set; }

        public TicketType Type { get; private set; }

        public TicketStatus Status { get; private set; }

        public TicketNotifications Notifications { get; private set; }

        #endregion

        #region --- REFERENCES ---

        public readonly User User;

        private readonly HashSet<TicketComment> _comments;

        public IReadOnlyCollection<TicketComment> Comments => _comments.ToList().AsReadOnly();

        #endregion

        #region --- CONSTRUCTORS ---

        private Ticket()
        {
            _comments = new HashSet<TicketComment>();
        }

        public Ticket(string summary, string description, TicketType type, User user, IEnumerable<TicketComment> comments = default) : this()
        {
            Id = IdService.GetUniqueId();
            UpdateText(summary, description);
            User = Guard.Argument(user, nameof(user)).IsNotNull().Value;
            UpdateType(type);
            UpdateStatus(TicketStatus.Created);
            UpdateNotifications(TicketNotifications.None);
            AddComments(comments);
            Created = DateTime.UtcNow;
            Updated = Created;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public Ticket UpdateText(string summary, string description)
        {
            Guard.Argument(summary, nameof(summary)).IsNotNullOrWhiteSpace();
            Guard.Argument(description, nameof(description)).IsNotNullOrWhiteSpace();
            if (!Equals(Summary, summary))
            {
                Summary = summary;
                Updated = DateTime.UtcNow;
            }

            if (!Equals(Description, description))
            {
                Description = description;
                Updated = DateTime.UtcNow;
            }

            return this;
        }

        public Ticket UpdateType(TicketType type)
        {
            Guard.Argument(type, nameof(type)).IsContainedInEnum().IsNotDefaultValue((int)TicketType.Unknown);
            if (!Equals(Type, type))
            {
                Type = type;
                Updated = DateTime.UtcNow;
            }

            return this;
        }

        public Ticket UpdateStatus(TicketStatus status)
        {
            Guard.Argument(status, nameof(status)).IsContainedInEnum().IsNotDefaultValue((int)TicketStatus.Unknown);
            if (!Equals(Status, status))
            {
                if (status.Equals(TicketStatus.Created) && !Status.Equals(TicketStatus.Unknown)) throw new ArgumentOutOfRangeException(nameof(status), $"Cannot be {nameof(TicketStatus.Created)}.");
                Status = status;
                Updated = DateTime.UtcNow;
            }

            return this;
        }

        public Ticket UpdateReference(string reference)
        {
            Reference = reference;
            return this;
        }

        public Ticket UpdateNotifications(TicketNotifications notifications)
        {
            Guard.Argument(notifications, nameof(notifications)).IsContainedInEnum();
            if (!Equals(Notifications, notifications))
            {
                Notifications = notifications;
                Updated = DateTime.UtcNow;
            }

            return this;
        }

        public Ticket AddComments(IEnumerable<TicketComment> comments)
        {
            if (comments != null)
            {
                comments.ForEach(x => _comments.Add(Guard.Argument(x, nameof(x)).IsNotNull().Value));
                if (comments.Any()) Updated = DateTime.UtcNow;
            }

            return this;
        }

        public Ticket RemoveComment(long commentId)
        {
            _comments.RemoveWhere(x => x.Id.Equals(commentId));
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Summary,
                Description,
                Type,
                Status,
                Created,
                Updated,
                Reference,
                Comments,
                Notifications,
                User
            };

        #endregion
    }
}
