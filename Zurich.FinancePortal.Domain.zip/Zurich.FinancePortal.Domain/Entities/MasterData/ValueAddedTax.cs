﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class ValueAddedTax : MasterData
    {
        #region --- PROPERTIES ---

        #region --- CONSTANTS ---

        public const string SwitzerlandCountry = "Switzerland";

        public const string SwitzerlandCountry2024 = "Switzerland2024";

        public const string None = "None";

        #endregion

        private string _country;
        public string Country { get => _country; private set => _country = value.Trim(); }

        public decimal PercentageAmount { get; private set; }

        #endregion

        #region --- CONSTRUCTORS ---

        public ValueAddedTax(string country, decimal percentageAmount)
        {
            PercentageAmount = percentageAmount;
            Country = Guard.Argument(country, nameof(country)).IsNotNullOrWhiteSpace().Value;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Country
            };

        #endregion
    }
}
