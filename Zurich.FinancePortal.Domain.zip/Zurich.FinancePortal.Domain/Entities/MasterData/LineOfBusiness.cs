﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class LineOfBusiness : MasterData
    {
        #region --- PROPERTIES ---

        internal const string Description = "Line of Business";

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        private string _icon;
        public string Icon { get => _icon; private set => _icon = value?.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        public LineOfBusiness(string name, string icon = default)
        {
            UpdateName(name);
            UpdateIcon(icon);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public LineOfBusiness UpdateName(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        public LineOfBusiness UpdateIcon(string icon)
        {
            Icon = icon;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
