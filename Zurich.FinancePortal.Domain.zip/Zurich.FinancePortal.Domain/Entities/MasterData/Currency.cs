﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class Currency : MasterData
    {
        #region --- PROPERTIES ---

        #region --- CONSTANTS ---

        public const string ChiefsName = "Chief";

        public const string ChiefsCode = "CHF";

        public const string ChiefsSymbol = "CHF";

        public const string EuroName = "Euro";

        public const string EuroCode = "EUR";

        public const string EuroSymbol = "€";

        public const string DollarName = "United States Dollar";

        public const string DollarCode = "USD";

        public const string DollarSymbol = "US$";

        #endregion

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        private string _code;
        public string Code { get => _code; private set => _code = value.Trim(); }

        private string _symbol;
        public string Symbol { get => _symbol; set => _symbol = value?.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        public Currency(string name, string code, string symbol)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            Code = Guard.Argument(code, nameof(code)).IsNotNullOrWhiteSpace().Value;
            Symbol = symbol;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name,
                Code
            };

        #endregion
    }
}
