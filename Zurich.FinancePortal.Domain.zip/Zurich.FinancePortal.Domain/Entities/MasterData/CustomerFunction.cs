﻿namespace Zurich.FinancePortal.Domain;

public class CustomerFunction : MasterData
{
    #region --- PROPERTIES ---

    private string _name;
    public string Name { get => _name; private set => _name = value.Trim(); }

    #endregion

    #region --- CONSTRUCTORS ---

    private CustomerFunction() { }

    public CustomerFunction(string name) => UpdateName(name);

    #endregion

    #region --- PUBLIC METHODS ---

    public CustomerFunction UpdateName(string name)
    {
        Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Name
        };

    #endregion
}
