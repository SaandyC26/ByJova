﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;

public class BusinessUnit : MasterData
{
    #region --- PROPERTIES ---

    internal const string Description = "Business Unit";

    private string _name;
    public string Name { get => _name; private set => _name = value.Trim(); }

    private string _code;
    public string Code { get => _code; private set => _code = value.Trim(); }

    #endregion

    #region --- CONSTRUCTORS ---

    public BusinessUnit(string name, string code)
    {
        UpdateName(name);
        UpdateCode(code);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public BusinessUnit UpdateName(string name)
    {
        Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
        return this;
    }

    public BusinessUnit UpdateCode(string code)
    {
        Code = Guard.Argument(code, nameof(code)).IsNotNullOrWhiteSpace().Value;
        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Name,
            Code
        };

    #endregion
}
