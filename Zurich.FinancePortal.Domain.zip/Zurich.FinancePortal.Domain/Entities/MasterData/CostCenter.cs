﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

public enum CostCenterType
{
    Internal = 0,
    Customer = 1
}

public class CostCenter : MasterData
{
    #region --- PROPERTIES ---

    internal const string CustomerDescription = "Customer Cost Center";

    internal const string InternalDescription = "Internal Cost Center per Cost";

    private string _code;
    public string Code { get => _code; private set => _code = value.Trim(); }

    // EF Core
    private string _Types;

    #endregion

    #region --- REFERENCES ---
    [SuppressMessage("Critical Code Smell", "S2365: Properties should not make collection or array copies", Justification = "EF Core")]
    public ICollection<CostCenterType> Types
    {
        get => _Types.Split(';', StringSplitOptions.RemoveEmptyEntries).Select(t => Enum.Parse<CostCenterType>(t.Trim(), true)).Distinct().ToList();
        private set => _Types = string.Join(';', value);
    }

    #endregion

    #region --- CONSTRUCTORS ---

    private CostCenter()
    {
        Types = new HashSet<CostCenterType>();
    }

    public CostCenter(string code, IEnumerable<CostCenterType> types) : this()
    {
        UpdateCode(code);
        UpdateTypes(types);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public CostCenter UpdateCode(string code)
    {
        Code = Guard.Argument(code, nameof(code)).IsNotNullOrWhiteSpace().Value;
        return this;
    }

    public CostCenter UpdateTypes(IEnumerable<CostCenterType> types)
    {
        Types = Guard.Argument(types, nameof(types)).IsNotNull().IsNotEmpty().Value.ToList();
        return this;
    }

    public bool IsInternal() => Types.Any(t => t.Equals(CostCenterType.Internal));

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Code
        };

    #endregion
}
