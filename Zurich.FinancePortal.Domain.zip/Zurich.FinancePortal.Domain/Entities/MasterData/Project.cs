﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public enum ProjectType
    {
        NA = 0,
        Waterfall = 1,
        Agile = 2,
        Hybrid = 3
    }

    public class Project : MasterData
    {
        #region --- PROPERTIES ---

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        public ProjectType Type { get; private set; } = ProjectType.NA;

        #endregion

        #region --- REFERENCES ---

        private readonly HashSet<PlanningItApp> _planningItApps = new();
        public IEnumerable<PlanningItApp> PlanningItApps => _planningItApps;

        #endregion

        #region --- CONSTRUCTORS ---

        private Project()
        { }

        public Project(string name, ProjectType type, IEnumerable<PlanningItApp> planningItApps = default) : this()
        {
            Update(name, type, planningItApps: planningItApps);
        }            

        #endregion

        #region --- PUBLIC METHODS ---

        public Project Update(string name, ProjectType type, IEnumerable<PlanningItApp> planningItApps = default)
        {
            if (!Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value.Equals(Name)) Name = name;
            if (!Guard.Argument(type, nameof(type)).IsContainedInEnum().Value.Equals(Type)) Type = type;
            if (planningItApps != null)
            {
                foreach (var x in _planningItApps.Where(y => !planningItApps.Any(z => z.Equals(y)))) _planningItApps.Remove(x);
                foreach (var x in planningItApps.Where(y => !_planningItApps.Any(z => z.Equals(y)))) _planningItApps.Add(x);
            }
            
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name,
                Type,
                PlanningItApps
            };

        #endregion
    }
}
