﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public sealed class TestingTool : MasterData
    {
        #region --- PROPERTIES ---

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        public TestingTool(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public TestingTool UpdateName(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
