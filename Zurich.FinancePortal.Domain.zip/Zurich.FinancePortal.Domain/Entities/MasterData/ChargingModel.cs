﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class ChargingModelType : MasterData
    {
        #region --- PROPERTIES ---

        private string _type;
        public string Type { get => _type; private set => _type = value.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        private ChargingModelType() { }

        public ChargingModelType(string type)
        {
            UpdateType(type);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public ChargingModelType UpdateType(string type)
        {
            Type = Guard.Argument(type, nameof(type)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Type
            };

        #endregion
    }

    public class ChargingModel : MasterData
    {
        #region --- PROPERTIES ---

        public const string RbiChargingModelCode = "RBI";

        public const string RbdChargingModelCode = "RBD";

        public const string BicChargingModelCode = "BIC";

        public const string BieChargingModelCode = "BIE";

        public const string BiChargingModelCode = "BI";

        public const string CaChargingModelCode = "CA";

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        private string _code;
        public string Code { get => _code; private set => _code = value.Trim(); }

        #endregion

        #region --- REFERENCES ---

        private ChargingModelType _type;
        public ChargingModelType Type { get => _type; private set => _type = value; }

        #endregion

        #region --- CONSTRUCTORS ---

        private ChargingModel() { }

        public ChargingModel(string name, string code, ChargingModelType type)
        {
            UpdateName(name);
            UpdateCode(code);
            UpdateType(type);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public ChargingModel UpdateName(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        public ChargingModel UpdateCode(string code)
        {
            Code = Guard.Argument(code, nameof(code)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        public ChargingModel UpdateType(ChargingModelType type)
        {
            Type = Guard.Argument(type, nameof(type)).IsNotNull().Value;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name,
                Code
            };

        #endregion
    }
}
