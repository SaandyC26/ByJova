﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class TypeOfService : MasterData
    {
        #region --- PROPERTIES ---

        public const string TrueUpName = "True-Up";

        internal const string Description = "Type of Service";

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        public bool IsTrueUp => Name.EqualsICIC(TrueUpName);

        #endregion

        #region --- CONSTRUCTORS ---

        public TypeOfService(string name)
        {
            UpdateName(name);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public TypeOfService UpdateName(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
