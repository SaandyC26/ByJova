﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class CurrencyExchangeRate : MasterData
    {
        #region --- PROPERTIES ---

        public decimal Rate { get; private set; }

        public int Year { get; private set; }

        public Month Month { get; private set; }

        #endregion

        #region --- REFERENCES ---

        public Currency From { get; private set; }

        public Currency To { get; private set; }

        #endregion

        #region --- CONSTRUCTORS ---

        private CurrencyExchangeRate() { }

        public CurrencyExchangeRate(int year, decimal rate, Currency from, Currency to, Month month = Month.None)
        {
            UpdateYear(year);
            UpdateRate(rate);
            UpdateFrom(from);
            UpdateTo(to);
            UpdateMonth(month);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public CurrencyExchangeRate UpdateYear(int year)
        {
            Year = Guard.Argument(year, nameof(year)).IsGreaterThan(0).Value;
            return this;
        }

        public CurrencyExchangeRate UpdateRate(decimal rate)
        {
            Rate = rate;
            return this;
        }

        public CurrencyExchangeRate UpdateFrom(Currency from)
        {
            From = Guard.Argument(from, nameof(from)).IsNotNull().Value;
            return this;
        }

        public CurrencyExchangeRate UpdateTo(Currency to)
        {
            To = Guard.Argument(to, nameof(to)).IsNotNull().Value;
            return this;
        }

        public CurrencyExchangeRate UpdateMonth(Month month)
        {
            if (!Month.Equals(Guard.Argument(month, nameof(month)).IsContainedInEnum().Value)) Month = month;
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Year,
                Month,
                From,
                To
            };

        #endregion
    }
}
