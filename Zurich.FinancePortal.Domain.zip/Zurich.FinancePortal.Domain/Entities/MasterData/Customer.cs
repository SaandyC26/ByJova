﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;

public class Customer : MasterData
{
    #region --- PROPERTIES ---

    private string _name;
    public string Name { get => _name; private set => _name = value.Trim(); }

    #endregion

    #region --- REFERENCES ---

    public CustomerFunction Function { get; private set; }

    #endregion

    #region --- CONSTRUCTORS ---

    private Customer()
    { }

    public Customer(string name, CustomerFunction function = null) : this()
    {
        UpdateName(name).UpdateFunction(function);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public Customer UpdateName(string name)
    {
        Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
        return this;
    }

    public Customer UpdateFunction(CustomerFunction function)
    {
        if (!Equals(Function, function))
        {
            Function = function;
        }

        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Name
        };

    #endregion
}
