﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class Product : MasterData
    {
        #region --- PROPERTIES ---

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        #endregion

        #region --- CONSTRUCTORS ---

        public Product(string name)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
