﻿namespace Zurich.FinancePortal.Domain;

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;

public enum Month
{
    None = 0,
    January = 1,
    February = 2,
    March = 3,
    April = 4,
    May = 5,
    June = 6,
    July = 7,
    August = 8,
    September = 9,
    October = 10,
    November = 11,
    December = 12
}

public class Revenue : Entity<long>
{
    #region --- PROPERTIES ---

    private bool _updatedCommentSet = false;

    private bool _createdCommentSet = false;

    // Internal Code
    private string _internalCode;
    public string InternalCode { get => _internalCode; set => _internalCode = value?.Trim(); }

    // Year
    public int Year { get; private set; }

    // LC No VAT
    public decimal? FYFCLC { get; private set; }

    // CHF No VAT
    public decimal? FYFCCHF { get; private set; }

    // CHF VAT
    public decimal? FYFCCHFVAT { get; private set; }

    // Plan
    public decimal? PlanLC { get; private set; }

    // Transfer
    public decimal? TransferLC { get; private set; }

    // Difference
    public decimal? DifferenceLC { get; private set; }

    // Service Description
    public string ServiceDescription { get; private set; }

    // Planned Dates
    private DateTime _plannedStartDate;
    public DateTime PlannedStartDate
    { 
        get => _plannedStartDate;
        private set => _plannedStartDate = new DateTime(value.Year, value.Month, value.Day, 0, 0, 0, DateTimeKind.Utc);
    }
    public const string PlannedStartDateDescription = "Planned Start Date";

    private DateTime _plannedEndDate;
    public DateTime PlannedEndDate
    {
        get => _plannedEndDate;
        private set => _plannedEndDate = new DateTime(value.Year, value.Month, value.Day, 23, 59, 59, DateTimeKind.Utc);
    }
    public const string PlannedEndDateDescription = "Planned End Date";

    // Testing Tool Project Name
    public string TestingToolProjectName { get; private set; }

    // Testing Tool Detailed Info
    public string TestingToolDetailedInfo { get; private set; }

    #endregion

    #region --- REFERENCES ---

    // Line of Business
    public LineOfBusiness LineOfBusiness { get; private set; }

    // Customer
    public Customer Customer { get; private set; }

    // Project
    public Project Project { get; private set; }

    // Type of Service
    public TypeOfService TypeOfService { get; private set; }

    // Owner/PM
    public const string OwnerProjectManagerDescription = "Owner / PM";
    public User OwnerProjectManager { get; private set; }

    // Bu Code
    public const string BusinessUnitDescription = "Business Unit";
    public BusinessUnit BusinessUnit { get; private set; }

    // CC Customer
    public const string CustomerCostCenterDescription = "Customer Cost Center";
    public CostCenter CustomerCostCenter { get; private set; }

    // Charging Model
    public ChargingModel ChargingModel { get; private set; }

    // Internal CC Per Cost
    public CostCenter InternalCostCenterPerCost { get; private set; }

    // Product
    public Product Product { get; private set; }

    // Currency
    public Currency Currency { get; private set; }

    // Testing Tool
    public TestingTool TestingTool { get; private set; }

    // VAT
    public ValueAddedTax ValueAddedTax { get; private set; }

    // Group
    public const string GroupOwnerDescription = "Group Owner";
    public Group GroupOwner { get; private set; }

    public MonthRevenue January { get; private set; }

    public MonthRevenue February { get; private set; }

    public MonthRevenue March { get; private set; }

    public MonthRevenue April { get; private set; }

    public MonthRevenue May { get; private set; }

    public MonthRevenue June { get; private set; }

    public MonthRevenue July { get; private set; }

    public MonthRevenue August { get; private set; }

    public MonthRevenue September { get; private set; }

    public MonthRevenue October { get; private set; }

    public MonthRevenue November { get; private set; }

    public MonthRevenue December { get; private set; }

    // Currency Exnchage Rates
    public ICollection<CurrencyExchangeRate> CurrencyExchangeRates { get; private set; }

    // Comments
    private HashSet<RevenueComment> _comments;

    public IReadOnlyCollection<RevenueComment> Comments
    {
        get => _comments.ToList().AsReadOnly();
        set => _comments = value.ToHashSet();
    }

    // Updates
    private readonly IDictionary<string, object> _updates;

    public IReadOnlyDictionary<string, object> Updates => new ReadOnlyDictionary<string, object>(_updates);

    #endregion

    #region --- CONSTRUCTORS ---

    private Revenue()
    {
        CurrencyExchangeRates = new HashSet<CurrencyExchangeRate>();
        _comments = new HashSet<RevenueComment>();
        _updates = new Dictionary<string, object>();
        foreach (var property in GetMonthsProperties()) property.SetValue(this, new MonthRevenue(null));
    }

    public Revenue(int year, LineOfBusiness lineOfBusiness, Project project, Customer customer, TypeOfService typeOfService, (BusinessUnit BusinessUnit, CostCenter CustomerCostCenter) aggregate, ChargingModel chargingModel, CostCenter internalCostCenterPerCost, Currency currency, ValueAddedTax valueAddedTax, User ownerProjectManager, Product product, DateTime plannedStartDate, DateTime plannedEndDate, IEnumerable<CurrencyExchangeRate> currencyExchangeRates = default, string internalCode = default, string serviceDescription = default, TestingTool testingTool = default, string testingToolProjectName = default, string testingToolDetailedInfo = default, Group groupOwner = null, User currentUser = default) : this()
    {
        UpdateYearAndPlannedDates(year, plannedStartDate, plannedEndDate, currentUser: currentUser);
        UpdateLineOfBusiness(lineOfBusiness, currentUser: currentUser);
        UpdateCustomer(customer, currentUser: currentUser);
        UpdateProject(project, currentUser: currentUser);
        UpdateTypeOfService(typeOfService, currentUser: currentUser);
        UpdateServiceDescription(serviceDescription, currentUser: currentUser);
        UpdateOwnerProjectManager(ownerProjectManager, currentUser: currentUser);
        UpdateProduct(product, currentUser: currentUser);
        UpdateBusinessUnitAndCustomerCostCenter(aggregate.BusinessUnit, aggregate.CustomerCostCenter, currentUser: currentUser);
        UpdateChargingModel(chargingModel, currentUser: currentUser);
        UpdateInternalCostCenterPerCost(internalCostCenterPerCost, currentUser: currentUser);
        UpdateInternalCode(internalCode, currentUser: currentUser);
        UpdateCurrency(currency, currentUser: currentUser);
        SetCurrencyExchangeRates(currencyExchangeRates);
        UpdateValueAddedTax(valueAddedTax);
        UpdateGroupOwner(groupOwner);
        UpdateTestingTool(testingTool, testingToolProjectName, testingToolDetailedInfo, currentUser: currentUser);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public Revenue UpdateYearAndPlannedDates(int year, DateTime start, DateTime end, User currentUser = default)
    {
        if (!Guard.Argument(year, nameof(year)).IsGreaterThan(0).Value.Equals(Year))
        {
            Year = year;
            AddUpdate(nameof(Year), currentUser: currentUser);
        }

        if (end < start) throw new ArgumentException($"{PlannedStartDateDescription} cannot be greater than {PlannedEndDateDescription}.", nameof(end));
        if (!Year.Equals(start.Year)) throw new ArgumentException($"{PlannedStartDateDescription} {nameof(Year)} cannot be different than {nameof(Year)} '{Year}'.", nameof(start));
        if (!Year.Equals(end.Year)) throw new ArgumentException($"{PlannedStartDateDescription} {nameof(Year)} cannot be different than {nameof(Year)}: '{Year}'.", nameof(end));
        if (!end.Equals(PlannedEndDate))
        {
            PlannedEndDate = end;
            AddUpdate(start.ToString(), currentUser: currentUser);
        }

        if (!start.Equals(PlannedStartDate))
        {
            PlannedStartDate = start;
            AddUpdate(end.ToString(), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateLineOfBusiness(LineOfBusiness lineOfBusiness, User currentUser = default)
    {
        if (!Guard.Argument(lineOfBusiness, nameof(lineOfBusiness)).IsNotNull().Value.Equals(LineOfBusiness))
        {
            LineOfBusiness = lineOfBusiness;
            AddUpdate(nameof(LineOfBusiness), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateCustomer(Customer customer, User currentUser = default)
    {
        if (!Guard.Argument(customer, nameof(customer)).IsNotNull().Value.Equals(Customer))
        {
            Customer = customer;
            AddUpdate(nameof(Customer), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateProject(Project project, User currentUser = default)
    {
        if (!Guard.Argument(project, nameof(project)).IsNotNull().Value.Equals(Project))
        {
            Project = project;
            AddUpdate(nameof(Project), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateTypeOfService(TypeOfService typeOfService, User currentUser = default)
    {
        if (!Guard.Argument(typeOfService, nameof(typeOfService)).IsNotNull().Value.Equals(TypeOfService))
        {
            TypeOfService = typeOfService;
            AddUpdate(nameof(TypeOfService), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateServiceDescription(string serviceDescription, User currentUser = default)
    {
        if (!string.Equals(ServiceDescription, serviceDescription))
        {
            ServiceDescription = serviceDescription;
            AddUpdate(nameof(ServiceDescription), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateOwnerProjectManager(User ownerProjectManager, User currentUser = default)
    {
        if (!Guard.Argument(ownerProjectManager, nameof(ownerProjectManager)).IsNotNull().Value.Equals(OwnerProjectManager))
        {
            OwnerProjectManager = ownerProjectManager;
            AddUpdate(nameof(OwnerProjectManager), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateProduct(Product product, User currentUser = default)
    {
        if (!Guard.Argument(product, nameof(product)).IsNotNull().Value.Equals(Product))
        {
            Product = product;
            AddUpdate(nameof(Product), currentUser: currentUser);
        }

        return this;
    }

    [SuppressMessage("Major Code Smell", "S3928: Parameter names used into ArgumentException constructors should match an existing one ", Justification = "False positive")]
    public Revenue UpdateBusinessUnitAndCustomerCostCenter(BusinessUnit businessUnit, CostCenter customerCostCenter, User currentUser = default)
    {
        if (businessUnit == null && customerCostCenter == null) throw new ArgumentNullException($"Both \"{nameof(businessUnit)} - {nameof(customerCostCenter)}\"", "Cannot be null.");
        if (customerCostCenter != null && !customerCostCenter.Types.Any(cc => cc.Equals(CostCenterType.Customer))) throw new ArgumentOutOfRangeException(nameof(customerCostCenter), $"Should be {nameof(CostCenterType.Customer)}.");
        if (!Equals(BusinessUnit, businessUnit))
        {
            BusinessUnit = businessUnit;
            AddUpdate(nameof(BusinessUnit), currentUser: currentUser);
        }

        if (!Equals(CustomerCostCenter, customerCostCenter))
        {
            CustomerCostCenter = customerCostCenter;
            AddUpdate(nameof(CustomerCostCenter), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateChargingModel(ChargingModel chargingModel, User currentUser = default)
    {
        if (!Guard.Argument(chargingModel, nameof(chargingModel)).IsNotNull().Value.Equals(ChargingModel))
        {
            ChargingModel = chargingModel;
            AddUpdate(nameof(ChargingModel), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateInternalCostCenterPerCost(CostCenter internalCostCenterPerCost, User currentUser = default)
    {
        if (!Guard.Argument(internalCostCenterPerCost, nameof(internalCostCenterPerCost)).IsNotNull().Value.Equals(InternalCostCenterPerCost))
        {
            InternalCostCenterPerCost = internalCostCenterPerCost;
            AddUpdate(nameof(InternalCostCenterPerCost), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateInternalCode(string internalCode, User currentUser = default)
    {
        if (!string.Equals(InternalCode, internalCode))
        {
            InternalCode = internalCode;
            AddUpdate(nameof(InternalCode), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateCurrency(Currency currency, User currentUser = default)
    {
        if (!Guard.Argument(currency, nameof(currency)).IsNotNull().Value.Equals(Currency))
        {
            Currency = currency;
            AddUpdate(nameof(Currency), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateGroupOwner(Group group, User currentUser = default)
    {
        if (!Equals(GroupOwner, group))
        {
            GroupOwner = group;
            AddUpdate(nameof(GroupOwner), currentUser: currentUser);
        }

        return this;
    }

    public Revenue UpdateValueAddedTax(ValueAddedTax valueAddedTax)
    {
        if (!Guard.Argument(valueAddedTax, nameof(valueAddedTax)).IsNotNull().Value.Equals(ValueAddedTax)) ValueAddedTax = valueAddedTax;
        return this;
    }

    public Revenue SetCurrencyExchangeRates(IEnumerable<CurrencyExchangeRate> currencyExchangeRates)
    {
        if (currencyExchangeRates == null) return this;
        var filteredCurrencyExchangeRates = currencyExchangeRates.Where(cer => cer.Year.Equals(Year) && cer.From.Equals(Currency) && (!TypeOfService.IsTrueUp || cer.Month.Equals(Month.None))).ToArray();
        if (filteredCurrencyExchangeRates.Length != CurrencyExchangeRates.Count || filteredCurrencyExchangeRates.Any(cer => !CurrencyExchangeRates.Any(cer2 => cer2.Id.Equals(cer.Id))))
        {
            CurrencyExchangeRates = filteredCurrencyExchangeRates;
        }

        return this;
    }

    public Revenue UpdateMonthsRevenues(IDictionary<Month, MonthRevenue> monthsRevenues, User currentUser = default)
    {
        Guard.Argument(monthsRevenues, nameof(monthsRevenues)).IsNotNull();
        monthsRevenues.Where(mr => mr.Value != null).ForEach(x =>
        {
            var currentMonthRevenue = GetMonthsRevenues().Single(mr => mr.Month.Equals(x.Key)).Value;
            if (!currentMonthRevenue.Equals(x.Value))
            {
                GetMonthsProperties().Single(mr => Enum.Parse<Month>(mr.Name).Equals(x.Key)).SetValue(this, x.Value);
                AddUpdate(x.Key.ToString(), currentUser: currentUser);
            }
        });

        RefreshFyf(currentUser: currentUser);
        return this;
    }

    public Revenue UpdatePlanAndTransfer(decimal? plan = null, decimal? transfer = null, User currentUser = default)
    {
        if (!Equals(PlanLC, plan))
        {
            PlanLC = plan;
            AddUpdate(nameof(PlanLC), currentUser: currentUser);
        }

        if (!Equals(TransferLC, transfer))
        {
            TransferLC = transfer;
            AddUpdate(nameof(TransferLC), currentUser: currentUser);
        }

        RefreshFyf(currentUser: currentUser);
        return this;
    }

    public Revenue UpdateTestingTool(TestingTool testingTool, string testingToolProjectName, string testingToolDetailedInfo, User currentUser = default)
    {
        if (!Equals(TestingTool, testingTool))
        {
            TestingTool = testingTool;
            AddUpdate(nameof(TestingTool), currentUser: currentUser);
        }

        if (testingTool is null)
        {
            if (!string.IsNullOrWhiteSpace(TestingToolProjectName)) AddUpdate(nameof(TestingToolProjectName), currentUser: currentUser);
            TestingToolProjectName = null;
            if (!string.IsNullOrWhiteSpace(TestingToolDetailedInfo)) AddUpdate(nameof(TestingToolDetailedInfo), currentUser: currentUser);
            TestingToolDetailedInfo = null;
        }
        else
        {
            if (!Equals(TestingToolProjectName, testingToolProjectName))
            {
                TestingToolProjectName = testingToolProjectName;
                AddUpdate(nameof(TestingToolProjectName), currentUser: currentUser);
            }

            if (!Equals(TestingToolDetailedInfo, testingToolDetailedInfo))
            {
                TestingToolDetailedInfo = testingToolDetailedInfo;
                AddUpdate(nameof(TestingToolDetailedInfo), currentUser: currentUser);
            }
        }

        return this;
    }

    public IEnumerable<(Month Month, MonthRevenue Value)> GetMonthsRevenues() =>
        GetType().GetProperties().Where(p => p.PropertyType.Equals(typeof(MonthRevenue))).Select(p => (Enum.Parse<Month>(p.Name, true), (MonthRevenue)p.GetValue(this)));

    public static IEnumerable<Month> GetMonths(bool excludeNone = true) =>
        Enum.GetValues<Month>().Where(m => !excludeNone || !m.Equals(Month.None));

    public static string GetShortMonthName(Month month) =>
        month.ToString()?[..3]?.ToUpperInvariant();

    public static int GetMonthOrder(Month month) =>
        month switch
        {
            Month.January => 1,
            Month.February => 2,
            Month.March => 3,
            Month.April => 4,
            Month.May => 5,
            Month.June => 6,
            Month.July => 7,
            Month.August => 8,
            Month.September => 9,
            Month.October => 10,
            Month.November => 11,
            Month.December => 12,
            _ => 0,
        };

    public Revenue RefreshFyf(User currentUser = default, bool autoComment = true, string autoCommentText = default)
    {
        var amounts = GetMonthsRevenues().Where(mr => mr.Value != null && mr.Value.Amount != null).Select(mr => (mr.Month, mr.Value.Amount));
        var fyfclc = GetFYFCLC(amounts);
        if (!Equals(fyfclc, FYFCLC))
        {
            FYFCLC = fyfclc;
            AddUpdate(nameof(FYFCLC), currentUser: currentUser, autoComment: autoComment, text: autoCommentText);
        }

        var fyfcchf = GetFYFCCHF(Year, amounts, Currency, CurrencyExchangeRates);
        if (!Equals(fyfcchf, FYFCCHF))
        {
            FYFCCHF = fyfcchf;
            AddUpdate(nameof(FYFCCHF), currentUser: currentUser, autoComment: autoComment, text: autoCommentText);
        }

        var fyfcchfvat = ValueAddedTax.PercentageAmount < 0.0m ? default : GetFYFCCHFVAT(FYFCCHF, ValueAddedTax);
        if (!Equals(fyfcchfvat, FYFCCHFVAT))
        {
            FYFCCHFVAT = fyfcchfvat;
            AddUpdate(nameof(FYFCCHFVAT), currentUser: currentUser, autoComment: autoComment, text: autoCommentText);
        }

        var difference = (PlanLC ?? decimal.Zero) + (TransferLC ?? decimal.Zero) - (FYFCLC ?? decimal.Zero);
        if (!Equals(DifferenceLC, difference))
        {
            DifferenceLC = difference;
            AddUpdate(nameof(DifferenceLC), currentUser: currentUser, autoComment: autoComment, text: autoCommentText);
        }

        return this;
    }

    public static decimal? GetFYFCLC(IEnumerable<(Month Month, decimal? Amount)> mrs) =>
        mrs.Any(mr => mr.Amount.HasValue) ? mrs.Where(mr => mr.Amount.HasValue).Select(mr => mr.Amount.Value).Sum() : null;

    public static decimal? GetFYFCCHF(int year, IEnumerable<(Month Month, decimal? Amount)> mrs, Currency currency, IEnumerable<CurrencyExchangeRate> currencyExchangeRates) =>
        mrs.Any(mr => mr.Amount.HasValue) ? RevenueService.Round(mrs.Where(mr => mr.Amount != null).Sum(mr =>
        {
            // Get CurrencyExchangeRate
            var rate = RevenueService.GetCurrencyExchangeRate(year, mr.Month, currency.Code, Currency.ChiefsCode, currencyExchangeRates);
            // Result
            if (rate != null) return mr.Amount.Value * rate;
            return mr.Amount.Value;
        })) : null;

    public static decimal? GetFYFCCHFVAT(decimal? fyfcchf, ValueAddedTax valueAddedTax) =>
        RevenueService.Round(RevenueService.AddVat(fyfcchf, valueAddedTax));

    public void AddComment(string text, User user = default) =>
        _comments.Add(new RevenueComment(text, user: user));

    public void RemoveComment(long revenueCommentId) =>
        _comments.RemoveWhere(rc => !rc.AutoGenerated && rc.Id.Equals(revenueCommentId));

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Id,
            LineOfBusiness,
            Customer,
            Project,
            TypeOfService,
            ServiceDescription,
            OwnerProjectManager,
            BusinessUnit,
            CustomerCostCenter,
            ChargingModel,
            InternalCostCenterPerCost,
            InternalCode,
            Currency,
            Year,
            ValueAddedTax
        };

    #endregion

    #region --- PRIVATE METHODS ---

    private static IEnumerable<PropertyInfo> GetMonthsProperties() =>
        typeof(Revenue).GetProperties().Where(p => p.PropertyType.Equals(typeof(MonthRevenue)));

    private void AddUpdate(string key, User currentUser = default, bool autoComment = true, string text = default)
    {
        // Comments
        if (Id.Equals(0))
        {
            if (autoComment && !_createdCommentSet)
            {
                _comments.Add(new RevenueComment(!string.IsNullOrWhiteSpace(text) ? text : "Created.", autoGenerated: true, user: currentUser));
                _createdCommentSet = true;
            }
        }
        else
        {
            if (autoComment && !_updatedCommentSet)
            {
                _comments.Add(new RevenueComment(!string.IsNullOrWhiteSpace(text) ? text : "Updated.", autoGenerated: true, user: currentUser));
                _updatedCommentSet = true;
            }
        }
        // Updates
        if (!_updates.ContainsKey(key)) _updates.Add(key, null);
    }

    #endregion
}
