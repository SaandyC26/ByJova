﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;

    public class ApplicationConfiguration : Entity<int>
    {
        #region --- PROPERTIES ---

        public string Name { get; set; }

        public string Value { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        public ApplicationConfiguration(string name, string value)
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            Value = value;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
