﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;

    public class Permission : Entity<int>
    {
        #region --- PROPERTIES ---

        public string Name { get; private set; }

        public string Description { get; set; }

        #endregion

        #region --- REFERENCES ---

        // Roles
        [SuppressMessage("CodeQuality", "IDE0052: Remove unread private members.", Justification = "EF Core")]
        private readonly HashSet<Role> _roles = new();

        #endregion

        #region --- CONSTRUCTORS ---

        private Permission()
        { }

        public Permission(string name, string description = default) : this()
        {
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;
            Description = description;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
