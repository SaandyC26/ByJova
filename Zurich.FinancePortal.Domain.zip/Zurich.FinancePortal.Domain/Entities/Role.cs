﻿namespace Zurich.FinancePortal.Domain
{
    using System.Collections.Generic;
    using System.Linq;

    public class Role : Entity<int>
    {
        #region --- PROPERTIES ---

        public const string SuperAdminName = "Super Admin";

        public const string SuperAdminDescription = "Super Admin Role";

        public const string AdminName = "Admin";

        public const string AdminDescription = "Admin Role";

        private string _name;
        public string Name { get => _name; private set => _name = value.Trim(); }

        private string _description;
        public string Description { get => _description; set => _description = value?.Trim(); }

        public bool IsSuperAdmin { get; private set; }

        #endregion

        #region --- REFERENCES ---

        private readonly HashSet<User> _users = new();
        public IEnumerable<User> Users => _users;

        private readonly HashSet<Permission> _permissions = new();
        public IEnumerable<Permission> Permissions => _permissions;

        #endregion

        #region --- CONSTRUCTORS ---

        private Role()
        { }

        public Role(string name, string description = default, IEnumerable<Permission> permissions = default, bool isSuperAdmin = false) : this()
        {
            IsSuperAdmin = isSuperAdmin;
            UpdateName(name);
            Description = description;
            if (permissions != null) foreach (var permission in permissions) _permissions.Add(permission);
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public void UpdateName(string name) =>
            Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;

        public bool HasPermission(Permission permission) =>
            _permissions.Any(p => p.Equals(permission));

        public Role AddUser(User user)
        {
            if (!_users.Any(u => u.Id.Equals(user.Id))) _users.Add(user);
            return this;
        }

        public Role RemoveUser(int userId)
        {
            if (_users.Any(r => r.Id.Equals(userId))) _users.RemoveWhere(u => u.Id.Equals(userId));
            return this;
        }

        public Role AddPermission(Permission permission)
        {
            if (!_permissions.Any(p => p.Id.Equals(permission.Id))) _permissions.Add(permission);
            return this;
        }

        public Role RemovePermission(int permissionId)
        {
            if (_permissions.Any(p => p.Id.Equals(permissionId))) _permissions.RemoveWhere(p => p.Id.Equals(permissionId));
            return this;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private override IEnumerable<object> GetAtomicValues() =>
            new object[]
            {
                Name
            };

        #endregion
    }
}
