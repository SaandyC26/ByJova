﻿namespace Zurich.FinancePortal.Domain;

public sealed class Group : Entity<int>
{
    #region --- PROPERTIES ---

    public string Name { get; set; } = null!;

    #endregion

    #region --- REFERENCES ---

    private readonly HashSet<User> _users = new();
    public IReadOnlyCollection<User> Users => _users;

    #endregion

    #region --- CONSTRUCTORS ---

    private Group() { }

    public Group(string name, IEnumerable<User> users = default) : this()
    {
        UpdateName(name);
        if (users is not null) foreach (var user in users) _users.Add(user);
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public void UpdateName(string name) =>
        Name = Guard.Argument(name, nameof(name)).IsNotNullOrWhiteSpace().Value;

    public Group AddUser(User user)
    {
        if (!_users.Any(u => u.Id.Equals(user.Id))) _users.Add(user);
        return this;
    }

    public Group RemoveUser(int userId)
    {
        if (_users.Any(r => r.Id.Equals(userId))) _users.RemoveWhere(u => u.Id.Equals(userId));
        return this;
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected private override IEnumerable<object> GetAtomicValues() =>
        new object[]
        {
            Name
        };

    #endregion
}
