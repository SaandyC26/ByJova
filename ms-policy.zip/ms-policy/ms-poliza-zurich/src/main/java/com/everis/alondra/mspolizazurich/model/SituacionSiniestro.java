package com.everis.alondra.mspolizazurich.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;
import java.util.UUID;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "CUSTOM_SITUACION_SINIESTRO")
public class SituacionSiniestro {
    @Id
    @GeneratedValue
    @Type(type="org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "SINIESTRO_ID" ,nullable = false)
    private Siniestro siniestro;

    @Column(name = "NUMERO_ORDEN")
    private Integer numeroOrden;

    @Column(name = "SITUACION_SINIESTRO", length = 50, nullable = false)
    private String situacionSiniestro;

    @Column(name = "FECHA_SITUACION", nullable = false)
    private Date fechaSituacion;

    @Column(name = "DESCRIPCION_SITUACION",length = 200, nullable = false)
    private String descripcionSituacion;

}
