package com.everis.alondra.mspolizazurich.controller;

import com.everis.alondra.mspolizazurich.client.IPoliza;
import com.everis.alondra.mspolizazurich.client.request.PolizaRequest;
import com.everis.alondra.mspolizazurich.client.response.getDataPolizaResponse;
import com.everis.alondra.mspolizazurich.service.PolizaService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PolizaController implements IPoliza {

    @Autowired
    PolizaService polizaService;

    @ApiOperation(value="Devuelve todos los datos relacionados con la póliza.", notes = "Se buscará en función de: " +
            "\n - ID de la póliza." +
            "\n - Número de la póliza, número de endoso, número de certificado y el ID del producto asociado. Finalmente se mostrará la última versión que contiene todos estos campos." +
            "\n - En el caso de que se encuentre tanto el ID como el resto de campos juntos en la solicitud, se buscará usando el ID.")
    @Override
    public ResponseEntity<getDataPolizaResponse> getDataPoliza(PolizaRequest polizaRequest) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(polizaService.getDataPoliza(polizaRequest));
    }
}
