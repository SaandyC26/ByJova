package com.everis.alondra.mspolizazurich.repository;

import com.everis.alondra.mspolizazurich.model.Cobertura;
import com.everis.alondra.mspolizazurich.model.Poliza;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Repository
public interface PolizaRepository extends JpaRepository<Poliza, UUID> {

    @Query(nativeQuery = true,value = "SELECT TOP 1 * from CUSTOM_POLIZA where NUMERO_POLIZA = ?1 and NUMERO_CERTIFICADO = ?2 and NUMERO_ENDOSO = ?3 and PRODUCTO_ID = ?4 " +
            "order by VERSION_POLIZA DESC")
    public Poliza getPolizaLastVersionByDataPoliza(Integer numeroPoliza, Integer numeroCertificado, Integer numeroEndoso, String productoID);

    @Query(nativeQuery = true, value = "SELECT TOP 1 * from CUSTOM_POLIZA where NUMERO_POLIZA = ?1 " +
            " AND NUMERO_CERTIFICADO = ?2" +
            " AND PLAN_ID = ?3" +
            " AND PRODUCTO_ID = ?4 " +
            " AND ?5 BETWEEN FECHA_INICIO and FECHA_FIN " +
            " ORDER BY VERSION_POLIZA DESC")
    Poliza getDetallePolizaRangoFechas(Long numeroPoliza,
                            Integer numeroCertificado,
                            String planID,
                            String productoID,
                            LocalDate fechaOcurrencia);

    @Query(nativeQuery = true, value = "SELECT TOP 1 * from CUSTOM_POLIZA where NUMERO_POLIZA = ?1 " +
            " AND NUMERO_CERTIFICADO = ?2" +
            " AND PLAN_ID = ?3" +
            " AND PRODUCTO_ID = ?4 " +
            " AND FECHA_INICIO >= ?5 AND FECHA_FIN <=  ?6 " +
            " ORDER BY VERSION_POLIZA DESC")
    Poliza getDetallePolizaMismoDia(Long numeroPoliza,
                                       Integer numeroCertificado,
                                       String planID,
                                       String productoID,
                                       LocalDate fechaOcurrencia,
                                       LocalDateTime fechaOcurrenciaMenosUnSegundo);

    @Query(nativeQuery = true, value = "SELECT * from CUSTOM_POLIZA where NUMERO_POLIZA = ?1 and NUMERO_CERTIFICADO = ?2 and PLAN_ID = ?3 and PRODUCTO_ID = ?4 " +
            "AND FECHA_INICIO <= ?5 order by FECHA_INICIO DESC")
    List<Poliza> getDetallesPolizas(Long numeroPoliza,
                                    Integer numeroCertificado,
                                    String planID,
                                    String productoID,
                                    Date fechaOcurrencia);

    @Query(nativeQuery = true, value = "SELECT R.* FROM CUSTOM_RECAUDOS R, CUSTOM_POLIZA P, CUSTOM_PARAM_PRODUCTOS PS\n" +
            "WHERE R.NUMERO_POLIZA=p.NUMERO_POLIZA\n" +
            "AND R.NUMERO_CERTIFICADO=P.NUMERO_CERTIFICADO\n" +
            "AND R.NUMERO_ENDOSO=P.NUMERO_ENDOSO\n" +
            "AND P.PRODUCTO_ID=PS.ID\n" +
            "AND PS.PRODUCTO_ID=R.PRODUCTO_ID\n" +
            "AND PS.PLAN_ID=R.PLAN_ID\n" +
            "AND P.NUMERO_POLIZA=?1")
    public List<Object> getRecibos(Long numeroPoliza);


}
