package com.everis.alondra.mspolizazurich.exception;

public class BadRequestException extends Throwable {
    private static final long serialVersionUID = 7883283395096400811L;

    BadRequestException(String message) { super(message);}
    BadRequestException(Throwable throwable) { super(throwable);}

}
