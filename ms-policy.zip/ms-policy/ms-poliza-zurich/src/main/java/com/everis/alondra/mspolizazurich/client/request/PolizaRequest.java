package com.everis.alondra.mspolizazurich.client.request;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PolizaRequest {
    @NotNull(message = "numeroPoliza no puede ser nulo")
    private Long numeroPoliza;

    @NotNull(message = "numeroCertificado no puede ser nulo")
    private Integer numeroCertificado;

    @NotNull(message = "productID no puede ser nulo")
    private String productID;

    @NotNull(message = "planID no puede ser nulo")
    private String planID;

    @NotNull(message = "fechaOcurrencia no puede ser nulo")
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDate fechaOcurrencia;

}