package com.everis.alondra.mspolizazurich.exception;

import lombok.Data;

@Data
public class RespuestaModel {

    String status;
    String message;
}
