package com.everis.alondra.mspolizazurich.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Table(name = "CUSTOM_RIESGO")
public class Riesgo {

    @Id
    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "DIRECCION_BIEN_ASEGURADO", nullable = false, length = 100)
    private String direccionBienAsegurado;

    @OneToOne
    @JoinColumn(name = "CIUDAD_ID", nullable = false)
    private Dane ciudad;

    @Column(name = "TOTAL_PISOS")
    private Integer totalPisos;

    @Column(name = "USO_RIESGO", nullable = false, length = 10)
    private String usoRiesgo;

    @Column(name = "ANYO_CONSTRUCCION", nullable = false)
    private Integer anyoConstruccion;

    @Column(name = "CLASE_CONSTRUCCION", nullable = false, length = 10)
    private String claseConstruccion;

    @Column(name = "CLASIFICACION_RIESGO", nullable = false, length = 15)
    private String clasificacionRiesgo;

    @Column(name = "MATERIAL_CONSTRUCCION", nullable = false, length = 15)
    private String materialConstruccion;

    @Column(name = "DATO1", length = 100)
    private String dato1;

    @Column(name = "DATO2", length = 100)
    private String dato2;

    @Column(name = "NUMERO_CONTRATO", length = 100)
    private String numeroContrato;

    @Column(name = "ALTURA", length = 100)
    private String altura;

    @Column(name = "DATO5", length = 100)
    private String dato5;

    @JoinTable(name = "CUSTOM_RIESGO_POLIZA_LINK",
            joinColumns = @JoinColumn(name = "RIESGO_ID"),
            inverseJoinColumns = @JoinColumn(name = "POLIZA_ID"))
    @ManyToMany
    @JsonIgnore
    protected List<Poliza> polizas;
}
