package com.everis.alondra.mspolizazurich.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "CUSTOM_PARAM_PRODUCTOS")
public class Producto {

    @Id
    @GeneratedValue
    @Type(type="org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "NOMBRE_CONVENIO" ,nullable = false)
    private String nombreConvenio;

    @Column(name = "PRODUCTO_ID" ,nullable = false)
    private String producto;

    @Column(name = "PRODUCTO_NOMBRE" ,nullable = false)
    private String productoNombre;

    @Column(name = "PLAN_ID" ,nullable = false)
    private String plan;

    @Column(name = "REV_PLAN" ,nullable = false)
    private Integer revPlan;

    @Column(name = "PLAN_MODALIDAD" ,nullable = false)
    private String planModalidad;

    @Column(name = "RAMO_ID" ,nullable = false)
    private Integer ramo;

    @Column(name = "RAMO_TIPO" ,nullable = false)
    private String ramoTipo;

    @Column(name = "COBERTURA_ID" ,nullable = false)
    private Integer cobertura;

    @Column(name = "COBERTURA_NOMBRE" ,nullable = false)
    private String coberturaNombre;

}
