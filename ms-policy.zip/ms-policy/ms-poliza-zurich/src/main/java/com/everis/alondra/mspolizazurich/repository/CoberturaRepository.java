package com.everis.alondra.mspolizazurich.repository;

import com.everis.alondra.mspolizazurich.model.Cobertura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface CoberturaRepository extends JpaRepository<Cobertura, Integer> {
    List<Cobertura> findByPolizaIdIn(List<UUID> polizasIds);

}
