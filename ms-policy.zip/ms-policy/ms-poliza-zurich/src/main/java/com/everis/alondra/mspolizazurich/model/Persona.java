package com.everis.alondra.mspolizazurich.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "CUSTOM_PERSONA")
public class Persona {


    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Id
    @Column(name = "ID_PERSONA", nullable = false, length = 20)
    private String idPersona;

    @Column(name = "TIPO_PERSONA", nullable = false, length = 3)
    private String tipoPersona;

    @Column(name = "TIPO_DOCUMENTO", nullable = false, length = 1)
    private String tipoDocumento;

    @Column(name = "DIGITO_VERIFICACION", length = 1)
    private String digitoVerificacion;

    @Column(name = "NOMBRE", length = 100)
    private String nombre;

    @Column(name = "APELLIDO1", length = 100)
    private String apellido1;

    @Column(name = "APELLIDO2", length = 100)
    private String apellido2;

    @Column(name = "RAZON_SOCIAL", nullable = false, length = 100)
    private String razonSocial;

    @Column(name = "DIRECCION", nullable = false, length = 100)
    private String direccion;

    @OneToOne
    @JoinColumn(name = "CIUDAD_ID")
    private Dane ciudad;

    @Column(name = "TELEFONO")
    private String telefono;

    @Column(name = "TELEFONO_MOVIL")
    private String telefonoMovil;

    @Column(name = "CORREO_ELECTRONICO", nullable = false, length = 100)
    private String correoElectronico;

    @Column(name = "FECHA_NACIMIENTO")
    private Date fechaNacimiento;

    @Column(name = "GENERO", nullable = false, length = 10)
    private String genero;

    @OneToMany(mappedBy = "asegurado")
    private List<Poliza> polizasAsegurado;

    @OneToMany(mappedBy = "tomador")
    private List<Poliza> polizasTomador;

    @OneToMany(mappedBy = "beneficiario")
    private List<Poliza> polizasBeneficiario;

}
