package com.everis.alondra.mspolizazurich.domain;

import com.everis.alondra.mspolizazurich.model.Riesgo;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class DatosRiesgo {
    private List<Riesgo> riesgos;
}
