package com.everis.alondra.mspolizazurich.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "CUSTOM_PARAM_DANE")
public class Dane {

    @Id
    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @JoinColumn(name = "DISPLAY_cODE")
    private Integer displayCode;

    @JoinColumn(name = "DESCRIPCION")
    private String descripcion;

}
