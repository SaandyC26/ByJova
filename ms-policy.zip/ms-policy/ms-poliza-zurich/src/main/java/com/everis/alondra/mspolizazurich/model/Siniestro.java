package com.everis.alondra.mspolizazurich.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "CUSTOM_SINIESTRO")
public class Siniestro {
    @Id
    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "POLIZA_ID", nullable = false)
    private Poliza poliza;

    @Column(name = "ID_SINIESTRO_MEDIADOR", length = 40)
    private String idSiniestroMediador;

    @Column(name = "ID_SINIESTRO_ENTIDAD", length = 40)
    private String idSiniestroEntidad;

    @Column(name = "FECHA_DECLARACION", nullable = false)
    private Date fechaDeclaracion;

    @Column(name = "FECHA_OCURRENCIA", nullable = false)
    private Date fechaOcurrencia;

    @Column(name = "DESCRIPCION_SINIESTRO", length = 255)
    private String descripcionSiniestro;

    @Column(name = "CALLE", length = 100)
    private String calle;

    @Column(name = "CAUSA_PERDIDA", length = 100)
    private String causaPerdida;

    @OneToOne
    @JoinColumn(name = "CIUDAD_ID", nullable = false)
    private Dane ciudadID;

    @OneToMany(mappedBy = "siniestro")
    private List<SituacionSiniestro> situacionesSiniestro;

}
