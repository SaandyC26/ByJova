package com.everis.alondra.mspolizazurich.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Table(name = "CUSTOM_POLIZA")
public class Poliza {

    @Id
    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "NUMERO_POLIZA", nullable = false, unique = true)
    private Long numeroPoliza;

    @Column(name = "NUMERO_CERTIFICADO", nullable = false, unique = true)
    private Integer numeroCertificado;

    @Column(name = "TIPO_ENDOSO", nullable = false, length = 3)
    private String tipoEndoso;

    @Column(name = "NUMERO_ENDOSO", nullable = false, unique = true)
    private Integer numeroEndoso;

    @Column(name = "TIPO_MOVIMIENTO", length = 2)
    private String tipoMovimiento;

    @Column(name = "CANAL")
    private Integer canal;

    @Column(name = "TIPO_NEGOCIO", nullable = false, length = 8)
    private String tipoNegocio;

    @Column(name = "FECHA_INICIO", nullable = false)
    private LocalDateTime fechaInicio;

    @Column(name = "FECHA_FIN", nullable = false)
    private LocalDateTime fechaFin;

    @Column(name = "FECHA_EXPEDICION", nullable = false)
    private LocalDateTime fechaExpedicion;

    @OneToOne
    @JoinColumn(name = "CIUDAD_EXPEDICION", nullable = false)
    private Dane ciudad;

    @Column(name = "FORMA_PAGO", nullable = false, length = 10)
    private String formaPago;

    @Column(name = "PORC_GESTION", nullable = false)
    private BigDecimal porcGestion;

    @Column(name = "VALOR_PRIMA", nullable = false)
    private BigDecimal valorPrima;

    @Column(name = "VALOR_IVA", nullable = false)
    private BigDecimal valorIva;

    @Column(name = "VALOR_TOTAL", nullable = false)
    private BigDecimal valorTotal;

    @Column(name = "VALOR_GESTION", nullable = false)
    private BigDecimal valorGestion;

    @Column(name = "OBSERVACIONES", nullable = false, length = 100)
    private String observaciones;

    @Column(name = "VERSION_POLIZA")
    private Integer versionPoliza;

    @Column(name = "PRODUCTO_ID", nullable = false)
    private String productID;

    @Column(name = "PLAN_ID")
    private String planID;
    @ManyToOne
    @JoinColumn(name = "TOMADOR_ID", nullable = false)
    private Persona tomador;

    @ManyToOne
    @JoinColumn(name = "ASEGURADOR_ID", nullable = false)
    private Persona asegurado;

    @ManyToOne
    @JoinColumn(name = "BENEFICIARIO_ID", nullable = false)
    private Persona beneficiario;

    @JoinTable(name = "CUSTOM_RIESGO_POLIZA_LINK",
            joinColumns = @JoinColumn(name = "POLIZA_ID"),
            inverseJoinColumns = @JoinColumn(name = "RIESGO_ID"))
    @ManyToMany
    protected List<Riesgo> riesgos;

    @OneToMany(mappedBy = "poliza")
    protected List<Cobertura> coberturas;

    @OneToMany(mappedBy = "poliza")
    private List<Siniestro> siniestros;
    @Column(name = "SALIDA_TIA")
    private Date salidaTIA;

    @Column(name = "FECHA_CANCELACION")
    private Date fechaCancelacion;

    @Column(name = "MOTIVO_CANCELACION")
    private String motivoCancelacion;

}




