package com.everis.alondra.mspolizazurich.domain;

import com.everis.alondra.mspolizazurich.model.Poliza;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.UUID;

@NoArgsConstructor
@Getter
@Setter
public class DatosTomador {
    private UUID id;
    private String idPersona;
    private String tipoPersona;
    private String tipoDocumento;
    private String digitoVerificacion;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String razonSocial;
    private String direccion;
    private String ciudad;
    private String telefonoMovil;
    private String correoElectronico;
    private Date fechaNacimiento;
    private String genero;

    public DatosTomador(UUID id, String idPersona, String tipoPersona, String tipoDocumento, String digitoVerificacion, String nombre, String apellido1, String apellido2, String razonSocial, String direccion, String ciudad, String telefonoMovil, String correoElectronico, Date fechaNacimiento, String genero) {
        this.id = id;
        this.idPersona = idPersona;
        this.tipoPersona = tipoPersona;
        this.tipoDocumento = tipoDocumento;
        this.digitoVerificacion = digitoVerificacion;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.telefonoMovil = telefonoMovil;
        this.correoElectronico = correoElectronico;
        this.fechaNacimiento = fechaNacimiento;
        this.genero = genero;
    }

}
