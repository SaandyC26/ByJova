package com.everis.alondra.mspolizazurich.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "CUSTOM_PARAM_BIENES")
public class Bienes {

    @Id
    @GeneratedValue
    @Type(type="org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "BIEN_ID", nullable = false, unique = true)
    private String bien;

    @Column(name = "CLASE_BIEN_ID", nullable = false, unique = true)
    private String claseBien;

    @Column(name = "DESC_BIEN", nullable = false, unique = true)
    private String descBien;

}
