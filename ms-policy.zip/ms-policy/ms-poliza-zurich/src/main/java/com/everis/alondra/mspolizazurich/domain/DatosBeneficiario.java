package com.everis.alondra.mspolizazurich.domain;

import lombok.*;

import java.util.Date;
import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class DatosBeneficiario {
    private UUID id;
    private String idPersona;
    private String tipoPersona;
    private String tipoDocumento;
    private String digitoVerificacion;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String razonSocial;
    private String direccion;
    private String ciudad;
    private String telefonoMovil;
    private String correoElectronico;
    private Date fechaNacimiento;
    private String genero;

}
