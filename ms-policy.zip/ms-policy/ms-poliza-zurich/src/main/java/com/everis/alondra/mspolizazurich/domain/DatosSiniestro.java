package com.everis.alondra.mspolizazurich.domain;

import com.everis.alondra.mspolizazurich.model.Siniestro;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@AllArgsConstructor
@Getter
@Setter
public class DatosSiniestro {
    private List<Siniestro> siniestro;
}
