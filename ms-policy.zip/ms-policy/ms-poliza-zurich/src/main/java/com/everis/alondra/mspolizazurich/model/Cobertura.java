package com.everis.alondra.mspolizazurich.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name = "CUSTOM_COBERTURA")
public class Cobertura {

    @Id
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;


    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "POLIZA_ID")
    private Poliza poliza;

    @OneToOne
    @JoinColumn(name = "PARAM_BIENES_ID")
    private Bienes bienes;

    @Column(name = "VALOR_PRIMA")
    private BigDecimal valorPrima;

    @Column(name = "VALOR_IVA")
    private BigDecimal valorIva;

    @Column(name = "VALOR_ASEGURADO")
    private BigDecimal valorAsegurado;

    @Column(name = "COD_BASE", length = 10)
    private String baseID;

    @Column(name = "DESC_BASE")
    private String descBase;

    @Column(name = "TIPO_DEDUCIBLE_1")
    private String tipoDeducible1;

    @Column(name = "VALOR_DEDUCIBLE_1")
    private BigDecimal valorDeducible1;

    @Column(name = "TIPO_DEDUCIBLE_2")
    private String tipoDeducible2;

    @Column(name = "VALOR_DEDUCIBLE_2")
    private BigDecimal valorDeducible2;

    @Column(name = "TIPO_LIMITE")
    private String tipoLimite;

    @Column(name = "VALOR_LIMITE")
    private BigDecimal valorLimite;

    @Column(name = "OBSERVACIONES")
    private String observaciones;

    @Column(name = "COBERTURA_ID")
    private Integer coberturaID;

    @Column(name = "COBERTURA_TIA_ID")
    private String coberturaTiaID;

}
