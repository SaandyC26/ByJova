package com.everis.alondra.mspolizazurich.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.everis.alondra.mspolizazurich.client.request.PolizaRequest;
import com.everis.alondra.mspolizazurich.client.response.getDataPolizaResponse;
import com.everis.alondra.mspolizazurich.domain.DatosAsegurado;
import com.everis.alondra.mspolizazurich.domain.DatosBeneficiario;
import com.everis.alondra.mspolizazurich.domain.DatosCobertura;
import com.everis.alondra.mspolizazurich.domain.DatosPoliza;
import com.everis.alondra.mspolizazurich.domain.DatosRecibo;
import com.everis.alondra.mspolizazurich.domain.DatosRiesgo;
import com.everis.alondra.mspolizazurich.domain.DatosSiniestro;
import com.everis.alondra.mspolizazurich.domain.DatosTomador;
import com.everis.alondra.mspolizazurich.model.Cobertura;
import com.everis.alondra.mspolizazurich.model.Poliza;
import com.everis.alondra.mspolizazurich.model.Recibo;
import com.everis.alondra.mspolizazurich.repository.CoberturaRepository;
import com.everis.alondra.mspolizazurich.repository.PolizaMapper;
import com.everis.alondra.mspolizazurich.repository.PolizaRepository;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class PolizaService {

    @Autowired
    PolizaRepository polizaRepository;
    @Autowired
    CoberturaRepository coberturaRepository;

    private final PolizaMapper polizaMapper;

    public PolizaService(PolizaMapper polizaMapper) {
        this.polizaMapper = polizaMapper;
    }

    public getDataPolizaResponse getDataPoliza(PolizaRequest polizaRequest) throws Exception {

        Poliza poliza = getPoliza(polizaRequest);

        if (poliza.getTipoEndoso().equals("MOD")) {
            log.info("Procesa tipo MOD");

            getPolizaTypeMod(polizaRequest, poliza);
        }

        DatosPoliza datosPoliza = polizaMapper.fromPolizaEntityToDatosPolizaDto(poliza);
        if (poliza.getCiudad() != null) {
            datosPoliza.setCiudadExpedicion(poliza.getCiudad().getDescripcion());
        }

        DatosTomador datosTomador = null;
        if (poliza.getTomador() != null) {
            datosTomador = polizaMapper.fromPersonaEntityToDatosTomadorDto(poliza.getTomador());
            if (poliza.getTomador().getCiudad() != null) {
                datosTomador.setCiudad(poliza.getTomador().getCiudad().getDescripcion());
            }

        }

        DatosAsegurado datosAsegurado = null;
        if (poliza.getAsegurado() != null) {
            datosAsegurado = polizaMapper.fromPersonaEntityToDatosAseguradoDto(poliza.getAsegurado());
            if (poliza.getAsegurado().getCiudad() != null) {
                datosAsegurado.setCiudad(poliza.getAsegurado().getCiudad().getDescripcion());
            }
        }

        DatosBeneficiario datosBeneficiario = null;
        if (poliza.getBeneficiario() != null) {
            datosBeneficiario = polizaMapper.fromPersonaEntityToDatosBeneficiarioDto(poliza.getBeneficiario());
            if (poliza.getBeneficiario().getCiudad() != null) {
                datosBeneficiario.setCiudad(poliza.getAsegurado().getCiudad().getDescripcion());
            }
        }

        DatosSiniestro datosSiniestro = new DatosSiniestro(poliza.getSiniestros());
        DatosCobertura datosCobertura = new DatosCobertura(poliza.getCoberturas());
        DatosRiesgo datosRiesgo = new DatosRiesgo(poliza.getRiesgos());
        List<Recibo> listaRecibos = new ArrayList<>();

        for (Iterator it = polizaRepository.getRecibos(poliza.getNumeroPoliza()).iterator(); it.hasNext();) {
            Object[] row = (Object[]) it.next();
            Recibo r = new Recibo(UUID.fromString(row[0].toString()), (Integer) row[8], (String) row[9],
                    (String) row[10], (Integer) row[11], (String) row[12], (String) row[13],
                    (String) row[14], (Long) row[15], (Integer) row[16], (Integer) row[17], (String) row[18],
                    (String) row[19], (Integer) row[20], (String) row[21],
                    (java.util.Date) row[22], (java.util.Date) row[23], (java.util.Date) row[24], (Integer) row[25],
                    (Integer) row[26],
                    (BigInteger) row[27], (BigInteger) row[28], (BigInteger) row[29], (Integer) row[30],
                    (String) row[31], (Integer) row[32], (BigInteger) row[33],
                    (Integer) row[34], (BigInteger) row[35], (BigInteger) row[36], (String) row[37],
                    (BigInteger) row[38], (Integer) row[39], (BigInteger) row[40], (java.util.Date) row[41],
                    (java.util.Date) row[42], (Integer) row[43]);
            listaRecibos.add(r);
        }

        DatosRecibo datosRecibo = new DatosRecibo(listaRecibos);

        return new getDataPolizaResponse(poliza.getId(), datosPoliza, datosTomador, datosAsegurado, datosBeneficiario,
                datosSiniestro, datosRiesgo, datosCobertura, datosRecibo);

    }

    private Poliza getPoliza(PolizaRequest polizaRequest) throws Exception {
        Poliza poliza;

        if (polizaRequest.getNumeroPoliza() != null
                && polizaRequest.getNumeroCertificado() != null
                && polizaRequest.getProductID() != null
                && polizaRequest.getPlanID() != null && !polizaRequest.getPlanID().isEmpty()
                && polizaRequest.getFechaOcurrencia() != null) {

            poliza = polizaRepository.getDetallePolizaRangoFechas(polizaRequest.getNumeroPoliza(),
                    polizaRequest.getNumeroCertificado(),
                    polizaRequest.getPlanID(),
                    polizaRequest.getProductID(),
                    polizaRequest.getFechaOcurrencia());

            if (poliza == null) {
                poliza = polizaRepository.getDetallePolizaMismoDia(polizaRequest.getNumeroPoliza(),
                        polizaRequest.getNumeroCertificado(),
                        polizaRequest.getPlanID(),
                        polizaRequest.getProductID(),
                        polizaRequest.getFechaOcurrencia(),
                        polizaRequest.getFechaOcurrencia().atTime(23, 59, 59));
                System.out.println("fecha con cambio hora " + polizaRequest.getFechaOcurrencia().atTime(23, 59, 59));
            }

        } else {
            throw new Exception(String.format("Póliza con el ID: %s, no ha sido encontrada, campos incompletos.",
                    polizaRequest.getNumeroPoliza()));
        }

        if (poliza == null) {
            throw new Exception(
                    String.format("Póliza con el ID: %s, no ha sido encontrada.", polizaRequest.getNumeroPoliza()));
        }
        return poliza;
    }

    private void getPolizaTypeMod(PolizaRequest polizaRequest, Poliza poliza) {
        log.info("Extrae información de pólizas anteriores");
        List<Poliza> polizas = polizaRepository.getDetallesPolizas(polizaRequest.getNumeroPoliza(),
                polizaRequest.getNumeroCertificado(),
                polizaRequest.getPlanID(),
                polizaRequest.getProductID(),
                Date.valueOf(polizaRequest.getFechaOcurrencia()));

        BigDecimal valorTotalFinal = sumaValorTotal(polizas);

        poliza.setValorTotal(valorTotalFinal);
    }

    private BigDecimal sumaValorTotal(List<Poliza> polizas) {
        // Cuando es modificación, se debe tomar el valor de emisión y sumar con el
        // valor asegurado de la emisión y de endosos anteriores
        log.info("Obtiene valor total de emisión ");
        BigDecimal valorEmision = BigDecimal.valueOf(0);
        valorEmision = polizas.stream()
                .filter(p -> p.getTipoEndoso().equals("EMI"))
                .map(Poliza::getValorTotal).collect(Collectors.toList()).get(0);
        System.out.println("valorEmision " + valorEmision);

        BigDecimal sumaValoresAseguradosBienes = getValorAseguradoBienes(polizas);

        BigDecimal sumaValorTotalValorAsegurado = valorEmision.add(sumaValoresAseguradosBienes);
        System.out.println("sumaValorTotalValorAsegurado " + sumaValorTotalValorAsegurado);

        return sumaValorTotalValorAsegurado;
    }

    private BigDecimal getValorAseguradoBienes(List<Poliza> polizas) {
        List<UUID> polizasIds = polizas.stream()
                .map(p -> p.getId())
                .distinct()
                .collect(Collectors.toList());

        BigDecimal sumaValoresAseguradosBienes = new BigDecimal(0);

        if (polizasIds != null) {
            List<Cobertura> coberturasByPolizas = coberturaRepository.findByPolizaIdIn(polizasIds);
            if (coberturasByPolizas.size() >= 0) {
                sumaValoresAseguradosBienes = coberturasByPolizas.stream()
                        .map(c -> c.getValorAsegurado())
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                System.out.println("getValorAseguradoBienes total" + sumaValoresAseguradosBienes);
            }
        }
        return sumaValoresAseguradosBienes;
    }

}
