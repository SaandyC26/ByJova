package com.everis.alondra.mspolizazurich.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.util.Date;
import java.util.UUID;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Table(name = "CUSTOM_RECAUDADO")
public class Recibo {

    @Id
    @Type(type = "org.hibernate.type.UUIDCharType")
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "CODIGO_COASEG", nullable = false)
    private Integer codigoCoAseg;

    @Column(name = "NIT_COASEGURADORA", length = 11, nullable = false)
    private String nitCoAseguradora;

    @Column(name = "NOMBRE_COASEGURADORA", length = 100, nullable = false)
    private String nombreCoAseguradora;

    @Column(name = "CODIGO_SUC", nullable = false)
    private Integer codigoSuc;

    @Column(name = "NOMBRE_SUCURSAL", length = 50, nullable = false)
    private String nombreSucursal;

    @Column(name = "NIT_TOMADOR", length = 11, nullable = false)
    private String nitTomador;

    @Column(name = "NOMBRE_TOMADOR", length = 100, nullable = false)
    private String nombreTomador;

    @Column(name = "NUMERO_POLIZA")
    private Long numeroPoliza;

    @Column(name = "NUMERO_CERTIFICADO")
    private Integer numeroCertificado;

    @Column(name = "NUMERO_ENDOSO")
    private Integer numeroEndoso;

    @Column(name = "PRODUCTO_ID", length = 10)
    private String productID;

    @Column(name = "PLAN_ID", length = 10)
    private String planID;

    @Column(name = "COD_RAMO", nullable = false)
    private Integer codRamo;

    @Column(name = "NOMBRE_RAMO", length = 30, nullable = false)
    private String nombreRamo;

    @Column(name = "INICIO_VIGENCIA", nullable = false)
    private Date inicioVigencia;

    @Column(name = "FIN_VIGENCIA", nullable = false)
    private Date finVigencia;

    @Column(name = "FECHA_RECAUDO", nullable = false, unique = true)
    private Date fechaRecaudo;

    @Column(name = "PORC_PART_LIDER", nullable = false)
    private Integer porcPartLider;

    @Column(name = "PORC_PRIMA_COA", nullable = false)
    private Integer porcPartCoa;

    @Column(name = "PRIMA_TOTAL", nullable = false, unique = true)
    private BigInteger primaTotal;

    @Column(name = "PORC_PRIMA_PARTICIPACION", nullable = false)
    private BigInteger porcPrimaParticipacion;

    @Column(name = "PORC_PRIMA_ABONADA", nullable = false)
    private BigInteger porcPrimaAbonada;

    @Column(name = "COD_INTER", nullable = false)
    private Integer codInter;

    @Column(name = "NOMBRE_INTERMEDIARIO", length = 100, nullable = false)
    private String nombreIntermediario;

    @Column(name = "PORC_COMISION", nullable = false)
    private Integer porcComision;

    @Column(name = "VR_COMISION", nullable = false)
    private BigInteger vrComision;

    @Column(name = "PORC_GASTOS", nullable = false)
    private Integer porcGastos;

    @Column(name = "VR_GASTOS_ADM", nullable = false)
    private BigInteger vrGastosADM;

    @Column(name = "IMP_GASTOS_ADM", nullable = false)
    private BigInteger impGastosADM;

    @Column(name = "MONEDA", length = 3, nullable = false)
    private String moneda;

    @Column(name = "VR_TOTAL", nullable = false)
    private BigInteger vrTotal;

    @Column(name = "PORC_RETRIBUCION")
    private Integer porcRetribucion;

    @Column(name = "VR_RETRIBUCION")
    private BigInteger vrRetribucion;

    @Column(name = "PERIODO_DESDE")
    private Date periodoDesde;

    @Column(name = "PERIODO_HASTA")
    private Date periodoHasta;

    @Column(name = "NUMERO_CUOTA", unique = true)
    private Integer numeroCuota;

}
