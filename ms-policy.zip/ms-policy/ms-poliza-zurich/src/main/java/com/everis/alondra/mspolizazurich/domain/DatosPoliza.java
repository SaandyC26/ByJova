package com.everis.alondra.mspolizazurich.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DatosPoliza {
    private Long numeroPoliza;
    private Integer numeroCertificado;
    private String tipoEndoso;
    private Integer numeroEndoso;
    private String tipoMovimiento;
    private Integer canal;
    private String tipoNegocio;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;
    private LocalDateTime fechaExpedicion;
    private String ciudadExpedicion;
    private String formaPago;
    private BigDecimal porcGestion;
    private BigDecimal valorPrima;
    private BigDecimal valorIva;
    private BigDecimal valorTotal;
    private BigDecimal valorGestion;
    private String observaciones;
    private Integer versionPoliza;
    private String productID;
    private String planID;
    private Date fechaCancelacion;
    private String motivoCancelacion;

}
