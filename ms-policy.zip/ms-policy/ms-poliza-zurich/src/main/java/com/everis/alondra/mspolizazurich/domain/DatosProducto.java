package com.everis.alondra.mspolizazurich.domain;

import com.everis.alondra.mspolizazurich.model.Producto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class DatosProducto {
    private UUID id;
    private String nombreConvenio;
    private String productoID;
    private String productoNombre;
    private String planID;
    private String planModalidad;
    private Integer revPlan;
    private Integer ramoID;
    private String rampoTipo;
    private Integer coberturaID;
    private String coberturaNombre;
    private Producto producto;

    public DatosProducto(Producto producto) {
    }
}
