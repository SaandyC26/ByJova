package com.everis.alondra.mspolizazurich.client.response;

import com.everis.alondra.mspolizazurich.domain.*;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
public class getDataPolizaResponse {
    private UUID idPoliza;
    private DatosPoliza datosPoliza;
    private DatosTomador datosTomador;
    private DatosAsegurado datosAsegurado;
    private DatosBeneficiario datosBeneficiario;
    private DatosSiniestro datosSiniestro;
    private DatosRiesgo datosRiesgo;
    private DatosCobertura datosCobertura;
    private DatosRecibo datosRecibo;


    public getDataPolizaResponse(UUID idPoliza, DatosPoliza datosPoliza, DatosTomador datosTomador, DatosAsegurado datosAsegurado, DatosBeneficiario datosBeneficiario, DatosSiniestro datosSiniestro, DatosRiesgo datosRiesgo, DatosCobertura datosCobertura, DatosRecibo datosRecibo) {
        this.idPoliza = idPoliza;
        this.datosPoliza = datosPoliza;
        this.datosTomador = datosTomador;
        this.datosAsegurado = datosAsegurado;
        this.datosBeneficiario = datosBeneficiario;
        this.datosSiniestro = datosSiniestro;
        this.datosRiesgo = datosRiesgo;
        this.datosCobertura = datosCobertura;
        this.datosRecibo = datosRecibo;
    }

}
