package com.everis.alondra.mspolizazurich.exception;

import lombok.Data;

@Data
public class ErrorDescriptor {
    long timestamp;
    int status;
    String error;
    String message;

    String path;
}
