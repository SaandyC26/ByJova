package com.everis.alondra.mspolizazurich.repository;

import com.everis.alondra.mspolizazurich.domain.DatosAsegurado;
import com.everis.alondra.mspolizazurich.domain.DatosBeneficiario;
import com.everis.alondra.mspolizazurich.domain.DatosPoliza;
import com.everis.alondra.mspolizazurich.domain.DatosTomador;
import com.everis.alondra.mspolizazurich.model.Persona;
import com.everis.alondra.mspolizazurich.model.Poliza;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PolizaMapper {

    private final ModelMapper modelMapper;

    public DatosPoliza fromPolizaEntityToDatosPolizaDto(final Poliza poliza){
        return this.modelMapper.map(poliza, DatosPoliza.class);
    }

    public DatosTomador fromPersonaEntityToDatosTomadorDto(final Persona tomador){
        return this.modelMapper.map(tomador, DatosTomador.class);
    }

    public DatosAsegurado fromPersonaEntityToDatosAseguradoDto(final Persona asegurado){
        return this.modelMapper.map(asegurado, DatosAsegurado.class);
    }

    public DatosBeneficiario fromPersonaEntityToDatosBeneficiarioDto(final Persona beneficiario){
        return this.modelMapper.map(beneficiario, DatosBeneficiario.class);
    }

}
