package com.everis.alondra.mspolizazurich.client;

import com.everis.alondra.mspolizazurich.client.request.PolizaRequest;
import com.everis.alondra.mspolizazurich.client.response.getDataPolizaResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RequestMapping("")
public interface IPoliza {

    @PostMapping("/getDataPoliza")
    ResponseEntity<getDataPolizaResponse> getDataPoliza(@RequestBody PolizaRequest polizaRequest) throws Exception;


}
