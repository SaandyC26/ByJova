package com.everis.alondra.mspolizazurich.exception;

public class DataNotFoundException extends Throwable {

    private static final long serialVersionUID = 7883283395096400811L;

    DataNotFoundException(String message) { super(message);}
    DataNotFoundException(Throwable throwable) { super(throwable);}
}
