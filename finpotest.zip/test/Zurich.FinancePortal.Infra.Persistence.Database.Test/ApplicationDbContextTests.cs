﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Test;

using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System.Threading.Tasks;

public sealed class ApplicationDbContextTests : BaseDatabaseTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldGetRevenueAsync()
    {
        // Arrange
        await AddRevenueAsync().ConfigureAwait(false);
        // Act
        var revenue = await DbContext.Revenues.FirstOrDefaultAsync().ConfigureAwait(false);
        var revenueFrontend = await DbContext.RevenuesFrontEnd.FirstOrDefaultAsync().ConfigureAwait(false);
        var revenueOData = await DbContext.RevenuesODataDto.FirstOrDefaultAsync().ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(revenue);
        Assert.IsNotNull(revenueFrontend);
        Assert.IsNotNull(revenueOData);
    }

    [Test]
    public async Task ShouldRemoveUserAsync()
    {
        // Arrange
        var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
        // Act
        DbContext.Users.Remove(user);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        // Assert
        user = await DbContext.Users.AsNoTracking().SingleOrDefaultAsync(u => u.Id.Equals(user.Id)).ConfigureAwait(false);
        Assert.IsNull(user);
    }

    #endregion
}
