﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Test;

using Application;
using AutoMapper;
using DevOps.CrossCutting;
using Domain;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

public abstract class BaseDatabaseTests
{
    #region --- PROPERTIES ---

    private const string _sqliteConnectionString = "DataSource=:memory:";

    private const int RetryExpectedTimeMilliseconds = 3;

    protected private const long DatabaseExpectedTimeMilliseconds = 250;

    protected bool Sqlite { get; set; } = true;

    #endregion

    #region --- REFERENCES ---

    private SqliteConnection _sqliteConnection;

    private Random _random;

    protected Random Random => _random ??= new Random((int)DateTime.UtcNow.Ticks);

    private ServiceProvider _services;
    protected ServiceProvider Services
    {
        get
        {
            if (_services == null) _services = ServiceCollection.BuildServiceProvider();
            return _services;
        }
    }

    private ServiceCollection _serviceCollection;
    protected ServiceCollection ServiceCollection
    {
        get
        {
            _services?.Dispose();
            _services = null;
            return _serviceCollection;
        }
        private set => _serviceCollection = value;
    }

    protected private ApplicationDbContext DbContext => Services.GetRequiredService<ApplicationDbContext>();

    protected IMapper Mapper { get; private set; }

    #endregion

    #region --- PUBLIC METHODS ---

    [TearDown]
    public void TearDown()
    {
        if (_sqliteConnection != null)
        {
            _sqliteConnection.Close();
            _sqliteConnection.Dispose();
            _sqliteConnection = null;
        }

        if (DbContext != null) DbContext.Dispose();
        if (Services != null) Services.Dispose();
    }

    [SetUp]
    public virtual void SetUp()
    {
        ServiceCollection = new ServiceCollection();
        // Sqlite
        if (Sqlite)
        {
            _sqliteConnection = new SqliteConnection(_sqliteConnectionString);
            _sqliteConnection.OpenAsync().Wait();
        }

        ServiceCollection.AddLogging();
        ServiceCollection.AddPersistenceDatabase(PersistenceConfiguration.GetDefaultIConfiguration(), sqliteConnection: _sqliteConnection);
        // Migrate
        DbContext.MigrateAsync().Wait();
        // Seed Database
        DbContext.SeedDatabase(SeedMode.UnitTesting).Wait();
        // Others
        Mapper = Services.GetRequiredService<IMapper>();
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected IQueryable<T> GetIQuerable<T>(bool asNoTracking = true) where T : class
    {
        var query =  asNoTracking ? DbContext.Set<T>().AsNoTracking() : DbContext.Set<T>();
        query = typeof(T).Name switch
        {
            nameof(Revenue) => (IQueryable<T>)((IQueryable<Revenue>)query).Include(r => r.LineOfBusiness).Include(r => r.Customer).ThenInclude(x => x.Function).Include(r => r.Project).Include(r => r.TypeOfService).Include(r => r.OwnerProjectManager).Include(r => r.BusinessUnit).Include(r => r.CustomerCostCenter).Include(r => r.ChargingModel).Include(r => r.InternalCostCenterPerCost).Include(r => r.Product).Include(r => r.Currency).Include(r => r.ValueAddedTax).Include(r => r.Comments),
            _ => query
        };

        return query;
    }

    protected async Task SaveChangesAsync() => await DbContext.SaveChangesAsync().ConfigureAwait(false);

    protected T GetProperty<TEntry, T>(TEntry entry, string propertyName) => (T)DbContext.Entry(entry).Property(propertyName).CurrentValue;

    protected async Task RemoveAsync<T>(T t) where T : class
    {
        DbContext.Set<T>().Remove(t);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
    }

    protected async static Task<TResult> ActAndAssertRequestWithTimewatch<TResult>(Func<Task<TResult>> func, long maximumExpectedTimeMilliseconds, Func<Task> retryFunc = default)
    {
        var result = default(TResult);
        for (var i = 0; i < RetryExpectedTimeMilliseconds; i++)
        {
            // Arrange
            var stopwatch = Stopwatch.StartNew();
            // Act
            result = await func().ConfigureAwait(false);
            // Assert
            stopwatch.Stop();
            var elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
            if (elapsedMilliseconds < maximumExpectedTimeMilliseconds) break;
            Console.WriteLine($"Current elapsed milliseconds: {elapsedMilliseconds}.");
            if (retryFunc != null) await retryFunc().ConfigureAwait(false);
            if (i >= RetryExpectedTimeMilliseconds) Assert.Warn($"Maximum expected time was {maximumExpectedTimeMilliseconds} but {elapsedMilliseconds} instead.");
        }
        // Result
        return result;
    }

    protected Currency GetCurrencyMock() => new(Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), ((char)('a' + Random.Next(0, 26))).ToString());

    protected async Task<(Currency Entity, CurrencyDto Dto)> AddCurrencyAsync(Currency currency = default)
    {
        if (currency == null) currency = GetCurrencyMock();
        DbContext.Add(currency);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (currency, Mapper.Map<Currency, CurrencyDto>(currency));
    }

    protected static Customer GetCustomerMock(CustomerFunction customerFunction = default) => new(Guid.NewGuid().ToString(), function: customerFunction);

    protected async Task<(Customer Entity, CustomerDto Dto)> AddCustomerAsync(Customer customer = default)
    {
        if (customer == null) customer = GetCustomerMock(customerFunction: (await AddCustomerFunctionAsync().ConfigureAwait(false)).Entity);
        DbContext.Add(customer);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (customer, Mapper.Map<Customer, CustomerDto>(customer));
    }

    protected static CustomerFunction GetCustomerFunctionMock() => new(Guid.NewGuid().ToString());

    protected async Task<(CustomerFunction Entity, CustomerFunctionDto Dto)> AddCustomerFunctionAsync(CustomerFunction customerFunction = default)
    {
        if (customerFunction == null) customerFunction = GetCustomerFunctionMock();
        DbContext.Add(customerFunction);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (customerFunction, Mapper.Map<CustomerFunction, CustomerFunctionDto>(customerFunction));
    }

    protected static CostCenter GetCostCenterMock() => new(Guid.NewGuid().ToString(), new CostCenterType[] { CostCenterType.Customer, CostCenterType.Internal });

    protected async Task<(CostCenter Entity, CostCenterDto Dto)> AddCostCenterAsync(CostCenter costCenter = default)
    {
        if (costCenter == null) costCenter = GetCostCenterMock();
        DbContext.Add(costCenter);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (costCenter, Mapper.Map<CostCenter, CostCenterDto>(costCenter));
    }

    protected static BusinessUnit GetBusinessUnitMock() => new(Guid.NewGuid().ToString(), Guid.NewGuid().ToString());

    protected async Task<(BusinessUnit Entity, BusinessUnitDto Dto)> AddBusinessUnitAsync(BusinessUnit businessUnit = default)
    {
        if (businessUnit == null) businessUnit = GetBusinessUnitMock();
        DbContext.Add(businessUnit);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (businessUnit, Mapper.Map<BusinessUnit, BusinessUnitDto>(businessUnit));
    }

    protected static Project GetProjectMock() => new(Guid.NewGuid().ToString(), ProjectType.NA, planningItApps: new PlanningItApp[] { new(PlanningItAppPrefix.APP, Guid.NewGuid().ToString(), Guid.NewGuid().ToString()) });

    protected async Task<(Project Entity, ProjectDto Dto)> AddProjectAsync(Project project = default)
    {
        if (project == null) project = GetProjectMock();
        DbContext.Add(project);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (project, Mapper.Map<Project, ProjectDto>(project));
    }

    protected static ChargingModelType GetChargingModelTypeMock() => new(Guid.NewGuid().ToString());

    protected async Task<(ChargingModelType Entity, ChargingModelTypeDto Dto)> AddChargingModelTypeAsync(ChargingModelType chargingModelType = default)
    {
        if (chargingModelType == null) chargingModelType = GetChargingModelTypeMock();
        DbContext.Add(chargingModelType);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (chargingModelType, Mapper.Map<ChargingModelType, ChargingModelTypeDto>(chargingModelType));
    }

    protected async Task<ChargingModel> GetChargingModelMock() => new(Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), (await AddChargingModelTypeAsync().ConfigureAwait(false)).Entity);

    protected async Task<(ChargingModel Entity, ChargingModelDto Dto)> AddChargingModelAsync(ChargingModel chargingModel = default)
    {
        if (chargingModel == null) chargingModel = await GetChargingModelMock().ConfigureAwait(false);
        DbContext.Add(chargingModel);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (chargingModel, Mapper.Map<ChargingModel, ChargingModelDto>(chargingModel));
    }

    protected static LineOfBusiness GetLineOfBusinessMock() => new(Guid.NewGuid().ToString());

    protected static Product GetProductMock() => new(Guid.NewGuid().ToString());

    protected async Task<(Product Entity, ProductDto Dto)> AddProductAsync(Product product = default)
    {
        if (product == null) product = GetProductMock();
        DbContext.Add(product);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (product, Mapper.Map<Product, ProductDto>(product));
    }

    protected async Task<(LineOfBusiness Entity, LineOfBusinessDto Dto)> AddLineOfBusinessAsync(LineOfBusiness lineOfBusiness = default)
    {
        if (lineOfBusiness == null) lineOfBusiness = GetLineOfBusinessMock();
        DbContext.Add(lineOfBusiness);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (lineOfBusiness, Mapper.Map<LineOfBusiness, LineOfBusinessDto>(lineOfBusiness));
    }

    protected static TypeOfService GetTypeOfServiceMock() => new(Guid.NewGuid().ToString());

    protected async Task<(TypeOfService Entity, TypeOfServiceDto Dto)> AddTypeOfServiceAsync(TypeOfService typeOfService = default)
    {
        if (typeOfService == null) typeOfService = GetTypeOfServiceMock();
        DbContext.Add(typeOfService);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (typeOfService, Mapper.Map<TypeOfService, TypeOfServiceDto>(typeOfService));
    }

    protected static TestingTool GetTestingToolMock() => new (Guid.NewGuid().ToString());

    protected async Task<(TestingTool Entity, TestingToolDto Dto)> AddTestingToolAsync(TestingTool testingTool = default)
    {
        if (testingTool == null) testingTool = GetTestingToolMock();
        DbContext.Add(testingTool);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (testingTool, Mapper.Map<TestingTool, TestingToolDto>(testingTool));
    }

    protected ValueAddedTax GetValueAddedTaxMock() => new(Guid.NewGuid().ToString(), Random.Next(1, 21));

    protected async Task<(ValueAddedTax Entity, ValueAddedTaxDto Dto)> AddValueAddedTaxAsync(ValueAddedTax valueAddedTax = default)
    {
        if (valueAddedTax == null) valueAddedTax = GetValueAddedTaxMock();
        DbContext.Add(valueAddedTax);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (valueAddedTax, Mapper.Map<ValueAddedTax, ValueAddedTaxDto>(valueAddedTax));
    }

    protected async Task<CurrencyExchangeRate> GetCurrencyExchangeRateMock()
    {
        var from = (await AddCurrencyAsync().ConfigureAwait(false)).Entity;
        var to = (await AddCurrencyAsync().ConfigureAwait(false)).Entity;
        return new CurrencyExchangeRate(Random.Next(2000, DateTime.UtcNow.Year), 1 + (Random.Next(-50, 50) / 100), from, to);
    }

    protected async Task<(CurrencyExchangeRate Entity, CurrencyExchangeRateDto Dto)> AddCurrencyExchangeRateAsync(CurrencyExchangeRate currencyExchangeRate = default)
    {
        if (currencyExchangeRate == null) currencyExchangeRate = await GetCurrencyExchangeRateMock();
        else
        {
            DbContext.Attach(currencyExchangeRate.From);
            DbContext.Attach(currencyExchangeRate.To);
        }

        DbContext.Add(currencyExchangeRate);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (currencyExchangeRate, Mapper.Map<CurrencyExchangeRate, CurrencyExchangeRateDto>(currencyExchangeRate));
    }

    protected async Task RemoveCurrencyExchangeRateAsync(int year)
    {
        var currencyExchangeRates = await DbContext.Set<CurrencyExchangeRate>().Where(cer => cer.Year.Equals(year)).ToArrayAsync().ConfigureAwait(false);
        DbContext.RemoveRange(currencyExchangeRates);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
    }

    protected async Task<Revenue> GetRevenueMock()
    {
        var currency = (await AddCurrencyAsync().ConfigureAwait(false)).Entity;
        var valueAddedTax = await DbContext.ValueAddedTaxes.SingleAsync(vat => vat.Country.Equals(ValueAddedTax.SwitzerlandCountry)).ConfigureAwait(false);
        var customerCostCenter = (await AddCostCenterAsync().ConfigureAwait(false)).Entity;
        var internalCostCenterPerCost = (await AddCostCenterAsync().ConfigureAwait(false)).Entity;
        var businessUnit = (await AddBusinessUnitAsync().ConfigureAwait(false)).Entity;
        var project = (await AddProjectAsync().ConfigureAwait(false)).Entity;
        var customer = (await AddCustomerAsync().ConfigureAwait(false)).Entity;
        var typeOfService = (await AddTypeOfServiceAsync().ConfigureAwait(false)).Entity;
        var chargingModel = (await AddChargingModelAsync().ConfigureAwait(false)).Entity;
        var lineOfBusiness = (await AddLineOfBusinessAsync().ConfigureAwait(false)).Entity;
        var ownerProjectManager = (await AddUserAsync().ConfigureAwait(false)).Entity;
        var product = (await AddProductAsync().ConfigureAwait(false)).Entity;
        var testingTool = (await AddTestingToolAsync().ConfigureAwait(false)).Entity;
        var r = Random.Next(3, 12);
        var year = DateTime.UtcNow.Year;
        var revenue = new Revenue(year, lineOfBusiness, project, customer, typeOfService, (businessUnit, customerCostCenter), chargingModel, internalCostCenterPerCost, currency, valueAddedTax, ownerProjectManager, product, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc), internalCode: Guid.NewGuid().ToString(), serviceDescription: Guid.NewGuid().ToString(), testingTool: testingTool, testingToolProjectName: Guid.NewGuid().ToString(), testingToolDetailedInfo: Guid.NewGuid().ToString());
        var monthsRevenues = new Dictionary<Month, MonthRevenue>();
        Revenue.GetMonths().ForEach((m, i) => monthsRevenues.Add(m, (r - 1 >= i) ? new MonthRevenue(Random.Next(1000, 10000)) : null));
        revenue.UpdateMonthsRevenues(monthsRevenues);
        for (var i = 0; i < Random.Next(3, 10); i++) revenue.AddComment(Guid.NewGuid().ToString(), revenue.OwnerProjectManager);
        return revenue;
    }

    protected async Task<(Revenue Entity, RevenueDto Dto)> AddRevenueAsync(Revenue revenue = default)
    {
        if (revenue == null) revenue = await GetRevenueMock().ConfigureAwait(false);
        DbContext.Add(revenue);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        DbContext.ChangeTracker.Entries<Revenue>().ForEach(ee => ee.State = EntityState.Detached);
        return (revenue, Mapper.Map<RevenueModel, RevenueDto>(await DbContext.RevenuesFrontEnd.SingleAsync(r => r.Id.Equals(revenue.Id)).ConfigureAwait(false)));
    }

    protected static User GetUserMock() => new(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()));

    protected async Task<(User Entity, UserDto Dto)> AddUserAsync(User user = default)
    {
        if (user == null) user = GetUserMock();
        DbContext.Add(user);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (user, Mapper.Map<User, UserDto>(user));
    }

    protected static Group GetGroupMock() => new(Guid.NewGuid().ToString());

    protected async Task<(Group Entity, GroupDto Dto)> AddGroupAsync(Group group = default)
    {
        if (group == null) group = GetGroupMock();
        DbContext.Add(group);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (group, Mapper.Map<Group, GroupDto>(group));
    }

    protected static Role GetRoleMock() => new(Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString());

    protected async Task<(Role Entity, RoleDto Dto)> AddRoleAsync(Role role = default)
    {
        if (role == null) role = GetRoleMock();
        DbContext.Add(role);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (role, Mapper.Map<Role, RoleDto>(role));
    }

    protected static Permission GetPermissionMock() => new(Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString());

    protected async Task<(Permission Entity, PermissionDto Dto)> AddPermissionAsync(Permission permission = default)
    {
        if (permission == null) permission = GetPermissionMock();
        DbContext.Add(permission);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (permission, Mapper.Map<Permission, PermissionDto>(permission));
    }

    protected async Task<YearLocks> AddYearLocksAsync(YearLocks yearLocks)
    {
        DbContext.Add(yearLocks);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return yearLocks;
    }

    protected static TicketComment GetTicketComment(User user) => new(Guid.NewGuid().ToString(), user);

    protected async Task<Ticket> GetTicketMockAsync()
    {
        var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
        var comments = new List<TicketComment>();
        for (var i = Random.Next(1, 10); i > 0; i--) comments.Add(GetTicketComment(user));
        return new Ticket(Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), (TicketType)Random.Next(0, Enum.GetValues<TicketType>().Length - 1), user, comments);
    }

    protected async Task<(Ticket Entity, TicketDto Dto)> AddTicketAsync(Ticket ticket = default)
    {
        if (ticket == null) ticket = await GetTicketMockAsync().ConfigureAwait(false);
        DbContext.Add(ticket);
        await DbContext.SaveChangesAsync().ConfigureAwait(false);
        return (ticket, Mapper.Map<Ticket, TicketDto>(ticket));
    }

    protected static IEnumerable<object> GetMasterDataTypes() =>
        MasterData.GetMasterDataTypes().Select(t => new object[] { t }).ToList();

    protected static IEnumerable<Month> GetMonths() => Revenue.GetMonths();

    #endregion
}
