﻿namespace Zurich.FinancePortal.Application.Test;

using DevOps.CrossCutting;
using Domain;
using NUnit.Framework;
using System.Linq;
using System.Threading.Tasks;

public sealed class GetUsersQueryTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldGetUsersAsync()
    {
        // Arrange
        var (query, deletedUser, user) = await ProtectedShouldGetUsersAsync().ConfigureAwait(false);
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString());
        Assert.AreNotEqual(0, result.Result.Count);
        Assert.IsNotNull(result.Result.Users);
        Assert.AreEqual(result.Result.Count, result.Result.Users.Count());
        AssertUserDto(result.Result.Users.Single(u => u.Id.Equals(user.Id)), user);
        Assert.IsNull(result.Result.Users.SingleOrDefault(u => u.Id.Equals(deletedUser.Id)));
    }

    [Test]
    public async Task ShouldGetUsersFilteredAndOrderedAsync()
    {
        // Arrange
        var user1 = (await AddUserAsync().ConfigureAwait(false)).Entity;
        var user2 = (await AddUserAsync().ConfigureAwait(false)).Entity;
        var query = new GetUsersQuery()
        {
            DataSourceRequest = new DataSourceRequest()
            {
                Skip = 1,
                Take = 1,
                Sort = new Sort[]
                {
                    new Sort()
                    {
                        Field = nameof(User.Id),
                        Dir = SortDir.desc
                    }
                },
                Filter = new Filter()
                {
                    Logic = FilterLogic.and,
                    Filters = new Filter[]
                    {
                        new Filter()
                        {
                            Logic = FilterLogic.or,
                            Filters = new Filter[]
                            {
                                new Filter()
                                {
                                    Field = nameof(User.AdAccount.SAMAccountName),
                                    Value = user1.AdAccount.SAMAccountName,
                                    Operator = FilterOperator.eq
                                },
                                new Filter()
                                {
                                    Field = nameof(User.AdAccount.SAMAccountName),
                                    Value = user2.AdAccount.SAMAccountName,
                                    Operator = FilterOperator.eq
                                }
                            }
                        },
                        new Filter()
                        {
                            Logic = FilterLogic.or,
                            Filters = new Filter[]
                            {
                                new Filter()
                                {
                                    Field = nameof(User.Id),
                                    Value = user1.Id,
                                    Operator = FilterOperator.eq
                                },
                                new Filter()
                                {
                                    Field = nameof(User.Id),
                                    Value = user2.Id,
                                    Operator = FilterOperator.eq
                                }
                            }
                        }
                    }
                }
            }
        };
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString());
        Assert.AreNotEqual(0, result.Result.Count);
        Assert.IsNotNull(result.Result.Users);
        Assert.AreEqual(2, result.Result.Count);
        Assert.AreEqual(1, result.Result.Users.Count());
        AssertUserDto(result.Result.Users.Single(u => u.Id.Equals(user1.Id)), user1);
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<(GetUsersQuery Query, User DeletedUser, User user)> ProtectedShouldGetUsersAsync()
    {
        var deletedUser = (await AddUserAsync(GetUserMock().SetDeleted()).ConfigureAwait(false)).Entity;
        var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
        return (new GetUsersQuery(), deletedUser, user);
    }

    #endregion
}
