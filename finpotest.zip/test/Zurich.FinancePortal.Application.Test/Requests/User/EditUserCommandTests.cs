﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class EditUserCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditUserAsync()
        {
            // Arrange
            var user = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()));
            user = (await AddUserAsync(user: user).ConfigureAwait(false)).Entity;
            var command = new EditUserCommand()
            {
                User = new UserDto()
                {
                    Id = user.Id,
                    Name = Guid.NewGuid().ToString(),
                    SAMAccountName = user.AdAccount.SAMAccountName
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().SingleOrDefaultAsync(u => u.Name.Equals(command.User.Name)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
        }

        [Test]
        public async Task ShouldEditUserWithRolesAsync()
        {
            // Arrange
            var (command, _) = await ProtectedShouldEditUserWithRolesAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().Include(u => u.Roles).SingleOrDefaultAsync(u => u.Name.Equals(command.User.Name)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsNotNull(userDb.Roles);
            Assert.AreNotEqual(0, userDb.Roles);
        }

        [Test]
        public async Task ShouldEditUserWithGroupsAsync()
        {
            // Arrange
            var (command, _) = await ProtectedShouldEditUserWithGroupsAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().Include(u => u.Groups).SingleOrDefaultAsync(u => u.Name.Equals(command.User.Name)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsNotNull(userDb.Groups);
            Assert.AreNotEqual(0, userDb.Groups);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(EditUserCommand Command, User User)> ProtectedShouldEditUserWithRolesAsync()
        {
            var roleDto = (await AddRoleAsync().ConfigureAwait(false)).Dto;
            var user = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()));
            user = (await AddUserAsync(user: user).ConfigureAwait(false)).Entity;
            var command = new EditUserCommand()
            {
                User = new UserDto()
                {
                    Id = user.Id,
                    Name = Guid.NewGuid().ToString(),
                    SAMAccountName = user.AdAccount.SAMAccountName,
                    Roles = new RoleDto[]
                    {
                        roleDto
                    }
                }
            };

            return (command, user);
        }

        protected async Task<(EditUserCommand Command, User User)> ProtectedShouldEditUserWithGroupsAsync()
        {
            var groupDto = (await AddGroupAsync().ConfigureAwait(false)).Dto;
            var user = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()));
            user = (await AddUserAsync(user: user).ConfigureAwait(false)).Entity;
            var command = new EditUserCommand()
            {
                User = new UserDto()
                {
                    Id = user.Id,
                    Name = Guid.NewGuid().ToString(),
                    SAMAccountName = user.AdAccount.SAMAccountName,
                    Groups = new GroupDto[]
                    {
                        groupDto
                    }
                }
            };

            return (command, user);
        }

        #endregion
    }
}
