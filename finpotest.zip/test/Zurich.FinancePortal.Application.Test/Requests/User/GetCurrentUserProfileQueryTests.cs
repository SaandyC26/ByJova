﻿namespace Zurich.FinancePortal.Application.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetCurrentUserProfileQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetCurrentUserProfileWithReleaseNotesAsync()
        {
            // Arrange
            var query = await ProtectedShouldGetCurrentUserProfileWithReleaseNotesAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsNotNull(result.Result.User);
            Assert.AreEqual(CurrentUserService.Username, result.Result.User.SAMAccountName);
            Assert.IsTrue(string.IsNullOrWhiteSpace(result.Result.User.LastSeenVersion));
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.Result.User.ReleaseNotes));
        }

        [Test]
        public async Task ShouldGetCurrentUserProfileWithoutReleaseNotesAsync()
        {
            // Arrange
            var query = await ProtectedShouldGetCurrentUserProfileWithReleaseNotesAsync().ConfigureAwait(false);
            Assert.IsTrue((await Mediatr.Send(new EditUserLastSeenReleaseNotesCommand()).ConfigureAwait(false)).Success);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsNotNull(result.Result.User);
            Assert.AreEqual(CurrentUserService.Username, result.Result.User.SAMAccountName);
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.Result.User.LastSeenVersion));
            Assert.IsTrue(string.IsNullOrWhiteSpace(result.Result.User.ReleaseNotes));
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<GetCurrentUserProfileQuery> ProtectedShouldGetCurrentUserProfileWithReleaseNotesAsync()
        {
            var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
            SetCurrentUser(user);
            return new GetCurrentUserProfileQuery();
        }

        #endregion
    }
}
