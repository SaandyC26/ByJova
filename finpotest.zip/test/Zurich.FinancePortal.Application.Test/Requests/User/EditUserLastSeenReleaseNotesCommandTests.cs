﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class EditUserLastSeenReleaseNotesCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditUserLastSeenReleaseNotesAsync()
        {
            // Arrange
            var command = await ProtectedShouldEditUserLastSeenReleaseNotesAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            Assert.IsNotEmpty(GetProperty<User, string>(await GetIQuerable<User>().SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.ToUpper().Equals(CurrentUserService.Username.ToUpper())).ConfigureAwait(false), nameof(User.LastSeenReleaseNotes)));
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<EditUserLastSeenReleaseNotesCommand> ProtectedShouldEditUserLastSeenReleaseNotesAsync()
        {
            var user = new User(CurrentUserService.Username, new AdAccount(CurrentUserService.Username));
            await AddUserAsync(user: user).ConfigureAwait(false);
            return new EditUserLastSeenReleaseNotesCommand();
        }

        #endregion
    }
}
