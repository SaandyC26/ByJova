﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public class CreateUserCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateUserAsync()
        {
            // Arrange
            var command = new CreateUserCommand()
            {
                User = new UserDto()
                {
                    SAMAccountName = Guid.NewGuid().ToString(),
                    Name = Guid.NewGuid().ToString()
                }
            };

            var retryFunc = new Func<Task>(() =>
            {
                command.User.SAMAccountName = Guid.NewGuid().ToString();
                command.User.Name = Guid.NewGuid().ToString();
                return Task.CompletedTask;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.Equals(command.User.SAMAccountName)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
        }

        [Test]
        public async Task ShouldReCreateUserAsync()
        {
            // Arrange
            var user = (await AddUserAsync(user: new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).SetDeleted()).ConfigureAwait(false)).Entity;
            var command = new CreateUserCommand()
            {
                User = new UserDto()
                {
                    SAMAccountName = user.AdAccount.SAMAccountName,
                    Name = Guid.NewGuid().ToString()
                }
            };

            var retryFunc = new Func<Task>(async () =>
            {
                user = (await AddUserAsync(user: new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).SetDeleted()).ConfigureAwait(false)).Entity;
                command.User.SAMAccountName = user.AdAccount.SAMAccountName;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.Equals(command.User.SAMAccountName)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsFalse(userDb.IsDeleted);
        }

        [Test]
        public async Task ShouldCreateUserWithRolesAsync()
        {
            // Arrange
            var roleDto = (await AddRoleAsync().ConfigureAwait(false)).Dto;
            var command = new CreateUserCommand()
            {
                User = new UserDto()
                {
                    SAMAccountName = Guid.NewGuid().ToString(),
                    Name = Guid.NewGuid().ToString(),
                    Roles = new RoleDto[]
                    {
                        roleDto
                    }
                }
            };

            var retryFunc = new Func<Task>(() =>
            {
                command.User.SAMAccountName = Guid.NewGuid().ToString();
                command.User.Name = Guid.NewGuid().ToString();
                return Task.CompletedTask;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().Include(u => u.Roles).SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.Equals(command.User.SAMAccountName)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsNotNull(userDb.Roles);
            Assert.AreNotEqual(0, userDb.Roles);
        }

        [Test]
        public async Task ShouldCreateUserWithGroupsAsync()
        {
            // Arrange
            var groupDto = (await AddGroupAsync().ConfigureAwait(false)).Dto;
            var command = new CreateUserCommand()
            {
                User = new UserDto()
                {
                    SAMAccountName = Guid.NewGuid().ToString(),
                    Name = Guid.NewGuid().ToString(),
                    Groups = new GroupDto[]
                    {
                        groupDto
                    }
                }
            };

            var retryFunc = new Func<Task>(() =>
            {
                command.User.SAMAccountName = Guid.NewGuid().ToString();
                command.User.Name = Guid.NewGuid().ToString();
                return Task.CompletedTask;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().Include(u => u.Groups).SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.Equals(command.User.SAMAccountName)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsNotNull(userDb.Groups);
            Assert.AreNotEqual(0, userDb.Groups);
        }

        #endregion
    }
}
