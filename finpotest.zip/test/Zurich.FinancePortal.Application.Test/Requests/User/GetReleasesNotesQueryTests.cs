﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using NUnit.Framework;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetReleasesNotesQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetReleasesNotesQueryAsync()
        {
            // Arrange
            var query = new GetReleasesNotesQuery();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Message ?? result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.AreEqual("0.0.0", result.Result.Results.ElementAt(0).Version);
        }

        [Test]
        public async Task ShouldGetReleasesNotesQueryFilteredAsync()
        {
            // Arrange
            var query = new GetReleasesNotesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Take = 1,
                    Skip = 0,
                    Sort = new Sort[]
                    {
                        new Sort() { Dir = SortDir.asc, Field = nameof(ReleaseNotesDto.Version) }
                    },
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Operator = FilterOperator.eq,
                                        Value = "0.0.0",
                                        Field = nameof(ReleaseNotesDto.Version)
                                    }
                                }
                            }
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Message ?? result.Exception?.ToString());
            Assert.AreEqual(1, result.Result.Count);
            Assert.AreEqual("0.0.0", result.Result.Results.ElementAt(0).Version);
        }

        #endregion
    }
}
