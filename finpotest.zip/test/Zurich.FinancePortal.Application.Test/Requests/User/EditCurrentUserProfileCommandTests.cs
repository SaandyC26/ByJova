﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class EditCurrentUserProfileCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditCurrentUserProfileAsync()
        {
            // Arrange
            var (command, user) = await ProtectedShouldEditCurrentUserProfileAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().Include(u => u.GridPreferences).SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.Equals(user.AdAccount.SAMAccountName)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.AreEqual(command.GridPreferences.Revenues, userDb.GridPreferences.Revenues);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(EditCurrentUserProfileCommand Command, User User)> ProtectedShouldEditCurrentUserProfileAsync()
        {
            var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
            SetCurrentUser(user);
            var command = new EditCurrentUserProfileCommand()
            {
                GridPreferences = new UserGridPreferencesDto()
                {
                    Revenues = Guid.NewGuid().ToString()
                }
            };

            return (command, user);
        }

        #endregion
    }
}
