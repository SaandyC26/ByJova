﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public class DeleteUserCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteUserAsync()
        {
            // Arrange
            var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteUserCommand()
            {
                Id = user.Id
            };

            var retryFunc = new Func<Task>(async () =>
            {
                user = (await AddUserAsync().ConfigureAwait(false)).Entity;
                command.Id = user.Id;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var userDb = await GetIQuerable<User>().SingleOrDefaultAsync(u => u.Id.Equals(command.Id)).ConfigureAwait(false);
            Assert.IsNotNull(userDb);
            Assert.IsTrue(userDb.IsDeleted);
        }

        #endregion
    }
}
