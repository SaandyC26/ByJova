﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public sealed class GetEnumValuesQueryTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    [TestCaseSource(nameof(GetEnumsTypes))]
    public async Task ShouldGetEnumValuesAsync(string type)
    {
        // Arrange
        var query = new GetEnumValuesQuery() { Type = type };
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString());
        Assert.AreNotEqual(0, result.Result.Count);
    }

    #endregion
}
