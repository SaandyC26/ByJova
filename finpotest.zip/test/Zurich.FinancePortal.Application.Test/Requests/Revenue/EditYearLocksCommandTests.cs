﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class EditYearLocksCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditYearLocksCommandUnauthorizedAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()));
            SetCurrentUser(cu);
            var command = new EditYearLocksCommand();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.Success);
            Assert.AreEqual(RequestResult.ERROR_UNAUTHORIZED, result.ErrorType);
        }

        [Test]
        public async Task ShouldEditYearLocksCommandLockAsync()
        {
            // Arrange
            var (command, revenueEntity, r) = await ProtectedShouldEditYearLocksCommandAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            var yearLocks = await GetIQuerable<YearLocks>().SingleAsync(ml => ml.Year.Equals(revenueEntity.Year) && ml.ChargingModelType.Equals(revenueEntity.ChargingModel.Type)).ConfigureAwait(false);
            Revenue.GetMonths().ForEach(m => { if (r <= Revenue.GetMonthOrder(m)) Assert.IsTrue(yearLocks.GetLock(m)); });
        }

        [Test]
        public async Task ShouldEditYearLocksCommandUnlockAsync()
        {
            // Arrange
            var (revenueEntity, _) = await AddRevenueAsync().ConfigureAwait(false);
            var r = Random.Next(1, Revenue.GetMonths(excludeNone: false).Count());
            var command = new EditYearLocksCommand()
            {
                YearLocks = new YearLocksDto[]
                {
                    new YearLocksDto()
                    {
                        Year = revenueEntity.Year,
                        ChargingModelType = new ChargingModelTypeDto() { Id = revenueEntity.ChargingModel.Type.Id, Type = revenueEntity.ChargingModel.Type.Type }
                    }
                }
            };

            var months = new List<Month>();
            foreach (var m in Revenue.GetMonths())
            {
                if (r <= Revenue.GetMonthOrder(m))
                {
                    months.Add(m);
                    command.YearLocks[0].GetType().GetProperty(m.ToString()).SetValue(command.YearLocks[0], false);
                }
            }

            await AddYearLocksAsync(new YearLocks(revenueEntity.Year, revenueEntity.ChargingModel.Type, months: months.ToDictionary(x => x, x => true)));
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            var yearLocks = await GetIQuerable<YearLocks>().SingleAsync(ml => ml.Year.Equals(revenueEntity.Year) && ml.ChargingModelType.Equals(revenueEntity.ChargingModel.Type)).ConfigureAwait(false);
            Revenue.GetMonths().ForEach(m => { if (r <= Revenue.GetMonthOrder(m)) Assert.IsFalse(yearLocks.GetLock(m)); });
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(EditYearLocksCommand Command, Revenue Revenue, int Random)> ProtectedShouldEditYearLocksCommandAsync()
        {
            var (revenueEntity, _) = await AddRevenueAsync().ConfigureAwait(false);
            var r = Random.Next(1, Revenue.GetMonths(excludeNone: false).Count());
            var command = new EditYearLocksCommand()
            {
                YearLocks = new YearLocksDto[]
                {
                    new YearLocksDto()
                    {
                        Year = revenueEntity.Year,
                        ChargingModelType = new ChargingModelTypeDto() { Id = revenueEntity.ChargingModel.Type.Id, Type = revenueEntity.ChargingModel.Type.Type }
                    }
                }
            };

            Revenue.GetMonths().ForEach(m =>
            {
                if (r <= Revenue.GetMonthOrder(m))
                {
                    command.YearLocks[0].GetType().GetProperty(m.ToString()).SetValue(command.YearLocks[0], true);
                }
            });

            return (command, revenueEntity, r);
        }

        #endregion
    }
}
