﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetBarcelonaInvoicesQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetBarcelonaInvoicesAsync(Month month)
        {
            // Arrange
            var (query, revenueA, revenueB, revenueC) = await ProtectedShouldGetBarcelonaInvoicesAsync(month).ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            var aHasValue = revenueA.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            var bHasValue = revenueB.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            var cHasValue = revenueC.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            if (aHasValue || bHasValue || cHasValue) Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Results);
            Assert.AreEqual(result.Result.Count, result.Result.Results.Count());
            if (cHasValue)
            {
                var singleExpected = revenueC.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount;
                var singleActual = result.Result.Results.SingleOrDefault(r =>
                    StringExtensions.EqualsICIC(r.ChargingModelCode, revenueC.ChargingModel?.Code) &&
                    StringExtensions.EqualsICIC(r.BusinessUnitCode, revenueC.BusinessUnit?.Code) &&
                    StringExtensions.EqualsICIC(r.ProjectName, revenueC.Project?.Name) &&
                    StringExtensions.EqualsICIC(r.InternalCostCenterPerCostCode, revenueC.InternalCostCenterPerCost?.Code) &&
                    StringExtensions.EqualsICIC(r.CustomerCostCenterCode, revenueC.CustomerCostCenter?.Code))?.TotalEur;

                Console.WriteLine($"Single {month} Actual {singleActual} and Expected {singleExpected}");
                Assert.AreEqual(singleExpected, singleActual);
            }

            if (aHasValue || bHasValue)
            {
                var groupedExpectedArray = new decimal?[] { revenueA.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount, revenueB.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount }.Where(x => x != null);
                var groupedExpected = groupedExpectedArray.Any() ? groupedExpectedArray.Sum() : null;
                var groupedActual = result.Result.Results.SingleOrDefault(r =>
                    StringExtensions.EqualsICIC(r.ChargingModelCode, revenueA.ChargingModel?.Code) &&
                    StringExtensions.EqualsICIC(r.BusinessUnitCode, revenueA.BusinessUnit?.Code) &&
                    StringExtensions.EqualsICIC(r.ProjectName, revenueA.Project?.Name) &&
                    StringExtensions.EqualsICIC(r.InternalCostCenterPerCostCode, revenueA.InternalCostCenterPerCost?.Code) &&
                    StringExtensions.EqualsICIC(r.CustomerCostCenterCode, revenueA.CustomerCostCenter?.Code))?.TotalEur;

                Console.WriteLine($"Grouped {month} Actual {groupedActual} and Expected {groupedExpected}");
                Assert.AreEqual(groupedExpected, groupedActual);
            }
        }

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetBarcelonaInvoicesFilteredAndOrderedAsync(Month month)
        {
            // Arrange
            var year = DateTime.Now.Year;
            var chargingModel = await GetIQuerable<ChargingModel>(asNoTracking: false).SingleOrDefaultAsync(cm => cm.Code.Equals(ChargingModel.BicChargingModelCode)).ConfigureAwait(false);
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc)).UpdateChargingModel(chargingModel);
            await AddRevenueAsync(revenue: revenueA.UpdateBusinessUnitAndCustomerCostCenter(null, revenueA.CustomerCostCenter)).ConfigureAwait(false);
            var query = new GetBarcelonaInvoicesQuery()
            {
                Year = year,
                Month = month,
                DataSourceRequest = new DataSourceRequest()
                {
                    Skip = 0,
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Field = nameof(BarcelonaInvoiceDto.ChargingModelCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.ChargingModel?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(BarcelonaInvoiceDto.BusinessUnitCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.BusinessUnit?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(BarcelonaInvoiceDto.ProjectName),
                                Operator = FilterOperator.eq,
                                Value = revenueA.Project?.Name
                            },
                            new Filter()
                            {
                                Field = nameof(BarcelonaInvoiceDto.CustomerCostCenterCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.CustomerCostCenter?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(BarcelonaInvoiceDto.Description),
                                Operator = FilterOperator.contains,
                                Value = revenueA.ServiceDescription
                            }
                        }
                    },
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.ChargingModelCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.BusinessUnitCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.ProjectName)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.CustomerCostCenterCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.ShortMonth)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.TotalEur)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(BarcelonaInvoiceDto.Description)
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            var aHasValue = revenueA.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            if (aHasValue) Assert.AreNotEqual(0, result.Result.Results.Count());
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetBarcelonaInvoicesQuery Query, Revenue A, Revenue B, Revenue C)> ProtectedShouldGetBarcelonaInvoicesAsync(Month month)
        {
            var year = DateTime.Now.Year;
            var chargingModel = await GetIQuerable<ChargingModel>(asNoTracking: false).SingleOrDefaultAsync(cm => cm.Code.Equals(ChargingModel.BicChargingModelCode)).ConfigureAwait(false);
            var revenueC = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc)).UpdateChargingModel(chargingModel);
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc)).UpdateChargingModel(chargingModel);
            var revenueB = (await GetRevenueMock().ConfigureAwait(false))
                .UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc))
                .UpdateCustomer((await AddCustomerAsync().ConfigureAwait(false)).Entity)
                .UpdateChargingModel(revenueA.ChargingModel)
                .UpdateBusinessUnitAndCustomerCostCenter(revenueA.BusinessUnit, revenueA.CustomerCostCenter)
                .UpdateLineOfBusiness(revenueA.LineOfBusiness)
                .UpdateInternalCostCenterPerCost(revenueA.InternalCostCenterPerCost)
                .UpdateServiceDescription($"{revenueA.ServiceDescription}{Guid.NewGuid()}")
                .UpdateProject(revenueA.Project);

            await AddRevenueAsync(revenueA).ConfigureAwait(false);
            await AddRevenueAsync(revenueB).ConfigureAwait(false);
            await AddRevenueAsync(revenueC).ConfigureAwait(false);
            var query = new GetBarcelonaInvoicesQuery()
            {
                Year = year,
                Month = month
            };

            return (query, revenueA, revenueB, revenueC);
        }

        #endregion
    }
}
