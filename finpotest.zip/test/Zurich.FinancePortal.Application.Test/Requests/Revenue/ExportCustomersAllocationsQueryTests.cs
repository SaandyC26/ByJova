﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class ExportCustomersAllocationsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldExportCustomersAllocationsQueryAsync()
        {
            // Arrange
            var (query, revenue) = await ProtectedShouldExportCustomersAllocationsQueryAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds * 10).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? result.Message);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(ExportCustomersAllocationsQuery Query, Revenue Revenue)> ProtectedShouldExportCustomersAllocationsQueryAsync()
        {
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new ExportCustomersAllocationsQuery()
            {
                Year = revenue.Year,
                Month = Month.January
            };

            return (query, revenue);
        }

        #endregion
    }
}
