﻿namespace Zurich.FinancePortal.Application.Test;

using NUnit.Framework;
using System.Threading.Tasks;

public sealed class ExportRevenuesTemplateQueryTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldExportRevenuesTemplateQueryAsync()
    {
        // Arrange
        var query = await ProtectedShouldExportRevenuesTemplateQueryAsync().ConfigureAwait(false);
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds * 10).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString());
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<ExportRevenuesTemplateQuery> ProtectedShouldExportRevenuesTemplateQueryAsync()
    {
        await AddRevenueAsync().ConfigureAwait(false);
        var query = new ExportRevenuesTemplateQuery();
        return query;
    }

    #endregion
}
