﻿namespace Zurich.FinancePortal.Application.Test;

using Microsoft.AspNetCore.Http.Internal;
using NUnit.Framework;
using System.IO;
using System.Threading.Tasks;

public sealed class ImportRevenuesTemplateCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldImportRevenuesTemplateCommandAsync()
    {
        // Arrange
        var command = await ProtectedShouldImportRevenuesTemplateCommandAsync().ConfigureAwait(false);
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds * 10).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result?.Message ?? result.Exception?.ToString());
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<ImportRevenuesTemplateCommand> ProtectedShouldImportRevenuesTemplateCommandAsync()
    {
        await AddRevenueAsync().ConfigureAwait(false);
        await AddRevenueAsync().ConfigureAwait(false);
        var query = new ExportRevenuesTemplateQuery();
        var queryResult = await Mediatr.Send(query).ConfigureAwait(false);
        Assert.IsTrue(queryResult.Success, queryResult?.Message ?? queryResult?.Exception?.ToString());
        var memoryStream = new MemoryStream(queryResult.Result.Content);
        var command = new ImportRevenuesTemplateCommand()
        {
            File = new FormFile(memoryStream, 0, memoryStream.Length, null, queryResult.Result.Name)
        };

        return command;
    }

    #endregion
}
