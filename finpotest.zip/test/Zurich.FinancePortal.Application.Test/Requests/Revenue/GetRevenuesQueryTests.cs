﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using NUnit.Framework;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetRevenuesQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRevenuesAsync()
        {
            // Arrange
            var (query, revenue) = await ProtectedShouldGetRevenuesAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Revenues);
            Assert.AreEqual(result.Result.Count, result.Result.Revenues.Length);
            AssertRevenueDto(result.Result.Revenues.Single(r => r.Id.Equals(revenue.Id)), revenue);
        }

        [Test]
        public async Task ShouldGetRevenuesFilteredAsync()
        {
            // Arrange
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new GetRevenuesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Operator = FilterOperator.eq,
                                        Value = revenue.Project.Name,
                                        Field = nameof(RevenueDto.ProjectName)
                                    },
                                    new Filter()
                                    {
                                        Operator = FilterOperator.eq,
                                        Value = revenue.Project.Name,
                                        Field = nameof(RevenueDto.ProjectName)
                                    }
                                }
                            },
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Operator = FilterOperator.contains,
                                        Value = revenue.ServiceDescription,
                                        Field = nameof(Revenue.ServiceDescription)
                                    },
                                    new Filter()
                                    {
                                        Operator = FilterOperator.contains,
                                        Value = revenue.ServiceDescription,
                                        Field = nameof(Revenue.ServiceDescription)
                                    }
                                }
                            },
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Operator = FilterOperator.gt,
                                        Value = -1,
                                        Field = nameof(Revenue.January)
                                    },
                                    new Filter()
                                    {
                                        Operator = FilterOperator.gt,
                                        Value = -1,
                                        Field = $"{nameof(Revenue.January)}.{nameof(MonthRevenue.Amount)}"
                                    }
                                }
                            }
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Revenues);
            Assert.AreEqual(result.Result.Count, result.Result.Revenues.Length);
            AssertRevenueDto(result.Result.Revenues.Single(r => r.Id.Equals(revenue.Id)), revenue);
        }

        [Test]
        public async Task ShouldGetRevenuesFilteredByDateAsync()
        {
            // Arrange
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new GetRevenuesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Operator = FilterOperator.gte,
                                        Value = revenue.PlannedStartDate.ToString(NewtonsoftDateFormatConverter.Format),
                                        Field = nameof(RevenueDto.PlannedStartDate)
                                    },
                                    new Filter()
                                    {
                                        Operator = FilterOperator.lte,
                                        Value = revenue.PlannedEndDate.ToString(NewtonsoftDateFormatConverter.Format),
                                        Field = nameof(RevenueDto.PlannedEndDate)
                                    }
                                }
                            }
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Revenues);
            Assert.AreEqual(result.Result.Count, result.Result.Revenues.Length);
            AssertRevenueDto(result.Result.Revenues.Single(r => r.Id.Equals(revenue.Id)), revenue);
        }

        [Test]
        public async Task ShouldGetRevenuesEmptyFilteredAsync()
        {
            // Arrange
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new GetRevenuesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = System.Array.Empty<Filter>()
                    },
                    Sort = System.Array.Empty<Sort>()
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Revenues);
            Assert.AreEqual(result.Result.Count, result.Result.Revenues.Length);
            AssertRevenueDto(result.Result.Revenues.Single(r => r.Id.Equals(revenue.Id)), revenue);
        }

        [Test]
        public async Task ShouldGetRevenuesOrderedAsync()
        {
            // Arrange
            var random = Random.Next(5, 10);
            const int d = 4;
            var revenues = new List<Revenue>();
            for (var i = 0; i < random; i++) revenues.Add((await AddRevenueAsync().ConfigureAwait(false)).Entity);
            var query = new GetRevenuesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Skip = random / d,
                    Take = random / d,
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RevenueDto.ProjectName)
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsNotNull(result.Result.Revenues);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetRevenuesQuery Query, Revenue Revenue)> ProtectedShouldGetRevenuesAsync()
        {
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new GetRevenuesQuery();
            return (query, revenue);
        }

        #endregion
    }
}
