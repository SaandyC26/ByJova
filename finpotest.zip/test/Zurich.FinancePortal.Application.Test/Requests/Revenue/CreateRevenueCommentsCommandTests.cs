﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class CreateRevenueCommentsCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateRevenueCommentsAsync()
        {
            // Arrange
            var (command, revenue) = await ProtectedShouldCreateRevenueCommentsAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var revenueDb = await GetIQuerable<Revenue>().SingleAsync(r => r.Id.Equals(revenue.Id)).ConfigureAwait(false);
            command.Comments.ForEach(c => Assert.IsTrue(revenueDb.Comments.Any(rc => rc.Text.EqualsICIC(c))));
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(CreateRevenueCommentsCommand Command, Revenue Revenue)> ProtectedShouldCreateRevenueCommentsAsync()
        {
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var command = new CreateRevenueCommentsCommand()
            {
                Id = revenue.Id,
                Comments = new string[] { Guid.NewGuid().ToString(), Guid.NewGuid().ToString() }
            };

            return (command, revenue);
        }

        #endregion
    }
}
