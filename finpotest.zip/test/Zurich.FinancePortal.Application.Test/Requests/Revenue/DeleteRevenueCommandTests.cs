﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class DeleteRevenueCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteRevenueAsync()
        {
            // Arrange
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteRevenueCommand()
            {
                Id = revenue.Id
            };

            var retryFunc = new Func<Task>(async () =>
            {
                revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
                command.Id = revenue.Id;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var revenueDb = await GetIQuerable<Revenue>().Include(r => r.Comments).SingleOrDefaultAsync(r => r.Id.Equals(revenue.Id)).ConfigureAwait(false);
            Assert.IsNull(revenueDb);
        }

        #endregion
    }
}
