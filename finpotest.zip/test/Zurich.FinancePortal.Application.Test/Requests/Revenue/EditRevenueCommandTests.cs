﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class EditRevenueCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]

        public async Task ShouldEditRevenueAsync()
        {
            // Arrange
            var (revenueEntityA, revenueDtoA) = await AddRevenueAsync().ConfigureAwait(false);
            var revenueEntityB = (await GetRevenueMock().ConfigureAwait(false)).RefreshFyf();
            revenueEntityB.GetType().GetProperty(nameof(Revenue.Id)).SetValue(revenueEntityB, revenueEntityA.Id);
            revenueEntityB.GetType().GetProperty(nameof(Revenue.Comments)).SetValue(revenueEntityB, revenueEntityA.Comments);
            var revenueDtoB = Mapper.Map<Revenue, RevenueDto>(revenueEntityB);
            var command = new EditRevenueCommand()
            {
                Revenue = revenueDtoB
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            var revenueDb = await GetIQuerable<Revenue>().Include(r => r.Product).Include(r => r.LineOfBusiness).Include(r => r.Customer).ThenInclude(x => x.Function).Include(r => r.Project).Include(r => r.TypeOfService).Include(r => r.OwnerProjectManager).Include(r => r.BusinessUnit).Include(r => r.CustomerCostCenter).Include(r => r.ChargingModel).Include(r => r.InternalCostCenterPerCost).Include(r => r.Currency).Include(r => r.ValueAddedTax).Include(r => r.Comments).SingleOrDefaultAsync(r => r.Id.Equals(revenueDtoA.Id)).ConfigureAwait(false);
            AssertRevenueDto(revenueDtoB, revenueDb);
        }

        [Test]
        public async Task ShouldFailEditRevenueLockedMonthAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).AddRole(new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue, Constants.Permission_BypassOwnedRevenues }));
            SetCurrentUser(cu);
            var (revenueEntity, revenueDto) = await AddRevenueAsync().ConfigureAwait(false);
            await AddYearLocksAsync(new YearLocks(revenueEntity.Year, revenueEntity.ChargingModel.Type, Revenue.GetMonths().ToDictionary(x => x, x => true)));
            foreach (var m in Revenue.GetMonths())
            {
                var monthRevenue = revenueDto.GetType().GetProperty(m.ToString()).GetValue(revenueDto);
                monthRevenue.GetType().GetProperty(nameof(MonthRevenueDto.Amount)).SetValue(monthRevenue, (decimal?)Random.Next(1, 100));
            }

            var command = new EditRevenueCommand()
            {
                Revenue = revenueDto
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.Success);
            Assert.AreEqual(RequestResult.ERROR_BADREQUEST, result.ErrorType);
            foreach (var m in Revenue.GetMonths())
            {
                Assert.IsTrue(result.Message.ContainsICIC($"Month {m} cannot be modified due to the Month is locked."), $"{m}{Environment.NewLine}{result.Message}");
            }
        }

        [Test]
        public async Task ShouldEditRevenueWithCommentsAsync()
        {
            // Arrange
            var (_, revenueDto) = await AddRevenueAsync().ConfigureAwait(false);
            var (_, businessUnitDto) = await AddBusinessUnitAsync().ConfigureAwait(false);
            revenueDto.Comments = revenueDto.Comments.Concat(new RevenueCommentDto[] { new RevenueCommentDto() { Text = Guid.NewGuid().ToString() } });
            revenueDto.BusinessUnitCode = businessUnitDto.Code;
            var command = new EditRevenueCommand() { Revenue = revenueDto };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, $"{result.ErrorType} - {result.Message ?? result.Exception?.ToString()}");
            var revenueDb = await GetIQuerable<Revenue>().Include(r => r.Product).Include(r => r.LineOfBusiness).Include(r => r.Customer).ThenInclude(x => x.Function).Include(r => r.Project).Include(r => r.TypeOfService).Include(r => r.OwnerProjectManager).Include(r => r.BusinessUnit).Include(r => r.CustomerCostCenter).Include(r => r.ChargingModel).Include(r => r.InternalCostCenterPerCost).Include(r => r.Currency).Include(r => r.ValueAddedTax).Include(r => r.Comments).SingleOrDefaultAsync(r => r.Id.Equals(revenueDto.Id)).ConfigureAwait(false);
            AssertRevenueDto(revenueDto, revenueDb);
        }

        [Test]
        public async Task ShouldFailEditRevenueFromOtherOwnerPmAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue }) });
            SetCurrentUser(cu);
            var (_, revenueDto) = await AddRevenueAsync().ConfigureAwait(false);
            var (_, businessUnitDto) = await AddBusinessUnitAsync().ConfigureAwait(false);
            revenueDto.BusinessUnitCode = businessUnitDto.Code;
            var command = new EditRevenueCommand() { Revenue = revenueDto };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsFalse(result.Success);
            Assert.AreNotEqual(RequestResult.ERROR_UNAUTHORIZED, result.ErrorType);
        }

        [Test]
        public async Task ShouldAllowEditRevenueToOtherOwnerPmAsync()
        {
            // Arrange
            var permission = await GetIQuerable<Permission>(asNoTracking: false).SingleAsync(p => p.Name.Equals(Constants.Permission_ManageRevenue.Name)).ConfigureAwait(false);
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { permission }) });
            await AddUserAsync(user: cu).ConfigureAwait(false);
            SetCurrentUser(cu);
            var action = new Func<Task<EditRevenueCommand>>(async () =>
            {
                var revenue = await GetRevenueMock().ConfigureAwait(false);
                revenue.UpdateOwnerProjectManager(cu);
                var (_, revenueDto) = await AddRevenueAsync(revenue: revenue).ConfigureAwait(false);
                var (_, UserDto) = await AddUserAsync().ConfigureAwait(false);
                revenueDto.OwnerProjectManagerName = UserDto.Name;
                return new EditRevenueCommand() { Revenue = revenueDto };
            });

            var command = await action().ConfigureAwait(false);
            var retryFunc = new Func<Task>(async () =>
            {
                command = await action().ConfigureAwait(false);
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, $"{result.ErrorType} - {result.Message ?? result.Exception?.ToString()}");
            var revenueDb = await GetIQuerable<Revenue>().Include(r => r.OwnerProjectManager).SingleOrDefaultAsync(r => r.Id.Equals(command.Revenue.Id)).ConfigureAwait(false);
            Assert.AreEqual(command.Revenue.OwnerProjectManagerName, revenueDb.OwnerProjectManager.Name);
        }

        #endregion
    }
}
