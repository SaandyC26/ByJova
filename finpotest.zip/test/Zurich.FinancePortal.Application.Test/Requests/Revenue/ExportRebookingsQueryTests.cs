﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class ExportRebookingsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldExportRebookingsQueryAsync()
        {
            // Arrange
            var (query, revenue) = await ProtectedShouldExportRebookingsQueryAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds * 10).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? result.Message);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(ExportRebookingsQuery Query, Revenue Revenue)> ProtectedShouldExportRebookingsQueryAsync()
        {
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var query = new ExportRebookingsQuery()
            {
                Year = revenue.Year,
                Month = Month.January,
                InternalCostCenterCode = revenue.InternalCostCenterPerCost.Code
            };

            return (query, revenue);
        }

        #endregion
    }
}
