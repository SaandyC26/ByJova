﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class CreateRevenueCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateRevenueAsync()
        {
            // Arrange
            var revenueEntity = await GetRevenueMock().ConfigureAwait(false);
            var revenueDto = Mapper.Map<Revenue, RevenueDto>(revenueEntity);
            var command = new CreateRevenueCommand()
            {
                Revenue = revenueDto
            };

            var retryFunc = new Func<Task>(async () =>
            {
                var revenue = await GetIQuerable<Revenue>(asNoTracking: false).SingleOrDefaultAsync(r =>
                    r.Year.Equals(revenueEntity.Year)
                    && r.LineOfBusiness.Id.Equals(revenueEntity.LineOfBusiness.Id)
                    && r.Customer.Id.Equals(revenueEntity.Customer.Id)
                    && r.Project.Id.Equals(revenueEntity.Project.Id)
                    && r.TypeOfService.Id.Equals(revenueEntity.TypeOfService.Id)
                    && (r.ServiceDescription != null && r.ServiceDescription.Equals(revenueEntity.ServiceDescription))).ConfigureAwait(false);

                if (revenue != null) await RemoveAsync(revenue).ConfigureAwait(false);
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            var revenueDb = await GetIQuerable<Revenue>().Include(r => r.ValueAddedTax).SingleOrDefaultAsync(r => r.Id.Equals(result.Result.Revenue.Id)).ConfigureAwait(false);
            Assert.IsNotNull(revenueDb);
        }

        #endregion
    }
}
