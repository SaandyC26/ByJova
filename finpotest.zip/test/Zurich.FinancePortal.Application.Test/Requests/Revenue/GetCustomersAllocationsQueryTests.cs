﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetCustomersAllocationsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetCustomersAllocationsAsync(Month month)
        {
            // Arrange
            var (query, vat, percentageAB, revenueA, revenueB, revenueC, revenueD) = await ProtectedShouldGetCustomersAllocationsAsync(month).ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Results);
            Assert.AreEqual(result.Result.Count, result.Result.Results.Count());
            var singleExpectedChf = revenueD.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount;
            var singleExpectedChfVat = RevenueService.Round(RevenueService.AddVat(revenueD.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount, vat));
            var singleActual = result.Result.Results.SingleOrDefault(r =>
                StringExtensions.EqualsICIC(r.ChargingModelCode, revenueD.ChargingModel?.Code) &&
                StringExtensions.EqualsICIC(r.LineOfBusinessName, revenueD.LineOfBusiness?.Name) &&
                StringExtensions.EqualsICIC(r.InternalCostCenterPerCostCode, revenueD.InternalCostCenterPerCost?.Code) &&
                StringExtensions.EqualsICIC(r.BusinessUnitCode, revenueD.BusinessUnit?.Code) &&
                StringExtensions.EqualsICIC(r.ShortMonth, Revenue.GetShortMonthName(month)));

            Console.WriteLine($"Single {month} Actual {singleActual?.TotalChf} but Expected {singleExpectedChf}");
            Console.WriteLine($"Single {month} Actual {singleActual?.TotalChfVat} but Expected {singleExpectedChfVat}");
            Console.WriteLine($"Single {month} Percentage {singleActual?.Percentage} but Expected 1");
            Assert.AreEqual(singleExpectedChf, singleActual?.TotalChf);
            Assert.AreEqual(singleExpectedChfVat, singleActual?.TotalChfVat);
            Assert.AreEqual(decimal.One, singleActual?.Percentage);

            var groupedExpectedArray = new decimal?[] { revenueA.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount, revenueB.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount }.Where(x => x != null);
            var groupedExpectedChf = groupedExpectedArray.Any() ? groupedExpectedArray.Sum() : null;
            var groupedExpectedChfVat = groupedExpectedArray.Any() ? RevenueService.Round(RevenueService.AddVat(groupedExpectedArray.Sum(), vat)) : null;
            var groupedActual = result.Result.Results.SingleOrDefault(r =>
                     StringExtensions.EqualsICIC(r.ChargingModelCode, revenueA.ChargingModel?.Code) &&
                     StringExtensions.EqualsICIC(r.InternalCostCenterPerCostCode, revenueA.InternalCostCenterPerCost?.Code) &&
                     StringExtensions.EqualsICIC(r.LineOfBusinessName, revenueA.LineOfBusiness?.Name) &&
                     StringExtensions.EqualsICIC(r.BusinessUnitCode, revenueA.BusinessUnit?.Code) &&
                     StringExtensions.EqualsICIC(r.ShortMonth, Revenue.GetShortMonthName(month)));

            Console.WriteLine($"Grouped {month} Actual {groupedActual?.TotalChf} but Expected {groupedExpectedChf}");
            Console.WriteLine($"Grouped {month} Actual {groupedActual?.TotalChfVat} but Expected {groupedExpectedChfVat}");
            Console.WriteLine($"Grouped {month} Percentage {groupedActual?.Percentage} but Expected {percentageAB}");
            Assert.AreEqual(groupedExpectedChf, groupedActual?.TotalChf);
            Assert.AreEqual(groupedExpectedChfVat, groupedActual?.TotalChfVat);
            Assert.LessOrEqual(groupedActual?.Percentage, percentageAB + 0.01M);
            Assert.GreaterOrEqual(groupedActual?.Percentage, percentageAB - 0.01M);
        }

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetCustomersAllocationsFilteredAndOrderedAsync(Month month)
        {
            // Arrange
            var year = DateTime.Now.Year;
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc));
            await AddRevenueAsync(revenue: revenueA.UpdateBusinessUnitAndCustomerCostCenter(null, revenueA.CustomerCostCenter)).ConfigureAwait(false);
            var revenueB = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc));
            await AddRevenueAsync(revenue: revenueB.UpdateBusinessUnitAndCustomerCostCenter(revenueB.BusinessUnit, null)).ConfigureAwait(false);
            var query = new GetCustomersAllocationsQuery()
            {
                Year = year,
                Month = month,
                DataSourceRequest = new DataSourceRequest()
                {
                    Skip = 0,
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Field = nameof(CustomerAllocationDto.ChargingModelCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.ChargingModel?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(CustomerAllocationDto.LineOfBusinessName),
                                Operator = FilterOperator.eq,
                                Value = revenueA.LineOfBusiness?.Name
                            },
                            new Filter()
                            {
                                Field = nameof(CustomerAllocationDto.InternalCostCenterPerCostCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.InternalCostCenterPerCost?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(CustomerAllocationDto.BusinessUnitCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.BusinessUnit?.Code
                            }
                        }
                    },
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.ChargingModelCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.LineOfBusinessName)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.InternalCostCenterPerCostCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.LineOfBusinessName)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.ShortMonth)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.TotalChf)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.TotalChfVat)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(CustomerAllocationDto.Percentage)
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetCustomersAllocationsQuery Query, ValueAddedTax Vat, decimal P, Revenue A, Revenue B, Revenue C, Revenue D)> ProtectedShouldGetCustomersAllocationsAsync(Month month)
        {
            var year = DateTime.Now.Year;
            const decimal amountA = 9.8M;
            const decimal percentageAB = 0.75M;
            const decimal amountB = 5.1M;
            const decimal amountC = 5.1M;
            var vat = (await GetIQuerable<ValueAddedTax>(asNoTracking: true).ToArrayAsync().ConfigureAwait(false)).Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry));
            var chargingModel = await GetIQuerable<ChargingModel>(asNoTracking: false).SingleOrDefaultAsync(cm => cm.Code.Equals(ChargingModel.CaChargingModelCode)).ConfigureAwait(false);
            var revenueD = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc)).UpdateChargingModel(chargingModel);
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc)).UpdateChargingModel(chargingModel);
            var revenueB = (await GetRevenueMock().ConfigureAwait(false))
                .UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc))
                .UpdateChargingModel(revenueA.ChargingModel)
                .UpdateInternalCostCenterPerCost(revenueA.InternalCostCenterPerCost)
                .UpdateLineOfBusiness(revenueA.LineOfBusiness)
                .UpdateBusinessUnitAndCustomerCostCenter(revenueA.BusinessUnit, revenueA.CustomerCostCenter);

            var revenueC = (await GetRevenueMock().ConfigureAwait(false))
                .UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc))
                .UpdateChargingModel(revenueA.ChargingModel)
                .UpdateInternalCostCenterPerCost(revenueA.InternalCostCenterPerCost);

            Revenue.GetMonths().ForEach(m =>
            {
                revenueA.GetType().GetProperty(m.ToString()).SetValue(revenueA, new MonthRevenue(amountA));
                revenueB.GetType().GetProperty(m.ToString()).SetValue(revenueB, new MonthRevenue(amountB));
                revenueC.GetType().GetProperty(m.ToString()).SetValue(revenueC, new MonthRevenue(amountC));
                revenueD.GetType().GetProperty(m.ToString()).SetValue(revenueD, new MonthRevenue(amountA + amountB + amountC));
            });

            await AddRevenueAsync(revenueA).ConfigureAwait(false);
            await AddRevenueAsync(revenueB).ConfigureAwait(false);
            await AddRevenueAsync(revenueC).ConfigureAwait(false);
            await AddRevenueAsync(revenueD).ConfigureAwait(false);
            var query = new GetCustomersAllocationsQuery()
            {
                Year = year,
                Month = month
            };

            return (query, vat, percentageAB, revenueA, revenueB, revenueC, revenueD);
        }

        #endregion
    }
}
