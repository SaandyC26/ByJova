﻿namespace Zurich.FinancePortal.Application.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRevenuesRestrictionsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRevenuesRestrictionsAsync()
        {
            // Arrange
            var query = new GetRevenuesRestrictionsQuery();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            Assert.IsNotNull(result.Result);
        }

        #endregion
    }
}
