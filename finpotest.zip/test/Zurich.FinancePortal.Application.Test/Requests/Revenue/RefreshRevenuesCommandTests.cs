﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class RefreshRevenuesCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldRefreshRevenuesAsync()
        {
            // Arrange
            var (command, entity, rate) = await ProtectedShouldRefreshRevenuesAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var entityDb = await GetIQuerable<Revenue>().SingleAsync(r => r.Id.Equals(entity.Id)).ConfigureAwait(false);
            Assert.AreNotEqual(entity.FYFCCHF, entityDb.FYFCCHF);
            Assert.AreEqual(entity.FYFCCHF * rate, entityDb.FYFCCHF);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(RefreshRevenuesCommand Command, Revenue Revenue, decimal Rate)> ProtectedShouldRefreshRevenuesAsync()
        {
            const decimal rate = 0.5m;
            var entity = await GetRevenueMock().ConfigureAwait(false);
            entity.UpdateMonthsRevenues(Revenue.GetMonths().ToDictionary(m => m, _ => new MonthRevenue(Random.Next(1, 10))));
            entity = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var chfC = await GetIQuerable<Currency>(asNoTracking: false).SingleAsync(c => c.Code.Equals(Currency.ChiefsCode)).ConfigureAwait(false);
            var cer = new CurrencyExchangeRate(entity.Year, rate, entity.Currency, chfC);
            await AddCurrencyExchangeRateAsync(currencyExchangeRate: cer).ConfigureAwait(false);
            var command = new RefreshRevenuesCommand()
            {
                Years = new int[] { entity.Year }
            };

            return (command, entity, rate);
        }

        #endregion
    }
}
