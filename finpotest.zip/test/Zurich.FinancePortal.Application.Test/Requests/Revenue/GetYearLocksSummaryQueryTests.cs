﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using NUnit.Framework;
    using System.Linq;
    using System.Threading.Tasks;

    public class GetYearLocksSummaryQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetYearLocksSummaryAsync()
        {
            // Arrange
            var (query, revenueEntity) = await ProtectedGetYearLocksSummaryAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsTrue(result.Result.Summaries.Any(rs => rs.Year.Equals(revenueEntity.Year)));
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetYearLocksSummaryQuery Command, Revenue Revenue)> ProtectedGetYearLocksSummaryAsync()
        {
            var (revenueEntity, _) = await AddRevenueAsync().ConfigureAwait(false);
            var query = new GetYearLocksSummaryQuery();
            return (query, revenueEntity);
        }

        #endregion
    }
}
