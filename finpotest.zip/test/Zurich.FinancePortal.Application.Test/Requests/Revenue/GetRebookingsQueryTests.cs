﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetRebookingsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetRebookingsAsync(Month month)
        {
            // Arrange
            var (query, vat, revenueA, revenueB) = await ProtectedShouldGetRebookingsAsync(month).ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            var aHasValue = revenueA.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            var bHasValue = revenueB.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsNotNull(result.Result.Results);
            Assert.AreEqual(result.Result.Count + ((aHasValue || bHasValue) ? 2 : 0), result.Result.Results.Count());
            if (aHasValue || bHasValue)
            {
                Assert.AreNotEqual(0, result.Result.Count);
                var groupedExpectedArray = new decimal?[] { revenueA.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount, revenueB.GetMonthsRevenues().Single(mr => mr.Month.Equals(month)).Value.Amount }.Where(x => x != null);
                var groupedExpectedChfVat = groupedExpectedArray.Any() ? RevenueService.Round(RevenueService.AddVat(groupedExpectedArray.Sum(), vat)) : null;
                var groupedActual = result.Result.Results.SingleOrDefault(r =>
                    StringExtensions.EqualsICIC(r.ChargingModelCode, revenueA.ChargingModel?.Code) &&
                    StringExtensions.EqualsICIC(r.CustomeName, revenueA.Customer?.Name) &&
                    StringExtensions.EqualsICIC(r.CustomerCostCenterCode, revenueA.CustomerCostCenter?.Code) &&
                    StringExtensions.EqualsICIC(r.ProjectName, revenueA.Project?.Name));

                Console.WriteLine($"Grouped {month} Actual {groupedActual?.DebitValueChf} but Expected {groupedExpectedChfVat}");
                Assert.AreEqual(groupedExpectedChfVat, groupedActual?.DebitValueChf);
            }
        }

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetRebookingsFilteredAndOrderedAsync(Month month)
        {
            // Arrange
            var year = DateTime.Now.Year;
            var chargingModel = (await GetIQuerable<ChargingModel>(asNoTracking: false).ToArrayAsync().ConfigureAwait(false)).Single(cm => cm.Code.EqualsICIC(ChargingModel.RbiChargingModelCode));
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc));
            await AddRevenueAsync(revenue: revenueA.UpdateChargingModel(chargingModel).UpdateBusinessUnitAndCustomerCostCenter(null, revenueA.CustomerCostCenter)).ConfigureAwait(false);
            var query = new GetRebookingsQuery()
            {
                Year = year,
                Month = month,
                InternalCostCenterCode = revenueA.InternalCostCenterPerCost.Code,
                DataSourceRequest = new DataSourceRequest()
                {
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Field = nameof(RebookingDto.ChargingModelCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.ChargingModel?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(RebookingDto.CustomerCostCenterCode),
                                Operator = FilterOperator.eq,
                                Value = revenueA.CustomerCostCenter?.Code
                            },
                            new Filter()
                            {
                                Field = nameof(RebookingDto.Description),
                                Operator = FilterOperator.contains,
                                Value = Revenue.GetShortMonthName(month)
                            }
                        }
                    },
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.ChargingModelCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.CustomerCostCenterCode)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.ShortMonth)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.DebitValueChf)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.DebitValueChf)
                        },
                        new Sort()
                        {
                            Dir = SortDir.asc,
                            Field = nameof(RebookingDto.Description)
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            var aHasValue = revenueA.GetMonthsRevenues().Single(x => x.Month.Equals(month)).Value.Amount.HasValue;
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            if (aHasValue) Assert.AreNotEqual(0, result.Result.Results.Count());
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetRebookingsQuery Query, ValueAddedTax Vat, Revenue A, Revenue B)> ProtectedShouldGetRebookingsAsync(Month month)
        {
            var year = DateTime.Now.Year;
            var vat = (await GetIQuerable<ValueAddedTax>(asNoTracking: true).ToArrayAsync().ConfigureAwait(false)).Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry));
            var chargingModel = (await GetIQuerable<ChargingModel>(asNoTracking: false).ToArrayAsync().ConfigureAwait(false)).Single(cm => cm.Code.EqualsICIC(ChargingModel.RbiChargingModelCode));
            var revenueA = (await GetRevenueMock().ConfigureAwait(false)).UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc))
                .UpdateChargingModel(chargingModel);

            var revenueB = (await GetRevenueMock().ConfigureAwait(false))
                .UpdateYearAndPlannedDates(year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc))
                .UpdateCustomer(revenueA.Customer)
                .UpdateChargingModel(chargingModel)
                .UpdateBusinessUnitAndCustomerCostCenter(revenueA.BusinessUnit, revenueA.CustomerCostCenter)
                .UpdateInternalCostCenterPerCost(revenueA.InternalCostCenterPerCost)
                .UpdateProject(revenueA.Project);

            await AddRevenueAsync(revenueA).ConfigureAwait(false);
            await AddRevenueAsync(revenueB).ConfigureAwait(false);
            var query = new GetRebookingsQuery()
            {
                Year = year,
                Month = month,
                InternalCostCenterCode = revenueA.InternalCostCenterPerCost.Code
            };

            return (query, vat, revenueA, revenueB);
        }

        #endregion
    }
}
