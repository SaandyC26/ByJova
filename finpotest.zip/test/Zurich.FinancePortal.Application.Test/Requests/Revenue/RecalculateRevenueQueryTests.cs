﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class RecalculateRevenueQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldRecalculateRevenueAsync()
        {
            // Arrange
            var (query, valueAddedTax, rate, januaryAmount, februaryAmount) = await ProtectedShouldRecalculateRevenueAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreEqual(result.Result.FYFCLC, RevenueService.Round(januaryAmount + februaryAmount));
            Assert.AreEqual(result.Result.FYFCCHF, RevenueService.Round((januaryAmount + februaryAmount) * rate));
            Assert.AreEqual(result.Result.FYFCCHFVAT, RevenueService.Round(RevenueService.AddVat((januaryAmount + februaryAmount) * rate, valueAddedTax)));
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(RecalculateRevenueQuery Query, ValueAddedTax Vat, decimal Rate, decimal A, decimal B)> ProtectedShouldRecalculateRevenueAsync()
        {
            var rate = Random.Next(1, 10);
            var januaryAmount = 1.1m;
            var februaryAmount = 2.2m;
            var year = Random.Next(int.MaxValue / 2, int.MaxValue);
            var valueAddedTax = await GetIQuerable<ValueAddedTax>().SingleAsync(vat => vat.Country.Equals(ValueAddedTax.SwitzerlandCountry)).ConfigureAwait(false);
            var chfCurrency = await GetIQuerable<Currency>().SingleOrDefaultAsync(c => c.Code.Equals(Currency.ChiefsCode)).ConfigureAwait(false) ?? (await AddCurrencyAsync(new Currency(Currency.ChiefsName, Currency.ChiefsCode, Currency.ChiefsSymbol)).ConfigureAwait(false)).Entity;
            var currency = (await AddCurrencyAsync().ConfigureAwait(false)).Entity;
            await RemoveCurrencyExchangeRateAsync(year).ConfigureAwait(false);
            await AddCurrencyExchangeRateAsync(new CurrencyExchangeRate(year, rate, currency, chfCurrency)).ConfigureAwait(false);
            var query = new RecalculateRevenueQuery()
            {
                Revenue = new RevenueDto()
                {
                    Year = year,
                    CurrencyCode = currency.Code,
                    January = new MonthRevenueDto()
                    {
                        Amount = januaryAmount,
                        Locked = false
                    },
                    February = new MonthRevenueDto()
                    {
                        Amount = februaryAmount,
                        Locked = false
                    },
                }
            };

            return (query, valueAddedTax, rate, januaryAmount, februaryAmount);
        }

        #endregion
    }
}
