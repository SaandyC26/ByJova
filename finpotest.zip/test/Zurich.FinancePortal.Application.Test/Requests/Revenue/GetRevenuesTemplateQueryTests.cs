﻿namespace Zurich.FinancePortal.Application.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRevenuesTemplateQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRevenuesTemplateQueryAsync()
        {
            // Arrange
            var query = new GetRevenuesTemplateQuery();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.IsNotNull(result.Result);
        }

        #endregion
    }
}
