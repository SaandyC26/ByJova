﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

public class DeleteGroupCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldDeleteGroupAsync()
    {
        // Arrange
        var group = (await AddGroupAsync().ConfigureAwait(false)).Entity;
        var command = new DeleteGroupCommand()
        {
            Id = group.Id
        };

        var retryFunc = new Func<Task>(async () =>
        {
            group = (await AddGroupAsync().ConfigureAwait(false)).Entity;
            command.Id = group.Id;
        });
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var groupDb = await GetIQuerable<Group>().SingleOrDefaultAsync(x => x.Id.Equals(command.Id)).ConfigureAwait(false);
        Assert.IsNull(groupDb);
    }

    #endregion
}
