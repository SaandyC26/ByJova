﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using NUnit.Framework;
using System.Linq;
using System.Threading.Tasks;

public sealed class GetGroupsQueryTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldGetGroupsAsync()
    {
        // Arrange
        var (query, group) = await ProtectedShouldGetGroupsAsync().ConfigureAwait(false);
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString());
        Assert.AreNotEqual(0, result.Result.Count);
        Assert.IsNotNull(result.Result.Groups);
        Assert.AreEqual(result.Result.Count, result.Result.Groups.Count());
        AssertGroupDto(result.Result.Groups.Single(x => x.Id.Equals(group.Id)), group);
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<(GetGroupsQuery Query, Group Group)> ProtectedShouldGetGroupsAsync()
    {
        var group = (await AddGroupAsync().ConfigureAwait(false)).Entity;
        return (new GetGroupsQuery(), group);
    }

    #endregion
}
