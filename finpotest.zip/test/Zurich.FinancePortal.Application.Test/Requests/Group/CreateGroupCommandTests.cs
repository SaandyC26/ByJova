﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

public class CreateGroupCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldCreateGroupAsync()
    {
        // Arrange
        var command = new CreateGroupCommand()
        {
            Group = new GroupDto()
            {
                Name = Guid.NewGuid().ToString()
            }
        };

        var retryFunc = new Func<Task>(() =>
        {
            command.Group.Name = Guid.NewGuid().ToString();
            return Task.CompletedTask;
        });
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var groupDb = await GetIQuerable<Group>().SingleOrDefaultAsync(x => x.Name.Equals(command.Group.Name)).ConfigureAwait(false);
        Assert.IsNotNull(groupDb);
    }

    [Test]
    public async Task ShouldCreateGroupWithUserAsync()
    {
        // Arrange
        var userDto = (await AddUserAsync().ConfigureAwait(false)).Dto;
        var command = new CreateGroupCommand()
        {
            Group = new GroupDto()
            {
                Name = Guid.NewGuid().ToString(),
                Users = new UserDto[]
                {
                    userDto
                }
            }
        };

        var retryFunc = new Func<Task>(() =>
        {
            command.Group.Name = Guid.NewGuid().ToString();
            return Task.CompletedTask;
        });
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var groupDb = await GetIQuerable<Group>().Include(x => x.Users).SingleOrDefaultAsync(x => x.Name.Equals(command.Group.Name)).ConfigureAwait(false);
        Assert.IsNotNull(groupDb);
        Assert.IsNotNull(groupDb.Users);
        Assert.AreNotEqual(0, groupDb.Users);
    }

    #endregion
}
