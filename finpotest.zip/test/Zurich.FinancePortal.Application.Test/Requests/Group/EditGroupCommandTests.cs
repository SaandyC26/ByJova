﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

public sealed class EditGroupCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldEditGroupAsync()
    {
        // Arrange
        var group = new Group(Guid.NewGuid().ToString());
        group = (await AddGroupAsync(group: group).ConfigureAwait(false)).Entity;
        var command = new EditGroupCommand()
        {
            Group = new GroupDto()
            {
                Id = group.Id,
                Name = Guid.NewGuid().ToString()
            }
        };
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var groupDb = await GetIQuerable<Group>().SingleOrDefaultAsync(x => x.Name.Equals(command.Group.Name)).ConfigureAwait(false);
        Assert.IsNotNull(groupDb);
    }

    [Test]
    public async Task ShouldEditGroupWithRolesAsync()
    {
        // Arrange
        var (command, _) = await ProtectedShouldEditGroupWithRolesAsync().ConfigureAwait(false);
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var groupDb = await GetIQuerable<Group>().Include(x => x.Users).SingleOrDefaultAsync(x => x.Name.Equals(command.Group.Name)).ConfigureAwait(false);
        Assert.IsNotNull(groupDb);
        Assert.IsNotNull(groupDb.Users);
        Assert.AreNotEqual(0, groupDb.Users);
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<(EditGroupCommand Command, Group Group)> ProtectedShouldEditGroupWithRolesAsync()
    {
        var userDto = (await AddUserAsync().ConfigureAwait(false)).Dto;
        var group = new Group(Guid.NewGuid().ToString());
        group = (await AddGroupAsync(group: group).ConfigureAwait(false)).Entity;
        var command = new EditGroupCommand()
        {
            Group = new GroupDto()
            {
                Id = group.Id,
                Name = Guid.NewGuid().ToString(),
                Users = new UserDto[]
                {
                    userDto
                }
            }
        };

        return (command, group);
    }

    #endregion
}
