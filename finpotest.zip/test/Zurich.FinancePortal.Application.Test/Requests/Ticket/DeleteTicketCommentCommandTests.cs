﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class DeleteTicketCommentCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteTicketCommentAsync()
        {
            // Arrange
            var (command, ticket) = await ProtectedShouldDeleteTicketCommentAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var ticketDb = await GetIQuerable<Ticket>().Include(x => x.User).Include(x => x.Comments).FirstOrDefaultAsync(x => x.Id.Equals(ticket.Id)).ConfigureAwait(false);
            var ticketCommentDb = ticketDb.Comments.SingleOrDefault(x => x.Id.Equals(command.Id));
            Assert.IsNull(ticketCommentDb);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(DeleteTicketCommentCommand Command, Ticket Ticket)> ProtectedShouldDeleteTicketCommentAsync()
        {
            SetCurrentUser((await AddUserAsync(new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)).ConfigureAwait(false) })).ConfigureAwait(false)).Entity);
            var ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteTicketCommentCommand()
            {
                TicketId = ticket.Id,
                Id = ticket.Comments.First().Id
            };

            return (command, ticket);
        }

        #endregion
    }
}
