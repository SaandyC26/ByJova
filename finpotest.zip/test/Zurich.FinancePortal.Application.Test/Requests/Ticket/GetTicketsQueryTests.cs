﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System.Linq;
    using System.Threading.Tasks;

    public class GetTicketsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetTicketsAsync()
        {
            // Arrange
            var (query, ticket, ticketCompleted) = await ProtectedShouldGetTicketsAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Tickets);
            Assert.IsNull(result.Result.Tickets.SingleOrDefault(x => x.Id.Equals(ticketCompleted.Id)));
            AssertTicketDto(result.Result.Tickets.Single(x => x.Id.Equals(ticket.Id)), ticket);
        }

        [Test]
        public async Task ShouldGetTicketsOnlyMinesAsync()
        {
            // Arrange
            await AddTicketAsync().ConfigureAwait(false);
            var ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
            var user = await GetIQuerable<User>(asNoTracking: false).SingleAsync(x => x.Id.Equals(ticket.User.Id)).ConfigureAwait(false);
            user.AddRole(await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)));
            await SaveChangesAsync().ConfigureAwait(false);
            SetCurrentUser(user);
            var query = new GetTicketsQuery()
            {
                OnlyMines = true
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            Assert.AreEqual(1, result.Result.Count);
            Assert.IsNotNull(result.Result.Tickets);
            AssertTicketDto(result.Result.Tickets.Single(x => x.Id.Equals(ticket.Id)), ticket);
        }

        [Test]
        public async Task ShouldGetTicketsIncludeHiddenAsync()
        {
            // Arrange
            var ticketCompleted = await GetTicketMockAsync().ConfigureAwait(false);
            ticketCompleted.GetType().GetProperty(nameof(Ticket.Status)).SetValue(ticketCompleted, TicketStatus.Completed);
            await AddTicketAsync(ticket: ticketCompleted).ConfigureAwait(false);
            var query = new GetTicketsQuery()
            {
                IncludeHidden = true
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Tickets);
            AssertTicketDto(result.Result.Tickets.Single(x => x.Id.Equals(ticketCompleted.Id)), ticketCompleted);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetTicketsQuery Query, Ticket Ticket, Ticket ticketCompleted)> ProtectedShouldGetTicketsAsync()
        {
            var ticketCompleted = await GetTicketMockAsync().ConfigureAwait(false);
            ticketCompleted.GetType().GetProperty(nameof(Ticket.Status)).SetValue(ticketCompleted, TicketStatus.Completed);
            await AddTicketAsync(ticket: ticketCompleted).ConfigureAwait(false);
            return (new GetTicketsQuery(), (await AddTicketAsync().ConfigureAwait(false)).Entity, ticketCompleted);
        }

        #endregion
    }
}
