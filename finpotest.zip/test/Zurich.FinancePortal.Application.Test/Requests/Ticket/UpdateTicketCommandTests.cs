﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class UpdateTicketCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldUpdateTicketAsync()
        {
            // Arrange
            var (command, ticket) = await ProtectedShouldUpdateTicketAsyncAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var ticketDb = await GetIQuerable<Ticket>().Include(x => x.User).Include(x => x.Comments).FirstOrDefaultAsync(x => x.Id.Equals(ticket.Id)).ConfigureAwait(false);
            Assert.IsNotNull(ticketDb);
            Assert.AreEqual(command.Ticket.Summary, ticketDb.Summary);
            Assert.AreEqual(command.Ticket.Description, ticketDb.Description);
            Assert.AreEqual(command.Ticket.Type, ticketDb.Type);
            Assert.AreEqual(command.Ticket.Status, ticketDb.Status);
            Assert.AreEqual(command.Ticket.Type, ticketDb.Type);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(UpdateTicketCommand Command, Ticket Ticket)> ProtectedShouldUpdateTicketAsyncAsync()
        {
            SetCurrentUser((await AddUserAsync(new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)).ConfigureAwait(false) })).ConfigureAwait(false)).Entity);
            var ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
            var command = new UpdateTicketCommand()
            {
                Ticket = new TicketDto()
                {
                    Id = ticket.Id,
                    Summary = Guid.NewGuid().ToString(),
                    Description = Guid.NewGuid().ToString(),
                    Reference = Guid.NewGuid().ToString(),
                    Status = TicketStatus.Implementation,
                    Type = TicketType.Incident
                }
            };

            return (command, ticket);
        }

        #endregion
    }
}
