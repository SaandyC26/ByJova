﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class CreateTicketCommentCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateTicketCommentAsync()
        {
            // Arrange
            var (command, ticket) = await ProtectedShouldCreateTicketCommentAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var ticketDb = await GetIQuerable<Ticket>().Include(x => x.User).Include(x => x.Comments).FirstOrDefaultAsync(x => x.Id.Equals(ticket.Id)).ConfigureAwait(false);
            var ticketCommentDb = ticketDb.Comments.SingleOrDefault(x => x.Text.Equals(command.TicketComment.Text));
            Assert.IsNotNull(ticketCommentDb);
            Assert.AreEqual(command.TicketComment.Text, ticketCommentDb.Text);
            Assert.AreEqual((await CurrentUserService.GetUserAsync()).AdAccount.SAMAccountName, ticketCommentDb.SAMAccountName);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(CreateTicketCommentCommand Command, Ticket Ticket)> ProtectedShouldCreateTicketCommentAsync()
        {
            SetCurrentUser((await AddUserAsync(new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)).ConfigureAwait(false) })).ConfigureAwait(false)).Entity);
            var ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
            var command = new CreateTicketCommentCommand()
            {
                TicketId = ticket.Id,
                TicketComment = new TicketCommentDto()
                {
                    Text = Guid.NewGuid().ToString()
                }
            };

            return (command, ticket);
        }

        #endregion
    }
}
