﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class DeleteTicketCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteTicketAsync()
        {
            // Arrange
            var (command, ticket) = await ProtectedShouldDeleteTicketAsync().ConfigureAwait(false);
            var retryFunc = new Func<Task>(async () =>
            {
                ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
                command.Id = ticket.Id;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var ticketDb = await GetIQuerable<Ticket>().Include(x => x.User).Include(x => x.Comments).FirstOrDefaultAsync(x => x.Id.Equals(ticket.Id)).ConfigureAwait(false);
            Assert.IsNull(ticketDb);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(DeleteTicketCommand Command, Ticket Ticket)> ProtectedShouldDeleteTicketAsync()
        {
            SetCurrentUser((await AddUserAsync(new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)).ConfigureAwait(false) })).ConfigureAwait(false)).Entity);
            var ticket = (await AddTicketAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteTicketCommand()
            {
                Id = ticket.Id
            };

            return (command, ticket);
        }

        #endregion
    }
}
