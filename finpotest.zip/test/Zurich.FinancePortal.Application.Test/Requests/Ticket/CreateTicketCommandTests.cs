﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class CreateTicketCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateTicketAsync()
        {
            // Arrange
            var command = await ProtectedShouldCreateTicketAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            var ticketDb = await GetIQuerable<Ticket>().Include(x => x.User).Include(x => x.Comments).FirstOrDefaultAsync(x => x.Summary.Equals(command.Ticket.Summary)).ConfigureAwait(false);
            Assert.IsNotNull(ticketDb);
            Assert.AreEqual(command.Ticket.Summary, ticketDb.Summary);
            Assert.AreEqual(command.Ticket.Description, ticketDb.Description);
            Assert.AreEqual(command.Ticket.Type, ticketDb.Type);
            Assert.AreEqual(TicketStatus.Created, ticketDb.Status);
            Assert.AreEqual((await CurrentUserService.GetUserAsync()).Id, ticketDb.User.Id);
            Assert.AreEqual(TicketNotifications.None, ticketDb.Notifications);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<CreateTicketCommand> ProtectedShouldCreateTicketAsync()
        {
            SetCurrentUser((await AddUserAsync(new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString()), roles: new Role[] { await GetIQuerable<Role>(asNoTracking: false).SingleAsync(x => x.Name.Equals(Role.SuperAdminName)).ConfigureAwait(false) })).ConfigureAwait(false)).Entity);
            return new CreateTicketCommand()
            {
                Ticket = new TicketDto()
                {
                    Summary = Guid.NewGuid().ToString(),
                    Description = Guid.NewGuid().ToString(),
                    Type = (TicketType)Random.Next(0, Enum.GetValues<TicketType>().Length - 1)
                }
            };
        }

        #endregion
    }
}
