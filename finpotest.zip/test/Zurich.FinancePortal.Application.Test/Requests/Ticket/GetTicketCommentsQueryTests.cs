﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using NUnit.Framework;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class GetTicketCommentsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetTicketCommentsAsync()
        {
            // Arrange
            var (query, ticketComments) = await ProtectedShouldGetTicketCommentsAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            AssertResult(result, true);
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.TicketComments);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetTicketCommentsQuery Query, IEnumerable<TicketComment> TicketComments)> ProtectedShouldGetTicketCommentsAsync()
        {
            var ticket = await AddTicketAsync().ConfigureAwait(false);
            return (new GetTicketCommentsQuery() { TicketId = ticket.Entity.Id }, ticket.Entity.Comments);
        }

        #endregion
    }
}
