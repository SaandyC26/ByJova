﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Threading.Tasks;

    public sealed class EditMasterDataCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMasterDataTypes))]
        public async Task ShouldEditMasterDataAsync(Type type)
        {
            // Arrange
            var command = await ProtectedShouldEditMasterDataAsync(type).ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<EditMasterDataCommand> ProtectedShouldEditMasterDataAsync(Type type)
        {
            if (type.Equals(typeof(Currency))) Assert.Pass();
            if (type.Equals(typeof(ValueAddedTax))) Assert.Pass();
            if (type.Equals(typeof(Product))) Assert.Pass();

            var task = (Task)GetType().GetMethod($"Add{type.Name}Async", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, new object[] { null });
            await task.ConfigureAwait(false);
            var masterData = ((dynamic)task).Result.Item2;
            var properties = new List<string>(new string[] { nameof(MasterDataDto.Id) });
            switch (((object)masterData).GetType().Name)
            {
                case nameof(CustomerDto):
                    ((CustomerDto)masterData).Function = (await AddCustomerFunctionAsync().ConfigureAwait(false)).Dto;
                    properties.Add(nameof(CustomerDto.Function));
                    break;
                case nameof(CostCenterDto):
                    ((CostCenterDto)masterData).Types = new CostCenterType[] { Random.Next(0, 1).Equals(0) ? CostCenterType.Customer : CostCenterType.Internal };
                    properties.Add(nameof(CostCenterDto.Types));
                    break;
                case nameof(CurrencyDto):
                    ((CurrencyDto)masterData).Symbol = Guid.NewGuid().ToString()[..8];
                    properties.Add(nameof(CurrencyDto.Symbol));
                    break;
                case nameof(ProjectDto):
                    properties.Add(nameof(ProjectDto.Type));
                    properties.Add(nameof(ProjectDto.PlanningItAppsIds));
                    properties.Add(nameof(ProjectDto.PlanningItAppsNames));
                    ((ProjectDto)masterData).PlanningItApps = new PlanningItAppDto[] { new() { Prefix = PlanningItAppPrefix.APP, Id = Guid.NewGuid().ToString(), Name = Guid.NewGuid().ToString() }, new() { Prefix = PlanningItAppPrefix.COM, Id = Guid.NewGuid().ToString(), Name = Guid.NewGuid().ToString() } };
                    properties.Add(nameof(ProjectDto.PlanningItApps));
                    break;
                case nameof(CurrencyExchangeRateDto):
                    ((CurrencyExchangeRateDto)masterData).Year = ((CurrencyExchangeRateDto)masterData).Year = Random.Next(2000, DateTime.UtcNow.Year);
                    properties.Add(nameof(CurrencyExchangeRateDto.Year));
                    ((CurrencyExchangeRateDto)masterData).Month = Revenue.GetMonths().ElementAt(Random.Next(0, Revenue.GetMonths().Count())).ToString();
                    properties.Add(nameof(CurrencyExchangeRateDto.Month));
                    ((CurrencyExchangeRateDto)masterData).From = (await AddCurrencyAsync().ConfigureAwait(false)).Dto;
                    properties.Add(nameof(CurrencyExchangeRateDto.From));
                    ((CurrencyExchangeRateDto)masterData).To = (await AddCurrencyAsync().ConfigureAwait(false)).Dto;
                    properties.Add(nameof(CurrencyExchangeRateDto.To));
                    break;
            }

            foreach (var property in ((object)masterData).GetType().GetProperties().Where(p => !properties.Any(p2 => p2.EqualsICIC(p.Name))))
            {
                switch (property.PropertyType.Name.ToLowerInvariant())
                {
                    case "string":
                        property.SetValue(masterData, Guid.NewGuid().ToString());
                        break;
                    case "decimal":
                        property.SetValue(masterData, Random.Next(1, 10) + (decimal)(Random.Next(0, 99) / 100));
                        break;
                    case "int":
                        property.SetValue(masterData, Random.Next(1, 10));
                        break;
                    case "chargingmodeltypedto":
                        property.SetValue(masterData, (await AddChargingModelTypeAsync().ConfigureAwait(false)).Dto);
                        break;
                    default:
                        throw new NotImplementedException(property.PropertyType.Name);
                }
            }

            return new EditMasterDataCommand()
            {
                Type = type.Name,
                MasterData = masterData
            };
        }

        #endregion
    }
}
