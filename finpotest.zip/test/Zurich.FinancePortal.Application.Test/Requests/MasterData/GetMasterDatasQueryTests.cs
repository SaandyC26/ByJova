﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Threading.Tasks;

    public class GetMasterDatasQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMasterDataTypes))]
        public async Task ShouldGetMasterDatas(Type type)
        {
            // Arrange
            var (query, masterData) = await ProtectedShouldGetMasterDatas(type).ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            Assert.AreEqual(result.Result.Count, result.Result.MasterDatas.Count());
            var assertMethod = typeof(BaseApplicationTests).GetMethod($"{nameof(Assert)}{type.Name}Dto", BindingFlags.NonPublic | BindingFlags.Static);
            var parameters = new List<object>
            {
                result.Result.MasterDatas.Single(md => md.GetType().GetProperty(nameof(MasterDataDto.Id)).GetValue(md).Equals(((object)masterData).GetType().GetProperty(nameof(MasterData.Id)).GetValue(masterData))),
                masterData
            };

            assertMethod.Invoke(this, parameters.ToArray());
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetMasterDatasQuery Query, dynamic MasterData)> ProtectedShouldGetMasterDatas(Type type)
        {
            var task = (Task)GetType().GetMethod($"Add{type.Name}Async", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, new object[] { null });
            await task.ConfigureAwait(false);
            var masterData = ((dynamic)task).Result.Item1;
            var query = new GetMasterDatasQuery()
            {
                Type = type.Name
            };

            return (query, masterData);
        }

        #endregion
    }
}
