﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using NUnit.Framework;
using System;
using System.Reflection;
using System.Threading.Tasks;

public sealed class DeleteMasterDataCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    [TestCaseSource(nameof(GetMasterDataTypes))]
    public async Task ShouldDeleteMasterDataAsync(Type type)
    {
        // Arrange
        if (type.Equals(typeof(Currency))) Assert.Pass();
        if (type.Equals(typeof(ValueAddedTax))) Assert.Pass();
        if (type.Equals(typeof(Product))) Assert.Pass();

        await AddRevenueAsync().ConfigureAwait(false);
        var task = (Task)GetType().GetMethod($"Add{type.Name}Async", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, new object[] { null });
        await task.ConfigureAwait(false);
        var masterData = ((dynamic)task).Result.Item1;

        var command = new DeleteMasterDataCommand()
        {
            Type = type.Name,
            Id = masterData.Id
        };

        var retryFunc = new Func<Task>(async () =>
        {
            task = (Task)GetType().GetMethod($"Add{type.Name}Async", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, new object[] { null });
            await task.ConfigureAwait(false);
            masterData = ((dynamic)task).Result.Item1;
            command.Id = masterData.Id;
        });
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
    }

    #endregion
}
