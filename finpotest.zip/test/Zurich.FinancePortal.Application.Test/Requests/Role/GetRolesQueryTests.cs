﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetRolesQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRolesAsync()
        {
            // Arrange
            var role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
            var query = new GetRolesQuery();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Roles);
            Assert.AreEqual(result.Result.Count, result.Result.Roles.Count());
            AssertRoleDto(result.Result.Roles.Single(r => r.Id.Equals(role.Id)), role);
            Assert.IsFalse(result.Result.Roles.Any(r => r.Name.EqualsICIC(Role.SuperAdminName)));
        }

        [Test]
        public async Task ShouldGetRolesWithUsersAndPermissionsAsync()
        {
            // Arrange
            var (query, role) = await ProtectedShouldGetRolesWithUsersAndPermissionsAsync().ConfigureAwait(false);
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Roles);
            Assert.AreEqual(result.Result.Count, result.Result.Roles.Count());
            var roleResult = result.Result.Roles.Single(r => r.Id.Equals(role.Id));
            AssertRoleDto(roleResult, role);
            Assert.AreNotEqual(0, roleResult.Users?.Count() ?? 0);
            Assert.AreNotEqual(0, roleResult.Permissions?.Count() ?? 0);
        }

        [Test]
        public async Task ShouldGetRolesFilteredAndOrderedAsync()
        {
            // Arrange
            var role1 = (await AddRoleAsync().ConfigureAwait(false)).Entity;
            var role2 = (await AddRoleAsync().ConfigureAwait(false)).Entity;
            var query = new GetRolesQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Skip = 1,
                    Take = 1,
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Field = nameof(Role.Id),
                            Dir = SortDir.desc
                        }
                    },
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Field = nameof(Role.Name),
                                        Value = role1.Name,
                                        Operator = FilterOperator.eq
                                    },
                                    new Filter()
                                    {
                                        Field = nameof(Role.Name),
                                        Value = role2.Name,
                                        Operator = FilterOperator.eq
                                    }
                                }
                            },
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Field = nameof(Role.Id),
                                        Value = role1.Id,
                                        Operator = FilterOperator.eq
                                    },
                                    new Filter()
                                    {
                                        Field = nameof(Role.Id),
                                        Value = role2.Id,
                                        Operator = FilterOperator.eq
                                    }
                                }
                            }
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Roles);
            Assert.AreEqual(2, result.Result.Count);
            Assert.AreEqual(1, result.Result.Roles.Count());
            AssertRoleDto(result.Result.Roles.Single(u => u.Id.Equals(role1.Id)), role1);
        }

        #endregion
    }

    public abstract partial class BaseApplicationTests
    {
        #region --- PROTECTED METHODS ---

        protected async Task<(GetRolesQuery Query, Role Role)> ProtectedShouldGetRolesWithUsersAndPermissionsAsync()
        {
            var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
            var permission = (await AddPermissionAsync().ConfigureAwait(false)).Entity;
            var role = new Role(Guid.NewGuid().ToString(), description: Guid.NewGuid().ToString()).AddUser(user).AddPermission(permission);
            role = (await AddRoleAsync(role: role).ConfigureAwait(false)).Entity;
            var query = new GetRolesQuery()
            {
                Dtos = new string[] { nameof(User), nameof(Permission) }
            };

            return (query, role);
        }

        #endregion
    }
}
