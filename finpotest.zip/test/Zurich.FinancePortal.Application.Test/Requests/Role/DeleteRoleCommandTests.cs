﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public class DeleteRoleCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteRoleAsync()
        {
            // Arrange
            var role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteRoleCommand()
            {
                Id = role.Id
            };

            var retryFunc = new Func<Task>(async () =>
            {
                role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
                command.Id = role.Id;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var roleDb = await GetIQuerable<Role>().SingleOrDefaultAsync(u => u.Id.Equals(command.Id)).ConfigureAwait(false);
            Assert.IsNull(roleDb);
        }

        #endregion
    }
}
