﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using NUnit.Framework;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class GetPermissionsQueryTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetPermissions()
        {
            // Arrange
            var query = new GetPermissionsQuery();
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Permissions);
            Assert.AreEqual(result.Result.Count, result.Result.Permissions.Count());
        }

        [Test]
        public async Task ShouldGetPermissionsFilteredAndOrdered()
        {
            // Arrange
            var query = new GetPermissionsQuery()
            {
                DataSourceRequest = new DataSourceRequest()
                {
                    Skip = 1,
                    Take = 1,
                    Sort = new Sort[]
                    {
                        new Sort()
                        {
                            Field = nameof(Permission.Id),
                            Dir = SortDir.desc
                        }
                    },
                    Filter = new Filter()
                    {
                        Logic = FilterLogic.and,
                        Filters = new Filter[]
                        {
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Field = nameof(Permission.Name),
                                        Value = Constants.Permission_ManageRevenue.Name,
                                        Operator = FilterOperator.eq
                                    },
                                    new Filter()
                                    {
                                        Field = nameof(Permission.Name),
                                        Value = Constants.Permission_ManageUser.Name,
                                        Operator = FilterOperator.eq
                                    }
                                }
                            },
                            new Filter()
                            {
                                Logic = FilterLogic.or,
                                Filters = new Filter[]
                                {
                                    new Filter()
                                    {
                                        Field = nameof(Permission.Description),
                                        Value = Constants.Permission_ManageRevenue.Description,
                                        Operator = FilterOperator.eq
                                    },
                                    new Filter()
                                    {
                                        Field = nameof(Permission.Description),
                                        Value = Constants.Permission_ManageUser.Description,
                                        Operator = FilterOperator.eq
                                    }
                                }
                            }
                        }
                    }
                }
            };
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(query).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString());
            Assert.AreNotEqual(0, result.Result.Count);
            Assert.IsNotNull(result.Result.Permissions);
            Assert.AreEqual(2, result.Result.Count);
            Assert.AreEqual(1, result.Result.Permissions.Count());
        }

        #endregion
    }

}
