﻿namespace Zurich.FinancePortal.Application.Test;

using Domain;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Linq;
using System.Threading.Tasks;

public class EditRoleCommandTests : BaseApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldEditRoleAsync()
    {
        // Arrange
        var role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
        var command = new EditRoleCommand()
        {
            Role = new RoleDto()
            {
                Id = role.Id,
                Name = Guid.NewGuid().ToString(),
                Description = Guid.NewGuid().ToString()
            }
        };
        // Act
        var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds).ConfigureAwait(false);
        // Assert
        Assert.IsNotNull(result);
        Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
        var roleDb = await GetIQuerable<Role>().SingleOrDefaultAsync(r => r.Name.Equals(command.Role.Name)).ConfigureAwait(false);
        Assert.IsNotNull(roleDb);
    }

    #endregion
}

public abstract partial class BaseApplicationTests
{
    #region --- PROTECTED METHODS ---

    protected async Task<EditRoleCommand> ProtectedShouldEditRoleWithUsersAndPermissionsAsync()
    {
        var role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
        var user = (await AddUserAsync().ConfigureAwait(false)).Dto;
        var permission = (await AddPermissionAsync().ConfigureAwait(false)).Dto;
        return new EditRoleCommand()
        {
            Role = new RoleDto()
            {
                Id = role.Id,
                Name = Guid.NewGuid().ToString(),
                Description = Guid.NewGuid().ToString(),
                Users = new UserDto[]
                {
                    user
                },
                Permissions = new PermissionDto[]
                {
                    permission
                }
            }
        };
    }

    #endregion
}
