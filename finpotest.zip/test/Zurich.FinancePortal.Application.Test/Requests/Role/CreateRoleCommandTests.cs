﻿namespace Zurich.FinancePortal.Application.Test
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using NUnit.Framework;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public class CreateRoleCommandTests : BaseApplicationTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateRoleAsync()
        {
            // Arrange
            var command = new CreateRoleCommand()
            {
                Role = new RoleDto()
                {
                    Name = Guid.NewGuid().ToString(),
                    Description = Guid.NewGuid().ToString()
                }
            };

            var retryFunc = new Func<Task>(() =>
            {
                command.Role.Name = Guid.NewGuid().ToString();
                return Task.CompletedTask;
            });
            // Act
            var result = await ActAndAssertRequestWithTimewatch(async () => await Mediatr.Send(command).ConfigureAwait(false), ApplicationExpectedTimeMilliseconds, retryFunc: retryFunc).ConfigureAwait(false);
            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success, result.Exception?.ToString() ?? $"{result.ErrorType} - {result.Message}");
            var roleDb = await GetIQuerable<Role>().SingleOrDefaultAsync(r => r.Name.Equals(command.Role.Name)).ConfigureAwait(false);
            Assert.IsNotNull(roleDb);
        }

        #endregion
    }
}
