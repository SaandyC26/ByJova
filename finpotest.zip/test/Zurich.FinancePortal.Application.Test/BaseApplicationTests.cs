﻿namespace Zurich.FinancePortal.Application.Test;

using DevOps.Application;
using DevOps.CrossCutting;
using Domain;
using Infra.Persistence.Database.Test;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

[Category(nameof(Application))]
public class ApplicationTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public void ShouldAllApplicationRequest()
    {
        // Arrange
        var assembly = Assembly.GetAssembly(typeof(BaseRequestResult));
        var requestTypes = assembly.GetTypes().Where(t => !t.IsAbstract && (t.BaseType?.BaseType?.IsGenericType ?? false) && t.BaseType.BaseType.GetGenericTypeDefinition().Equals(typeof(Request<>)));
        Assert.AreNotEqual(0, requestTypes.Count());
        var testAssembly = Assembly.GetAssembly(GetType());
        var methods = testAssembly.GetTypes().SelectMany(t => t.GetMethods());
        var list = new List<string>();
        // Act
        foreach (var requestType in requestTypes)
        {
            if (!methods.Any(m => m.Name.ContainsICIC(requestType.Name.Replace("Command", string.Empty).Replace("Query", string.Empty))))
            {
                list.Add($"{nameof(IRequest)} {requestType.Name} does not contains an {nameof(Application)}.{nameof(Test)} method.");
            }
        }
        // Assert
        Assert.IsEmpty(list, string.Join(Environment.NewLine, list));
    }

    [Test]
    public void ShouldAllApplicationRequestHttp()
    {
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) Assert.Pass();
        // Arrange
        const string extension = ".http";
        var assembly = Assembly.GetAssembly(typeof(BaseRequest<>));
        var requestTypes = assembly.GetTypes().Where(t => !t.IsAbstract && (t.BaseType?.BaseType?.IsGenericType ?? false) && t.BaseType.BaseType.GetGenericTypeDefinition().Equals(typeof(Request<>)));
        Assert.AreNotEqual(0, requestTypes.Count());
        var slnFolder = new StringBuilder();
        var slnFile = $"{nameof(Zurich)}.{nameof(FinancePortal)}.sln";
        foreach (var x in Assembly.GetExecutingAssembly().Location.Split(Path.DirectorySeparatorChar, StringSplitOptions.RemoveEmptyEntries))
        {
            if (!slnFolder.Length.Equals(0)) slnFolder.Append(Path.DirectorySeparatorChar);
            slnFolder.Append(x);
            if (File.Exists(Path.Join(slnFolder.ToString(), slnFile))) break;
            if (slnFolder.ToString().EqualsICIC(Assembly.GetExecutingAssembly().Location)) Assert.Ignore($"{slnFile} not found.");
        }

        var https = Directory.GetFiles(Path.Combine(slnFolder.ToString(), "doc", "Api", "Requests"), $"*{extension}");
        var list = new List<string>();
        // Act
        requestTypes
            .Where(requestType => !https.Any(x => x.EndsWithICIC($"{requestType.Name}{extension}")))
            .ForEach(requestType => list.Add($"{nameof(IRequest)} {requestType.Name} does not contains an .http file."));

        https
            .Where(http => !http.EndsWithICIC($"Ping{extension}") && !requestTypes.Any(x => !http.EndsWithICIC($"{x.Name}{extension}")))
            .ForEach(requestType => list.Add($"{extension} file {requestType} not necessary."));
        // Assert
        Assert.IsEmpty(list, string.Join(Environment.NewLine, list));
    }

    #endregion
}

[Category(nameof(Application))]
public abstract partial class BaseApplicationTests : BaseDatabaseTests
{
    #region --- PROPERTIES ---

    protected private const long ApplicationExpectedTimeMilliseconds = 500;

    private const int RetryExpectedTimes = 3;

    protected private const string RevenuesTemplateName = "Revenues_Default.xlsx";

    #endregion

    #region --- REFERENCES ---

    protected IMediator Mediatr { get; private set; }

    protected ICurrentUserService<User> CurrentUserService { get; private set; }

    #endregion

    #region --- PUBLIC METHODS ---

    [SetUp]
    public override void SetUp()
    {
        base.SetUp();
        ServiceCollection.AddApplication(currentUserService: new CurrentUserServiceMock(), folderFileRepositoryConfiguration: GetFolderFileRepositoryConfiguration()).AddLogging();
        Mediatr = Services.GetRequiredService<IMediator>();
        CurrentUserService = Services.GetRequiredService<ICurrentUserService<User>>();
    }

    #endregion

    #region --- PROTECTED METHODS ---

    protected async Task<RequestResult<T>> ActAndAssertRequestWithTimewatchV2<T>(Func<Task<object>> func, long maximumExpectedTimeMilliseconds = ApplicationExpectedTimeMilliseconds)
    {
        var result = default(RequestResult<T>);
        for (var i = 0; i < RetryExpectedTimes; i++)
        {
            // Arrange
            var request = await func().ConfigureAwait(false);
            var stopwatch = Stopwatch.StartNew();
            // Act
            result = await Mediatr.Send((BaseRequest<T>)request).ConfigureAwait(false);
            // Assert
            stopwatch.Stop();
            var elapsedMilliseconds = stopwatch.ElapsedMilliseconds;
            if (elapsedMilliseconds < maximumExpectedTimeMilliseconds) break;
            Console.WriteLine($"Current elapsed milliseconds: {elapsedMilliseconds}.");
            if (i >= RetryExpectedTimes) Assert.Warn($"Maximum expected time was {maximumExpectedTimeMilliseconds} but {elapsedMilliseconds} instead.");
        }
        // Result
        return result;
    }

    protected private static void AssertResult(RequestResult result, bool success)
    {
        Assert.IsNotNull(result);
        Assert.AreEqual(success, result.Success, $"{result.ErrorType} - {result.Message ?? result.Exception?.ToString()}");
    }

    protected void SetCurrentUser(User user)
    {
        var currentUserService = (CurrentUserServiceMock)Services.GetRequiredService<ICurrentUserService<User>>();
        currentUserService.SetCurrentUser(user);
    }

    protected private static void AssertMonthRevenueDto(MonthRevenueDto dto, MonthRevenue entity) => Assert.AreEqual(entity.Amount, dto.Amount);

    protected private static void AssertRevenueCommentDto(RevenueCommentDto dto, RevenueComment entity)
    {
        Assert.AreEqual(entity.DateTime, dto.DateTime);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Text, dto.Text);
        Assert.AreEqual(dto.UserName, entity.Username);
    }

    protected private static void AssertRevenueDto(RevenueDto dto, Revenue entity)
    {
        Revenue.GetMonths().ForEach(m =>
        {
            var mr = (MonthRevenue)entity.GetType().GetProperty(m.ToString()).GetValue(entity);
            var mrDto = (MonthRevenueDto)dto.GetType().GetProperty(m.ToString()).GetValue(dto);
            AssertMonthRevenueDto(mrDto, mr);
        });

        Assert.AreEqual(entity.BusinessUnit?.Code, dto.BusinessUnitCode);
        Assert.AreEqual(entity.ChargingModel.Code, dto.ChargingModelCode);
        if (dto.Comments.Any()) Assert.AreNotEqual(0, entity.Comments.Count);
        if (entity.Comments.Any()) Assert.AreNotEqual(0, dto.Comments.Count());
        Assert.AreEqual(entity.Currency.Code, dto.CurrencyCode);
        Assert.AreEqual(entity.Customer.Name, dto.CustomerName);
        Assert.AreEqual(entity.CustomerCostCenter?.Code, dto.CustomerCostCenterCode);
        Assert.AreEqual(entity.FYFCCHF, dto.FYFCCHF);
        Assert.AreEqual(entity.FYFCCHFVAT, dto.FYFCCHFVAT);
        Assert.AreEqual(entity.FYFCLC, dto.FYFCLC);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.InternalCode, dto.InternalCode);
        Assert.AreEqual(entity.InternalCostCenterPerCost.Code, dto.InternalCostCenterPerCostCode);
        Assert.AreEqual(entity.LineOfBusiness.Name, dto.LineOfBusinessName);
        Assert.AreEqual(entity.OwnerProjectManager.Name, dto.OwnerProjectManagerName);
        Assert.AreEqual(entity.Project.Name, dto.ProjectName);
        Assert.AreEqual(entity.ServiceDescription, dto.ServiceDescription);
        Assert.AreEqual(entity.TypeOfService.Name, dto.TypeOfServiceName);
        Assert.AreEqual(entity.Product.Name, dto.ProductName);
        Assert.AreEqual(entity.Customer.Function.Name, dto.CustomerFunctionName);
        Assert.AreEqual(entity.Year, dto.Year);
    }

    protected private static void AssertRoleDto(RoleDto dto, Role entity)
    {
        Assert.AreEqual(entity.Description, dto.Description);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        Assert.AreEqual(entity.Users.Count(), dto.Users.Count());
        Assert.AreEqual(entity.Permissions.Count(), dto.Permissions.Count());
    }

    protected private static void AssertUserDto(UserDto dto, User entity, bool includeGridPreferences = false)
    {
        Assert.AreEqual(entity.AdAccount.SAMAccountName, dto.SAMAccountName);
        if (includeGridPreferences) Assert.AreEqual(entity.GridPreferences.Revenues, dto.GridPreferences.Revenues);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        Assert.AreEqual(entity.Roles.Count(), dto.Roles.Count());
    }

    protected private static void AssertGroupDto(GroupDto dto, Group entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        Assert.AreEqual(entity.Users.Count, dto.Users.Count());
    }

    protected private static void AssertBusinessUnitDto(BusinessUnitDto dto, BusinessUnit entity)
    {
        Assert.AreEqual(entity.Code, dto.Code);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertProductDto(ProductDto dto, Product entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertChargingModelTypeDto(ChargingModelTypeDto dto, ChargingModelType entity)
    {
        Assert.AreEqual(entity.Type, dto.Type);
        Assert.AreEqual(entity.Id, dto.Id);
    }

    protected private static void AssertChargingModelDto(ChargingModelDto dto, ChargingModel entity)
    {
        Assert.AreEqual(entity.Code, dto.Code);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        AssertChargingModelTypeDto(dto.Type, entity.Type);
    }

    protected private static void AssertCostCenterDto(CostCenterDto dto, CostCenter entity)
    {
        Assert.AreEqual(entity.Code, dto.Code);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Types.Count, dto.Types.Count());
    }

    protected private static void AssertCurrencyDto(CurrencyDto dto, Currency entity)
    {
        Assert.AreEqual(entity.Code, dto.Code);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        Assert.AreEqual(entity.Symbol, dto.Symbol);
    }

    protected private static void AssertCurrencyExchangeRateDto(CurrencyExchangeRateDto dto, CurrencyExchangeRate entity)
    {
        AssertCurrencyDto(dto.From, entity.From);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Month.ToString(), dto.Month);
        Assert.AreEqual(entity.Rate, dto.Rate);
        AssertCurrencyDto(dto.To, entity.To);
        Assert.AreEqual(entity.Year, dto.Year);
    }

    protected private static void AssertCustomerFunctionDto(CustomerFunctionDto dto, CustomerFunction entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertCustomerDto(CustomerDto dto, Customer entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
        Assert.AreEqual(dto != null, entity != null);
        AssertCustomerFunctionDto(dto.Function, entity.Function);
    }

    protected private static void AssertLineOfBusinessDto(LineOfBusinessDto dto, LineOfBusiness entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertProjectDto(ProjectDto dto, Project entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertTestingToolDto(TestingToolDto dto, TestingTool entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertTypeOfServiceDto(TypeOfServiceDto dto, TypeOfService entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Name, dto.Name);
    }

    protected private static void AssertValueAddedTaxDto(ValueAddedTaxDto dto, ValueAddedTax entity)
    {
        Assert.AreEqual(entity.Country, dto.Country);
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.PercentageAmount, dto.PercentageAmount);
    }

    protected private static void AssertTicketDto(TicketDto dto, Ticket entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Summary, dto.Summary);
        Assert.AreEqual(entity.Description, dto.Description);
        Assert.AreEqual(entity.Reference, dto.Reference);
        Assert.AreEqual(entity.Status, dto.Status);
        Assert.AreEqual(entity.Type, dto.Type);
        Assert.AreEqual(entity.Created, dto.Created);
        Assert.AreEqual(entity.Updated, dto.Updated);
        Assert.AreEqual(entity.User.AdAccount.SAMAccountName, dto.SAMAccountName);
        Assert.AreEqual(dto.Comments?.Count(), entity.Comments.Count);
        for (var i = 0; i < entity.Comments.Count; i++) AssertTicketCommentDto(dto.Comments.ElementAt(i), entity.Comments.ElementAt(i));
    }

    protected private static void AssertTicketCommentDto(TicketCommentDto dto, TicketComment entity)
    {
        Assert.AreEqual(entity.Id, dto.Id);
        Assert.AreEqual(entity.Text, dto.Text);
        Assert.AreEqual(entity.DateTime, dto.DateTime);
        Assert.AreEqual(entity.SAMAccountName, dto.SAMAccountName);
    }

    #region --- PROTECTED METHODS ---

    protected static IEnumerable<object> GetEnumsTypes() =>
        new object[] { typeof(ProjectType).Name, typeof(CostCenterType).Name, typeof(TicketType).Name }.ToList();

    #endregion

    #endregion

    #region --- PRIVATE METHODS ---

    internal static IConfiguration GetFolderFileRepositoryConfiguration()
    {
        var dictionary = new Dictionary<string, string>()
        {
            { nameof(FolderFileRepositoryConfiguration.BasePath), Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ExternalFiles") }
        };

        return new ConfigurationBuilder()
            .AddInMemoryCollection(dictionary)
            .Build();
    }

    #endregion
}
