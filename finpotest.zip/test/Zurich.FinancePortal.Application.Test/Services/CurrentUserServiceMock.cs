﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.Application;
    using Domain;
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Threading;
    using System.Threading.Tasks;

    internal class CurrentUserServiceMock : ICurrentUserService<User>
    {
        #region --- PROPERTIES ---

        public string Username { get; set; }

        public string Mail => null;

        public string DisplayName => null;

        public string EmployeeId => null;

        public string Domain => null;

        #endregion

        #region --- REFERENCES ---

        private User _user;

        #endregion

        #region --- CONSTRUCTORS ---

        public CurrentUserServiceMock()
        {
            Username = Guid.NewGuid().ToString();
        }

        #endregion

        #region --- PUBLIC METHODS ---

        [SuppressMessage("Major Code Smell", "S1121: Assignments should not be made from within sub-expressions", Justification = "N/A")]
        public Task<User> GetUserAsync(CancellationToken cancellationToken = default) =>
            Task.FromResult(_user ??= new User(Guid.NewGuid().ToString(), new AdAccount(Username), roles: new Role[] { new Role(Role.SuperAdminName, Role.SuperAdminDescription, isSuperAdmin: true) }));

        #endregion

        #region --- INTERNAL METHODS ---

        internal void SetCurrentUser(User user)
        {
            _user = user;
            Username = user.AdAccount.SAMAccountName;
        }

        #endregion
    }
}
