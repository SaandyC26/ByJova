﻿namespace Zurich.FinancePortal.Application.Test
{
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.DependencyInjection;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Threading.Tasks;

    public sealed class RevenueServiceTests : BaseApplicationTests
    {
        #region --- REFERENCES ---

        private IRevenueService _revenueService;

        #endregion

        #region --- PUBLIC METHODS ---

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();
            _revenueService = Services.GetRequiredService<IRevenueService>();
        }

        [Test]
        public async Task ShouldToRevenueAsync()
        {
            // Arrange
            var dto = (await AddRevenueAsync().ConfigureAwait(false)).Dto;
            // Act
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(0, errors.Single().Count());
            Assert.IsNotNull(revenues);
        }

        [Test]
        public async Task ShouldFailDuplicatedRevenuesAsync()
        {
            // Arrange
            var dto = (await AddRevenueAsync().ConfigureAwait(false)).Dto;
            // Act
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto, dto }, initialLine: 1).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Count());
            Assert.IsTrue(errors.Single().Single().StartsWithICIC($"Duplicated {nameof(Revenue)}s in rows [1, 2]"));
            Assert.IsNull(revenues);
        }

        [Test]
        public async Task ShouldCreateUpdateRevenuesFromDtoAsync()
        {
            // Arrange
            var dtoA = Mapper.Map<Revenue, RevenueDto>(await GetRevenueMock().ConfigureAwait(false));
            var dtoB = Mapper.Map<Revenue, RevenueDto>(await GetRevenueMock().ConfigureAwait(false));
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dtoA, dtoB }, initialLine: 1).ConfigureAwait(false);
            await SaveChangesAsync().ConfigureAwait(false);
            // Assert
            errors.ForEach(e => Assert.AreEqual(0, e.Count()));
        }

        [Test]
        [SuppressMessage("Major Code Smell", "S3358: Ternary operators should not be nested", Justification = "N/A")]
        public async Task ShouldCreateTrueUpSumZeroAsync()
        {
            // Arrange
            var revenuesConfiguration = RevenuesConfiguration.CreateDefault();
            var tos = await GetIQuerable<TypeOfService>().SingleAsync(x => x.Name.ToUpper().Equals(TypeOfService.TrueUpName.ToUpper())).ConfigureAwait(false);
            var dto = (await AddRevenueAsync().ConfigureAwait(false)).Dto;
            dto.TypeOfServiceName = tos.Name;
            Revenue.GetMonths().ForEach((m, i) => dto.GetType().GetProperty(m.ToString()).SetValue(dto, new MonthRevenueDto() { Amount = i < 2 ? null : i % 2 == 0 ? 1 : -1 }));
            var currencies = await GetIQuerable<Currency>(asNoTracking: false).ToArrayAsync().ConfigureAwait(false);
            for (var i = 0; i < Random.Next(1, GetMonths().Count()); i++) await AddCurrencyExchangeRateAsync(new CurrencyExchangeRate(dto.Year, Random.Next(2 + i, 5 + i), currencies.Single(c => c.Code.EqualsICIC(dto.CurrencyCode)), currencies.Single(c => c.Code.EqualsICIC(Currency.ChiefsCode)), month: (Month)(i + 1))).ConfigureAwait(false);
            // Act
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(revenuesConfiguration, new RevenueDto[] { dto }, initialLine: 0).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(0, errors.Single().Count());
            Assert.AreEqual(0, revenues.Single().FYFCLC);
            Assert.AreEqual(0, revenues.Single().FYFCCHF);
            Assert.AreEqual(0, revenues.Single().FYFCCHFVAT);
        }

        [Test]
        public async Task ShouldErrorTrueUpSumNonZeroAsync()
        {
            // Arrange
            var revenuesConfiguration = RevenuesConfiguration.CreateDefault();
            var tos = await GetIQuerable<TypeOfService>().SingleAsync(x => x.Name.ToUpper().Equals(TypeOfService.TrueUpName.ToUpper())).ConfigureAwait(false);
            var dto = (await AddRevenueAsync().ConfigureAwait(false)).Dto;
            dto.TypeOfServiceName = tos.Name;
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(revenuesConfiguration, new RevenueDto[] { dto }, initialLine: 0).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(2, errors.Single().Count());
        }

        [Test]
        [TestCaseSource(nameof(GetChargingModelCodesInternalCostCenterPerCostRestrictions))]
        public async Task ShouldErrorChargingModelInternalCostCenterPerCostRestrictionAsync(string chargingModelCode, string internalCostCenterPerCostCode)
        {
            // Arrange
            var chargingModel = await GetIQuerable<ChargingModel>(asNoTracking: false).SingleAsync(cm => cm.Code.Equals(chargingModelCode)).ConfigureAwait(false);
            var revenue = await GetRevenueMock().ConfigureAwait(false);
            revenue.UpdateChargingModel(chargingModel);
            var dto = (await AddRevenueAsync(revenue: revenue).ConfigureAwait(false)).Dto;
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }, initialLine: 0).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Single().Count());
            Assert.IsTrue(errors.Single().Single().ContainsICIC("Restricted"), errors.Single().Single());
        }

        [Test]
        [TestCaseSource(nameof(GetChargingModelCodesInternalCostCenterPerCostRestrictions))]
        public async Task ShouldChargingModelInternalCostCenterPerCostRestrictionAsync(string chargingModelCode, string internalCostCenterPerCostCode)
        {
            // Arrange
            var iccpc = await GetIQuerable<CostCenter>(asNoTracking: false).SingleAsync(cc => cc.Code.ToUpper().Equals(internalCostCenterPerCostCode.ToUpper())).ConfigureAwait(false);
            var chargingModel = await GetIQuerable<ChargingModel>(asNoTracking: false).SingleAsync(cm => cm.Code.Equals(chargingModelCode)).ConfigureAwait(false);
            var revenue = await GetRevenueMock().ConfigureAwait(false);
            revenue.UpdateChargingModel(chargingModel);
            revenue.UpdateInternalCostCenterPerCost(iccpc);
            var dto = (await AddRevenueAsync(revenue: revenue).ConfigureAwait(false)).Dto;
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(0, errors.Single().Count());
        }

        [Test]
        [TestCaseSource(nameof(GetChargingModelCodesInternalCostCenterPerCostRestrictions))]
        public async Task ShouldVatNoneChargingModelRestrictionAsync(string chargingModelCode, string internalCostCenterPerCostCode)
        {
            // Arrange
            var revenue = await GetRevenueMock().ConfigureAwait(false);
            var dto = Mapper.Map<Revenue, RevenueDto>(revenue);
            dto.ChargingModelCode = chargingModelCode;
            dto.InternalCostCenterPerCostCode = internalCostCenterPerCostCode;
            // Act
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(0, errors.Single().Count(), string.Join(Environment.NewLine, errors.Single().Select(x => x)));
            Assert.AreEqual(ValueAddedTax.None, revenues.Single().ValueAddedTax.Country);
            Assert.AreEqual(null, revenues.Single().FYFCCHFVAT);
        }

        [Test]
        public async Task ShouldErrorBusinessUnitPreviouslyBilledAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).AddRole(new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue, Constants.Permission_BypassOwnedRevenues, Constants.Permission_BypassLockedRevenues }));
            SetCurrentUser(cu);
            var (entity, dto) = await AddRevenueAsync().ConfigureAwait(false);
            await AddYearLocksAsync(new YearLocks(dto.Year, entity.ChargingModel.Type, new Dictionary<Month, bool>() { { Month.January, true } }));
            var businessUnit = (await AddBusinessUnitAsync().ConfigureAwait(false)).Entity;
            dto.BusinessUnitCode = businessUnit.Code;
            // Arrange
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Single().Count(), string.Join(Environment.NewLine, errors.Single().Select(x => x)));
            Assert.IsTrue(errors.Single().Single().ContainsICIC(Revenue.BusinessUnitDescription) && errors.Single().Single().ContainsICIC(Revenue.CustomerCostCenterDescription));
        }

        [Test]
        public async Task ShouldErrorCustomerCostCenterPreviouslyBilledAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).AddRole(new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue, Constants.Permission_BypassOwnedRevenues, Constants.Permission_BypassLockedRevenues }));
            SetCurrentUser(cu);
            var (entity, dto) = await AddRevenueAsync().ConfigureAwait(false);
            await AddYearLocksAsync(new YearLocks(dto.Year, entity.ChargingModel.Type, new Dictionary<Month, bool>() { { Month.January, true } }));
            var costCenter = (await AddCostCenterAsync().ConfigureAwait(false)).Entity;
            dto.CustomerCostCenterCode = costCenter.Code;
            // Arrange
            var (revenues, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Single().Count(), string.Join(Environment.NewLine, errors.Single().Select(x => x)));
            Assert.IsTrue(errors.Single().Single().ContainsICIC(Revenue.BusinessUnitDescription) && errors.Single().Single().ContainsICIC(Revenue.CustomerCostCenterDescription));
        }

        [Test]
        public async Task ShouldErrorPlannedStartDateGreaterThanPlannedEndDateAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).AddRole(new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue }));
            SetCurrentUser(cu);
            var dto = Mapper.Map<Revenue, RevenueDto>(await GetRevenueMock().ConfigureAwait(false));
            var year = DateTime.UtcNow.Year;
            dto.PlannedStartDate = new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc);
            dto.PlannedEndDate = new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Single().Count(), string.Join(Environment.NewLine, errors.Single().Select(x => x)));
            Assert.IsTrue(errors.Single().Single().ContainsICIC($"{Revenue.PlannedStartDateDescription} cannot be greater than {Revenue.PlannedEndDateDescription}."), errors.Single().Single());
        }

        [Test]
        public async Task ShouldErrorPlannedEndDateGreaterThanNowAsync()
        {
            // Arrange
            var cu = new User(Guid.NewGuid().ToString(), new AdAccount(Guid.NewGuid().ToString())).AddRole(new Role(Guid.NewGuid().ToString(), permissions: new Permission[] { Constants.Permission_ManageRevenue, Constants.Permission_BypassOwnedRevenues, Constants.Permission_BypassLockedRevenues }));
            SetCurrentUser(cu);
            var year = DateTime.UtcNow.Year;
            var revenue = await GetRevenueMock().ConfigureAwait(false);
            revenue.UpdateYearAndPlannedDates(revenue.Year, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc));
            var dto = (await AddRevenueAsync(revenue: revenue).ConfigureAwait(false)).Dto;
            dto.ServiceDescription = Guid.NewGuid().ToString();
            // Act
            var (_, errors) = await _revenueService.CreateUpdateRevenuesFromDtoAsync(RevenuesConfiguration.CreateDefault(), new RevenueDto[] { dto }).ConfigureAwait(false);
            // Assert
            Assert.AreEqual(1, errors.Single().Count(), string.Join(Environment.NewLine, errors.Single().Select(x => x)));
            Assert.IsTrue(errors.Single().Single().ContainsICIC(ConstantsMessages.Revenue.ExpiredPlannedEndDate(revenue.PlannedEndDate)), errors.Single().Single());
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static IEnumerable<object> GetChargingModelCodesInternalCostCenterPerCostRestrictions()
        {
            var restriction = RevenuesConfiguration.CreateDefault().Restrictions.Single(r => r.Property.EqualsICIC(nameof(Revenue.ChargingModel)) && r.RestrictedProperty.EqualsICIC(nameof(Revenue.InternalCostCenterPerCost)));
            return restriction.Values.Select(v => new object[] { v, restriction.RestrictedValues.First() });
        }

        #endregion
    }
}
