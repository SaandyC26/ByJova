﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRolesQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRolesAsync()
        {
            // Arrange
            var (query, _) = await ProtectedShouldGetRolesWithUsersAndPermissionsAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
