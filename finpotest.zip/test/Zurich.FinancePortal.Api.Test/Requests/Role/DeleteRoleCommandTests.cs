﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public class DeleteRoleCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteRoleAsync()
        {
            // Arrange
            var role = (await AddRoleAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteRoleCommand()
            {
                Id = role.Id
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
