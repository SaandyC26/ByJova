﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public class CreateRoleCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateRoleAsync()
        {
            // Arrange
            var user = (await AddUserAsync().ConfigureAwait(false)).Dto;
            var permission = (await AddPermissionAsync().ConfigureAwait(false)).Dto;
            var command = new CreateRoleCommand()
            {
                Role = new RoleDto()
                {
                    Name = Guid.NewGuid().ToString(),
                    Description = Guid.NewGuid().ToString(),
                    Users = new UserDto[]
                    {
                        user
                    },
                    Permissions = new PermissionDto[]
                    {
                        permission
                    }
                }
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
