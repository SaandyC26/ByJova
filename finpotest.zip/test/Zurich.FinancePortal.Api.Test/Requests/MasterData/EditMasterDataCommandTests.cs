﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class EditMasterDataCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMasterDataTypes))]
        public async Task ShouldEditMasterDataAsync(Type type)
        {
            // Arrange
            var command = await ProtectedShouldEditMasterDataAsync(type).ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
