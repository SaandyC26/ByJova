﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using Domain;
    using NUnit.Framework;
    using System;
    using System.Reflection;
    using System.Threading.Tasks;

    public sealed class DeleteMasterDataCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMasterDataTypes))]
        public async Task ShouldDeleteMasterDataAsync(Type type)
        {
            // Arrange
            if (type.Equals(typeof(Currency))) Assert.Pass();
            if (type.Equals(typeof(ValueAddedTax))) Assert.Pass();
            if (type.Equals(typeof(Product))) Assert.Pass();

            await AddRevenueAsync().ConfigureAwait(false);
            var task = (Task)GetType().GetMethod($"Add{type.Name}Async", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Invoke(this, new object[] { null });
            await task.ConfigureAwait(false);
            var masterData = ((dynamic)task).Result.Item1;

            var command = new DeleteMasterDataCommand()
            {
                Type = type.Name,
                Id = masterData.Id
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
