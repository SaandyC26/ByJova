﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public sealed class GetMasterDatasQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMasterDataTypes))]
        public async Task ShouldGetMasterDatas(Type type)
        {
            // Arrange
            var (query, _) = await ProtectedShouldGetMasterDatas(type).ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
