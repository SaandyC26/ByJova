﻿namespace Zurich.FinancePortal.Api.Test;

using NUnit.Framework;
using System.Threading.Tasks;

public sealed class GetGroupsQueryTests : BaseApiTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldGetGroupsAsync()
    {
        // Arrange
        var (query, _) = await ProtectedShouldGetGroupsAsync().ConfigureAwait(false);
        // Act
        var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
        // Assert
        AssertResult(objectResult, result);
    }

    #endregion
}
