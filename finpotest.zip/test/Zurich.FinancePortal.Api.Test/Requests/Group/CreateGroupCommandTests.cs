﻿namespace Zurich.FinancePortal.Api.Test;

using Application;
using NUnit.Framework;
using System;
using System.Threading.Tasks;

public class CreateGroupCommandTests : BaseApiTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldCreateGroupAsync()
    {
        // Arrange
        var userDto = (await AddUserAsync().ConfigureAwait(false)).Dto;
        var command = new CreateGroupCommand()
        {
            Group = new GroupDto()
            {
                Name = Guid.NewGuid().ToString(),
                Users = new UserDto[]
                {
                    userDto
                }
            }
        };
        // Act
        var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
        // Assert
        AssertResult(objectResult, result);
    }

    #endregion
}
