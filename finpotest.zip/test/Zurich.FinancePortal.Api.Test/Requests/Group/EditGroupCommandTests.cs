﻿namespace Zurich.FinancePortal.Api.Test;

using NUnit.Framework;
using System.Threading.Tasks;

public sealed class EditGroupCommandTests : BaseApiTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldEditGroupAsync()
    {
        // Arrange
        var (command, _) = await ProtectedShouldEditGroupWithRolesAsync().ConfigureAwait(false);
        // Act
        var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
        // Assert
        AssertResult(objectResult, result);
    }

    #endregion
}
