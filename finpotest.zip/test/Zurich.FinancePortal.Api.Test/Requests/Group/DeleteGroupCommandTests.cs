﻿namespace Zurich.FinancePortal.Api.Test;

using Application;
using NUnit.Framework;
using System.Threading.Tasks;

public class DeleteGroupCommandTests : BaseApiTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    public async Task ShouldDeleteGroupAsync()
    {
        // Arrange
        var group = (await AddGroupAsync().ConfigureAwait(false)).Entity;
        var command = new DeleteGroupCommand()
        {
            Id = group.Id
        };
        // Act
        var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
        // Assert
        AssertResult(objectResult, result);
    }

    #endregion
}
