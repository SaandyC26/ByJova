﻿namespace Zurich.FinancePortal.Api.Test;
using Application;
using NUnit.Framework;
using System.Threading.Tasks;


public sealed class GetEnumValuesQueryTests : BaseApiTests
{
    #region --- PUBLIC METHODS ---

    [Test]
    [TestCaseSource(nameof(GetEnumsTypes))]
    public async Task ShouldGetEnumValuesAsync(string type)
    {
        // Arrange
        var query = new GetEnumValuesQuery() { Type = type };
        // Act
        var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
        // Assert
        AssertResult(objectResult, result);
    }

    #endregion
}
