﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class EditYearLocksCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditYearLocksCommandAsync()
        {
            // Arrange
            var (command, _, _) = await ProtectedShouldEditYearLocksCommandAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
