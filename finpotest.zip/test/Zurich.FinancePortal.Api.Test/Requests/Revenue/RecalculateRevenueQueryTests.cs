﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class RecalculateRevenueQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldRecalculateRevenueAsync()
        {
            // Arrange
            var (query, _, _, _, _) = await ProtectedShouldRecalculateRevenueAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
