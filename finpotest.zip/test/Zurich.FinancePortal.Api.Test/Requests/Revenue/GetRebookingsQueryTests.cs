﻿namespace Zurich.FinancePortal.Api.Test
{
    using Domain;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRebookingsQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        [TestCaseSource(nameof(GetMonths))]
        public async Task ShouldGetRebookingsAsync(Month month)
        {
            // Arrange
            var (query, _, _, _) = await ProtectedShouldGetRebookingsAsync(month).ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
