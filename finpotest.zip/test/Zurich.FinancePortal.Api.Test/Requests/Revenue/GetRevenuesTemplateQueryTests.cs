﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRevenuesTemplateQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRevenuesTemplateQueryAsync()
        {
            // Arrange
            var query = new GetRevenuesTemplateQuery();
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
