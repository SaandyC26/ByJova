﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class GetRevenuesRestrictionsQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldGetRevenuesRestrictionsAsync()
        {
            // Arrange
            var query = new GetRevenuesRestrictionsQuery();
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
