﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using Domain;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class EditRevenueCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]

        public async Task ShouldEditRevenueAsync()
        {
            // Arrange
            var (revenueEntityA, _) = await AddRevenueAsync().ConfigureAwait(false);
            var revenueEntityB = (await GetRevenueMock().ConfigureAwait(false)).RefreshFyf();
            revenueEntityB.GetType().GetProperty(nameof(Revenue.Id)).SetValue(revenueEntityB, revenueEntityA.Id);
            revenueEntityB.GetType().GetProperty(nameof(Revenue.Comments)).SetValue(revenueEntityB, revenueEntityA.Comments);
            var revenueDtoB = Mapper.Map<Revenue, RevenueDto>(revenueEntityB);
            var command = new EditRevenueCommand()
            {
                Revenue = revenueDtoB
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
