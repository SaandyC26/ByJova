﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class RefreshRevenuesCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldRefreshRevenuesAsync()
        {
            // Arrange
            var (command, _, _) = await ProtectedShouldRefreshRevenuesAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
