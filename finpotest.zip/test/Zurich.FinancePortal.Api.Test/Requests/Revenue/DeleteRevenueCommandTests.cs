﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class DeleteRevenueCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteRevenueAsync()
        {
            // Arrange
            var revenue = (await AddRevenueAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteRevenueCommand()
            {
                Id = revenue.Id
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
