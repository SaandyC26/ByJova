﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class ExportCustomersAllocationsQueryTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldExportCustomersAllocationsQueryAsync()
        {
            // Arrange
            var (query, _) = await ProtectedShouldExportCustomersAllocationsQueryAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(query).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
