﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class CreateTicketCommentCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateTicketCommentAsync()
        {
            // Arrange
            var (command, _) = await ProtectedShouldCreateTicketCommentAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
