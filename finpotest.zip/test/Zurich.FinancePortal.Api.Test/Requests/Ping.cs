﻿namespace Zurich.FinancePortal.Api.Test
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class Ping : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldPingAsync()
        {
            // Act
            var result = (ObjectResult)await PingController.GetAsync().ConfigureAwait(false);
            // Assert
            Assert.AreEqual(StatusCodes.Status200OK, result.StatusCode);
        }

        #endregion
    }
}
