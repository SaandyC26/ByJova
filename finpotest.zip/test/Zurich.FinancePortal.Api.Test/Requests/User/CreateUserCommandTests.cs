﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System;
    using System.Threading.Tasks;

    public class CreateUserCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldCreateUserAsync()
        {
            // Arrange
            var RoleDto = (await AddRoleAsync().ConfigureAwait(false)).Dto;
            var command = new CreateUserCommand()
            {
                User = new UserDto()
                {
                    SAMAccountName = Guid.NewGuid().ToString(),
                    Name = Guid.NewGuid().ToString(),
                    Roles = new RoleDto[]
                    {
                        RoleDto
                    }
                }
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
