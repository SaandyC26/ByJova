﻿namespace Zurich.FinancePortal.Api.Test
{
    using NUnit.Framework;
    using System.Threading.Tasks;

    public sealed class EditUserLastSeenReleaseNotesCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldEditUserLastSeenReleaseNotesAsync()
        {
            // Arrange
            var command = await ProtectedShouldEditUserLastSeenReleaseNotesAsync().ConfigureAwait(false);
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
