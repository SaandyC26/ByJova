﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using NUnit.Framework;
    using System.Threading.Tasks;

    public class DeleteUserCommandTests : BaseApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public async Task ShouldDeleteUserAsync()
        {
            // Arrange
            var user = (await AddUserAsync().ConfigureAwait(false)).Entity;
            var command = new DeleteUserCommand()
            {
                Id = user.Id
            };
            // Act
            var (objectResult, result) = await ControllerPostAsync(command).ConfigureAwait(false);
            // Assert
            AssertResult(objectResult, result);
        }

        #endregion
    }
}
