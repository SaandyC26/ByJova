﻿namespace Zurich.FinancePortal.Api.Test
{
    using Application;
    using Application.Test;
    using DevOps.Application;
    using DevOps.CrossCutting;
    using FluentValidation;
    using MediatR;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.DependencyInjection;
    using Moq;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Threading.Tasks;

    [Category(nameof(Application))]
    public class ApiTests
    {
        #region --- PUBLIC METHODS ---

        [Test]
        public void ShouldAllApplicationRequest()
        {
            // Arrange
            var assembly = Assembly.GetAssembly(typeof(BaseRequestResult));
            var excludedRequestTypes = new Type[] { typeof(ImportRevenuesTemplateCommand) };
            var requestTypes = assembly.GetTypes().Where(t => !t.IsAbstract && (t.BaseType?.BaseType?.IsGenericType ?? false) && t.BaseType.BaseType.GetGenericTypeDefinition().Equals(typeof(Request<>)));
            Assert.AreNotEqual(0, requestTypes.Count());
            var testAssembly = Assembly.GetAssembly(GetType());
            var methods = testAssembly.GetTypes().SelectMany(t => t.GetMethods());
            var list = new List<string>();
            // Act
            foreach (var requestType in requestTypes.Where(t => !excludedRequestTypes.Contains(t)))
            {
                if (!methods.Any(m => m.Name.ContainsICIC(requestType.Name.Replace("Command", string.Empty).Replace("Query", string.Empty))))
                {
                    list.Add($"{nameof(IRequest)} {requestType.Name} does not contains an {nameof(Api)}.{nameof(Test)} method.");
                }
            }
            // Assert
            Assert.IsEmpty(list, string.Join(Environment.NewLine, list));
        }

        #endregion
    }

    internal static class BaseRequestExtension
    {
        #region --- INTERNAL METHODS ---

        internal static BaseRequestDto ToBaseRequestDto<T>(this BaseRequest<T> baseRequest) =>
            new() { Type = baseRequest.GetType().Name, Content = JsonConvert.SerializeObject(baseRequest) };

        #endregion
    }

    [Category(nameof(Application))]
    public class BaseApiTests : BaseApplicationTests
    {
        #region --- REFERENCES ---

        protected PingController PingController { get; private set; }

        protected RequestController Controller { get; private set; }

        private Mock<IWebHostEnvironment> _webHostEnvironmentMoq;

        #endregion

        #region --- PUBLIC METHODS ---

        [SetUp]
        public override void SetUp()
        {
            base.SetUp();
            _webHostEnvironmentMoq = new Mock<IWebHostEnvironment>();
            _webHostEnvironmentMoq.Setup(m => m.EnvironmentName).Returns("Staging");
            ServiceCollection.AddScoped(_ => _webHostEnvironmentMoq.Object);
            AssemblyScanner.FindValidatorsInAssemblyContaining<BaseRequest<Unit>>().ForEach(x => ServiceCollection.AddTransient(x.ValidatorType));
            AssemblyScanner.FindValidatorsInAssemblyContaining<Request<Unit>>().ForEach(x => ServiceCollection.AddTransient(x.ValidatorType));
            PingController = new PingController();
            Controller = new RequestController()
            {
                ControllerContext = new ControllerContext()
                {
                    HttpContext = new DefaultHttpContext()
                    {
                        RequestServices = Services
                    }
                }
            };
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected async Task<(IActionResult ObjectResult, T Result)> ControllerPostAsync<T>(BaseRequest<T> request)
        {
            var result = await Controller.BodyRequest(request.ToBaseRequestDto()).ConfigureAwait(false);
            if (result.GetType().Equals(typeof(StatusCodeResult))) return (result, default);
            else if (result.GetType().Equals(typeof(FileContentResult))) return (result, default);
            return (result, (T)((ObjectResult)result).Value);
        }

        protected private static void AssertResult<T>(IActionResult actionResult, T result, int objectResultStatusCodes = StatusCodes.Status200OK, int statusResultStatusCodes = StatusCodes.Status204NoContent)
        {
            if (actionResult.GetType().Equals(typeof(StatusCodeResult))) Assert.AreEqual(statusResultStatusCodes, ((StatusCodeResult)actionResult).StatusCode);
            else if (actionResult.GetType().Equals(typeof(FileContentResult))) return;
            else Assert.AreEqual(objectResultStatusCodes, ((ObjectResult)actionResult).StatusCode);
            Assert.IsNotNull(result);
        }

        #endregion
    }
}
