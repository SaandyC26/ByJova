package com.everis.alondra.claims.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "CUSTOM_SINIESTRO")
public class Siniestro {

    @Id
    private UUID id;

    @Column(name = "VERSION")
    private Integer version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "POLIZA_ID")
    private Poliza poliza;

    @Column(name = "ID_SINIESTRO_MEDIADOR")
    private String idSiniestroMediador;

    @Column(name = "ID_SINIESTRO_ENTIDAD")
    private String idSiniestroEntidad;

    @Column(name = "FECHA_DECLARACION" , nullable = false)
    private Date fechaDeclaracion;

    @Column(name = "FECHA_OCURRENCIA" , nullable = false)
    private Date fechaOcurrencia;

    @Column(name = "DESCRIPCION_SINIESTRO")
    private String descripcionSiniestro;

    @Column(name = "CALLE")
    private String calle;

    @Column(name = "CAUSA_PERDIDA")
    private String causaPerdida;

    @OneToOne
    @JoinColumn(name = "CIUDAD_ID")
    protected Ciudad ciudad;

    @OneToMany(mappedBy = "siniestro")
    protected List<SituacionSiniestro> situacionSiniestros;


    public List<SituacionSiniestro> getSituacionSiniestros() {
        return situacionSiniestros;
    }

    public void setSituacionSiniestros(List<SituacionSiniestro> situacionSiniestros) {
        this.situacionSiniestros = situacionSiniestros;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Poliza getPoliza() {
        return poliza;
    }

    public void setPoliza(Poliza poliza) {
        this.poliza = poliza;
    }

    public String getIdSiniestroMediador() {
        return idSiniestroMediador;
    }

    public void setIdSiniestroMediador(String idSiniestroMediador) {
        this.idSiniestroMediador = idSiniestroMediador;
    }

    public String getIdSiniestroEntidad() {
        return idSiniestroEntidad;
    }

    public void setIdSiniestroEntidad(String idSiniestroEntidad) {
        this.idSiniestroEntidad = idSiniestroEntidad;
    }

    public Date getFechaDeclaracion() {
        return fechaDeclaracion;
    }

    public void setFechaDeclaracion(Date fechaDeclaracion) {
        this.fechaDeclaracion = fechaDeclaracion;
    }

    public Date getFechaOcurrencia() {
        return fechaOcurrencia;
    }

    public void setFechaOcurrencia(Date fechaOcurrencia) {
        this.fechaOcurrencia = fechaOcurrencia;
    }

    public String getDescripcionSiniestro() {
        return descripcionSiniestro;
    }

    public void setDescripcionSiniestro(String descripcionSiniestro) {
        this.descripcionSiniestro = descripcionSiniestro;
    }

    public String getCalle() {
        return calle;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCausaPerdida() {
        return causaPerdida;
    }

    public void setCausaPerdida(String causaPerdida) {
        this.causaPerdida = causaPerdida;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }

    public void setCiudad(Ciudad ciudad) {
        this.ciudad = ciudad;
    }
}
