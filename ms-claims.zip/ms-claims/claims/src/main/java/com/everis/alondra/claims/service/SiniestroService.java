package com.everis.alondra.claims.service;

import com.everis.alondra.claims.client.request.SaveClaimsResquest;
import com.everis.alondra.claims.client.response.ErrorResponse;
import com.everis.alondra.claims.client.response.SaveClaimsResponse;
import com.everis.alondra.claims.domain.SituacionSiniestroDomain;
import com.everis.alondra.claims.exception.BadRequestException;
import com.everis.alondra.claims.exception.InternalErrorException;
import com.everis.alondra.claims.exception.NotFoundException;
import com.everis.alondra.claims.model.Ciudad;
import com.everis.alondra.claims.model.Poliza;
import com.everis.alondra.claims.model.Siniestro;
import com.everis.alondra.claims.model.SituacionSiniestro;
import com.everis.alondra.claims.repository.ICiudadRepository;
import com.everis.alondra.claims.repository.IPolizaRepository;
import com.everis.alondra.claims.repository.ISiniestroRepository;
import com.everis.alondra.claims.repository.ISituacionSiniestroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class SiniestroService {

    @Autowired
    ISiniestroRepository siniestroRepository;

    @Autowired
    IPolizaRepository polizaRepository;

    @Autowired
    ICiudadRepository ciudadRepository;

    @Autowired
    ISituacionSiniestroRepository situacionSiniestroRepository;

    /**
     * Servicio para grabar un siniestro y asociarlo con sus respectivas entidades.
     * @param saveClaimsResquest
     * @return
     */
    public SaveClaimsResponse saveClaims (SaveClaimsResquest saveClaimsResquest) {

        // Valido que en la request venga todos los campos obligatorios
        validateInputRequest(saveClaimsResquest);

        // Valido si encuentro la poliza relacionada
        Poliza poliza = validatePoliza(saveClaimsResquest);

        // Valido si encuentro la ciudad relacionada
        Ciudad ciudad = validateCiudad(saveClaimsResquest);

        // Relleno el siniestro
        Siniestro siniestro = fillSiniestro(saveClaimsResquest , poliza , ciudad);

         // Grabo el siniestro
        UUID idSiniestro = saveSiniestro(siniestro);

        // Preparo la respuesta de salida
        SaveClaimsResponse response = new SaveClaimsResponse();
        response.setId(idSiniestro);

        return response;
    }


    /**
     * Graba el siniestro en base de datos y delvuelve el id con el que se ha creado
     * @param siniestro
     * @return
     */
    @Transactional
    private UUID saveSiniestro (Siniestro siniestro) {

        String codeError = "";

        try {
            List<SituacionSiniestro> situacionSiniestroList = new ArrayList<>();
            situacionSiniestroList.addAll(siniestro.getSituacionSiniestros());
            siniestro.getSituacionSiniestros().clear();

            codeError = "500-3";
            UUID idSiniestro = siniestroRepository.save(siniestro).getId();

            codeError = "500-4";
            for (SituacionSiniestro situacionSiniestro : situacionSiniestroList) { situacionSiniestroRepository.save(situacionSiniestro); }

            return idSiniestro;
        } catch (Exception exception) {
            exception.printStackTrace();
            String desc = "Se ha producido un error interno en el servicio.";
            throw new InternalErrorException(new ErrorResponse(codeError, desc));
        }
    }


    /**
     * Mapea la request al modelo de datos de siniestros
     * @param saveClaimsResquest
     * @param poliza
     * @param ciudad
     * @return
     */
    private Siniestro fillSiniestro (SaveClaimsResquest saveClaimsResquest , Poliza poliza , Ciudad ciudad) {

        Siniestro siniestro = new Siniestro();
        siniestro.setId(UUID.randomUUID());
        siniestro.setVersion(1);
        siniestro.setFechaOcurrencia(saveClaimsResquest.getFechaOcurrencia());
        siniestro.setFechaDeclaracion(saveClaimsResquest.getFechaDeclaracion());
        siniestro.setCausaPerdida(saveClaimsResquest.getCausaPerdida());
        siniestro.setDescripcionSiniestro(saveClaimsResquest.getDescripcionSiniestro());
        siniestro.setCalle(saveClaimsResquest.getCalle());
        siniestro.setIdSiniestroEntidad(saveClaimsResquest.getIdSiniestroEntidad());
        siniestro.setIdSiniestroMediador(saveClaimsResquest.getIdSiniestroEntidad());
        siniestro.setPoliza(poliza);
        siniestro.setCiudad(ciudad);


        // Relleno la situacion siniestro
        if (saveClaimsResquest.getSituacionSiniestro() != null) {
            List<SituacionSiniestro> situacionSiniestroList = new ArrayList<>();
            siniestro.setSituacionSiniestros(situacionSiniestroList);

            for (SituacionSiniestroDomain situacionSiniestroDomain : saveClaimsResquest.getSituacionSiniestro()) {
                SituacionSiniestro situacionSiniestro = new SituacionSiniestro();

                situacionSiniestro.setId(UUID.randomUUID());
                situacionSiniestro.setVersion(1);
                situacionSiniestro.setNumeroOrden(situacionSiniestroDomain.getNumeroOrden());
                situacionSiniestro.setFechaSituacion(situacionSiniestroDomain.getFechaSituacion());
                situacionSiniestro.setDescripcionSituacion(situacionSiniestroDomain.getDescripcionSituacion());
                situacionSiniestro.setSituacionSiniestro(situacionSiniestroDomain.getSituacionSiniestro());
                situacionSiniestro.setSiniestro(siniestro);

                situacionSiniestroList.add(situacionSiniestro);
            }
        }

        return siniestro;
    }


    /**
     * Obtiene la poliza a la que va asociado el siniestro. Si no lo encuentra devuelve un error.
     * @param saveClaimsResquest
     * @return
     */
    private Poliza validatePoliza (SaveClaimsResquest saveClaimsResquest) {

        Poliza poliza = null;

        try {
            poliza = polizaRepository.findPoliza(saveClaimsResquest.getNumeroPoliza()
                    , saveClaimsResquest.getNumeroEndosoPoliza()
                    ,saveClaimsResquest.getNumeroCertificadoPoliza());
        } catch (Exception exception) {
            exception.printStackTrace();
            String desc = "Se ha producido un error interno en el servicio.";
            throw new InternalErrorException(new ErrorResponse("500-1", desc));
        }


       if (poliza == null) {
           String desc = String.format("No se ha podido encontrar la poliza con el número de póliza %s con el número de certificado %s y con el número de endoso %s" ,
                   saveClaimsResquest.getNumeroPoliza()
                   ,saveClaimsResquest.getNumeroCertificadoPoliza()
                   ,saveClaimsResquest.getNumeroEndosoPoliza());

           throw new NotFoundException(new ErrorResponse("404-1" , desc));
       }

       return poliza;
    }


    /**
     * Obtiene la cidad a la que va asociado el siniestro. Si no lo encuentra devuelve un error.
     * @param saveClaimsResquest
     * @return
     */
    private Ciudad validateCiudad (SaveClaimsResquest saveClaimsResquest) {

        Ciudad ciudad = null;

        // No es obligado que venga el codigo dane
        if (saveClaimsResquest.getDisplayCodeDane() == null) {return null;}

        try {
            ciudad = ciudadRepository.findCiudad(saveClaimsResquest.getDisplayCodeDane());
        } catch (Exception exception) {
            exception.printStackTrace();
            String desc = "Se ha producido un error interno en el servicio.";
            throw new InternalErrorException(new ErrorResponse("500-2", desc));
        }

        if (ciudad == null) {
            String desc = String.format("No se ha podido encontrar la ciudad DANE con el display code %s" , saveClaimsResquest.getDisplayCodeDane());
            throw new NotFoundException(new ErrorResponse("404-1" , desc));
        }

        return ciudad;
    }


    /**
     * Comprueba que todos los campos necesarios vengan informados. Si no es asi devuelve un error.
     * @param saveClaimsResquest
     */
    private void validateInputRequest (SaveClaimsResquest saveClaimsResquest) {
        List<String> fieldsRequired = new ArrayList<>();
        String codeError = "";

        try {
            if (saveClaimsResquest.getNumeroPoliza() == null) {
                fieldsRequired.add("numeroPoliza");
                codeError = "400-1";
            }

            if (saveClaimsResquest.getNumeroEndosoPoliza() == null) {
                fieldsRequired.add("numeroEndosoPoliza");
                codeError = "400-2";
            }

            if (saveClaimsResquest.getNumeroCertificadoPoliza() == null) {
                fieldsRequired.add("numeroCertificadoPoliza ");
                codeError = "400-3";
            }

            if (saveClaimsResquest.getFechaDeclaracion() == null) {
                fieldsRequired.add("fechaDeclaracion");
                codeError = "400-4";
            }

            if (saveClaimsResquest.getFechaOcurrencia() == null) {
                fieldsRequired.add("fechaOcurrencia");
                codeError = "400-5";
            }

            if (saveClaimsResquest.getSituacionSiniestro() != null && saveClaimsResquest.getSituacionSiniestro().stream().filter(f -> f.getSituacionSiniestro().isEmpty()).count() != 0) {
                fieldsRequired.add("situacionSiniestro");
                codeError = "400-6";
            }

            if (saveClaimsResquest.getSituacionSiniestro() != null && saveClaimsResquest.getSituacionSiniestro().stream().filter(f -> f.getFechaSituacion() == null).count() != 0) {
                fieldsRequired.add("fechaSituacion");
                codeError = "400-7";
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            String desc = "Se ha producido un error interno en el servicio.";
            throw new InternalErrorException(new ErrorResponse("500-2", desc));
        }


        if (fieldsRequired.size() == 1) {
            String desc = String.format("El atributo '%s' no esta informado y no puede ser nulo" , fieldsRequired.get(0));
            throw new BadRequestException(new ErrorResponse(codeError , desc));
        } else if (fieldsRequired.size() > 1) {

            String fields = "";
            for (String field : fieldsRequired) { fields += String.format("'%s', ",field); }
            fields = fields.trim().substring(0 , fields.lastIndexOf(","));

            String desc = String.format("Los siguientes atributos tienen que venir informados [%s] y no pueden ser nulos" , fields);
            throw new BadRequestException(new ErrorResponse("400-0" , desc));
        }
    }
}