package com.everis.alondra.claims.config;

import org.springframework.stereotype.Component;

@Component
public class PopulateConfig {

}
