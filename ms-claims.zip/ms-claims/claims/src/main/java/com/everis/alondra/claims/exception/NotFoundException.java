package com.everis.alondra.claims.exception;

import com.everis.alondra.claims.client.response.ErrorResponse;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class NotFoundException extends RuntimeException  {

    public NotFoundException() {
    }

    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException(ErrorResponse errorResponse) {
        super(new Gson().toJson(errorResponse));
    }
}
