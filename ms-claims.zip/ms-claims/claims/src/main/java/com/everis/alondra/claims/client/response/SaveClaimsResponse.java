package com.everis.alondra.claims.client.response;

import org.springframework.web.bind.annotation.ResponseBody;

import java.util.UUID;

@ResponseBody
public class SaveClaimsResponse {

    UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
