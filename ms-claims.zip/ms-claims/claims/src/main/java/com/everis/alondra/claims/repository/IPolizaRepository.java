package com.everis.alondra.claims.repository;

import com.everis.alondra.claims.model.Poliza;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface IPolizaRepository extends JpaRepository<Poliza, UUID> {

    @Query(value="select e from Poliza e where e.numeroPoliza = ?1 and  e.numeroEndoso = ?2 and e.numeroCertificado = ?3")
    public Poliza findPoliza (Long numeroPoliza , Integer numeroEndoso , Integer numeroCertificado);
}
