package com.everis.alondra.claims.exception;


import com.everis.alondra.claims.client.response.ErrorResponse;
import com.google.gson.Gson;

public class BadRequestException extends RuntimeException {

    public BadRequestException() {}

    public BadRequestException(String message) {
        super(message);
    }

    public BadRequestException(ErrorResponse errorResponse) {
        super(new Gson().toJson(errorResponse));
    }
}
