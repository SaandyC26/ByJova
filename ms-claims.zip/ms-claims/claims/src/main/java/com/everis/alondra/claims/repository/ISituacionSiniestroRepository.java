package com.everis.alondra.claims.repository;

import com.everis.alondra.claims.model.Siniestro;
import com.everis.alondra.claims.model.SituacionSiniestro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ISituacionSiniestroRepository  extends JpaRepository<SituacionSiniestro, UUID> {
}
