package com.everis.alondra.claims.controller;

import com.everis.alondra.claims.client.ISiniestro;
import com.everis.alondra.claims.client.request.SaveClaimsResquest;
import com.everis.alondra.claims.client.response.SaveClaimsResponse;
import com.everis.alondra.claims.service.SiniestroService;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SiniestroController implements ISiniestro {

    @Autowired
    SiniestroService siniestroService;

    @Override
    public ResponseEntity<SaveClaimsResponse> saveClaims(SaveClaimsResquest saveClaimsResquest) {
        return ResponseEntity.status(HttpStatus.SC_OK).body(siniestroService.saveClaims(saveClaimsResquest));

    }
}
