package com.everis.alondra.claims.client;


import com.everis.alondra.claims.client.request.SaveClaimsResquest;
import com.everis.alondra.claims.client.response.SaveClaimsResponse;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/api/rest/v2/claims/")
public interface ISiniestro {

    @ApiOperation(value = "Servicio para obtener la información de un asegurado mediante su número de documentación.")
    @ApiResponses({
            @ApiResponse(code = 200, message = "OK."),
            @ApiResponse(code = 401, message = "No autorizado."),
            @ApiResponse(code = 403, message = "Prohibido."),
            @ApiResponse(code = 404, message = "No encontrado."),
            @ApiResponse(code = 500, message = "Error interno del servicio.")
    })
    @PostMapping("/saveClaims")
    public ResponseEntity<SaveClaimsResponse> saveClaims(@RequestBody SaveClaimsResquest saveClaimsResquest);
}
