package com.everis.alondra.claims.client.request;

import com.everis.alondra.claims.domain.SituacionSiniestroDomain;

import java.util.Date;
import java.util.List;

public class SaveClaimsResquest {

   private Long numeroPoliza;
   private Integer numeroCertificadoPoliza;
   private Integer numeroEndosoPoliza;
   private String idSiniestroMediador;
   private String idSiniestroEntidad;
   private Date fechaDeclaracion;
   private Date fechaOcurrencia;
   private String descripcionSiniestro;
   private String calle;
   private String causaPerdida;
   private Integer displayCodeDane;
   private List<SituacionSiniestroDomain> situacionSiniestro;

    public Long getNumeroPoliza() {
        return numeroPoliza;
    }

    public void setNumeroPoliza(Long numeroPoliza) {
        this.numeroPoliza = numeroPoliza;
    }

    public Integer getNumeroCertificadoPoliza() {
        return numeroCertificadoPoliza;
    }

    public void setNumeroCertificadoPoliza(Integer numeroCertificadoPoliza) {
        this.numeroCertificadoPoliza = numeroCertificadoPoliza;
    }

    public Integer getNumeroEndosoPoliza() {
        return numeroEndosoPoliza;
    }

    public void setNumeroEndosoPoliza(Integer numeroEndosoPoliza) {
        this.numeroEndosoPoliza = numeroEndosoPoliza;
    }

    public String getIdSiniestroMediador() {
        return idSiniestroMediador;
    }

    public void setIdSiniestroMediador(String idSiniestroMediador) {
        this.idSiniestroMediador = idSiniestroMediador;
    }

    public String getIdSiniestroEntidad() {
        return idSiniestroEntidad;
    }

    public void setIdSiniestroEntidad(String idSiniestroEntidad) {
        this.idSiniestroEntidad = idSiniestroEntidad;
    }

    public Date getFechaDeclaracion() {
        return fechaDeclaracion;
    }

    public void setFechaDeclaracion(Date fechaDeclaracion) {
        this.fechaDeclaracion = fechaDeclaracion;
    }

    public Date getFechaOcurrencia() {
        return fechaOcurrencia;
    }

    public void setFechaOcurrencia(Date fechaOcurrencia) {
        this.fechaOcurrencia = fechaOcurrencia;
    }

    public String getDescripcionSiniestro() {
        return descripcionSiniestro;
    }

    public void setDescripcionSiniestro(String descripcionSiniestro) {
        this.descripcionSiniestro = descripcionSiniestro;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCausaPerdida() {
        return causaPerdida;
    }

    public void setCausaPerdida(String causaPerdida) {
        this.causaPerdida = causaPerdida;
    }

    public Integer getDisplayCodeDane() {
        return displayCodeDane;
    }

    public void setDisplayCodeDane(Integer displayCodeDane) {
        this.displayCodeDane = displayCodeDane;
    }

    public List<SituacionSiniestroDomain> getSituacionSiniestro() {
        return situacionSiniestro;
    }

    public void setSituacionSiniestro(List<SituacionSiniestroDomain> situacionSiniestro) {
        this.situacionSiniestro = situacionSiniestro;
    }
}
