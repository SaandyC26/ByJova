package com.everis.alondra.claims.domain;

import java.util.Date;

public class SituacionSiniestroDomain {

    private Long numeroOrden;
    private String situacionSiniestro;
    private Date fechaSituacion;
    private String descripcionSituacion;

    public Long getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(Long numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public String getSituacionSiniestro() {
        return situacionSiniestro;
    }

    public void setSituacionSiniestro(String situacionSiniestro) {
        this.situacionSiniestro = situacionSiniestro;
    }

    public Date getFechaSituacion() {
        return fechaSituacion;
    }

    public void setFechaSituacion(Date fechaSituacion) {
        this.fechaSituacion = fechaSituacion;
    }

    public String getDescripcionSituacion() {
        return descripcionSituacion;
    }

    public void setDescripcionSituacion(String descripcionSituacion) {
        this.descripcionSituacion = descripcionSituacion;
    }
}
