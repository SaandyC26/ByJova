package com.everis.alondra.claims.exception;


import com.everis.alondra.claims.client.response.ErrorResponse;
import com.google.gson.Gson;

public class InternalErrorException extends RuntimeException {

    public InternalErrorException() {
        super();
    }

    public InternalErrorException(String message) {
        super(message);
    }

    public InternalErrorException (ErrorResponse errorResponse) {
        super(new Gson().toJson(errorResponse));
    }
}
