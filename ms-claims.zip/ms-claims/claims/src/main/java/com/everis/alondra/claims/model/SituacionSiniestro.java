package com.everis.alondra.claims.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "CUSTOM_SITUACION_SINIESTRO")
public class SituacionSiniestro {

    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SINIESTRO_ID")
    private Siniestro siniestro;

    @Column(name = "NUMERO_ORDEN")
    private Long numeroOrden;

    @Column(name = "SITUACION_SINIESTRO" , nullable = false)
    private String situacionSiniestro;

    @Column(name = "FECHA_SITUACION" , nullable = false)
    private Date fechaSituacion;

    @Column(name = "DESCRIPCION_SITUACION")
    private String descripcionSituacion;

    @Column(name = "VERSION")
    private Integer version;


    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Siniestro getSiniestro() {
        return siniestro;
    }

    public void setSiniestro(Siniestro siniestro) {
        this.siniestro = siniestro;
    }

    public Long getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(Long numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public String getSituacionSiniestro() {
        return situacionSiniestro;
    }

    public void setSituacionSiniestro(String situacionSiniestro) {
        this.situacionSiniestro = situacionSiniestro;
    }

    public Date getFechaSituacion() {
        return fechaSituacion;
    }

    public void setFechaSituacion(Date fechaSituacion) {
        this.fechaSituacion = fechaSituacion;
    }

    public String getDescripcionSituacion() {
        return descripcionSituacion;
    }

    public void setDescripcionSituacion(String descripcionSituacion) {
        this.descripcionSituacion = descripcionSituacion;
    }
}
