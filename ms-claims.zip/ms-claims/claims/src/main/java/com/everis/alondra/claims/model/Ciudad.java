package com.everis.alondra.claims.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "CUSTOM_PARAM_DANE")
@ApiModel(description = "Ciudad riesgo para propiedades y en hurto dirección del asegurado.")
public class Ciudad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "Identificador interno de la ciudad.")
    private UUID id;

    @Column(name = "DISPLAY_CODE")
    @ApiModelProperty(notes = "Código de la ciudad.")
    private Integer displayCode;

    @Column(name = "DESCRIPCION")
    @ApiModelProperty(notes = "Descripción de la ciudad.")
    private String descripcion;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Integer getDisplayCode() {
        return displayCode;
    }

    public void setDisplayCode(Integer displayCode) {
        this.displayCode = displayCode;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
