package com.everis.alondra.claims.repository;

import com.everis.alondra.claims.model.Ciudad;
import com.everis.alondra.claims.model.Poliza;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ICiudadRepository extends JpaRepository<Poliza, UUID> {

    @Query(value="select e from Ciudad e where e.displayCode = ?1")
    public Ciudad findCiudad (Integer displayCode);
}
