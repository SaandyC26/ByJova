package com.everis.alondra.claims.model;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "CUSTOM_POLIZA")
public class Poliza {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "Unique identifier." , required = true)
    private UUID id;

    @Column(name = "NUMERO_POLIZA" , nullable = true)
    private Long numeroPoliza;

    @Column(name = "NUMERO_ENDOSO" , nullable = true)
    private Integer numeroEndoso;

    @Column(name = "NUMERO_CERTIFICADO" , nullable = true)
    private Integer numeroCertificado;

    @Column(name = "FECHA_INICIO" , nullable = true)
    private Date fechaInicio;

    @Column(name = "FECHA_FIN" , nullable = true)
    private Date fechaFin;

    @Column(name = "VERSION_POLIZA" , nullable = true)
    private Integer versionPoliza;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


    public Integer getNumeroEndoso() {
        return numeroEndoso;
    }

    public void setNumeroEndoso(Integer numeroEndoso) {
        this.numeroEndoso = numeroEndoso;
    }

    public Integer getNumeroCertificado() {
        return numeroCertificado;
    }

    public void setNumeroCertificado(Integer numeroCertificado) {
        this.numeroCertificado = numeroCertificado;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public Integer getVersionPoliza() {
        return versionPoliza;
    }

    public void setVersionPoliza(Integer versionPoliza) {
        this.versionPoliza = versionPoliza;
    }

    public Long getNumeroPoliza() {
        return numeroPoliza;
    }

    public void setNumeroPoliza(Long numeroPoliza) {
        this.numeroPoliza = numeroPoliza;
    }
}
