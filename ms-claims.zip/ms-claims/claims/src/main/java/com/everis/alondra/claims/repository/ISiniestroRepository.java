package com.everis.alondra.claims.repository;

import com.everis.alondra.claims.model.Siniestro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ISiniestroRepository extends JpaRepository<Siniestro , UUID> {

}
