module.exports = {
    parser: "@typescript-eslint/parser", // Specifies the ESLint parser
    extends: [
        //"plugin:react/recommended", // Uses the recommended rules from @eslint-plugin-react
        //"plugin:@typescript-eslint/recommended", // Uses the recommended rules from @typescript-eslint/eslint-plugin
        "prettier",
        // "plugin:prettier/recommended" // Enables eslint-plugin-prettier and eslint-config-prettier. This will display prettier errors as ESLint errors. Make sure this is always the last configuration in the extends array.
    ],
    parserOptions: {
        ecmaVersion: 2018, // Allows for the parsing of modern ECMAScript features
        sourceType: "module", // Allows for the use of imports
        ecmaFeatures: {
            jsx: true // Allows for the parsing of JSX
        }
    },
    rules: {
        'prettier/prettier': 0,
        // Place to specify ESLint rules. Can be used to overwrite rules specified from the extended configs
        // e.g. "@typescript-eslint/explicit-function-return-type": "off",
       // "@typescript-eslint/explicit-function-return-type": [
       //     "error",
        //    { "allowTypedFunctionExpressions": false }
       // ],
        "lines-around-comment": [
            "error",
            {
              "beforeBlockComment": false,
              "afterBlockComment": false,
              "beforeLineComment": false,
              "afterLineComment": false,
              "allowBlockStart": false,
              "allowBlockEnd": false,
              "allowObjectStart": false,
              "allowObjectEnd": false,
              "allowArrayStart": false,
              "allowArrayEnd": false
            }
          ]
    },
    settings: {
        react: {
            version: "detect" // Tells eslint-plugin-react to automatically detect the version of React to use
        }
    }
};