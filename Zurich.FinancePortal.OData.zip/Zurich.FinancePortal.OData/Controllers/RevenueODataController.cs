﻿namespace Zurich.FinancePortal.OData.Controllers
{
    using Application;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.OData.Query;
    using Microsoft.Extensions.DependencyInjection;
    using System;

    [Authorize]
    public sealed class RevenueODataController : ControllerBase
    {
        #region --- REFERENCES ---

        private readonly IRevenueODataRepository _revenueODataRepository;

        #endregion

        #region --- CONSTRUCTORS ---

        public RevenueODataController(IServiceProvider services)
        {
            _revenueODataRepository = services.GetRequiredService<IRevenueODataRepository>();
        }

        #endregion

        #region --- PUBLIC METHODS ---

        [EnableQuery]
        public IActionResult Get()
        {
            var query = _revenueODataRepository.GetQueryable();
            return Ok(query);
        }

        #endregion
    }
}
