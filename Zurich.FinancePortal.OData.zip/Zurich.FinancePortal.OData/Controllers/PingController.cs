﻿namespace Zurich.FinancePortal.OData
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public sealed class PingController : ControllerBase
    {
        #region --- PUBLIC METHODS ---

        [HttpGet]
        [AllowAnonymous]
        public Task<IActionResult> GetAsync() =>
            Task.FromResult((IActionResult)StatusCode(StatusCodes.Status200OK, $"Pong!{System.Environment.NewLine}"));

        #endregion
    }
}
