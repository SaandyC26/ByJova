﻿namespace Zurich.FinancePortal.OData
{
    using DevOps.CrossCutting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using System.Diagnostics;
    using System.Threading.Tasks;

    public sealed class PerformanceAndLoggingMiddleware
    {
        #region --- PROPERTIES ---

        private readonly int _longRunningExecutionElapsedMilliseconds = 10000;

        #endregion

        #region --- REFERENCES ---

        private readonly RequestDelegate _next;

        private readonly ILogger<PerformanceAndLoggingMiddleware> _logger;

        #endregion

        #region --- CONSTRUCTORS ---

        public PerformanceAndLoggingMiddleware(RequestDelegate next, ILogger<PerformanceAndLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task Invoke(HttpContext context)
        {
            // Logger
            using var loggerActionScope = _logger.BeginActionScope(context.Request.Path.ToString());
            using (var loggerIRequestScope = _logger.BeginIRequestScope(new { Query = context.Request.QueryString.ToString() }))
            {
                _logger.LogInformation("Starting execution.");
            }
            // Stopwatch
            var stopwatch = Stopwatch.StartNew();
            // Execution
            await _next(context).ConfigureAwait(false);
            // Logger
            using var loggerStopwatchScope = _logger.BeginStopwatchScope(stopwatch);
            if (stopwatch.ElapsedMilliseconds <= _longRunningExecutionElapsedMilliseconds) _logger.LogInformation("Finishing execution.");
            else _logger.LogInformation("Finishing long running execution.");
        }

        #endregion
    }
}
