namespace Zurich.FinancePortal.OData
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using DevOps.CrossCutting;
    using Microsoft.Extensions.Logging;
    using Infra.Persistence.Database;
    using Microsoft.AspNetCore.OData;
    using Microsoft.OData.Edm;
    using Microsoft.OData.ModelBuilder;
    using Application;
    using Domain;
    using Microsoft.AspNetCore.Authentication;

    public class Startup
    {
        #region --- PROPERTIES ---

        private const string _allowAny = "_allowAnyOrigin";

        #endregion

        #region --- REFERENCES ---

        public IConfiguration Configuration { get; }

        #endregion

        #region --- CONSTRUCTORS ---

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        #endregion

        #region --- PUBLIC METHODS ---

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // CORS
            services.AddCors(options =>
            {
                options.AddPolicy(_allowAny, builder => builder.SetIsOriginAllowed(_ => true).AllowAnyMethod().AllowAnyHeader().AllowCredentials().WithExposedHeaders("Content-Disposition"));
            });

            ConsoleExtensions.WriteLine(LogLevel.Information, nameof(Startup), nameof(ConfigureServices), value: "CORS.");
            // Persistence - Database
            services.AddPersistenceDatabase(Configuration.GetSection(nameof(PersistenceConfiguration)));
            ConsoleExtensions.WriteLine(LogLevel.Information, nameof(Startup), nameof(ConfigureServices), value: $"Persistence - PostgreSql.");
            // Authentication
            services.AddAuthentication("BasicAuthentication")
                .AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>("BasicAuthentication", null);
            // Api Controllers
            services
                .AddControllers()
                .AddOData(options => options.Select().Filter().Count().EnableQueryFeatures().OrderBy().SkipToken().AddRouteComponents(nameof(OData).ToLowerInvariant(), GetEdmModel()));

            ConsoleExtensions.WriteLine(LogLevel.Information, nameof(Startup), nameof(ConfigureServices), value: "Controllers.");
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // Development && Staging
            if (!env.IsProduction()) app.UseDeveloperExceptionPage();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseMiddleware<PerformanceAndLoggingMiddleware>();
            app.UseEndpoints(endpoints => endpoints.MapControllers());
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static IEdmModel GetEdmModel()
        {
            var modelBuilder = new ODataConventionModelBuilder();
            modelBuilder.EntitySet<RevenueODataDto>($"{nameof(Revenue)}{nameof(OData)}");
            modelBuilder.EntityType<RevenueODataDto>().Property(x => x.PlannedStartDate).AsDate();
            modelBuilder.EntityType<RevenueODataDto>().Property(x => x.PlannedEndDate).AsDate();
            return modelBuilder.GetEdmModel();
        }

        #endregion
    }
}
