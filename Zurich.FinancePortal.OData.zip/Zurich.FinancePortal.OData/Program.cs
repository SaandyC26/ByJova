namespace Zurich.FinancePortal.OData
{
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using System;
    using System.IO;
    using System.Threading.Tasks;
    using DevOps.CrossCutting;

    public class Program
    {
        #region --- REFERENCES ---

        private static IConfiguration Configuration { get; } = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddEnvironmentVariables()
            .Build();

        #endregion

        #region --- CONSTRUCTORS ---

        private Program() { }

        #endregion

        #region --- PUBLIC METHODS ---

        public static async Task Main(string[] args)
        {
            // Create Host
            var host = CreateHostBuilder(args).Build();
            // Init Host
            await InitHost(host).ConfigureAwait(false);
            // Run Host
            await host.RunAsync().ConfigureAwait(false);
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static Task InitHost(IHost host)
        {
            // Create Scope
            using var scope = host.Services.CreateScope();
            var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
            logger.LogInformation($"{nameof(OData)} Starting.");
            logger.LogInformation($"{nameof(OData)} Running.");
            return Task.CompletedTask;
        }

        private static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
                .ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    if (bool.TryParse(Environment.GetEnvironmentVariable("ConsoleLoggerProvider"), out var consoleLoggerProvider) && consoleLoggerProvider) logging.AddConsoleLogger(logging.Services, Configuration.GetSection(nameof(ConsoleLoggerConfiguration)));
                    if (bool.TryParse(Environment.GetEnvironmentVariable("TeamsLoggerProvider"), out var teamsLoggerProvider) && teamsLoggerProvider) logging.AddTeamsLogger(logging.Services, Configuration.GetSection(nameof(TeamsLoggerConfiguration)));
                });

        #endregion
    }
}
