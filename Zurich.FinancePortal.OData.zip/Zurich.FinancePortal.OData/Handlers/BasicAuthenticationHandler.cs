﻿namespace Zurich.FinancePortal.OData
{
    using DevOps.CrossCutting;
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Microsoft.Net.Http.Headers;
    using System;
    using System.Net.Http.Headers;
    using System.Security.Claims;
    using System.Text;
    using System.Text.Encodings.Web;
    using System.Threading.Tasks;

    public sealed class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        #region --- CONSTRUCTORS ---

        public BasicAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock) : base(options, logger, encoder, clock)
        { }

        #endregion

        #region --- PROTECTED METHODS ---

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            // skip authentication if endpoint has [AllowAnonymous] attribute
            var endpoint = Context.GetEndpoint();
            if (endpoint?.Metadata?.GetMetadata<IAllowAnonymous>() != null) return Task.FromResult(AuthenticateResult.NoResult());
            if (!Request.Headers.ContainsKey(HeaderNames.Authorization)) return Task.FromResult(AuthenticateResult.Fail($"Missing {HeaderNames.Authorization} Header."));
            var odataUsername = Environment.GetEnvironmentVariable("ODATA_USERNAME");
            var odataPassword = Environment.GetEnvironmentVariable("ODATA_PASSWORD");
            try
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                var username = credentials[0];
                var password = credentials[1];
                if (!StringExtensions.EqualsICIC(username, odataUsername) || !StringExtensions.EqualsICIC(password, odataPassword)) return Task.FromResult(AuthenticateResult.Fail("Invalid Username or Password."));
            }
            catch
            {
                return Task.FromResult(AuthenticateResult.Fail($"Invalid {HeaderNames.Authorization} Header."));
            }

            var claims = new[] {
                new Claim(ClaimTypes.NameIdentifier, odataUsername),
                new Claim(ClaimTypes.Name, odataUsername),
            };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);
            return Task.FromResult(AuthenticateResult.Success(ticket));
        }

        #endregion
    }
}
