#!/bin/bash
cd ./../app
case $1 in
  (true)    npm install && npm start;;
  (false)   npm start;;
esac