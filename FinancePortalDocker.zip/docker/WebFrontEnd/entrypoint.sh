#!/bin/sh
# Replace env vars in JavaScript files
echo "Replacing env vars in JS..."
for file in /usr/share/nginx/html/static/js/main.*.chunk.js;
do
	echo "Processing $file ..."
	if [ ! -f $file.tmpl.js ]; then
		cp $file $file.tmpl.js
	fi

	envsubst '$REACT_APP_API_LOGIN_ENDPOINT,$REACT_APP_API_ENDPOINT,$REACT_APP_MODE,$REACT_APP_HEADER' < $file.tmpl.js > $file
done
echo "Replaced env vars in JS."
nginx -g 'daemon off;'