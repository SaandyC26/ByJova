---
date: "2021-04-10"
title: "FINPO User Manual"
author: "Raul Alares"
version: 1.0
toc: false
draft: false
html:
  embed_local_images: true
  embed_svg: true
  offline: true
  toc: true

print_background: false
---

# Financial Portal
[`Financial Portal - https://finance-portal.zurich.com/`](https://finance-portal.zurich.com/)

## Introduction
**Financial portal** (FINFO) is a tool that has been designed to replace the Demand Files in *TCoE* department. These file have been historically a source of issues specially because the simultaneous access of several users. 
FINPO is Web based with a similar look&feel to other applications in the department. It allows simultaneous access for all the users and although all the users can change the information contained in the application we recommend that you change uniquely the information that you are owner. Next versions will contain the necessary security to avoid that only owner of a line can change the content of it.
Although some information as Customers, Cost Centers, Projects, etc can only be modified by administrators, project managers will be able to perform their day to day activities autonomously.
## Application Screens
We are going to do a quick review of the different screens that you are going to use most of the time and indicate what are the main buttons that you will find in each screen. If for some button there is not any info, don't worry, it will be detailed later.

### Login
![Login Page](./Assets/Login_Page.png "Login Page")

### General Page
All the pages in application follow a general distribution that you can see here.
![General Page](./Assets/General_Page.png "General Page Distribution")

### Home Page
![Home Page](./Assets/Home_Page.png "Home Page")

### Demand Page
![Demand Page](./Assets/Demand_Page.png "Demand Page")

## Basic Use Cases for "Collaborators"
We are going to review the most common use cases in the tool. Other ones will be added in the next versions of this manual.
### Login
* Go to login screen [`https://finance-portal.zurich.com/login`](https://finance-portal.zurich.com/login)
* [Login page](#login) has to appear
* Introduce your GITDIR user and password in corresponding text boxes.
* Click in "LOGIN" button
* [Home page](#home-page) has to appear.

### Logout
* Click in *User options* button. ![User Options Button](Assets/User_Options_Button.png)
* Click in *Log Out*. ![Log out option](Assets/log_out_option.png)
### Customize your revenues screen
Revenues screen is highly customizable in order to cover the necessities of each user, from those that only use a couple of rows till those that use dozens.
#### Saving / Resetting your screen configuration
First of all we need to clarify that the custom view you will generate can be stored in your profile and you will be recovered each time that you come back to application. The parameters that you can configure in your custom view are the visibility of the columns, column width, column position, sort into each column and filter of each column. Every time that you change some of this parameters the button 
![Save Grid Setting](Assets/Save_Grid_Setting_Button.png) 
will appear and when you click on it, setting will be stored in you profile and button will disappear.
When you want to remove the configuration of some of these parameters you can do it using the button
![Reset Grid Settings](Assets/Reset_Grid_Setting_Button.png)
Once you click in the button a new menu will appear and you will be able to:
* Reset filters
* Reset sorting
* Reset column order
* Reset column width
* Reset column visibility
* Reset all
#### Expand / Collapse a row
You have the possibility of hiding columns but this doesn't mean that you cannot see them. When you expand a row you are going to see, in separate panels, the hidden columns and the monetary information of each month grouped by quarter.
* To expand a row you only have to click on ![Expand button](Assets/Revenues_Expand_Button.png) at the beginning of the row you want to expand
* To collapse a expanded row you have to click on ![Collapse Button](Assets/Revenues_Collapse_Button.png) at the beginning of the row you have previously expanded
#### Hide/Show columns
Not all of you need the same information in the screen and besides this information can vary along the time, for example the months you want to see in the table, then the possibility of hiding columns is in place. Hidden columns don't disappear and you can always look them if you expand the row. To hide the columns you desire you have to:
* click on **Hide** button
* A new menu with the name of all the columns will appear. Those that are hidden switch will be activated.
* Activate / deactivate the associated switch as per your necessities.   
#### Column position order
You can decide the order where the different columns appear. 
* Left Click and maintain over the column header
* Move the column at the position you want
* Release left click
#### Column width
The width of a column can be modified as per your necessities.
* Hover on the right area of the column header you want to resize till cursor change to ![Column Width Cursor](Assets/Column_Width.png)
* Left click and maintain
* Move to the width tou desire and release the left button
#### Column sort
You can sort the revenues table for one or various columns.
* Click on header of the column you want to sort.
* First time table will be ordered from A-Z in this column
* Second time table will be ordered from Z-A in this column
* Third time, sort will be reset
In case you click in several columns the sort will follow the same principles.
#### Column Filter
Depending on the type of column you can find two types of filters.
* **DropDown filter** that is used in those columns that contains a limited and defined value for the entry. Normally you will identify this kind of entries with a DropDown. In this case the filter has a textbox associated where you can enter a search string and values in the dropdown will be shown only if contain this string. *Filter contains*
![DropDown Filter](Assets/DropDownFilter.png)
* **Free Text Filter** that is used for those columns that are free text entries. You can choose several types of search (*Contains*, *Start with*, *Ends with*, etc)
![Free Text Filter](Assets/FreeTextFilter.png)

### Add new entries to application
All of you belong to "Collaborators" group that allows you to add information about your projects to the application. This can be done in two ways: using application to create them manually or using the possibility of importing excel files.
In both cases some of the information you have to fill (as in GUI as in the columns of Excel) is mandatory and has had to be created previously in the application, for example: customer, project, cost centers, etc. In case you try to create a new entry with invalid values of some field an error will be raised.

#### Create new entry using the application 
![](Assets/revenues_create_entry.png)
* Go to [Demand Screen](#demand-page) [`https://finance-portal.zurich.com/all`](https://finance-portal.zurich.com/all)
* Click in (+) icon over the demand table
* A "New entry" form will appear.
* Fill all the mandatory fields with the required information
* Fill the financial data. Please take into account that some of the months can be blocked and you are not going to be able to add any value there. See [FAQ](#faq) for more information
* Click in "CREATE"
#### Create a new entry using Excel import.
Excel import file has to have a very specific format and information then we are going to show you the best option to get the last version of the excel and how to import it
* Go to [Demand Screen](#demand-page) [`https://finance-portal.zurich.com/all`](https://finance-portal.zurich.com/all)
* Get excel file
    * Click in "EXPORT TO EXCEL" button
    * New excel will be downloaded in your computer.
    * The format of this file is the correct one to import information
* Enter in excel and delete all the unnecessary rows that you have exported.
* Fill all the mandatory fields in all rows you need. See [FAQ](#faq) for more information
* Save the excel file
* Click in "IMPORT FROM EXCEL" button
* Select the excel file you have modified and click in Accept button 
* The new entries have to appear in demand table.

### Modify entries in the application.
As "Collaborators" you can modify information about your projects contained in your application. This can be done in two ways: using applciation to create them mmanually or using the possibility of importing excel files.
As we have commented previously, in this version of application there is not restrictions to modify the information that application contains, then please be careful to change only entries which you are owner.

#### Edit an entry using the application
![Edit Entry Form](Assets/revenues_edit_form.png  "Edit Entry Form")

* Go to [Demand Screen](#demand-page) [`https://finance-portal.zurich.com/all`](https://finance-portal.zurich.com/all)
* Click in (Pencil) icon at the beginning of the table row you want to edit
* A "Edit Entry" form will appear.
* Fill all the mandatory fields changing the required information
* Change the financial data if it is necessary. Please take into account that some of the months can be blocked and you are not going to be able to change any value there. See [FAQ](#faq) for more information
* Click in "UPDATE"
#### Edit entries using Excel import.
* Go to [Demand Screen](#demand-page) [`https://finance-portal.zurich.com/all`](https://finance-portal.zurich.com/all)
* Filter the columns you need to modify
* Click in "EXPORT TO EXCEL" button
* New excel will be downloaded in your computer.
* The format of this file is the correct one to import information
* Enter in excel and modify the rows you need to change.
* Save the excel file
* Click in "IMPORT FROM EXCEL" button
* Select the excel file you have modified and click in Accept button 
* The new entries have to appear in demand table.
### Manage your comments in demand entries
All the users can add comments to the demand table entries, so you can establish a communication for example with Financial Admins. Each comment belong to an entry (row in demand table) and application trace all of them.
There are a special type of comments that are generated automatically when someone change an entry in the demand table, they are marked as "\*auto\* Updated" and as we are going to see are treated in a different way.
Comments are shown as in application user interfaces as in Excel file when you export a file.
#### View the user comments in application
Comments are shown in the application when you expand a row just at the end
![Comments in demand row expand](Assets/revenues_expand_comments.png "Comments in demand row expand")
Only last 3 are shown. If you want to see all the comments you have to "Show All"
#### View all the comments in application
As commented in previous point to see all the comments for a demand entry you have to use the "Show All" button in expanded demand row. When you click in the button a new popup appears showing all the comments belonging to that row.
![Show all comments](Assets/revenues_comments_showall.png "Show All Comments for a Demand Row")
Besides the show all button shows the automatic comments too. They are marked as "\*auto\* Updated" then you can have a clear story of the entry.
On the other hand the table that shows the comments allows you to sort by column and filter by column.
#### Add comments in application
When you are using the application you have two possibilities to add comments to a demand row:
1. From the expanded row clicking on "Add Comment" button
![Comments in demand row expand](Assets/revenues_expand_comments.png "Comments in demand row expand")
2. From row edition form clicking on "Add Comment" button
![Edit Entry Form](Assets/revenues_edit_form.png  "Edit Entry Form")

In any case when you click the "Add Comment" button a new popup appears and you can there add your comment (multiline accepted.)
![Add Revenues Comment](Assets/revenues_comment_add.png "Add Revenues Comment")
#### View and Add Comments in Excel
In the same way you can see the comments in application, you can see them in the exported Excel files. There, automatic and manual comments are in separated columns.
![Comment in Demand Exported Excel](Assets/revenues_comments_excel.png "Comment in Demand Exported Excel") 
To add a new comment in a demand row you have to write the comment in the corresponding row of "New Comment" column (Only the comment, don't add the date or owner that will be added automatically when you import it). Then import the file.
## Processes
### Request access
Please send a mail to mariam.abdoullaeva@zurich.com or sofia.marques@zurich.com indicating the user that require access
### Add Customers, Projects or Cost Centers
Please send a mail to mariam.abdoullaeva@zurich.com or sofia.marques@zurich.com indicating the information you need to add.
## FAQ
### Why some of the month values in creation or edition form appear grey?
Once a month is billed to the customers, not changes in this month is allowed. Administrators will block this month and no changes can be done.
### What are the mandatory fields in excel?
Mandatory fields are the same that we have in application GUI. In the next version of application the columns will be marked as mandatory.
### Where are my columns?
In version 1.1.0 we have added the ability to hide/show columns. You can use the **HIDE COLUMNS** button to select the columns you need to show in the table. All the columns that are hidden can be seen when you [expand the corresponding row](#hideshow-columns)
## Knowledged issues
No knowledged issues