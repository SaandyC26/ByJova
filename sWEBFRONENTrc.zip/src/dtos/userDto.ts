import { RoleDto as role } from './roleDto';
import { ProjectDto as project } from './masterDataDto';

export interface UserDto {
    delete: boolean;
    new: boolean;
    id: number;
    name: string;
    samAccountName: string;
    roles: role[];
    projects: project[];
}

export interface UserUpdateResult {
    errors: string[],
    user : UserDto
}