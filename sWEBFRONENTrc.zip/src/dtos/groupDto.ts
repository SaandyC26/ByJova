import { UserDto as user } from './userDto';

export interface GroupDto {
    delete: boolean;
    new: boolean;
    id: number;
    name: string;    
    users: user[];
    
}

export interface GroupUpdateResult {
    errors: string[],
    user : GroupDto
}