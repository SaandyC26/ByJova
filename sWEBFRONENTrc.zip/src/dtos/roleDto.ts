import { FeatureDto as feature } from './masterDataDto';

export interface RoleDto {
    id: number;
    name: string;
    feature: feature[];
}