export interface PageDto<T> {
    data: T[];
    total: number;
}
