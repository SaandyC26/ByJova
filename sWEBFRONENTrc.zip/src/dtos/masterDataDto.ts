export interface ProjectDto {
    id: number;
    name: string;
}

export interface FeatureDto {
    id: number;
    name: string;
}