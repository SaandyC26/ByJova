import {createSlice} from "@reduxjs/toolkit";

const tokensSlice = createSlice({
    name: 'tokensData',
    initialState: {
        tokenId: null,
        refreshToken: null,
        tokenLife: null,
        onRefresh: false,
    },
    reducers:{
        setToken(state,action){
            state.tokenId = action.payload;
        },
        setRefresh(state,action){
            state.refreshToken = action.payload;
        },
        setTokenLife(state,action){
            state.tokenLife = action.payload;
        }
        ,
        setOnRefresh(state,action){
            state.onRefresh = action.payload;
        }
    }
})

export const {setToken,setRefresh,setTokenLife,setOnRefresh} = tokensSlice.actions;
export default tokensSlice.reducer;