import {combineReducers} from "@reduxjs/toolkit";
import userData from './user';
import tokenData from './tokens';
import MasterData from './MasterData';
import Theme from './theme';

export default combineReducers({
    userData,
    tokenData,
    MasterData,
    Theme

})