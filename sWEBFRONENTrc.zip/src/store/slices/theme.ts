import {createSlice} from "@reduxjs/toolkit";

const userSlice = createSlice({
    name: 'Theme',
    initialState: {
        Corporate:{
            blue: '#186eb4', // #91bfe3
            darkBlue: '#2167AE', // '#003399'
            lightBlue: '#91BFE3', // #e7eceb
            paleBlue: '#DDE4E3', // #f5f7f7
            veryDarkBlue: '#003399'
        }      
    },
    reducers:{
        setCorporateBlue(state,action){
            //state.Corporate.blue = action.payload; // #2167AE
        },
        setCorporateDarkBlue(state,action){
            //state.Corporate.darkBlue = action.payload;
        },
        setCorporateLightBlue(state,action){
            //state.Corporate.lightBlue = action.payload;
        }, 
        setCorporatePaleBlue(state,action){
            //state.Corporate.paleBlue = action.payload; //#DDE4E3
        }, 
        setCorporateVeryDarkBlue(state,action){
            //state.Corporate.veryDarkBlue = action.payload; //#006
        },      
    }
})

export const {setCorporateBlue,setCorporateDarkBlue,setCorporateLightBlue,setCorporatePaleBlue} = userSlice.actions;
export default userSlice.reducer;