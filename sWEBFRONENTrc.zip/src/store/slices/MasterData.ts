import {createSlice} from "@reduxjs/toolkit";

const tokensSlice = createSlice({
    name: 'MasterData',
    initialState: {
        Table: {Request: 'LineOfBusiness', Name: 'Line of business'},
        
    },
    reducers:{
        setTable(state,action){
            state.Table = action.payload;
        },
       
    }
})

export const {setTable} = tokensSlice.actions;
export default tokensSlice.reducer;