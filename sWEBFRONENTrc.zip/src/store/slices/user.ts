import {createSlice} from "@reduxjs/toolkit";


const OriginalDemandSettings = {    
    Filters: { 
        filter:{
            logic: 'and',
            filters: [
                {operator: 'neq',
                field: 'year',
                value: '0'}
            ]
         },                
        sort: [
            {field:"year",dir:"desc"}
        ],
        take: 15, 
        skip: 0
       

    },               
    Columns: [ 
        {field: 'none' ,width: 40, orderIndex : 0, Show: true},
        {field: 'year', width: 60, orderIndex : 1, Show: true},
        {field: 'lineOfBusinessName', width: 190,orderIndex : 2, Show: true},
        {field: 'customerName', width: 290,orderIndex : 3, Show: true},
        {field: 'customerFunctionName', width: 290,orderIndex : 5, Show: true},        
        {field: 'projectName', width: 270,orderIndex : 6, Show: true},
        {field: 'projectType', width: 100,orderIndex : 7, Show: true},
        {field: 'typeOfServiceName', width: 70,orderIndex : 7, Show: true},
        {field: 'serviceDescription', width: 150,orderIndex : 8, Show: true},
        {field: 'chargingModelCode', width: 80,orderIndex : 9, Show: true},
        {field: 'businessUnitCode', width: 110,orderIndex : 10, Show: true},
        {field: 'productName', width: 250,orderIndex : 11, Show: true},
        {field: 'currencyCode', width: 85,orderIndex : 12, Show: true},
        {field: 'planLC', width: 125,orderIndex : 13, Show: true},
        {field: 'transferLC', width: 125,orderIndex : 13.1, Show: true},
        {field: 'differenceLC', width: 125,orderIndex : 13.2, Show: true},
        {field: 'fyfclc', width: 125,orderIndex : 14, Show: true},
        {field: 'fyfcchf', width: 125,orderIndex : 15, Show: true},
        {field: 'fyfcchfvat', width: 125,orderIndex : 16, Show: true},
        {field: 'customerCostCenterCode', width: 110,orderIndex : 17, Show: true},
        {field: 'ownerProjectManagerName', width: 140,orderIndex : 18, Show: true},
        {field: 'groupOwnerName', width: 140,orderIndex : 19, Show: true},
        {field: 'internalCostCenterPerCostCode', width: 110,orderIndex : 20, Show: true},
        {field: 'internalCode', width: 110, orderIndex : 21, Show: true},
        {field: 'testingToolName', width: 290, orderIndex : 22, Show: true},
        {field: 'testingToolProjectName', width: 290, orderIndex : 23, Show: true},
        {field: 'testingToolDetailedInfo', width: 290, orderIndex : 24, Show: true},
        {field: 'plannedStartDate', width: 140, orderIndex : 25, Show: true},
        {field: 'plannedEndDate', width: 140, orderIndex : 26, Show: true},
        {field: 'projectPlanningItAppsIds', width: 290, orderIndex : 27, Show: true},
        {field: 'projectPlanningItAppsNames', width: 290, orderIndex : 28, Show: true},
        {field: 'january.amount', width: 90, orderIndex : 29, Show: true},
        {field: 'february.amount', width: 90, orderIndex : 30, Show: true},
        {field: 'march.amount', width: 90, orderIndex : 31, Show: true},
        {field: 'april.amount', width: 90, orderIndex : 32, Show: true},
        {field: 'may.amount', width: 90, orderIndex : 33, Show: true},
        {field: 'june.amount', width: 90, orderIndex : 34, Show: true},
        {field: 'july.amount', width: 90, orderIndex : 35, Show: true},
        {field: 'august.amount', width: 90, orderIndex : 36, Show: true},
        {field: 'september.amount', width: 90, orderIndex : 37, Show: true},
        {field: 'october.amount', width: 90, orderIndex : 38, Show: true},
        {field: 'november.amount', width: 90, orderIndex : 39, Show: true},
        {field: 'december.amount', width: 90, orderIndex : 40, Show: true}
    ]                  
        
}

const userSlice = createSlice({
    name: 'userData',
    initialState: {      
        News: {Show:false, Msg :'test', HideUntilNext: true},    
        Error: {Show:false, Msg: '', Mode: 'GoBack'},
        userName: null,  
        permissions: new Array, 
        Static:{
            MonthBlockerChanged: false
        },
        filters: <any> {
            'barcelona': new Array, 
            'rebookings': null} ,
        sidebarDeploy: "Open" ,
        DemandSettings: {...OriginalDemandSettings}, 
        OriginalDemandSettings: OriginalDemandSettings, 
        ShowSave : false ,
        DemandRestrictions : new Array  ,
        lang: "Eng" ,
        Petitions: new Array,
        Cache:{
            TicketDetail: new Array
        },
        pendingCalls: new Array
    },
    reducers:{
        Static_Change_MonthBlocker(state,action){
            state.Static.MonthBlockerChanged = action.payload
        },
        PendingCalls_Clear(state,action){
            state.pendingCalls = new Array
        },
        PendingCalls_Add(state,action){
            let oldList = [...state.pendingCalls];
            oldList.push(action.payload);
            console.log(oldList)
            state.pendingCalls = oldList;
        },
        PendingCalls_Remove(state,action){
            console.log('remove')
        },
        CacheAdd(state,action){
            let oldCache:any = {...state.Cache}
            oldCache[action.payload.Name].push(action.payload.Item)
            state.Cache = oldCache;

            let oldPending =  [...state.pendingCalls].filter(function( obj ) {
                return obj.Id !== action.payload.Item.Id;
            });

            state.pendingCalls = oldPending
        },
        CacheRemove(state,action){
            let oldCache:any = {...state.Cache};            
            oldCache[action.payload.Name] = oldCache[action.payload.Name].filter(function( obj:any ) {
                return obj.Id !== action.payload.Item.Id;
            });
            state.Cache = oldCache;
        },
        setRestrictions(state,action){
            state.DemandRestrictions = action.payload
        },
        saveGrid(state,action){
            state.DemandSettings = action.payload;  
            state.ShowSave = false;          
        },       
        setUser(state,action){
            state.userName = action.payload;
        }, 
        setFilters(state,action){
            state.filters[action.payload.key] = action.payload.value;
        },
        setPermissions(state,action){
            state.permissions = action.payload;
        },
        setSidebarStatus(state,action){
            state.sidebarDeploy = action.payload;
        },       
        setError(state, action){
            let Oldvalue = state.Error;
            Oldvalue.Show = action.payload.Show;
            if(action.payload.Msg !== ''){Oldvalue.Msg = action.payload.Msg}
            if(action.payload.Mode === ''){Oldvalue.Mode = 'GoBack'}else {Oldvalue.Mode = action.payload.Mode}            
            state.Error = Oldvalue
        } , 
        setNews(state, action){
            let Oldvalue = state.News;
            Oldvalue.Show = action.payload.Show;
            if(action.payload.Msg !== ''){Oldvalue.Msg = action.payload.Msg} 
            if(action.payload.HideUntilNext !== ''){Oldvalue.HideUntilNext = action.payload.HideUntilNext}                      
            state.News = Oldvalue
        },
        removeHiddenColumn(state,action){  
            state.DemandSettings.Columns.find((el:any) => el.field === action.payload)!.Show = true;
            state.ShowSave = true;
            
            
        },
        addHiddenColumn(state,action){
            state.DemandSettings.Columns.find((el:any) => el.field === action.payload)!.Show = false;
            state.ShowSave = true;
        },

        
    }
})

export const {Static_Change_MonthBlocker,CacheRemove,PendingCalls_Remove,PendingCalls_Add,PendingCalls_Clear,CacheAdd,setRestrictions,setUser,setPermissions,setFilters,setSidebarStatus,saveGrid,setError,setNews,removeHiddenColumn,addHiddenColumn} = userSlice.actions;
export default userSlice.reducer;