import React from 'react';
import ReactDOM from 'react-dom';
import { createRoot } from 'react-dom/client';
import App from './App'
import 'bootstrap/dist/css/bootstrap.min.css';
import '@progress/kendo-theme-material/dist/all.css';
import './index.css';
import 'bootstrap';
import * as serviceWorker from './serviceWorker';
import { Provider } from 'react-redux';
import Layout from './components/Generic/Layout';
import { BrowserRouter as Router } from 'react-router-dom';
import { CookiesProvider  } from 'react-cookie';
import store from './store'
require('./components/Functions/Http')

const container = document.getElementById('root');
const root = createRoot(container!); // createRoot(container!) if you use TypeScript
root.render(<Provider store={store}>       
    <CookiesProvider>
        <Router basename="/">
            <Layout>
                <App/>
            </Layout>
        </Router>
    </CookiesProvider>          
</Provider>);




// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
