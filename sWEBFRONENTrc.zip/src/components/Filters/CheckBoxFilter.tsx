import React from 'react';
import {GridColumnMenuCheckboxFilter,GridColumnMenuProps} from '@progress/kendo-react-grid';

export default function CheckBoxFilter(data: {}[]) {
    return class extends React.Component <GridColumnMenuProps, any>{
        constructor (props: GridColumnMenuProps){
            super(props);
        }
        render() {
            return (
                <div>
                    <GridColumnMenuCheckboxFilter {...this.props} data={data} expanded={true}/>
                </div>
            );
        }
    };
}