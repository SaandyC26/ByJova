import React from 'react';

import { DropDownList, DropDownListChangeEvent } from '@progress/kendo-react-dropdowns';
import {GridFilterCellProps} from '@progress/kendo-react-grid';

export default function dropdownFilterCell(data: string[], defaultItem: string) {
    return class extends React.Component <GridFilterCellProps,any>{
        constructor (props: GridFilterCellProps){
            super(props);
        }
        render() {
            return (
                <div className="k-filtercell">
                    <DropDownList
                        data={data}
                        onChange={this.onChange}
                        value={this.props.value || defaultItem}
                        defaultItem={defaultItem}
                    />
                    <button
                        className="k-button k-button-icon k-clear-button-visible"
                        title="Clear"
                        disabled={!this.hasValue(this.props.value)}
                        onClick={this.onClearButtonClick}
                    >
                        <span className="k-icon k-i-filter-clear" />
                    </button>
                </div>
            );
        }

        hasValue = (value : string) : boolean => Boolean(value && value !== defaultItem);

        onChange = (event : DropDownListChangeEvent) => {
            const hasValue = this.hasValue(event.target.value);
            this.props.onChange({
                value: hasValue ? event.target.value : '',
                operator: hasValue ? 'eq' : '',
                syntheticEvent: event.syntheticEvent
            });
        }

        onClearButtonClick = (event : React.MouseEvent) => {
            event.preventDefault();
            this.props.onChange({
                value: '',
                operator: '',
                syntheticEvent: event
            });
        }
    };
}