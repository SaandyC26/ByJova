import React, {useState,useEffect} from 'react';
import styled from "@emotion/styled";
import {Navigation} from '../Generic/RouteTypes';
import {Link, useLocation } from 'react-router-dom';
import {useSelector} from 'react-redux';
import {HasPermision} from '../Functions/Utils'
import {Contenedor, DefineSection} from '../Generic/Styles'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import { Theme, makeStyles } from '@material-ui/core/styles';


interface BarStatus {  
    Status: any;
  }

  function HeaderView() {
    const location = useLocation();      
    return location.pathname
  }

// this component populates sidebar menu from Navigation array 
export default function Menu(props:BarStatus){  
    
   

    const Theme =  useSelector((state: any) => state.Theme) ; 
    const Iconclass = props.Status === 'Open' ? 'col-4' : 'col-12';
    const TextClass = props.Status === 'Open'  ? 'col-8' : 'd-none';
    let ContextExpansion = null;  
    let ContextItem:any = null
    const [Granted, setGranted] = useState<any>({'Barcelona Invoices': false, 'Rebookings': false});
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
  
    


    useEffect(() => {  
        let Permissions = {
            'Barcelona Invoices': HasPermision('Barcelona Invoices'),
            'Rebookings': HasPermision('Rebookings')            
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])

   const useStylesBootstrap = makeStyles((theme: Theme) => ({
    arrow: {
      color: Theme.Corporate.blue,
    },
    tooltip: {
      backgroundColor: Theme.Corporate.blue,
    },
  }));

   function BootstrapTooltip(subprops: TooltipProps) {
    const classes = useStylesBootstrap();
  
    return <Tooltip arrow classes={classes} {...subprops} />;
  } 

    const Links = Navigation.map((El:any) => {  
        let Family:any = null;

        if(El.ContextBar !== null){
            Family = <SubFamily>{El.ContextBar(props)}</SubFamily>;
        }

        function Item () {
          
            if(El.Name === 'Home'){
                
                return props.Status === 'Compact' ? 
                        
                        <LinkItem Selected={HeaderView() === '/home/'} theme={Theme} key={El.Path}> 
                            <DefineSection className='unique'><Link to={El.Path}><span className={Iconclass} ><BootstrapTooltip title={El.Name} placement="right-start"><i><El.Icon/></i></BootstrapTooltip> </span><p className={TextClass}>{El.Name}</p></Link></DefineSection>
                        </LinkItem>
                        : 
                        <LinkItem Selected={HeaderView() === '/home/'} theme={Theme} key={El.Path}> 
                            <DefineSection className='unique'><Link to={El.Path}><span className={Iconclass} ><i><El.Icon/></i></span><p className={TextClass}>{El.Name}</p></Link></DefineSection>
                        </LinkItem>
                                     
                     
                
            }
            return props.Status === 'Compact' ?
            <LinkItem  theme={Theme} key={El.Path}> 
                <Accordion defaultExpanded={HeaderView().includes(El.Path)}>
                    <AccordionSummary className={props.Status === 'Compact' ? 'NotCompact' : ''} expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection><span className={Iconclass}><BootstrapTooltip title={El.Name} placement="right-start"><i><El.Icon/></i></BootstrapTooltip></span><p className={TextClass}>{El.Name}</p></DefineSection>
                    </AccordionSummary>
                    {Family !== null ? <AccordionDetails>{Family}</AccordionDetails> : null}
                    

                    
                </Accordion>                       
                </LinkItem>
            : 
                <LinkItem  theme={Theme} key={El.Path}> 
                <Accordion defaultExpanded={HeaderView().includes(El.Path)}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection><span className={Iconclass}><i><El.Icon/></i></span><p className={TextClass}>{El.Name}</p></DefineSection>
                    </AccordionSummary>
                    {Family !== null ? <AccordionDetails>{Family}</AccordionDetails> : null}
                    

                    
                </Accordion>                       
                </LinkItem> 
            
        }   
         

        if(!El.Dynamic){            
            if(El.Permissions[0] === 'All' ){
                return(<Item key={El.Name}/>)
            }else{
                let show = false;
                El.Permissions.forEach((element:string) => {                    
                    if(Granted[element]){show = true}
                });
                if(show){return(<Item key={El.Name}/>)}
                
            }
        }else{return(null)}        
    })

    Navigation.forEach((El:any)=>{    
        
        let Item = null;

        if(El.ContextBar !== null){Item = El.ContextBar(props);}
        
        let splited = HeaderView().split('/');        
        if(El.IsContext && El.ContextBar !== null && El.Path.replace(':slug', '').includes(splited[1])){
            if(splited[1] === "demand" || splited[1] === "financial"){
                ContextExpansion = Item;
                ContextItem = {...El}
            }
        }
        if(El.IsContext && El.ContextBar !== null && El.Path.replace(':slug', '') === HeaderView()){            
            ContextExpansion = Item
            ContextItem = {...El}
            
        }
       
        return(
         <LinkItem Selected={HeaderView() === El.Path} theme={Theme}  key={El.Path} >             
             <Link to={El.Path}><span className={Iconclass}><i><El.Icon/></i></span><p className={TextClass}>{El.Name}</p></Link>
         </LinkItem>
        )
        
    })
    
    

return(
    <Contenedorin is="Menu">  
    <Contenedor> {Links}   </Contenedor>
    { ContextExpansion !== null && ContextItem !== null ? <Separator>  </Separator> : null}
    
    {
        ContextExpansion !== null && ContextItem !== null ? 
        <Contenedor><LinkItem theme={Theme} key={ContextItem.Name }> 
            <Accordion defaultExpanded>
                <AccordionSummary className={props.Status === 'Compact' ? 'NotCompact' : ''} expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                    <DefineSection><span className={Iconclass}>
                        {props.Status === 'Compact' ? 
                        <BootstrapTooltip title={ContextItem.Name} placement="right-start"><i><ContextItem.Icon /></i></BootstrapTooltip>
                        :
                        <i><ContextItem.Icon /></i>
                        }
                        
                        </span><p className={TextClass}>{ContextItem.Name }</p></DefineSection>
                </AccordionSummary>
                <AccordionDetails>{ContextExpansion}</AccordionDetails>
            </Accordion>  
        </LinkItem></Contenedor>
         
        : null
    }
    </Contenedorin>
    )


    
}

const Contenedorin = styled.div({
    paddingTop: '20px',
    
       
}     
)

const SubFamily = styled.div({

})

const Separator = styled.div({
    height: '2px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: '-15px',
    marginBottom: '10px',
    backgroundColor: 'rgb(0 0 0 / 20%)',
    marginLeft: '5px',
    marginRight: '10px',

    
})
const LinkItem = styled.li<any>({
    marginBottom: 'calc(5px + 0.3vw)',
    paddingLeft: '5px' ,
    width: '100%',    
    '>div':{
        display: 'flex',
        height: '100%',
        alignItems: 'center',
        width: '100%',
        color: '#003399',
        cursor: 'pointer'
    },
    'a':{
        display: 'flex',
        height: '100%',
        alignItems: 'center',
        width: '100%'
    },
    'i':{
         width: '5vw',
         height: '5vw',
         display: 'flex',
         justifyContent:'center',
         alignItems: 'center',
         backgroundSize: 'cover',
         maxWidth: '40px',
         maxHeight: '40px',
         minWidth: '35px',
         minHeight: '35px',
         borderRadius: '5px',
         'svg,img':{
            fontSize: '40px',
            maxWidth: '25px',
            maxHeight: '25px',
            cursor: 'pointer',
            color: 'transparent',
           
            
            strokeWidth: '0.6px'
         },
     },
     'p':{
        margin: '0px',
        padding: '0px',
        fontSize: '90%',
        lineHeight: '1',
        opacity: '1'
     }
 }, (props) =>({
    'i':{
       
           border: '1px solid '+ props.theme.Corporate.darkBlue,
           stroke: props.theme.Corporate.darkBlue,   
       
    },
    'p': {
       color: props.theme.Corporate.blue
    },
    ':hover':{
        '.MuiButtonBase-root i, .unique i':{
            borderWidth: props.Selected ? '1px' : '2px'
        },
        '.MuiButtonBase-root p , .unique p':{
            fontWeight: props.Selected ? 'inherit' : 'bold',
            color: props.Selected ? 'inherit' : props.theme.Corporate.darkBlue,
            textShadow: props.Selected ? 'inherit' : '0px 0px 0px rgb(0 0 0 / 36%)'
        }
    },
    backgroundColor: props.Selected ? props.theme.Corporate.lightBlue : 'inherit'
}))
