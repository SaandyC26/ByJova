import React from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';


interface Entry {   
    onCallBack : any,
    SideBarStatus : any
}
// this component controls the sidebar mode
export default function BarWidthControler(props:Entry){     
    const Theme =  useSelector((state: any) => state.Theme) ;   
    const SideBarMode = props.SideBarStatus;
    
    const Contenedor = styled.div({
        position: 'absolute',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        left: '0',
        width: '100%',
        top: '10px',
        padding: '10px',        
        'span' : {
            position: 'absolute',            
            cursor: 'pointer',            
            fontSize: '20px',
            fontWeight: 'bold',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            
        }
    },()=>({
        color: Theme.Corporate.darkBlue,
        justifyContent: SideBarMode === 'Open' ? 'center' : 'flex-end',
        'span':{transform: SideBarMode === 'Open' ? 'rotate(0)' : 'rotate(180deg)'}
    }))

    return(
        <Contenedor id="BarWidthControler" onClick={()=>{props.onCallBack()}}>        
        <span>&gt;</span>
        </Contenedor>
    )


    
}


