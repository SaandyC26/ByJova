import React, {useState,useEffect} from 'react';
import styled from "@emotion/styled";
import {Navigation} from '../Generic/RouteTypes';
import {Link } from 'react-router-dom'
import {HasPermision} from '../Functions/Utils'
import {useSelector} from 'react-redux';


// this component populates nav menu from Navigation array 
export default function MenuUpper(){      
    const Theme =  useSelector((state: any) => state.Theme) ;   
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState<any>({'Barcelona Invoices': false, 'Rebookings': false});
    
    useEffect(() => {  
        let Permissions = {
            'Barcelona Invoices': HasPermision('Barcelona Invoices'),
            'Rebookings': HasPermision('Rebookings')            
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])


    const Links = Navigation.map(El=>{  
        function Item () {
            return(
                <LinkItem Theme={Theme} key={El.Path}>             
                     <Link to={El.Path} id={El.DisplayId}><span><i><El.Icon/></i></span><p>{El.Name}</p></Link>
                </LinkItem> 
            )
        }   
         

        if(!El.Dynamic){            
            if(El.Permissions[0] === 'All' ){
                return(<Item key={El.Name}/>)
            }else{
                let show = false;
                El.Permissions.forEach((element:string) => {                    
                    if(Granted[element]){show = true}
                });
                if(show){return(<Item key={El.Name}/>)}
                
            }
        }else{return(null)}        
    })
    


return(
    <div id="MenuUpper">
    <Contenedor>{Links}</Contenedor>       
    </div>
    )


    
}

const Contenedor = styled.ul({
    width: '100%',            
    display: 'flex',
    minWidth: '500px',
    justifyContent: 'center',
    alignItems: 'stretch',
    left: '0',
    margin: '0px',
    padding: '5px 5px 5px 30px',
    color: 'white',
    listStyle: 'none',
    'span' : {
        display: 'flex' ,
        padding: '0px',
        margin: '0px',
        justifyContent: 'center',
        alignItems: 'center'        
    },        
}     
)

const LinkItem = styled.li<any>({
   
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '100%',
    maxWidth: '100px',   
    'a':{
       textAlign : 'center',
       textDecoration: 'none !important',
       paddingTop: '5px',
       display: 'flex',
       justifyContent: 'center',
       alignItems: 'center',
       flexDirection: 'column',
       width: '5px'
    },
    'i':{
         width: '5vw',
         height: '5vw',
         display: 'block',
         backgroundSize: 'cover',
         backgroundPosition: 'center',
         maxWidth: '45px',
         maxHeight: '45px',
         minWidth: '45px',
         minHeight: '45px',
         marginBottom: '5px',
         'svg':{
            fontSize: '40px',
            cursor: 'pointer',
            color: 'transparent',                    
            borderRadius: '5px',
            strokeWidth: '0.6px'
         },
         
     },
     'p':{
        fontSize: '85%',
        fontWeight: 'bold',
        margin: '0px',
        padding: '0px',
        lineHeight: '1.2',
       

     }
 }, props =>({
     'i':{
         'svg':{
            border: '1px solid '+ props.Theme.Corporate.darkBlue,
            stroke: props.Theme.Corporate.darkBlue,   
         }
     },
     'p': {
        color: props.Theme.Corporate.darkBlue
     },
     ':hover':{
        outline: '1px solid '+props.Theme.Corporate.darkBlue,
        backgroundColor : props.Theme.Corporate.lightBlue,
     }
 }))
