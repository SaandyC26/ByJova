import React, {useState,useEffect} from 'react';
import {Link, useLocation} from 'react-router-dom';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import { Theme, makeStyles } from '@material-ui/core/styles';
import MDTService from '../../../services/MDTService';
import {useSelector} from 'react-redux';
import {infinite, IconList } from '../../Generic/Icons';
import {getCookie} from "../../../components/Functions/Utils";
import {Contenedor,LinkItem} from '../../Generic/Styles'
import {IconForm} from '../../Generic/Icons'

interface BarStatus {  
    Status: any;
  }

interface Params  {
    
}

function HeaderView() {
    const location = useLocation();      
    return location.pathname
  }

// this component generates some menu options for its caller
export default function Demand(props:BarStatus){  
    const MainTheme =  useSelector((state: any) => state.Theme) ;
    const [Results, setResults] = useState(new Array) ;
    const TokenData = useSelector((state: any) => state.tokenData);
    const [Loaded, setLoaded] = useState(false);
    const cookie = getCookie('ZurichCustomerPortal')
   function MatchIcon(name:string){    
    let filtered = IconList.filter((element:any) => element.name === name); 
    
    
   

    return filtered.length > 0 ? filtered[0].comp : infinite;

   }

    useEffect(() => {       
        if(cookie !== ''){       

        MDTService.postRequestMasterDataTabletoEdit('LineOfBusiness',TokenData.tokenId).then((result: any) => {  
        var tempList =  new Array;
        result.masterDatas.map((Item:any) => {                
            let newItem = Item;           
            newItem.name = typeof Item.name !== 'undefined' ? Item.name : Item.code;                
            tempList.push(newItem);      
        });       
        setResults(tempList);     
        setLoaded(true)
    });
}   
   },[Loaded,cookie])


   const useStylesBootstrap = makeStyles((theme: Theme) => ({
    arrow: {
      color: MainTheme.Corporate.blue,
    },
    tooltip: {
      backgroundColor: MainTheme.Corporate.blue,
    },
  }));

  function BootstrapTooltip(subprops: TooltipProps) {
    const classes = useStylesBootstrap();
  
    return <Tooltip arrow classes={classes} {...subprops} />;
  } 

    return(
    <Contenedor id="ContextDemand">  
    <LinkItem Selected={HeaderView() === '/demand/'} className={'Sub'} >                      
            <Link to='../../../demand/' id="SideBar_Button_Menu_Demand_All">
                <span className="col-4">
                    {props.Status  === 'Compact' ? <BootstrapTooltip title="All Demand" placement="right-start"><i>{IconForm('SideBarMenu')}</i></BootstrapTooltip> : <i>{IconForm('SideBarMenu')}</i>  }                 
                </span><p className="col-8">All Demand </p>
            </Link>            
        </LinkItem>
    {
        Results.map((element:any) => {
            let linkto = "../../../demand/"+element.name;            
            let Icon = MatchIcon(element.icon);
           

            return(
                <LinkItem Selected={HeaderView().replace('/demand/','') === element.name} className={'Sub'}  key={element.name}>                      
                    <Link to={linkto} id={"SideBar_Button_Menu_"+element.name}>
                        <span className="col-4">
                            {props.Status  === 'Compact' ? <BootstrapTooltip title={element.name} placement="right-start"><i>{Icon}</i></BootstrapTooltip> : <i>{Icon}</i>  }                 
                        </span><p className="col-8">{element.name}</p>
                    </Link>            
                </LinkItem>
            )
        })
    }      
        
        
    </Contenedor>
    )


    
}



