import React from 'react';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import { makeStyles } from '@material-ui/core/styles';
import {setTable} from '../../../store/slices/MasterData'
import {useDispatch, useSelector} from 'react-redux';
import {Contenedor,LinkItem} from '../../Generic/Styles'
import BusinessCenterIcon from '@material-ui/icons/BusinessCenter';
import PeopleAltIcon from '@material-ui/icons/PeopleAlt';
import AccountTreeIcon from '@material-ui/icons/AccountTree';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import BusinessIcon from '@material-ui/icons/Business';
import CenterFocusStrongIcon from '@material-ui/icons/CenterFocusStrong';
import FormatListBulletedIcon from '@material-ui/icons/FormatListBulleted';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import LanIcon from '@material-ui/icons/NetworkCell';
import {IconPouch,IconPeople,IconCharging,IconBussines,IconLister,IconProduct,IconFolder,IconPplGear,IconCostCenter} from '../../Generic/Icons'

interface BarStatus {  
    Status: any;
  }

// this component generates some menu options for its caller
export default function DataTables(props:BarStatus){   
    const MainTheme =  useSelector((state: any) => state.Theme) ;
    const dispatch = useDispatch();
    function SetSource(target:any){
        dispatch(setTable(target)) 
    }

    const useStylesBootstrap = makeStyles(() => ({
        arrow: {
        color: MainTheme.Corporate.blue,
        },
        tooltip: {
        backgroundColor: MainTheme.Corporate.blue,
        },
    }));

  function BootstrapTooltip(subprops: TooltipProps) {
    const classes = useStylesBootstrap();  
    return <Tooltip arrow classes={classes} {...subprops} />;
    } 

    return(
    <Contenedor id="ContextMenu_DataTables">        
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'LineOfBusiness', Name: 'Line of business'})} id="SideBar_Button_Menu_MasterDataTables_LineOfBusiness">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Line of business" placement="right-start"><i><IconPouch/></i></BootstrapTooltip> : <i><IconPouch/></i>  }                 
                </span><p className="col-7">Line of business</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'Customer', Name: 'Customer'})} id="SideBar_Button_Menu_MasterDataTables_Customer">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Customers" placement="right-start"><i><IconPeople/></i></BootstrapTooltip> : <i><IconPeople/></i>  }                 
                </span><p className="col-7">Customers</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'CustomerFunction', Name: 'Customer Function'})} id="SideBar_Button_Menu_MasterDataTables_Customer">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Customer Function" placement="right-start"><i><IconPplGear/></i></BootstrapTooltip> : <i><IconPplGear/></i>  }                 
                </span><p className="col-7">Customer Function</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'Project', Name: 'Project'})} id="SideBar_Button_Menu_MasterDataTables_Project">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Projects" placement="right-start"><i><IconFolder/></i></BootstrapTooltip> : <i><IconFolder/></i>  }                 
                </span><p className="col-7">Projects</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'TypeOfService', Name: 'Type of service'})} id="SideBar_Button_Menu_MasterDataTables_TypeOfService">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Type of service" placement="right-start"><i><IconLister/></i></BootstrapTooltip> : <i><IconLister/></i>  }                 
                </span><p className="col-7">Type of service</p>
            </div>            
        </LinkItem>        
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'ChargingModel', Name: 'Charging model'})} id="SideBar_Button_Menu_MasterDataTables_ChargingModel">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Charging model" placement="right-start"><i><IconCharging/></i></BootstrapTooltip> : <i><IconCharging/></i>  }                 
                </span><p className="col-7">Charging model</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'BusinessUnit', Name: 'Bussines unit'})} id="SideBar_Button_Menu_MasterDataTables_BusinessUnit">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Business unit" placement="right-start"><i><IconBussines/></i></BootstrapTooltip> : <i><IconBussines/></i>  }                 
                </span><p className="col-7">Business unit</p>
            </div>            
        </LinkItem>   
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'CostCenter', Name: 'Cost center'})} id="SideBar_Button_Menu_MasterDataTables_CostCenter">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Cost center" placement="right-start"><i><IconCostCenter/></i></BootstrapTooltip> : <i><IconCostCenter/></i>  }                 
                </span><p className="col-7">Cost center</p>
            </div>            
        </LinkItem>
        <LinkItem className='Sub' onClick={()=> SetSource({Request:'Product', Name: 'Product'})} id="SideBar_Button_Menu_MasterDataTables_Product">                      
            <div>
                <span className="col-5">
                    {props.Status === 'Compact' ? <BootstrapTooltip title="Product" placement="right-start"><i><IconProduct/></i></BootstrapTooltip> : <i><IconProduct/></i>  }                 
                </span><p className="col-7">Product</p>
            </div>            
        </LinkItem>
    </Contenedor>
    )


    
}

