import React, {useState,useEffect} from 'react';
import {Link, useLocation} from 'react-router-dom';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import { Theme, makeStyles } from '@material-ui/core/styles';
import {useSelector} from 'react-redux';
import {IconHandGlobal,rebooking, IconCustom,IconCalendar, chart} from '../../Generic/Icons';
import {HasPermision} from '../../Functions/Utils'
import {Contenedor,LinkItem} from '../../Generic/Styles'

function HeaderView() {
    const location = useLocation();      
    return location.pathname
  }
interface BarStatus {  
    Status: any;
  }

// this component generates some menu options for its caller
export default function Financial(props:BarStatus){  
    const MainTheme =  useSelector((state: any) => state.Theme) ; 
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({barcelona: false, rebooking: false, allocation:false, monthly: false, quarter:false });

    useEffect(() => { 
       
        let Permissions = {
            barcelona: HasPermision('Barcelona Invoices'),
            rebooking: HasPermision('Rebookings') ,
            allocation: HasPermision('Customers Allocations'),
            monthly: HasPermision('Monthly Report'),
            quarter: HasPermision('Quarter Report')           
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])

   const useStylesBootstrap = makeStyles((theme: Theme) => ({
    arrow: {
      color: MainTheme.Corporate.blue,
    },
    tooltip: {
      backgroundColor: MainTheme.Corporate.blue,
    },
  }));

  function BootstrapTooltip(subprops: TooltipProps) {
    const classes = useStylesBootstrap();
  
    return <Tooltip arrow classes={classes} {...subprops} />;
  } 

function Barcelona(){
    return(
        <LinkItem Selected={HeaderView().includes('servizurich_intercompany_charges-out')} className='Sub' >                      
                <Link to='../../financial/servizurich_intercompany_charges-out/' id="SideBar_Button_Menu_Financial_servizurich_intercompany_charges-out">
                    <span className="col-4">
                        {props.Status === 'Compact' ? <BootstrapTooltip title="Servizurich Intercompany Charges-Out" placement="right-start"><i>{IconHandGlobal('SideBarMenu')}</i></BootstrapTooltip> : <i>{IconHandGlobal('SideBarMenu')}</i>  }                 
                    </span><p className="col-8">Servizurich Intercompany Charges-Out</p>
                </Link>            
            </LinkItem>
    )
}
function Rebooking(){
    return(
        <LinkItem Selected={HeaderView().includes('rebooking')} className='Sub' >                      
        <Link to='../../financial/rebooking/' id="SideBar_Button_Menu_Financial_Rebooking">
            <span className="col-4">
                {props.Status  === 'Compact' ? <BootstrapTooltip title="Rebooking" placement="right-start"><i>{IconCalendar('SideBarMenu')}</i></BootstrapTooltip> : <i>{IconCalendar('SideBarMenu')}</i>  }                 
            </span><p className="col-8">Rebooking</p>
        </Link>            
     </LinkItem>
    )
}
function Allocation(){
    return(
        <LinkItem Selected={HeaderView().includes('customer_allocation')} className='Sub' >                      
                <Link to='../../financial/customer_allocation/' id="SideBar_Button_Menu_Financial_Customer_Allocation">
                    <span className="col-4">
                        {props.Status  === 'Compact' ? <BootstrapTooltip title="Customers Allocations" placement="right-start"><i>{IconCustom('SideBarMenu')}</i></BootstrapTooltip> : <i>{IconCustom('SideBarMenu')}</i>  }                 
                    </span><p className="col-8">Customers Allocations</p>
                </Link>            
            </LinkItem> 
    )
}
function Monthly(){
    return(
        <LinkItem Selected={HeaderView().includes('monthly_report')} className='Sub' >                      
                <Link to='../../financial/monthly_report/' id="SideBar_Button_Menu_Financial_Monthly_Report">
                    <span className="col-4">
                        {props.Status  === 'Compact' ? <BootstrapTooltip title="Monthly Report" placement="right-start"><i>{IconCalendar('SideBarMenu')}</i></BootstrapTooltip> : <i>{IconCalendar('SideBarMenu')}</i>  }                 
                    </span><p className="col-8">Monthly Report</p>
                </Link>            
            </LinkItem>
    )
}
function Quarter(){
    return(
        <LinkItem Selected={HeaderView().includes('quarter_report')} className='Sub' >                      
                <Link to='../../financial/quarter_report/' id="SideBar_Button_Menu_Financial_Quarter_Report">
                    <span className="col-4">
                        {props.Status  === 'Compact'  ? <BootstrapTooltip title="Quarter Report" placement="right-start"><i>{chart}</i></BootstrapTooltip> : <i>{chart}</i>  }                 
                    </span><p className="col-8">Quarter Report</p>
                </Link>            
            </LinkItem>
    )
}

    return(
    <Contenedor id="ContextMenu_Financial">        
        {!Granted.barcelona ? null : <Barcelona/> }
        {!Granted.rebooking ? null : <Rebooking/>}
        {!Granted.allocation ? null : <Allocation/>}
        {!Granted.monthly ? null : <Monthly/>}
        {!Granted.quarter ? null : <Quarter/>}              
    </Contenedor>
    )


    
}


