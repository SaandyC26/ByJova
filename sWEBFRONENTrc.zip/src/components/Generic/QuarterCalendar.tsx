import * as React from 'react';

import { Calendar } from '@progress/kendo-react-dateinputs';


export default function QuarterCalendar(props:any){



    return(
        <div>
                <Calendar
                    value={props.value.start}
                    //onChange={}

                    navigation={false}
                />
                <Calendar
                    value={props.value.end}
                   // onChange={}

                    navigation={false}
                />
            </div>
    )
}