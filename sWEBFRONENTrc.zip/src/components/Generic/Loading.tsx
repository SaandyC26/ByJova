import React  from 'react';
import styled from "@emotion/styled";
import CircularProgress from '@material-ui/core/CircularProgress'

interface Expected {
    Name?: 'ButtonFit'
}

export default function Loading(props:Expected){ 

   
        return(        
            <Content id="Loading">
                <span className={props.Name}>
                    <CircularProgress />
                </span>              
            </Content>
        )
    
    
}

const Content = styled.div({
    display: 'flex',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    '.ButtonFit': {
        minWidth: '55.75px',
        '.MuiCircularProgress-root':{
            width: '15px !important',
            height: '15px !important'
        }
    }
})
