import React, {useEffect, useState,useRef}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import Table from '../Generic/DataTable2'
import UserService from '../../services/UserService';
import { findWithAttr } from '../Functions/Utils';


export default function Subscription(props:any){  
    
    props = {...props} 
    
    const [isLoading, setIsLoading] = useState(false)
    const [List, setList] = useState(new Array);
    const Item = useRef<any>(new Object);
   

    const Cached = useSelector((state: any) => state.userData.Cache.TicketDetail)
    const Pending = useSelector((state: any) => state.userData.pendingCalls).filter((el:any) => el.Type === 'ExpandComments')
   
    const TableDef = ['id','samAccountName','dateTime','text']
    const SpecialFields = {               
        
        'text':{ type: 'textarea', required : true},
        
        
    };
    const ModItem = [{Name: 'text', Value: ''}]

    const HiddenFieldsEditNew = ['samAccountName','dateTime','id']
    const HiddenFields = ['id']
       
    
    const ConditionalDelete = {Field: 'links', Valid: "delete", Prop: 'rel'}
    const ConditionalEdit = {Field: 'links', Valid: "update", Prop: 'rel'}

    function UpdateItem(el:any){
        
        let Data:any = (new Array)
        if(typeof el.List !== 'undefined'){           
            Data = Data.concat(el.List)           
        } 
        setList([...Data])
        

    }

    useEffect(() => {

       
        let FoundfromCache:any = Cached.find((el:any) => el.Id === props.Transfer.id)
        let isPending = Pending.find((el:any) => el.Id === props.Transfer.id)  
        if(typeof FoundfromCache !== 'undefined'){ 
            setIsLoading(true)            
            UpdateItem({...FoundfromCache}); 
            Item.current = {...FoundfromCache}
            setIsLoading(false) 
                   
        }
        else if(typeof isPending === 'undefined'){
            UpdateTable()
           
        }
           
               
    
       
    },[])

    const Control = {
        CommentAdd : function (formProps:any) {                    
            UserService.Tickets_Comment_Add(props.Transfer.id, formProps.text)
            .then(() => {UpdateTable()});
        },       
        CommentDelete : function (formProps:any){           
            UserService.Tickets_Comment_Delete(formProps.id,props.Transfer.id)
            .then(() => {UpdateTable()});
        },
    }

    function UpdateTable(){            
        
        setIsLoading(true) 
        UserService.Tickets_Comment_Get(props.Transfer.id).then((result: any) => {       
       
          
    
            let Found:any = {Id: props.Transfer.id, List: result.data};
            
            
        Item.current = {...Found}
        UpdateItem({...Found});   
       
        setIsLoading(false)       
        
        }) 
               
            
    
    
        
       
       
    }

    
    let CanComment = false;    
    if(typeof props.Transfer.links !== 'undefined' && props.Transfer.links[findWithAttr(props.Transfer.links, 'ref' , '/TicketComment')] !== 'undefined'){
        CanComment = true;
    }
  
    console.log(props.Transfer.links)
   
   
        return(        
            
            <DinamicInfo>               
               
                <Title>Comments</Title>
                {isLoading ? null :     
                <Table                 
                    Download={false}
                    Windowed     
                    SpecialFields={[SpecialFields]}           
                    Addable={CanComment}
                    Editable
                    HiddenFieldsEditNew={HiddenFieldsEditNew}
                    HiddenFields={HiddenFields}                    
                    ModItem={ModItem}
                    ConditionalDelete={ConditionalDelete} 
                    ConditionalEdit={ConditionalEdit}
                    forcedText={{new: "New Comment", delete: "Delete Comment", update: "Edit Comment"}}                    
                    CallBackDelete={(formProps:any) => {Control.CommentDelete(formProps)}}                   
                    CallBackAdd={(formProps:any) => {Control.CommentAdd(formProps)}}
                    TableSizes={[0,0,0,0,0]}
                    TableDef={TableDef}
                    DataSet={List}
                    PrevRend             
               
                />
                }
            </DinamicInfo>
       
    )
        
   
}

const Title = styled.div({

})

const DinamicInfo = styled.div({
    padding: '10px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    },
    'a':{ textDecoration: 'none !important'}

})

