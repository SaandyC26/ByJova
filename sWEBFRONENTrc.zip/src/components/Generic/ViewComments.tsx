import React, {useState} from 'react';
import styled from "@emotion/styled"; 
import { Dialog } from "@progress/kendo-react-dialogs";
import {useSelector} from 'react-redux';
import DataTable from '../Generic/DataTable';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import { formatDate } from '@telerik/kendo-intl';
interface Expected {
  Comments: any
}


// this component styles the main screen workarea
export default function ViewComments(props:Expected){ 
    const Theme =  useSelector((state: any) => state.Theme) ;
    const [open,setOpen] = useState(false);
    let Data = new Array;
    
    //parse entry data

    props.Comments.map((el:any)=>{
        Data.push({User: el.userName, Date: formatDate(new Date(el.dateTime), "d"), Comment: el.text})
    })
      

   

    return(                          
        <Content id="ViewComments" Theme={Theme}>  
            <button className="k-button k-button-primary" onClick={()=>{setOpen(true)}}>Show All</button>    
            {!open ? null : 
            <Dialog appendTo={null}>
                
                <Table>
                <Closebtn Theme={Theme} onClick={()=>{setOpen(false)}}><HighlightOffIcon/></Closebtn>
                <DataTable Addable={false} Editable={false} DataSet={Data} TableDef={['User', 'Date','Comment']} TableSizes={[200,100,0]}/>
                </Table>
                
               
            </Dialog>
            
            }       
        </Content>         
    )
}

const Closebtn = styled.span<any>({
    float: 'right',
    cursor: 'pointer',
}, props =>({
    color: props.Theme.Corporate.darkBlue
  }))
const Table = styled.div<any>({ 
    width: '600px'

})
const Content = styled.div<any>({  
    maxWidth: '1000px',  
   '.k-form-buttons' :{
     display: 'flex',
     justifyContent: 'space-between',
     marginTop: '10px',
   
   },
   '.k-grid-content.k-virtual-content':{
    overflowY: 'scroll'
} 
}, props =>({
  'button ':{
      backgroundColor: props.Theme.Corporate.darkBlue,
      color: 'white'
  },
}));
