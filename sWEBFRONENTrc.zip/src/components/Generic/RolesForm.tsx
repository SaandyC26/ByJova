import React,{useState}  from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement } from "@progress/kendo-react-form";
import { Input,Checkbox } from "@progress/kendo-react-inputs";
import Paper from '@material-ui/core/Paper';
import styled from "@emotion/styled"; 
import {useSelector} from 'react-redux';
import { GetButtonText,GetRevenuesButtonText } from "../Functions/Utils";
import Loading from './Loading'
import {FormPrimaryButton, FormSecondaryButton} from './Styles'


const RolesForm = (props:any) => {  
    const Theme =  useSelector((state: any) => state.Theme) ;  
    const required = (value:any) => (value && value.length > 0 ? "" : 'This is a mandatory field.');
    function requiredanything(value:any){
        
        if(value &&  value.length > 0){
            return ''
        }else{
            return 'This is a mandatory field.'
        }
       
        
    }
    const unrequired = (value:any) => ("");

    const [feltypes, setfelTypes] = useState(props.item.permissions || new Array);   
    const [IsLoading, setIsLoading] = useState(false)
      
    const UpdateField = (a:any, b:string, c:any) => {
        let newlist = [...feltypes];
        let value = a.value;              
        
        if(!newlist.includes(b) && value){
                newlist.push(b)
        }else{
            let toremove = newlist.indexOf(b);  
            if (toremove !== -1) {
                newlist.splice(toremove, 1);
              } 
        }
        setfelTypes(newlist);
        c.onChange('permissions', { value: newlist });
    }

    

    function PreSend(subProps:any){
        setIsLoading(true)
        props.onSubmit(subProps);
    }

     

    return (
        <Content id="RolesForm" Theme={Theme}>
        <Dialog appendTo={null} title={GetButtonText(props.item)} onClose={props.cancelEdit}>            
            <Form 
                onSubmit={(e:any) => {PreSend(e)}}
                initialValues={props.item}
                render={formRenderProps => (
                    <FormElement>
                        <fieldset className={"k-form-fieldset"}>                             
                            <Paper elevation={3} style={{padding: '10px', minWidth: '300px'}}>
                                <div className= "row">
                                    <div className="col-12">
                                        <div className="mb-2">
                                            <Field
                                                id={"Field_name"}
                                                name="name"
                                                component={Input}
                                                data="name"
                                                label="Role Name"
                                                disabled={props.item.delete}
                                                validator={required}
                                            />
                                        </div> 
                                        <CheckBoxes>
                                        {
                                            props.Permissions.map((Element:any) => {
                                                    
                                                    return(
                                                        <div key={Element}>
                                                                                                                  
                                                            <Checkbox disabled={props.item.delete || false} defaultChecked={props.item.permissions?.includes(Element.name) || false} id={"Field_"+Element.name} label={Element.name} onChange={(value) => {UpdateField(value,Element.name,formRenderProps)}} />                                                                                                                        
                                                        
                                                        </div>
                                                        
                                                    )
                                                
                                                
                                                
                                            })
                                        }
                                        </CheckBoxes>
                                        <Field
                                                             id={"Field_"+Element}
                                                             name="permissions"
                                                             type='text'
                                                             component={Input}
                                                             data={"permissions"}                                                             
                                                             style={{display: 'none'}}
                                                             disabled={props.item.delete}
                                                             validator={props.NoneRequired ? unrequired : requiredanything}
                                                        />
                                        
                                                                      
                                       
                                    </div>
                                   
                                    
                                    
                                </div>
                                
                            </Paper>
                            
                        </fieldset>
                        <div className="k-form-buttons">                            
                            <FormPrimaryButton
                                id="Form_Button_Submit"
                                type={"submit"}
                                className="k-button k-primary"
                                disabled={!formRenderProps.allowSubmit && !props.item.delete || IsLoading}
                                onClick={props.item.delete ? props.onSubmit : null}
                            >
                                {IsLoading ? <Loading Name="ButtonFit"/> : GetRevenuesButtonText(props.item)}
                            </FormPrimaryButton>
                            <FormSecondaryButton
                                id="Form_Button_Cancel"
                                type={"submit"}
                                className="k-button"
                                onClick={props.cancelEdit}
                            >
                                Cancel
                            </FormSecondaryButton>
                        </div>
                    </FormElement>
                )}
            />
        </Dialog>
        </Content>
    );
};
export default RolesForm;


const CheckBoxes = styled.div({
  position: 'relative',
  display: 'flex',
  paddingTop: '0px',
  flexDirection: 'column',
  maxHeight:'400px',
  overflowY:'scroll',
  overflowX: 'hidden',
  'p':{
      position: 'absolute',
      top: '-15px',
      left: '0px'
  },
  'input[type=text]':{
      color: 'transparent',
      position: 'absolute',
      width: '70%',
      pointerEvents: 'none'
  } 
})


const Content = styled.div<any>({
    
    '.k-form-buttons':{
        display: 'flex',
        justifyContent: 'space-between'
    },
    '.k-content.k-window-content.k-dialog-content' :{
        overflow: 'visible'
    },
    '.k-select':{
        opacity: '1 !important'
    },
    'svg':{
        pointerEvents: 'none'
    },
    '.k-text-disabled':{
        
        opacity: 1
    },
    '.k-textbox:disabled':{
        borderStyle: 'solid'
    }
}, props =>({
    '.k-checkbox:checked':{
        borderColor: props.Theme.Corporate.darkBlue,
        backgroundColor: props.Theme.Corporate.darkBlue
    },
    '.k-button.k-primary:not(:disabled)':{
        backgroundColor: props.Theme.Corporate.darkBlue
    }
 }))
