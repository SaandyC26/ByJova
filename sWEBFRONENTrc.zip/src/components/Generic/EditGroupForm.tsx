import React, {useState} from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement } from "@progress/kendo-react-form";
import { Input } from "@progress/kendo-react-inputs";
import Paper from '@material-ui/core/Paper';
import styled from "@emotion/styled"; 
import { MultiSelect } from '@progress/kendo-react-dropdowns';
import {useSelector} from 'react-redux';
import {GetRevenuesButtonText} from '../Functions/Utils'
import Loading from './Loading'
import {FormPrimaryButton, FormSecondaryButton} from './Styles'
const required = (value:any) => (value.length > 0 ? "" : "This is a mandatory field.");

export default function EditGroupForm (props:any){
    const Theme =  useSelector((state: any) => state.Theme) ;  
    const [IsLoading, setIsLoading] = useState(false)
    
    const UpdateField = (data:any, name:string, formprops:any) => {        

        switch (name){
            case 'users' : formprops.onChange('users', { value: data.value }); break;
           
        }
        
    }


    

    let DisplayTitle = props.item.new ? 
    'New user'    : 
    `Edit ID: ${props.item.id} -- Name ${props.item.name}`

    let ConvertUsers = new Array;
    if(typeof props.item.users !== undefined){
        props.item.users.map((element:any) => {
            ConvertUsers.push(element.samAccountName)
        } )
    }

    function PreSend(subProps:any){
        setIsLoading(true)
        props.onSubmit(subProps);
    }

    if(props.item.delete){
        DisplayTitle = `Delete user ID: ${props.item.id} -- Name ${props.item.name}`       
    }     
    return (
        <Content id="EditGroupForm" Theme={Theme}>
            
                <Dialog appendTo={null} title={DisplayTitle} onClose={props.cancelEdit}>  
               
                <Form 
                    onSubmit={(e:any) => {PreSend(e)}}
                    initialValues={props.item}
                    render={formRenderProps => (
                        <FormElement>
                            <fieldset className={"k-form-fieldset"}>                             
                                <Paper className="mb-3" elevation={3} style={{padding: '10px'}}>
                                    <div className= "row mb-3">
                                        <div className="col-12">
                                            
                                            <div className="mb-2">
                                                <Field
                                                    id={"Field_name"}
                                                    name={"name"}
                                                    component={Input}
                                                    data={props.name}
                                                    label={"Name"}
                                                    disabled={props.item.delete}
                                                    validator={required}
                                                />
                                            </div>  
                                                                          
                                           
                                        </div>
                                       
                                        
                                        
                                    </div>
                                    <div className= "row mb-3">
                                        <div className="col-12">                                           
                                            <div className="mb-2" >
                                            <MultiSelect style={{width: '300px'}} id={"Field_Projects"} 
                                                    data={props.ListUsers.map((el:any) =>  {return el.samAccountName})}
                                                    onChange={(value)=> {UpdateField(value,"users",formRenderProps)}}
                                                    label={"Users"}
                                                    defaultValue={ConvertUsers}
                                                    name="users"
                                                    disabled={props.item.delete} // 
                                                />                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                </Paper>
                                
                            </fieldset>
                            <div className="k-form-buttons">                            
                                <FormPrimaryButton
                                    type={"submit"}
                                    id={'Form-Button-'+GetRevenuesButtonText(props.item)}
                                    className="k-button k-primary"
                                    disabled={!formRenderProps.allowSubmit && !props.item.delete || IsLoading}
                                    onClick={props.item.delete ? props.onSubmit : null}
                                >
                                    {IsLoading ? <Loading Name="ButtonFit"/> : GetRevenuesButtonText(props.item)}
                                </FormPrimaryButton>
                                <FormSecondaryButton
                                    type={"submit"}
                                    className="k-button"
                                    onClick={props.cancelEdit}
                                    id={"Form-Button-Cancel"}
                                >
                                    Cancel
                                </FormSecondaryButton>
                            </div>
                        </FormElement>
                    )}
                />
                        
            </Dialog>
           
        
        </Content>
    );
};





const Content = styled.div<any>({
    '.k-content.k-window-content.k-dialog-content' :{
        overflow: 'visible'
    },
    '.k-select':{
        opacity: '1 !important'
    },
    'svg':{
        pointerEvents: 'none'
    },
    '.k-text-disabled':{
        
        opacity: 1
    },
    '.k-textbox:disabled':{
        borderStyle: 'solid'
    }
}, props =>({
    '.k-button.k-primary:not(:disabled)':{
        borderColor:  props.Theme.Corporate.darkBlue,
        backgroundColor: props.Theme.Corporate.darkBlue
    },
    '.k-multiselect .k-multiselect-wrap .k-button::before, .k-dropdowntree .k-multiselect-wrap .k-button::before':{
        backgroundColor: props.Theme.Corporate.darkBlue,
        opacity: 0.2
    }
 }))
