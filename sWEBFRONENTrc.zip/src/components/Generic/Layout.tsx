import styled from "@emotion/styled";
import Drawer from "./Drawer"
import Header from "./Header";
import {useSelector} from 'react-redux';
import NewsSplash from './NewsSplash';
import DialogError from './ErrorDialog';
import DevWarning from './DevWarning';
import Configuration from '../../configuration/configuration';

// this component lays over all components and provides common interface for all pages
export default function Layout(props:any){   
    const Envoirment = Configuration.value('MODE');  
    const sidebarStatus = useSelector((state: any) => state.userData.sidebarDeploy);  
   
   return(
              
        <div id="Layout">         
            {Envoirment !== 'production' ? <DevWarning/> : null}           
            <Header />
           
                <MainScreen className="View">
                        {                                                                      
                           <Drawer Lead={sidebarStatus}/>
                        }
                        <IntroScroller>
                        {
                            props.children
                        }
                        </IntroScroller>
                </MainScreen>  
             
            <DialogError /> 
            <NewsSplash />    
        </div>
        
    )
}
const IntroScroller = styled.div({
   maxHeight: 'calc( 100vh - 50px )',
   overflowY: 'scroll',
   overflowX:'hidden',
   width: '100%'
})
const MainScreen = styled.div({
    display: 'flex',
    overflow: 'hidden',
    '.App': {minWidth: '400px'}
})

