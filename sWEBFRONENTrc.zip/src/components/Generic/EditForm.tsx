import React,{useState,useEffect}  from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement ,FieldWrapper} from "@progress/kendo-react-form";
import { Label, Error, Hint} from "@progress/kendo-react-labels";
import { Input, Checkbox,NumericTextBox,TextArea  } from "@progress/kendo-react-inputs";
import { DropDownList,MultiSelect , ComboBox } from '@progress/kendo-react-dropdowns';
import Paper from '@material-ui/core/Paper';
import styled from "@emotion/styled"; 
import {IconList} from '../Generic/Icons';
import {useSelector} from 'react-redux';
import {useDictionary as Dict, GetButtonText,GetRevenuesButtonText } from "../Functions/Utils";
import ObjectList from './ObjectList'
import Loading from './Loading'
import {FormPrimaryButton, FormSecondaryButton} from './Styles'

const EditForm = (props:any) => {  

    const Theme = useSelector( (state: any) => state.Theme); 

    const required = (value:any) => (value && value.length > 0 ? "" : 'This is a mandatory field.');
    function requiredanything(value:any){
        
        if(value &&  value.length > 0){
            return ''
        }else{
            return 'This is a mandatory field.'
        }
       
        
    }
    const unrequired = (value:any) => ("");
    const numberrequired =  (value:any) => (value !== null ? "" : 'This is a mandatory field.');
    const nonrequired = (value:any) => (true ? "" : 'This is a mandatory field.');   

    const [feltypes, setfelTypes] = useState(new Array());   
    const [IconSelected, setIconSelected] = useState('');
    const [IsLoading, setIsLoading] = useState(false)

    const Labels:any = new Object;

    const ProjectStyles = {
        'li':{

        },
        'li > span:first-of-type':{
            minWidth: '60px',
            maxWidth: '75px'
        }
    }

    props.Fields.forEach((item:any) => {
        Labels[item] = Dict('Tablenames-'+item)
    });

    
    function FindLabel(field:string){

        return Labels[field]

    }
    
    function IsSpecialField(field:string){
        for (const [key, value] of Object.entries(props.SpecialFields[0])) {
            if(field === key){
              
                return true
                
            }
          }
          return false
    }

    const NumericField = (subProps:any) =>{

        let ExtraProps:any = new Object
        
        if(typeof props.SpecialFields[0][subProps.name].Rules !== 'undefined'){
            ExtraProps = props.SpecialFields[0][subProps.name].Rules;
        }
       

        return(
            <NumericTextBox defaultValue={0} {...subProps} {...ExtraProps}/>
        )
    }

    useEffect(() => {        
        
        if(typeof props.item.types !== 'undefined'){
            setfelTypes(props.item.types)
        }
    },[])

    
    let Columns = 1;
    let CountFields= props.Fields.length
    let VirtualCount = 0;
   
    if(typeof props.Columnable !== 'undefined'){Columns = props.Columnable}
    if(typeof props.ColumnableNew !== 'undefined' && props.item.new){Columns = props.ColumnableNew}
    
    props.Fields.forEach((el:any) => {
        if(IsHidden(el)){VirtualCount++}
    });

    if(CountFields - VirtualCount < 8){Columns = 1}
    const itemsInCol = Math.floor( CountFields / Columns);
    
    const ColumnList = new Array;

   for (let i = 0; i < Columns; i++) {
       
        ColumnList.push(new Array)
       
   }
  
   const ActualFields = props.Override && props.item.new  ? props.Override : props.Fields;

   let currentIndex = 0;
    ActualFields.map((element:any) =>{
       if(typeof props.HiddenFieldsEdit !== 'undefined'){
            if(!props.HiddenFieldsEdit.includes(element)){
                if(ColumnList[currentIndex].length <= itemsInCol){
                    ColumnList[currentIndex].push(element);
                }
                else if(typeof  ColumnList[currentIndex+1] !== 'undefined'){
                    ColumnList[currentIndex+1].push(element);
                    currentIndex++;
        
                }
            }
       }else{
        if(ColumnList[currentIndex].length <= itemsInCol){
            ColumnList[currentIndex].push(element);
        }
        else if(typeof  ColumnList[currentIndex+1] !== 'undefined'){
            ColumnList[currentIndex+1].push(element);
            currentIndex++;

        }
       }
       
    })
    

    const FormTextArea = (fieldRenderProps:any) => {
       
        const {
          validationMessage,
          touched,
          label,
          id,
          valid,
          disabled,
          hint,
          type,
          optional,
          max,
          value,
          ...others
        } = fieldRenderProps;
      
        const showValidationMessage = touched && validationMessage;
        const showHint = !showValidationMessage && hint;
        const hindId = showHint ? `${id}_hint` : "";
        const errorId = showValidationMessage ? `${id}_error` : "";
      
        return (
          <FieldWrapper>
            <Label
              editorId={id}
              editorValid={valid}
              editorDisabled={disabled}
              optional={optional}
            >
              {label}
            </Label>
            <div className={"k-form-field-wrap"}>
              <TextArea
                defaultValue={fieldRenderProps.value}
                valid={valid}
                type={type}
                id={id}
                disabled={disabled}
                maxlength={max}                
                rows={4}
                ariaDescribedBy={`${hindId} ${errorId}`}
                {...others}
              />
              <Hint direction={"end"} style={{ position: "absolute", right: 0 }}>
                {typeof value.length !== 'undefined' ? value.length : 0} / {max}
              </Hint>
              {showHint && <Hint id={hindId}>{hint}</Hint>}
              {showValidationMessage && (
                <Error id={errorId}>{validationMessage}</Error>
              )}
            </div>
          </FieldWrapper>
        );
      };

    const UpdateField = (a:any, b:string, c:any) => {
        let newlist = [...feltypes];
        let value = a.value;  

        if(b==='Field_internal'){
            if(value){
                newlist.push('Internal');                
            }else{
                let toremove = newlist.indexOf('Internal');  
                if (toremove !== -1) {
                    newlist.splice(toremove, 1);
                  }            
            }
        }else{
            if(value){
                newlist.push('Customer');               
            }else{
                let toremove = newlist.indexOf('Customer'); 
                if (toremove !== -1) {
                    newlist.splice(toremove, 1);
                  }
                            
            }
        }

        

        setfelTypes(newlist);
        c.onChange('types', { value: newlist });
    }

    function IsMandatory(field:string){
        let status = false
        if(typeof props.Mandatory !== 'undefined' && props.Mandatory.includes(field)){status = true}

        return status
    }

    function IsDisabled(Element:any){  
        
          
        if(props.item.delete){
           
            return true
        }
        if(typeof props.ConditionalEdit !== 'undefined'){

            function HasProps(el:any) {
                
                if(typeof el !== 'undefined'  && typeof el[props.ConditionalEdit.Prop] !== 'undefined'){
                    return el[props.ConditionalEdit.Prop] === props.ConditionalEdit.Valid;
                }
                
              }

            if(typeof props.item[props.ConditionalEdit.Field] !== 'undefined'){
                let target = props.item[props.ConditionalEdit.Field].find(HasProps)
                
                if(target.properties === null){
                   
                    return false
                }else if(target.properties.includes(Element.toLowerCase()) ){
                    
                    return false
                }else{
                   
                    return true
                }
            }
         }
    }
    function IsHidden(Element:any){
        
             

     if(typeof props.HiddenFieldsEditNew !== 'undefined' 
     && props.item.new 
     && props.HiddenFieldsEditNew.includes(Element)){
         
         return true
     }

     if(typeof props.HiddenFieldsEdit !== 'undefined'
     && props.HiddenFieldsEdit.includes(Element)){
        
        return true
     }
     
    
      
    

        return false
    }

    function CheckifSpecialValues(el:any, form:any){
            
        if(typeof props.specialValues !== 'undefined'){
           
            let Found:any = new Array;
            props.specialValues.forEach((element:any) => {
             
                if(props.item[element.compare] === element.Value && element.affect === el){
                  
                    Found.push(element);
                    
                }
            });
            if(typeof Found[0] !== 'undefined'){
                if(typeof Found[0].special !== 'undefined') 
                {                    
                    let FormatedList = Found[0].special.values.map((ele:any)=>{return {key: ele.key, value: ele.value.Eng}});
                    
                    

                    let Defaulter = Found[0].special.values.find((ele:any) => ele.value.Eng === props.item[el] ); 
                    switch (Found[0].special.type){
                        case 'select':
                        case 'why2':
                        case 'why3': 
                        return(     
                           <ComboBox
                           label="Value"
                           data={FormatedList.filter((el2:any) => el2.value !== "")}
                           dataItemKey={'key'}
                           disabled={props.item.delete}
                           textField="value"                                                   
                           onChange={(response) => {form.onChange(el, { value: response.value });}}
                           allowCustom={false}
                           required={Found[0].mandatory}
                           clearButton={!Found[0].mandatory === true}
                           defaultValue={ typeof props.GivenList !== 'undefined' ? '' : {key: Defaulter.key , value: Defaulter.value.Eng}}
                          
                         />
                         
                        )                          
                    }
                }else{
                    return (
                        <Field                                                             
                            id={"Field_"+el}
                            name={el}
                            component={Input}
                            data={props[el]}
                            label={FindLabel(el) || el}
                            disabled={(el === 'Value' && Found[0].readonly && typeof props.GivenList === 'undefined') || props.item.delete || (el === 'Key' && !props.item.new)}
                            validator={(Found[0].mandatory) || (typeof props.HiddenFieldsMandatory !== 'undefined' &&  props.HiddenFieldsMandatory.includes(Element)) ?  required : nonrequired}
                    />
                    )
                }
                
            }
            else{
                return (
                    <Field                                                             
                        id={"Field_"+el}
                        name={el}
                        component={Input}
                        data={props[el]}
                        label={FindLabel(el)}
                        disabled={IsDisabled(el)}
                        validator={typeof props.HiddenFieldsMandatory !== 'undefined' &&  props.HiddenFieldsMandatory.includes(Element) ?  required : nonrequired}
                />
                )
            }
        }else{
            return (
                <Field                                                             
                    id={"Field_"+el}
                    name={el}
                    component={Input}
                    data={props[el]}
                    label={FindLabel(el)}
                    disabled={IsDisabled(el)}
                    validator={((typeof props.HiddenFieldsMandatory !== 'undefined' &&  props.HiddenFieldsMandatory.includes(Element)) || IsMandatory(el)) ?  required : nonrequired}
            />
            )
        }
        
       
    }

    function ComplexCalculation(rules:any, renderer:any){         
        if(typeof rules.ComplexAlter !== 'undefined'){
            let value:number = 0;
            rules.ComplexAlter.calc.forEach((el:any) => {
                let a =  renderer.valueGetter(el.field1)
                let b;
                if(el.field2 === ''){               
                    b = value
    
                }else{
                    b = renderer.valueGetter(el.field2)
                }
                switch(el.operator){
                    case "multiplicatibe": value = a*b;
                        break;
                    case "minus": value = a-b    
                }
            });       
            renderer.onChange(rules.ComplexAlter.field, { value: value !== value ? 0 : value })      
    
        }
       }
    
       
       function PreSend(rawsubProps:any){
       
        let subProps:any = {...rawsubProps}
       

        for (const [key, value] of Object.entries(subProps)) {
           
            if(
                typeof value === 'object' 
                && !Array.isArray(value) 
                && value !== null 
                && props.item[key] !== undefined 
                && props.SpecialFields[0][key].type === 'combobox' 
                && key !== 'types' 
            ){
               
               subProps[key] = props.item[key][ typeof props.SpecialFields[0][key].subname  !== 'undefined' ? props.SpecialFields[0][key].subname :  props.SpecialFields[0][key].key]
              
               
            }
          }

       

        props.onSubmit(subProps);
        setIsLoading(true)
        
       }

      

       


    return (
        <Content id="EditForm"  Theme={Theme}>
        <Dialog appendTo={null} title={GetButtonText(props.item,props.forcedText)} onClose={props.cancelEdit}>            
            <Form 
                onSubmit={PreSend}
                initialValues={props.item}
                render={formRenderProps => (
                    
                    <FormElement>
                        <fieldset className={"k-form-fieldset"}>                             
                            <Paper className="mb-3" elevation={3} style={{padding: '10px', minWidth: '300px'}}>
                                <div className= "row mb-3">
                                    
                                        {
                                             ColumnList.map((Listing:any, index:any)=>{
                                                return(
                                                    <div key={'column-'+index} className={"col-"+(12 / Columns)}>
                                                        <div className="col-12">
                                                        {

                                            Listing.map((Element:any, subindex: any) => {
                                                if(typeof props.SpecialFields !== 'undefined' && IsSpecialField(Element)){
                                                    switch(props.SpecialFields[0][Element].type){
                                                        case 'select':   
                                                                                                                                                                   
                                                            return (
                                                                <div key={Element} className="mb-2">
                                                                <DropDownList label={Element} name={Element} data={props.SpecialFields[0][Element].values} defaultValue={props.item[Element] || props.SpecialFields[0][Element].selected} onChange={(response) => {formRenderProps.onChange(Element, { value: response.value });}}/>
                                                                </div>
                                                            )
                                                        case 'multiselect':                                                            
                                                        let list = new Array;
                                                        typeof props.item[Element] === 'string' ? list.push(props.item[Element]): [...props.item[Element]].map((el:any)=>{ list.push(el)});
                                                        return(
                                                            <MultiSelect
                                                                label={'Role'}
                                                                data={props.SpecialFields[0][Element].values}
                                                                disabled={props.item.delete}
                                                                onChange={(response:any) => {formRenderProps.onChange(Element, { value: response.value });}}        
                                                                defaultValue={list}
                                                                    />
                                                        )
                                                        case 'ObjectList':{                                                            
                                                            return <ObjectList key={subindex} GivenStyles={ProjectStyles} Defs={props.SpecialFields[0][Element].DefList} requiredList={props.SpecialFields[0][Element].ReqList}  Name={Element} Title={props.SpecialFields[0][Element].title} Values={props.item[Element]} Renderer={formRenderProps}/>
                                                        } 
                                                        case 'combobox':  
                                                       
                                                        let parseval =  props.item[Element]
                                                        if(typeof parseval === 'object' &&  parseval !== null){
                                                            parseval = parseval[props.SpecialFields[0][Element].subname]
                                                        }

                                                        

                                                         let defaulty:any = props.SpecialFields[0][Element].values.find((el:any) => el[props.SpecialFields[0][Element].display] === parseval) 
                                                      


                                                        function UpdateCombo(response:any){
                                                             
                                                            formRenderProps.onChange(props.SpecialFields[0][Element].alters, { value:  response.value !== null ? response.value[props.SpecialFields[0][Element].key] : null });
                                                        }
                                                        
                                                        return (
                                                            <div key={Element} className={IsHidden(Element) ? "HiddenField" : "mb-2"}>
                                                            <ComboBox
                                                               name={Element} 
                                                               label={FindLabel(Element)}
                                                               data={props.SpecialFields[0][Element].values}
                                                               dataItemKey={props.SpecialFields[0][Element].key}
                                                               disabled={IsDisabled(Element)}
                                                               textField={props.SpecialFields[0][Element].display}                                                   
                                                               onChange={UpdateCombo}
                                                               allowCustom={false}   
                                                               clearButton={props.SpecialFields[0][Element].nulleable === true ? true : false}  
                                                               defaultValue={defaulty}   
                                                                                                                                                                                     
                                                           />
                                                           </div>
                                                        )                                                            
                                                        case 'number':                                                           
                                                            return( 
                                                                <div className={(typeof props.HiddenFieldsEditNew !== 'undefined' && props.HiddenFieldsEditNew && props.HiddenFieldsEditNew.includes(Element) && props.item.new) || (typeof props.HiddenFieldsEdit !== 'undefined' && props.HiddenFieldsEdit.includes(Element)) ? "HiddenField" : "mb-2"}                                                                 > 
                                                                <Field                                                                   
                                                                   label={FindLabel(Element)}
                                                                   name={Element}                                                                  
                                                                   component={NumericField}
                                                                   onChange={()=>{ComplexCalculation(props.SpecialFields[0][Element],formRenderProps)}}
                                                                   type='number'                                                                   
                                                                   autoComplete="off"                                                                   
                                                                   validator={props.SpecialFields[0][Element].required ? numberrequired : nonrequired}
                                                                />
                                                                </div>
                                                            )

                                                        case 'boolean':
                                                            return(
                                                                <CheckInput> 
                                                                                                                       
                                                                    <Checkbox 
                                                                    defaultChecked={formRenderProps.valueGetter(Element) ? true : false} 
                                                                    id={"Field_"+Element} 
                                                                    label={Element} 
                                                                    labelPlacement="before"
                                                                   
                                                                    onChange={(response) => {formRenderProps.onChange(Element, { value: response.value });}} 
                                                                    />
                                                                </CheckInput>
                                                            ) 
                                                               
                                                        case 'date':                                                           
                                                            return(  
                                                                <div>                                                             
                                                                
                                                                <Field                                                                   
                                                                   className={typeof props.HiddenFieldsEdit !== 'undefined' && props.HiddenFieldsEdit.includes(Element) ? "HiddenField" : ""}
                                                                   name={Element}
                                                                   component={Input}                                                                   
                                                                   type='date'                                                                   
                                                                   autoComplete="off"                                                                   
                                                                   
                                                                />  
                                                                </div>                                                           
                                                            )  
                                                            case 'text': case 'externalLink':                                                           
                                                            return(  
                                                                <div key={Element} className={IsHidden(Element) ? "HiddenField" : "mb-2"}>
                                                                <Field                                                                   
                                                                   label={FindLabel(Element)}
                                                                   name={Element}                                                                  
                                                                   component={Input} 
                                                                   disabled={IsDisabled(Element)}                                                                  
                                                                   type='text'                                                       
                                                                   validator={props.SpecialFields[0][Element].required ? required : nonrequired}
                                                                />
                                                                </div>
                                                            ) 
                                                            case 'textarea': 
                                                                    
                                                            return(  
                                                                <Field            
                                                                id={Element}                                                       
                                                                label={FindLabel(Element)}
                                                                name={Element}   
                                                                max={200}        
                                                                disabled={IsDisabled(Element)}                                                      
                                                                component={FormTextArea}  
                                                                validator={props.SpecialFields[0][Element].required ? required : nonrequired}                                                                
                                                                value={formRenderProps.valueGetter(Element)}                                                    
                                                                
                                                             />
                                                            )      

                                                        
                                                        
                                                    }
                                                } 
                                                else if(Element === 'types'){
                                                    let internalcheck = false;
                                                    let customercheck = false;
                                                    if(typeof props.item.types !== 'undefined'){
                                                       
                                                        internalcheck = props.item.types.includes('Internal');
                                                        customercheck = props.item.types.includes('Customer');
                                                       

                                                    }
                                                   
                                                    
                                                    return(
                                                        <div key={Element} className="mb-2">
                                                        <CheckBoxes>
                                                            <p>types</p>
                                                            <Checkbox defaultChecked={internalcheck} id={"Field_internal"} label={'Internal'} onChange={(value) => {UpdateField(value,'Field_internal',formRenderProps)}} />
                                                            <Checkbox defaultChecked={customercheck} id={"Field_customer"} label={'Customer'} onChange={(value) => {UpdateField(value,'Field_customer',formRenderProps)}} />
                                                            <Field
                                                             id={"Field_"+Element}
                                                             name={Element}
                                                             type='text'
                                                             component={Input}
                                                             data={props[Element]}                                                             
                                                             
                                                             disabled={props.item.delete}
                                                             validator={props.NoneRequired ? unrequired : requiredanything}
                                                        />
                                                       {JSON.stringify(props[Element])}
                                                        </CheckBoxes>
                                                        </div>
                                                        
                                                    )
                                                }
                                                else if(Element === 'icon'){
                                                    let read = formRenderProps.valueGetter('icon');
                                                   
                                                    return(
                                                    <IconSelection Theme={Theme} key={subindex}> 
                                                        <p>Icon</p>
                                                        <ol>
                                                            {IconList.map((element:any, indexe:any) => { 
                                                                return (
                                                                <li key={indexe}
                                                                    className={IconSelected.includes(element.name) || read === element.name ? 'selected' : ''} 
                                                                    onClick={()=>{
                                                                        setIconSelected(element.name); 
                                                                        formRenderProps.onChange('icon', { value: element.name });                                                                        
                                                                    }}
                                                                    >{element.comp}</li>)
                                                            })}                                                      
                                                        </ol>
                                                    <Field
                                                             id={"Field_"+Element}
                                                             name={Element}
                                                             component={Input}
                                                             data={props[Element]}
                                                             type="hidden"                                                             
                                                             disabled={IsDisabled(Element)}
                                                             validator={props.NoneRequired ? unrequired : required}
                                                        />
                                                    </IconSelection>   
                                                    )
                                                }
                                                else{       
                                                                                      
                                                    return(
                                                        <div key={Element} className={IsHidden(Element) ? "HiddenField" : "mb-2"}>
                                                        {CheckifSpecialValues(Element,formRenderProps)} 
                                                        </div>
                                                    )
                                                }
                                                
                                                
                                            })
                                        }
                                              </div>
                                              </div>
                                          )
                                       })
                                   }
                                   
                                        
                                        
                                                                      
                                       
                                   
                                   
                                    
                                    
                                </div>
                                
                            </Paper>
                            
                        </fieldset>
                        <div className="k-form-buttons">                            
                            <FormPrimaryButton   
                                                        
                                id="Form_Button_Submit"
                                type={"submit"}
                               
                                disabled={!formRenderProps.allowSubmit && !props.item.delete || IsLoading}
                                onClick={props.item.delete ? props.onSubmit : null}
                            >
                                {IsLoading ? <Loading Name="ButtonFit"/> : GetRevenuesButtonText(props.item)}
                            </FormPrimaryButton>
                            <FormSecondaryButton
                                id="Form_Button_Cancel"
                                type={"submit"}
                               
                                onClick={props.cancelEdit}
                            >
                                Cancel
                            </FormSecondaryButton>
                        </div>
                    </FormElement>
                )}
            />
        </Dialog>
        </Content>
    );
};
export default EditForm;

const IconSelection = styled.div<any>({
   'ol':{
       listStyle: 'none',
       padding: '0px',
       display: 'grid',
       gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 1fr',
       gridGap: '5px',
       maxWidth: '300px'
      
    },
   'li':{    
    cursor: 'pointer',    
   },
   'li.selected svg , li.selected img': {
    
    stroke: 'white'
    },
   'path':{color: 'transparent'},
   'svg, img':{
        ':hover':{          
            stroke: 'white'
        },
        pointerEvents: 'all',
        width: '40px',
        padding: '3px',
        fontSize: '40px',  
        borderRadius: '5px',
        strokeWidth: '0.6px'
   }
  }, props =>({
    'li.selected svg, li.selected img': {
        backgroundColor:  props.Theme.Corporate.lightBlue,
    },
    'svg, img':{
        ':hover':{
            backgroundColor : props.Theme.Corporate.lightBlue
        },
        stroke: props.Theme.Corporate.darkBlue,
        border: '1px solid '+props.Theme.Corporate.darkBlue,
    }
 }))

const CheckBoxes = styled.div({
  position: 'relative',
  display: 'flex',
  paddingTop: '20px',
  justifyContent: 'space-evenly' ,
  'p':{
      position: 'absolute',
      top: '-15px',
      left: '0px'
  },
  'input[type=text]':{
      color: 'transparent',
      position: 'absolute',
      width: '70%',
      pointerEvents: 'none'
  } 
})


const Content = styled.div<any>({
    '.HiddenField':{
        display: 'none'
    },  
    '.k-form-buttons':{
        display: 'flex',
        justifyContent: 'space-between'
    },
    '.k-content.k-window-content.k-dialog-content' :{
        overflow: 'visible'
    },
    '.k-select':{
        opacity: '1 !important'
    },
    'svg':{
        pointerEvents: 'none'
    },
    'textarea:disabled':{
       opacity: 0.6       
        
    },
    '.k-label.k-text-disabled':{opacity: 0.6},
    '.k-text-disabled + .k-form-field-wrap > .k-textarea:hover':{
        backgroundColor: '#f5f5f5'
    },
    '.k-text-disabled':{
        
        opacity: 1
    },
    '.k-textbox:disabled':{
        borderStyle: 'solid'
    }
}, props =>({
   '.k-button.k-primary:not(.k-button:disabled)':{
       backgroundColor: props.Theme.Corporate.darkBlue
   }
}))

const CheckInput = styled.div({
    textTransform: 'capitalize',
    label: {
        
        fontSize: '16px',
        marginInlineStart: '20px !important'
    }
    
})