import React  from 'react';
import styled from "@emotion/styled";
import ZurichLogo from '../../assets/images/logo-white.png'
import LogManager from "./LogManager"
import {useSelector,useDispatch} from 'react-redux';
import {setSidebarStatus}  from '../../store/slices/user'
import {IconWhiteBurger} from './Icons'
import Configuration from '../../configuration/configuration'

// this component forms the header bar with navigarion menu, sidebar burger action icon and login manager
export default function Header(props:any){
    const Theme =  useSelector((state: any) => state.Theme) ;   
    const sidebarStatus = useSelector((state: any) => state.userData.sidebarDeploy);
    const header = Configuration.value('HEADER');
    let dispatch = useDispatch();

    
    
    function Switch(){
       
        switch(sidebarStatus){
            case 'Closed':  dispatch(setSidebarStatus('Open'));
                break;
            case 'Open':  dispatch(setSidebarStatus('Compact'));
                break;
            case 'Compact':  dispatch(setSidebarStatus('Closed'));
                break;       
        }
    }


    return(
        <Contenedor id="Header" Theme={Theme}>  
            <Upper>
                <Brand><img src={ZurichLogo} alt="Zurich logo"/></Brand>
                <h1>{header === null || typeof header === 'undefined' || (header.startsWith('$') && header.endsWith('REACT_APP_HEADER')) ? 'Financial Portal' : header}</h1>
                <div><LogManager/></div>
            </Upper>  
            <Lower>
                <Product>
                    <Burger Theme={Theme} id="Header_Button_Hamburger" onClick={Switch}>
                        
                        {IconWhiteBurger('MuiSvgIcon-root')}
                    </Burger>
                </Product> 
            </Lower>
        </Contenedor>
    )
}
 


const Product = styled.div({
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'baseline',
    textAlign: 'right',
    width: '5vw',
    color: 'blue',   
    position: 'relative',
    'span':{
        width: '50%',
        fontSize: '110%',
        padding: '5px',
        fontWeight: 'bold',
        color: '#003399'
    }
})
const Burger = styled.div<any>({ 
    'img':{
        height: '20px',
        width: '30px',
        cursor: 'pointer',       
       
        strokeWidth: '0.6px',
        transition: 'all 100ms'
    },
    height: '40px',
    position: 'absolute',
    bottom: '5px',
    display: 'flex',
    justifyContent:'center',
    alignItems: 'center',
    left: '2px',
    width: '40px',
    backgroundSize: 'cover',
    cursor: 'pointer',
}, props =>({
    'svg':{
        color: props.Theme.Corporate.darkBlue,
       
        
    }
}))
const Upper = styled.div({   
    width: '100%',
    display: 'flex',
    justifyContent: 'space-between',
    '> div':{
        position: 'relative',
        ':last-of-type':{
            width: '250px'
        }
    },
    
})
const Lower = styled.div({   
    width: '100%',
    display: 'flex',
    justifyContent: 'flex-start',
    position: 'relative'
})
const Brand = styled.div({
    marginLeft: '45px',
    display: 'flex',
    height: '50px',
    justifyContent: 'center',
    alignItems: 'center',
    'img':{
     //filter : 'invert(1) saturate(0)',
     height: '120%'
    }
    
})
const Contenedor = styled.div<any>({ 
    
    paddingTop: '0px',
    maxHeight: '150px',
    position: 'relative',
    width: '100%',
    backgroundColor: 'white',
    zIndex: 11,    
    boxShadow: '0px 0px 10px 0px rgb(0 0 0 / 0.3)',
    h1:{
       
        padding: '0px',
        margin: '0px',
        fontSize: '20px',
        fontWeight: 'bold',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    }

    
}, props =>({
    'h1':{
        color: 'white'//props.Theme.Corporate.darkBlue,
    },
    backgroundColor: props.Theme.Corporate.darkBlue
}))