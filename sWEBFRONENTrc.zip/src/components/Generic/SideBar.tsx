import React  from 'react';
import styled from "@emotion/styled";
import Menu from "../Navigation/Menu"
import { CSSTransition } from 'react-transition-group';
import {useSelector} from 'react-redux';

// this component handles the sidebar context menu
export default function SideBar(props:any){
    const Theme =  useSelector((state: any) => state.Theme) ;  
    
    const Contenedor = styled.div({
       
        position: 'relative',
        overflow: 'hidden',
        height: 'inherit',
        maxHeight: '2000px',
        minHeight: 'calc(100vh - 50px)',
        zIndex: 5,
        backgroundColor: Theme.Corporate.paleBlue,
        width: '14vw',  
        minWidth: '150px', 
        boxShadow: '0px 0px 5px 0px rgb(0 0 0 / 0.5)',
        'a': {textDecoration: 'none'},
        '.Sub':{
            paddingLeft:'10px'
        }
        
    });


    return(            
        <CSSTransition in={props.ShowSideBar !== 'Closed' ? true : false} timeout={200} classNames="SideBarHeight">      
        <Contenedor key='Sidebar' id="SideBar">  
            <Menu Status={props.ShowSideBar}/>            
        </Contenedor> 
        </CSSTransition>          
    )
}

