import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Button } from '@progress/kendo-react-buttons';
import styled from "@emotion/styled";
import Loading from './Loading'
import {ToolbarButton} from './Styles'

export default function SaveBtn(props:any){
    const Theme = useSelector( (state: any) => state.Theme); 
    const Status = useSelector( (state: any) => state.userData).Static.MonthBlockerChanged; 
   


    return(
        <Toolbar className="col-12" Theme={Theme}>                            
            {!props.Granted.edit ? null :
            <ToolbarButton className="rounded float-right" onClick={props.Submit} disabled={!Status || props.Loading}>
                {props.Loading ? <Loading Name="ButtonFit"/> : "Save Changes" }

            </ToolbarButton>
            }
        </Toolbar> 
    )
}


const Toolbar = styled.div<any>({
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',
        color: '#003399',
        cursor: 'pointer',
    },
    padding: '0px',
    margin: '10px 0px'
    
     }, props =>({
        '.k-button-primary, .k-button.k-primary:not(:disabled)':{
            backgroundColor: props.Theme.Corporate.darkBlue,
            borderColor: props.Theme.Corporate.darkBlue,
        },
        'svg':{
            color: props.Theme.Corporate.darkBlue,          
            fill: props.Theme.Corporate.darkBlue,   
         }
     }))
