import React, {useState} from 'react';
import styled from "@emotion/styled"; 
import { Dialog } from "@progress/kendo-react-dialogs";
import {useSelector} from 'react-redux';
import {
  Form,
  Field,  
  FieldWrapper,
} from "@progress/kendo-react-form";
import { Label, Error } from "@progress/kendo-react-labels";
import { TextArea } from "@progress/kendo-react-inputs";
import Loading from "./Loading";
import RevenueService from "../../services/RevenueService";
import {FormPrimaryButton, FormSecondaryButton} from './Styles'
interface Expected {
  Revenue: number,
  Callback?: any
}


// this component styles the main screen workarea
export default function AddComment(props:Expected){ 
    const Theme =  useSelector((state: any) => state.Theme) ;
    const [open,setOpen] = useState(false);
    const [sending, setSending] = useState(false);   
    const [item, setItem] = useState(new Object);
    const textAreaValidator = (value:any) => (!value ? "Please enter a text." : "");
    const FormTextArea = (fieldRenderProps:any) => {
        const {
          validationMessage,
          touched,
          label,
          id,
          valid,
          disabled,
          hint,
          type,
          optional,
          max,
          value,
          ...others
        } = fieldRenderProps;
      
        const showValidationMessage = touched && validationMessage;
        const showHint = !showValidationMessage && hint;
        const hindId = showHint ? `${id}_hint` : "";
        const errorId = showValidationMessage ? `${id}_error` : "";
      
        return (
          <FieldWrapper>
            <Label
              editorId={id}
              editorValid={valid}
              editorDisabled={disabled}
              optional={optional}
            >
              {label}
            </Label>
            <div className={"k-form-field-wrap"}>
              <TextArea
                valid={valid}
                type={type}
                id={id}
                max={255}
                disabled={disabled}
                maxlength={max}
                rows={4}
                ariaDescribedBy={`${hindId} ${errorId}`}
                {...others}
              />
              
              {showValidationMessage && (
                <Error id={errorId}>{validationMessage}</Error>
              )}
            </div>
          </FieldWrapper>
        );
      };

   


    if(open && sending){setOpen(false); setSending(false) ; 
      if(typeof props.Callback !== 'undefined') {props.Callback(item);}
    }

      const handleSubmit = (propsa:any) => {
        
        setSending(true);
       let IncComments = new Array;

       IncComments.push(propsa);

        let SendItem = {
          Id: props.Revenue,
          Comments: IncComments
        }

        setItem(SendItem);

        RevenueService.addComment(SendItem)

      }

    if(open && sending){
      return(
        <Content id="AddComment" Theme={Theme}>  
            <button className="k-button k-button-primary" onClick={(e:any)=>{e.preventDefault();setOpen(true)}}>Add Comment</button>    
            <Dialog appendTo={null}>
                <Loading/>
            </Dialog>
        </Content>
      )
    }
    else if(open && !sending){
      return(
        <Content id="AddComment" Theme={Theme}>  
          <button className="k-button k-button-primary" onClick={(e:any)=>{e.preventDefault();setOpen(true)}}>Add Comment</button>    
          <Dialog appendTo={null}>
          <Form          
                render={formRenderProps => (
                <div>
                   <Field
                    id={"AddComment"}
                    name={"AddComment"}
                    label={"Comment to add:"}
                  
                    value={formRenderProps.valueGetter("AddComment")}
                    hint={"Hint: Enter your text here"}
                    component={FormTextArea}
                    validator={textAreaValidator}
                    />
                    <div className="k-form-buttons">
                        <FormPrimaryButton
                            type={"submit"}
                            className="k-button"
                            disabled={!formRenderProps.allowSubmit}
                            onClick={() => {handleSubmit(formRenderProps.valueGetter("AddComment"))}}
                        >
                            {sending ? <Loading Name="ButtonFit"/> : 'Add'}
                        </FormPrimaryButton>
                        <FormSecondaryButton
                            type={"submit"}
                            className="k-button"
                            onClick={()=>{setOpen(false)}}
                        >
                            Cancel
                        </FormSecondaryButton>
                                
                        </div>
                </div>)} />
                
          </Dialog>
        </Content>
      )
    }else{
      return(
        <Content id="AddComment" Theme={Theme}>  
        <FormPrimaryButton className="k-button k-button-primary" onClick={(e:any)=>{e.preventDefault();setOpen(true)}}>Add Comment</FormPrimaryButton>    
       
    </Content>
      )
    }
 
}

const Content = styled.div<any>({    
   '.k-form-buttons' :{
     display: 'flex',
     justifyContent: 'space-between',
     marginTop: '10px'
   } 
}, props =>({
  'button ':{
      backgroundColor: props.Theme.Corporate.darkBlue,
      color: 'white'
  },
}));
