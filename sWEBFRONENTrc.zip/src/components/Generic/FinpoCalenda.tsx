import * as React from "react";
import styled from "@emotion/styled"; 

import {
  CalendarNavigationItem,
  CalendarNavigationItemProps,
  Calendar,
  CalendarChangeEvent
} from "@progress/kendo-react-dateinputs";


const CustomNavigationItem = (props: CalendarNavigationItemProps) => {
    //console.log(props)
  return (
     
    <CalendarNavigationItem {...props}>
      <Styler>
        {/* Months count starts from 0 */}
        {<span className={props.isRangeStart ? 'Separator' : ''}>{props.isRangeStart ?  'Jan ' + props.text  : props.text}</span>}
      </Styler>
    </CalendarNavigationItem>
   
  );
};




export default function FinpoCalenda(props:any) {
  return <Calendar navigationItem={CustomNavigationItem} onChange={(e:CalendarChangeEvent) => {
          
    props.callback(e.target.value,props.param);
   
   
   
  
}}  />;
};

const Styler = styled.div({    
   '.Separator':{

    position: 'absolute',
    left: '9px',
    overflow: 'visible',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',

   }
});