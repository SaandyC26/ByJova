import React from 'react';
import styled from "@emotion/styled";
import {useSelector,useDispatch} from 'react-redux';
import {useNavigate } from 'react-router-dom';
import {setError} from '../../store/slices/user';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';

interface Themeprops {
    Theme: any
}


// this component lays over all components and provides common interface for all pages
export default function ErrorDialog(props:any){
    let dispatch = useDispatch();
    let history = useNavigate();
    const Error = useSelector( (state: any) => state.userData.Error);  
   
    const Theme = useSelector( (state: any) => state.Theme);
    const GenericError = "Something went wrong; please close this dialog in order to refresh this page and try again. Thank you.";
    
    function CloseError(){
        dispatch(setError({Show:false, Msg: GenericError})); 
        if(Error.Mode === 'GoBack'){ history(-1);}
       
    } 
   

    return(
              
        <div id="Dialog Error"> 
            {!Error.Show ? null : 
            <Main Theme={Theme}>
                <span onClick={CloseError}><HighlightOffIcon/></span>
                <h1>Error</h1>
                <div>{Error.Msg}</div>
            </Main> }               
        </div>
        
    )
}

const Main = styled.div<Themeprops>({
    padding: '20px',
    position: 'fixed',
    top: '50%',
    left: '50%',    
    width: '50%', 
    boxShadow: '0px 0px 0px 5000px rgb(0 0 0 / 0.4)',
    zIndex: 90000,
    borderRadius: '8px',
    color: 'white',
    transform: 'translate(-50%, -50%)',
    'h1':{
        textAlign: 'center',
        color: 'white',
        fontSize: '24px'
    },
    'p':{
       
    },
    'span':{
        position: 'absolute',
        top: '10px',
        right: '10px',
        cursor: 'pointer',
        
       
        
    }
},props=>({    
    backgroundColor: props.Theme.Corporate.darkBlue,
     
    
}))