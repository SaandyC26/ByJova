import React  from 'react';
import styled from "@emotion/styled";
import {useDispatch} from 'react-redux';
import {setCorporateBlue ,setCorporateDarkBlue,setCorporateLightBlue,setCorporatePaleBlue} from '../../store/slices/theme';


const Colors = {
    Main : '#c71068',
    Dark : '#730062',
    Light: '#fdb7f3',
    Pale: '#ffdefa'
}

// this component lays over all components and provides common interface for all pages
export default function DevWarning(props:any){      
    let dispatch = useDispatch();   
    dispatch(setCorporateBlue(Colors.Main));
    dispatch(setCorporateDarkBlue(Colors.Dark));
    dispatch(setCorporateLightBlue(Colors.Light)); 
    dispatch(setCorporatePaleBlue(Colors.Pale)); 
    return(              
        <Content id="DevWarning">Development Mode</Content>        
    )
}


const Content = styled.div({
    position: 'fixed',
    top: '30px',
    right: '-3px',
    fontSize: '90%',
    pointerEvents: 'none',
    backgroundColor: Colors.Pale,
    zIndex: 9000,
    borderRadius: '10px 0px 0px 10px',
    color: Colors.Main,
    border: '2px solid '+Colors.Main,
    textShadow: '1px 0px 0px rgb(0 0 0 / 20%)',
    padding: '5px',


})
