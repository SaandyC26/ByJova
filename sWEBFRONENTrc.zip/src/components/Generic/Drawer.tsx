import React, {useState, useEffect}  from 'react';
import {Drawer, DrawerContent} from "@progress/kendo-react-layout";
import Menu from "../Navigation/Menu"
import { Slide } from "@progress/kendo-react-animation";
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import { useLocation } from "react-router-dom";

export default function DrawerComp(props:any){   
  const Theme =  useSelector((state: any) => state.Theme) ;  
  const slug  = useLocation(); 
  
  const [ExpandedHeight, setExpandedHeight] = useState(true);
  const [ExpandedWidth, setExpandedWidth] = useState(true);

  useEffect(() => {     
   if(props.Lead !== 'Open' && ExpandedWidth){setExpandedWidth(false)}
   if(props.Lead === 'Closed' && ExpandedHeight){setExpandedHeight(false)}

   if(props.Lead === 'Open' && !ExpandedWidth){setExpandedWidth(true)}
   if(props.Lead !== 'Closed' && !ExpandedHeight){setExpandedHeight(true)}
},[props])





  const SidebarContent = ExpandedHeight && slug.pathname !== '/login/' ? 
  
  <Drawer 
      expanded={ExpandedWidth}
      position={"start"}
      mode={"push"}
      mini={true}
     
      
    >
      <DrawerContent >
        <Menu Status={props.Lead}/>
      </DrawerContent>
  </Drawer> 
: null;

  return(
    <Contenedor id="SideBar"  Theme={Theme}><Slide>{SidebarContent}</Slide></Contenedor>
  )


}


const Contenedor = styled.div<any>({
  '.k-child-animation-container':{
    minHeight: 'calc(100vh - 50px)'
  },
  '.k-drawer-expanded':{
    width: '150px !important'
  },
  '.k-drawer-mini:not(.k-drawer-expanded)':{
    width: '55px',
    '>div':{
      li:{
        maxWidth: '55px',
        '.MuiAccordionSummary-content > div > span':{
          width: '17px',
          margin: '0px'
        },
        '.MuiAccordionSummary-expandIcon':{
          marginRight: '-9px !important'
        }
      },
      '.NotCompact .MuiButtonBase-root':{
        width: '40px !important',
        marginRight: '27px'
      }
    },
    
  },
   
  boxShadow: '0px 0px 5px 0px rgb(0 0 0 / 0.5)',
  'a': {textDecoration: 'none'},
  '.Sub':{
      paddingLeft:'10px'
  }
  
}, props =>({
  backgroundColor: props.Theme.Corporate.paleBlue,
}))