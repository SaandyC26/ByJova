import React, {useState}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import { withStyles, Theme } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Popup from "../Generic/Popup";
import {ToolbarButton} from '../Generic/Styles'

interface Themeprops {
    Theme: any
}

interface Expected {
    CallBack: any;
}

// this component handles login/out operations
export default function ResetDemandGridSettings(props:Expected){
   const MainTheme = useSelector( (state: any) => state.Theme); 
   const [Status, SetStatus] = useState(false);  

   function SwitchStatus(){
    SetStatus(!Status);
}
   const handleTooltipClose = () => {
    SetStatus(false);
  };

  function Reset(type:string){
    props.CallBack(type);
    SwitchStatus();
  }

    
    
    const HtmlTooltip = withStyles((theme: Theme) => ({
        arrow: {
            color: MainTheme.Corporate.blue,
          },
          tooltip: {
              backgroundColor: MainTheme.Corporate.blue,
              color: 'white',  
              textShadow: '0px 0px 0px '+MainTheme.Corporate.darkBlue,   
              fontSize: '90%' ,
              minWidth: 220
          },
        
      }))(Tooltip);
   
   
   return(
        
           
    <Content Theme={MainTheme} id="Settings">    
    <ClickAwayListener onClickAway={handleTooltipClose}>
        <Contenedor>             
        
            <HtmlTooltip
            arrow
            PopperProps={{
                disablePortal: true,
            }}
            className='settingsToolTip'
            interactive
            open={Status}
            onClose={handleTooltipClose}
            disableFocusListener
            disableHoverListener
            disableTouchListener
            title={
                <Popup>
                    <ol>
                        <li onClick={(e:any) => Reset('Filter')} id="Reset_column_filters">Reset Column Filters</li>
                        <li onClick={(e:any) => Reset('Sort')} id="Reset_column_sort">Reset Column Sorting</li>                        
                        <li onClick={(e:any) => Reset('Order')} id="Reset_column_order">Reset Column Order</li>
                        <li onClick={(e:any) => Reset('Width')} id="Reset_column_widths">Reset Column Widths</li>
                        <li onClick={(e:any) => Reset('Visible')} id="Reset_column_visibility">Reset Column Visibility</li>
                        <li onClick={(e:any) => Reset('All')} id="Reset_column_all">Reset All</li>
                    </ol>
                </Popup>
            }
        >
                
                <ToolbarButton id="Grid_Reset_settings" onClick={SwitchStatus} className="k-button k-primary rounded">Reset Grid Settings</ToolbarButton>
            </HtmlTooltip>  
        
            
           
            
            
            
        </Contenedor>    
        </ClickAwayListener>
    </Content> 
             
        
        
    )
}


const Contenedor = styled.div({
   
    
   
    zIndex: 500
    
    })
const Content = styled.div<Themeprops>({
        '.logToolTip + div > div' :{       
           
            fontFamily: '"Frutiger 45 Light"'
        },
        '.logToolTip + div .MuiTooltip-arrow':{
            left: '10px',
           
            transform: ' scale(1.5) translateY(-1px)'
        }
    
},props=>({    
        '.logToolTip + div > div' :{
            backgroundColor: props.Theme.Corporate.blue,
            
        }
}))

   



