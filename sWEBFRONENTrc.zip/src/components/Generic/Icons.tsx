import React  from "react";
import store from '../../store';
import styled from "@emotion/styled";
import ImageIconUser from '../../assets/images/icon-user.png'
import ImageIconQuestion from '../../assets/images/icon-question.png'
import ImageIconGear from '../../assets/images/icon-gear.png'
import ImageIconVoice from '../../assets/images/icon-voice.png'
import ImageIconHome from '../../assets/images/icon-home.png'
import ImageIconCoin from '../../assets/images/icon-coin.png'
import ImageIconPouch from '../../assets/images/icon_pouch.png'
import ImageIconCalendar from '../../assets/images/icon-calendar.png'
import ImageIconCustom from '../../assets/images/icon-custom.png'
import ImageIconHandGlobal from '../../assets/images/icon-hand_global.png'
import ImageIconPeople from '../../assets/images/icon-people.png'
import ImageIconCharging from '../../assets/images/icon-charging.png'
import ImageIconBussines from '../../assets/images/icon-bussines.png'
import ImageIconList from '../../assets/images/icon-list.png'
import ImageIconProduct from '../../assets/images/icon-product.png'
import ImageIconFolder from '../../assets/images/icon-folder.png'
import ImageIconPplGear from '../../assets/images/icon-pplgear.png'
import ImageIconCostCenter from '../../assets/images/icon-costcenter.png'
import ImageIconPlane from '../../assets/images/icon-plane.png'
import ImageIconStar from '../../assets/images/icon-star.png'
import ImageIconBell from '../../assets/images/icon-bell.png' 
import ImageIconTool from '../../assets/images/icon-tool.png' 
import ImageIconBook from '../../assets/images/icon-book.png'
import ImageIconLight from '../../assets/images/icon-light.png'
import ImageIconLock from '../../assets/images/icon-lock.png'
import ImageIconGlobe from '../../assets/images/icon-globe.png'
import ImageIconLoop from '../../assets/images/icon-loop.png'
import ImageIconArrow_right_up from '../../assets/images/icon-arrow_right_up.png'
import ImageIconArrow_down from '../../assets/images/icon-arrow_down.png'
import ImageIconArrow_wide from '../../assets/images/icon-arrow-wide.png'
import ImageIconArrowMin from '../../assets/images/icon-arrow_min.png'
import ImageIconArrowSplit from '../../assets/images/icon-arrow_split.png'
import ImageIconInfo from '../../assets/images/icon-info.png'
import ImageIconBank from '../../assets/images/icon-bank.png'
import ImageIconClipboard from '../../assets/images/icon-clipboard.png'
import ImageIconAlert from '../../assets/images/icon-alert.png'
import ImageIconForm from '../../assets/images/icon-form.png'
import ImageIconBurger from '../../assets/images/icon-burger.png'
import ImageIconPlus from '../../assets/images/icon-plus.png'
import ImageIconTrash from '../../assets/images/icon-trash.png'
import ImageIconEdit from '../../assets/images/icon-edit.png'

import ImageIconWhiteQuestion from '../../assets/images/icon-white-question.png'
import ImageIconWhitePerson from '../../assets/images/icon-white-person.png'
import ImageIconWhiteGear from '../../assets/images/icon-white-gear.png'
import ImageIconWhiteVolume from '../../assets/images/icon-white-volume.png'
import ImageIconWhiteBurger from '../../assets/images/icon-white-burger.png'

export const Megaphone =
  
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="-2 -3 27 27" aria-hidden="true"><path d="m23 9.6c0-.9-.5-1.8-1.3-2.2v-6.1c.1-.4-.2-1.3-1.2-1.3c-.3 0-.6.1-.8.3l-3.4 2.7c-1.7 1.4-3.9 2.1-6.1 2.1h-7.6c-1.4 0-2.6 1.1-2.6 2.6v3.8c0 1.4 1.1 2.6 2.6 2.6h1.3c-.1.4-.1.8-.1 1.3c0 1.6.4 3.1 1 4.4c.2.4.7.7 1.1.7h3c1 0 1.7-1.2 1-2c-.7-.9-1-1.9-1-3.1c0-.4.1-.9.2-1.3h1.1c2.2 0 4.3.8 6 2.1l3.4 2.7a1.3 1.3 90 00.8.3c1 0 1.3-.9 1.3-1.3v-6.1c.8-.4 1.3-1.3 1.3-2.2zm-3.8 5.7-1.3-1.1c-2.2-1.7-4.9-2.7-7.7-2.7v-3.8c2.8 0 5.5-1 7.6-2.7l1.4-1.1v11.3z"></path></svg>


export const bug =
  
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M 20 8 h -2.81 c -0.45 -0.78 -1.07 -1.45 -1.82 -1.96 L 17 4.41 L 15.59 3 l -2.17 2.17 C 12.96 5.06 12.49 5 12 5 c -0.49 0 -0.96 0.06 -1.41 0.17 L 8.41 3 L 7 4.41 l 1.62 1.63 C 7.88 6.55 7.26 7.22 6.81 8 H 4 v 2 h 2.09 c -0.05 0.33 -0.09 0.66 -0.09 1 v 1 H 4 v 2 h 2 v 1 c 0 0.34 0.04 0.67 0.09 1 H 4 v 2 h 2.81 c 1.04 1.79 2.97 3 5.19 3 s 4.15 -1.21 5.19 -3 H 20 v -2 h -2.09 c 0.05 -0.33 0.09 -0.66 0.09 -1 v -1 h 2 v -2 h -2 v -1 c 0 -0.34 -0.04 -0.67 -0.09 -1 H 20 V 8 z v 2 z z"></path></svg>


export const infinite =
    
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="-1 0 26 25" aria-hidden="true"><path d="M18.6 6.62c-1.44 0-2.8.56-3.77 1.53L12 10.66 10.48 12h.01L7.8 14.39c-.64.64-1.49.99-2.4.99-1.87 0-3.39-1.51-3.39-3.38S3.53 8.62 5.4 8.62c.91 0 1.76.35 2.44 1.03l1.13 1 1.51-1.34L9.22 8.2C8.2 7.18 6.84 6.62 5.4 6.62 2.42 6.62 0 9.04 0 12s2.42 5.38 5.4 5.38c1.44 0 2.8-.56 3.77-1.53l2.83-2.5.01.01L13.52 12h-.01l2.69-2.39c.64-.64 1.49-.99 2.4-.99 1.87 0 3.39 1.51 3.39 3.38s-1.52 3.38-3.39 3.38c-.9 0-1.76-.35-2.44-1.03l-1.14-1.01-1.51 1.34 1.27 1.12c1.02 1.01 2.37 1.57 3.82 1.57 2.98 0 5.4-2.41 5.4-5.38s-2.42-5.37-5.4-5.37z"></path></svg>
    


export const dash =
    
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"></path></svg>
    
 

export const arrows =
    
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z"></path></svg>
    
export const administration = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10h3v7H4zM10.5 10h3v7h-3zM2 19h20v3H2zM17 10h3v7h-3zM12 1L2 6v2h20V6z"></path></svg>
export const wrench = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"></path></svg> 
export const bussines = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 16v-1H3.01L3 19c0 1.11.89 2 2 2h14c1.11 0 2-.89 2-2v-4h-7v1h-4zm10-9h-4.01V5l-2-2h-4l-2 2v2H4c-1.1 0-2 .9-2 2v3c0 1.11.89 2 2 2h6v-2h4v2h6c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-6 0h-4V5h4v2z"></path></svg>
export const star = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"></path></svg>
export const lock = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"></path></svg>
export const global = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zm6.93 6h-2.95c-.32-1.25-.78-2.45-1.38-3.56 1.84.63 3.37 1.91 4.33 3.56zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14C4.1 13.36 4 12.69 4 12s.1-1.36.26-2h3.38c-.08.66-.14 1.32-.14 2 0 .68.06 1.34.14 2H4.26zm.82 2h2.95c.32 1.25.78 2.45 1.38 3.56-1.84-.63-3.37-1.9-4.33-3.56zm2.95-8H5.08c.96-1.66 2.49-2.93 4.33-3.56C8.81 5.55 8.35 6.75 8.03 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66c-.09-.66-.16-1.32-.16-2 0-.68.07-1.35.16-2h4.68c.09.65.16 1.32.16 2 0 .68-.07 1.34-.16 2zm.25 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95c-.96 1.65-2.49 2.93-4.33 3.56zM16.36 14c.08-.66.14-1.32.14-2 0-.68-.06-1.34-.14-2h3.38c.16.64.26 1.31.26 2s-.1 1.36-.26 2h-3.38z"></path></svg>
export const plane = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16v-2l-8.5-5V3.5c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5V9L2 14v2l8.5-2.5V19L8 20.5V22l4-1 4 1v-1.5L13.5 19v-5.5L22 16z"></path></svg>
export const bell = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"></path></svg>
export const trendup = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 6l2.29 2.29-4.88 4.88-4-4L2 16.59 3.41 18l6-6 4 4 6.3-6.29L22 12V6z"></path></svg>
export const trenddown = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M16 18l2.29-2.29-4.88-4.88-4 4L2 7.41 3.41 6l6 6 4-4 6.3 6.29L22 12v6z"></path></svg>
export const plus = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"></path></svg>
export const merge = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M17 20.41L18.41 19 15 15.59 13.59 17 17 20.41zM7.5 8H11v5.59L5.59 19 7 20.41l6-6V8h3.5L12 3.5 7.5 8z"></path></svg>
export const split = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4l2.29 2.29-2.88 2.88 1.42 1.42 2.88-2.88L20 10V4zm-4 0H4v6l2.29-2.29 4.71 4.7V20h2v-8.41l-5.29-5.3z"></path></svg>
export const loop = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"></path></svg>
export const info = <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path></svg>

export const rebooking = <svg className="MuiSvgIcon-root" viewBox="-8 2 45 35">
        <path d="M16.44 24.57L13.05 23.55C12.66 23.43 12.39 23.04 12.39 22.59C12.39 22.05 12.81 21.6 13.29 21.6H15.39C15.72 21.6 16.05 21.69 16.35 21.87C16.59 22.02 16.92 22.02 17.1 21.81L18 20.97C18.27 20.73 18.24 20.28 17.94 20.07C17.28 19.56 16.44 19.26 15.6 19.23V17.4C15.6 17.07 15.33 16.8 15 16.8H13.8C13.47 16.8 13.2 17.07 13.2 17.4V19.2C11.43 19.26 9.99 20.76 9.99 22.59C9.99 24.09 10.98 25.44 12.36 25.83L15.75 26.85C16.14 26.97 16.41 27.36 16.41 27.81C16.41 28.35 15.99 28.8 15.51 28.8H13.41C13.05 28.8 12.72 28.71 12.45 28.53C12.21 28.38 11.88 28.38 11.7 28.59L10.8 29.43C10.53 29.67 10.56 30.12 10.86 30.33C11.52 30.84 12.36 31.14 13.2 31.17V33C13.2 33.33 13.47 33.6 13.8 33.6H15C15.33 33.6 15.6 33.33 15.6 33V31.2C17.37 31.14 18.81 29.64 18.81 27.81C18.81 26.31 17.82 24.99 16.44 24.57ZM5.4 7.2H13.8C14.13 7.2 14.4 6.93 14.4 6.6V5.4C14.4 5.07 14.13 4.8 13.8 4.8H5.4C5.07 4.8 4.8 5.07 4.8 5.4V6.6C4.8 6.93 5.07 7.2 5.4 7.2ZM14.4 11.4V10.2C14.4 9.87 14.13 9.6 13.8 9.6H5.4C5.07 9.6 4.8 9.87 4.8 10.2V11.4C4.8 11.73 5.07 12 5.4 12H13.8C14.13 12 14.4 11.73 14.4 11.4ZM27.75 7.35L21.45 1.05C20.79.39 19.86 0 18.9 0H3.6C1.62 0 0 1.62 0 3.6V34.8C0 36.78 1.62 38.4 3.6 38.4H25.2C27.18 38.4 28.8 36.78 28.8 34.8V9.9C28.8 8.94 28.41 8.01 27.75 7.35ZM19.2 2.43C19.41 2.49 19.59 2.61 19.77 2.76L26.04 9.06C26.22 9.21 26.31 9.39 26.37 9.6H19.2V2.43ZM26.4 34.8C26.4 35.46 25.86 36 25.2 36H3.6C2.94 36 2.4 35.46 2.4 34.8V3.6C2.4 2.94 2.94 2.4 3.6 2.4H16.8V10.2C16.8 11.19 17.61 12 18.6 12H26.4V34.8Z"/>
</svg>

export const barcelona = <svg className="MuiSvgIcon-root" viewBox="1 0 47 47">
        <path d="M30 29.1c-.2 0-.3-.1-.3-.3V21c0-.2.1-.3.3-.3s.3.1.3.3v7.8C30.3 28.9 30.2 29.1 30 29.1ZM18 29.1c-.2 0-.3-.1-.3-.3V21c0-.2.1-.3.3-.3s.3.1.3.3v7.8C18.3 28.9 18.2 29.1 18 29.1ZM30 33.3c-.2 0-.3-.1-.3-.3v-2.4c0-.2.1-.3.3-.3s.3.1.3.3v2.4C30.3 33.1 30.2 33.3 30 33.3ZM36.6 20c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C36.7 20 36.7 20 36.6 20ZM36.6 21.8c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C36.7 21.8 36.7 21.8 36.6 21.8ZM36.6 23.6c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C36.7 23.6 36.7 23.6 36.6 23.6ZM30 15.8c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C30.1 15.8 30.1 15.8 30 15.8ZM30 17.6c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C30.1 17.6 30.1 17.6 30 17.6ZM18 15.8c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C18.1 15.8 18.1 15.8 18 15.8ZM30 14c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C30.1 14 30.1 14 30 14ZM18 14c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C18.1 14 18.1 14 18 14ZM18 17.6c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C18.1 17.6 18.1 17.6 18 17.6ZM18 19.4c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C18.1 19.4 18.1 19.4 18 19.4ZM11.4 20.6c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C11.5 20.6 11.5 20.6 11.4 20.6ZM36.6 18.2c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C36.7 18.2 36.7 18.2 36.6 18.2ZM11.4 18.8c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C11.5 18.8 11.5 18.8 11.4 18.8ZM11.4 22.4c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C11.5 22.4 11.5 22.4 11.4 22.4ZM11.4 24.2c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C11.5 24.2 11.5 24.2 11.4 24.2ZM16 4.5c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2C16.3 4.4 16.1 4.4 16 4.5ZM20 4.5c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2C20.1 4.6 20 4.6 20 4.5ZM28 4.5c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2C28.3 4.4 28.1 4.4 28 4.5ZM9.4 9.3c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2C9.7 9.2 9.5 9.2 9.4 9.3ZM30 19.4c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C30.1 19.4 30.1 19.4 30 19.4ZM24 27.2c-.1 0-.2 0-.2-.1c-.1-.1-.1-.1-.1-.2c0-.1 0-.2.1-.2c.1-.1.3-.1.4 0c.1.1.1.1.1.2c0 .1 0 .2-.1.2C24.1 27.2 24.1 27.2 24 27.2ZM18 33.3c-.2 0-.3-.1-.3-.3v-2.4c0-.2.1-.3.3-.3s.3.1.3.3v2.4C18.3 33.1 18.2 33.3 18 33.3ZM38.4 18.4c-.6-3.6-1.1-4.6-1.5-4.9v-1.3h.3c.2 0 .3-.1.3-.3c0-.2-.1-.3-.3-.3h-.3v-.7c.7-.1 1.2-.7 1.2-1.5c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0-.8-.7-1.5-1.5-1.5c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c-.8 0-1.5.7-1.5 1.5c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2s0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0 .7.5 1.3 1.2 1.5v.7h-.3c-.2 0-.3.1-.3.3c0 .2.1.3.3.3h.3v1.3c-.2.2-.5.6-.8 1.6c-1.2-1-2.5-1.9-3.9-2.6c-.5-2.7-1-3.5-1.3-3.8v-1.3h.3c.2 0 .3-.1.3-.3s-.1-.3-.3-.3h-.3v-.7c.7-.1 1.2-.7 1.2-1.5c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0-.8-.7-1.5-1.5-1.5c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c-.8 0-1.5.7-1.5 1.5c0 .7.5 1.3 1.2 1.5v.7h-.3c-.2 0-.3.1-.3.3s.1.3.3.3h.3v1.3c-.3.2-.6.8-1.1 2.7c-1.5-.4-3-.6-4.6-.6c-1.6 0-3.2.2-4.7.6c-.4-1.9-.8-2.5-1.1-2.7v-1.3h.3c.2 0 .3-.1.3-.3s-.1-.3-.3-.3h-.3v-.7c.7-.1 1.2-.7 1.2-1.5c0-.8-.7-1.5-1.5-1.5c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c-.8 0-1.5.7-1.5 1.5c0 .7.5 1.3 1.2 1.5v.7h-.3c-.2 0-.3.1-.3.3s.1.3.3.3h.3v1.3c-.3.2-.8 1-1.3 3.8c-1.4.7-2.7 1.6-3.9 2.6c-.3-1.1-.6-1.5-.8-1.6v-1.3h.3c.2 0 .3-.1.3-.3c0-.2-.1-.3-.3-.3h-.3v-.7c.7-.1 1.2-.7 1.2-1.5c0 .1 0 .2.1.2c.1.1.1.1.2.1c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0-.8-.7-1.5-1.5-1.5c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-.1 0-.2-.1-.2c-.1-.1-.3-.1-.4 0c-.1.1-.1.1-.1.2c0 .1 0 .2.1.2c.1.1.1.1.2.1c-.8 0-1.5.7-1.5 1.5c0 .7.5 1.3 1.2 1.5v.7h-.3c-.2 0-.3.1-.3.3c0 .2.1.3.3.3h.3v1.3c-.4.3-.9 1.2-1.5 4.9c-1.8 2.8-2.9 6.1-2.9 9.6c0 9.5 7.8 17.3 17.3 17.3c9.5 0 17.3-7.8 17.3-17.3C41.3 24.5 40.2 21.2 38.4 18.4ZM35.7 9.5c0-.5.4-.9.9-.9s.9.4.9.9s-.4.9-.9.9S35.7 10 35.7 9.5ZM29.1 4.7c0-.5.4-.9.9-.9s.9.4.9.9s-.4.9-.9.9S29.1 5.2 29.1 4.7ZM24 11.3c1.6 0 3.1.2 4.5.6c-.1.6-.3 1.4-.4 2.3c-.5 3.7-.8 8.3-.8 13l-1.2-.2c0-.7-.7-5.7-2.1-5.7c-1.4 0-2.1 5-2.1 5.7l-1.2.2c0-4.7-.3-9.3-.8-13c-.1-.9-.3-1.7-.4-2.3C20.9 11.6 22.4 11.3 24 11.3ZM25.5 27.1c0 .8-.7 1.5-1.5 1.5c-.8 0-1.5-.7-1.5-1.5c0-1.9 1.1-5.1 1.5-5.1C24.4 22 25.5 25.1 25.5 27.1ZM17.1 4.7c0-.5.4-.9.9-.9s.9.4.9.9s-.4.9-.9.9S17.1 5.2 17.1 4.7ZM10.5 9.5c0-.5.4-.9.9-.9s.9.4.9.9s-.4.9-.9.9S10.5 10 10.5 9.5ZM8.7 34.7c-.9-2-1.4-4.3-1.4-6.7c0-3 .8-5.7 2.1-8.1c-.5 3.7-.7 8.1-.7 12.6V34.7ZM13.5 41c-.6-.5-1.2-1.1-1.8-1.7V25.8c0-.2-.1-.3-.3-.3s-.3.1-.3.3v12.9c-.7-.8-1.3-1.7-1.8-2.7v-3.5c0-10.4 1.4-17.8 2.1-18.4c.7.7 2.1 8.1 2.1 18.4V41ZM15.3 42.3c-.4-.3-.8-.5-1.2-.8V32.5c0-4.8-.3-9.6-.8-13.4c-.2-1.4-.4-2.5-.6-3.3c1.1-1 2.3-1.9 3.6-2.6c-.1.3-.1.7-.2 1.1c-.5 3.8-.8 8.5-.8 13.4V42.3ZM18.3 43.8V34.8c0-.2-.1-.3-.3-.3s-.3.1-.3.3v8.8c-.6-.3-1.2-.5-1.8-.9V27.7c0-10.4 1.4-17.8 2.1-18.4c.7.7 2.1 8.1 2.1 18.4c0 .1 0 .2.1.2c.1.1.2.1.2.1l1.5-.3c.1.4.4.8.7 1.1l-.1.6l-2.3.5c-.2 0-.3.2-.2.4c0 .2.2.3.4.2l2-.4l-.4 1.9l-1.7.3c-.1 0-.2.2-.2.3V40.3l-.9 3.8C18.9 44 18.6 43.9 18.3 43.8ZM21.9 32.5l-1.2 5.2v-5L21.9 32.5ZM24 44.8c-.6 0-1.2 0-1.8-.1l.4-1.9c0 0 .3-1.1 1.3-1.1c1 0 1.3 1.1 1.3 1.1l.4 1.9C25.2 44.7 24.6 44.8 24 44.8ZM27.4 44.4c0 0 0 0 0 0c-.3.1-.5.1-.8.1c0 0 0 0 0 0c-.1 0-.1 0-.2 0L25.9 42.6c-.1-.5-.7-1.5-1.9-1.5c-1.2 0-1.8 1-1.9 1.5l-.5 2c-.6-.1-1.2-.2-1.8-.4l3.5-15.2c.1.1.3.1.4.1v10.4c0 .2.1.3.3.3s.3-.1.3-.3V29.1c.1 0 .3-.1.4-.1l3.5 15.2C27.9 44.3 27.6 44.4 27.4 44.4ZM26.1 32.5l1.2.2v5L26.1 32.5ZM32.1 42.7c-.6.3-1.2.6-1.8.9V34.8c0-.2-.1-.3-.3-.3s-.3.1-.3.3v9c-.3.1-.6.2-1 .3l-.8-3.7V32.5c0-.1-.1-.3-.2-.3l-1.7-.3l-.4-1.9l2 .4c0 0 0 0 .1 0c.1 0 .3-.1.3-.2c0-.2-.1-.3-.2-.4l-2.3-.5l-.1-.6c.4-.3.6-.7.8-1.1l1.5.3c.1 0 .2 0 .2-.1c.1-.1.1-.1.1-.2c0-10.3 1.4-17.7 2.1-18.4c.7.7 2.1 8.1 2.1 18.4V42.7ZM33.9 41.5c-.4.3-.8.6-1.2.8V27.7c0-4.8-.3-9.6-.8-13.4c-.1-.4-.1-.8-.2-1.1c1.3.7 2.5 1.6 3.6 2.6c-.2.8-.4 1.9-.6 3.3c-.5 3.8-.8 8.5-.8 13.4V41.5ZM38.7 36c-.5.9-1.1 1.8-1.8 2.7V25.2c0-.2-.1-.3-.3-.3s-.3.1-.3.3v14.2c-.6.6-1.2 1.2-1.8 1.7V32.5c0-10.4 1.4-17.8 2.1-18.4c.7.7 2.1 8.1 2.1 18.4V36ZM38.6 19.9c1.4 2.4 2.1 5.2 2.1 8.2c0 2.4-.5 4.7-1.4 6.7v-2.3C39.3 28 39 23.5 38.6 19.9Z"/>
</svg>

export const allocation = <svg className="MuiSvgIcon-root" viewBox="0 0 24 24">
        <path d="M12.2 6.2zm.846 9.654V17h-1.602v-1.158c-1.026-.216-1.896-.876-1.962-2.04h1.176c.06.63.492 1.122 1.59 1.122c1.176 0 1.44-.588 1.44-.954c0-.498-.264-.966-1.602-1.284c-1.488-.36-2.508-.972-2.338-2.299c0-1.032.834-1.704 1.866-1.926V7.4h1.602v1.17c1.116.27 1.674 1.116 1.71 2.034H13.58c-.03-.666-.384-1.122-1.332-1.122c-.9 0-1.44.408-1.44.984c0 .504.39.834 1.602 1.146s2.508.834 2.508 2.346c-.006 1.098-.828 1.698-1.872 1.896z"/>
        <path d="M17 3l2 1l-2 2l1 1L20 5L21 7V3h-4zM3 7l1-2l2 2l1-1L5 4L7 3H3v4zm2 13l1-1l1-1l-1-1L4 19L3 17v4h4zm15-1l-2-2l-1 1l2 2L17 21h4v-4z"/>
</svg>

export const calendar = <svg className="MuiSvgIcon-root" viewBox="0 0 24 24">
        <path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"/>
</svg>

export const chart = <svg className="MuiSvgIcon-root" viewBox="0 0 24 24">
        <path d="M11 2v20c-5.07-.5-9-4.79-9-10s3.93-9.5 9-10zm2.03 0v8.99H22c-.47-4.74-4.24-8.52-8.97-8.99zm0 11.01V22c4.74-.47 8.5-4.25 8.97-8.99h-8.97z"/>
</svg>

export function Pound(){

        return(
            <svg viewBox="-456 -5 510 300"><path fill="currentColor" d="M 30.8 35.2 h -4.5495 c -0.6627 0 -1.2 0.5373 -1.2 1.2 v 5.0848 H 12.8 V 28.8 h 8.4 c 0.6627 0 1.2 -0.5373 1.2 -1.2 v -4 c 0 -0.6627 -0.5373 -1.2 -1.2 -1.2 h -8.4 v -6.3556 c 0 -3.2266 2.4562 -5.7086 6.1792 -5.7086 c 2.3658 0 4.5878 1.1505 5.7652 1.8849 c 0.5151 0.3213 1.1888 0.2051 1.5688 -0.2685 l 2.8493 -3.5513 c 0.4233 -0.5276 0.3279 -1.3005 -0.2119 -1.7081 C 27.3124 5.456 23.6576 3.2 18.7931 3.2 C 10.6026 3.2 4.8 8.4742 4.8 15.7961 V 22.4 H 2 c -0.6627 0 -1.2 0.5373 -1.2 1.2 v 4 c 0 0.6627 0.5373 1.2 1.2 1.2 h 2.8 v 12.8 H 1.2 c -0.6627 0 -1.2 0.5373 -1.2 1.2 v 4 c 0 0.6627 0.5373 1.2 1.2 1.2 h 29.6 c 0.6627 0 1.2 -0.5373 1.2 -1.2 V 36.4 c 0 -0.6627 -0.5373 -1.2 -1.2 -1.2 z" ></path></svg>
        )
    }
export function Chufo(){
    
        return(
            <svg style={{width:'150px', top:'50%'}} viewBox="-112 -0.5 127 15"><path fill="currentColor" d="M5 2C3 2 1 3 1 6C1 9 3 10 5 10M5 9c-1 0-3 0-3-3C2 3 4 3 5 3m1-1H7L7 5 9 5 9 2 10 2 10 10 9 10 9 6l-2 0L7 10 6 10M11 2 11 10 12 10 12 6 14 6 14 5 12 5 12 3 15 3 15 2" ></path></svg>
        )
    }

export function HelpIcon(){
return(
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="-4 -4 26 30" aria-hidden="true"><path d="M 9.394 0 C 5.6824 0 3.2784 1.4716 1.391 4.0962 c -0.3424 0.4761 -0.2368 1.1289 0.2408 1.4793 l 2.0059 1.4719 c 0.4823 0.3539 1.1686 0.2712 1.5463 -0.1867 c 1.1648 -1.4121 2.0288 -2.2252 3.8482 -2.2252 c 1.4305 0 3.1999 0.891 3.1999 2.2334 c 0 1.0148 -0.8657 1.536 -2.2782 2.3024 c -1.6472 0.8937 -3.8269 2.0059 -3.8269 4.7882 V 14.4 c 0 0.5965 0.4996 1.08 1.116 1.08 h 3.3699 c 0.6164 0 1.116 -0.4835 1.116 -1.08 v -0.2598 c 0 -1.9287 5.825 -2.009 5.825 -7.2282 C 17.5539 2.9815 13.3409 0 9.394 0 z M 8.928 16.8057 c -1.7761 0 -3.2211 1.3984 -3.2211 3.1172 c 0 1.7188 1.445 3.1171 3.2211 3.1171 s 3.2211 -1.3984 3.2211 -3.1172 s -1.445 -3.1171 -3.2211 -3.1171 z"></path></svg>
)
} 

export function MatchIcon(name:string){    
        let filtered = IconList.filter((element:any) => element.name === name); 
        
        
    
    
        return filtered.length > 0 ? filtered[0].comp : infinite;
    
       }

export function IconUser(props:any, White?: boolean){
        let theme = store.getState().Theme;
        return <SpecialProps><HudIcon className={props} Theme={theme} White={White} ><img height="25" alt="User" src={White ? ImageIconWhitePerson: ImageIconUser} /></HudIcon></SpecialProps>

}
export function IconQuestion(props:any, White?: boolean){
        let theme = store.getState().Theme;
        return <SpecialProps><HudIcon className={props} Theme={theme} White={White} ><img height="25" alt="Question" src={White ? ImageIconWhiteQuestion : ImageIconQuestion} /></HudIcon></SpecialProps>

}
export function IconGear(props:any, White?: boolean){
        if(props === 'SideBarMenu'){
                return <img height="25" alt="Gear" src={ImageIconGear} />
        }
        let theme = store.getState().Theme;
        return <SpecialProps><HudIcon className={props} Theme={theme} White={White} ><img height="25" alt="Gear" src={White ? ImageIconWhiteGear : ImageIconGear} /></HudIcon></SpecialProps>

}
export function IconVoice(props:any, White?: boolean){
        let theme = store.getState().Theme;
        return <SpecialProps><HudIcon className={props} Theme={theme} White={White} ><img height="25" alt="Gear" src={White ? ImageIconWhiteVolume : ImageIconVoice} /></HudIcon></SpecialProps>

}
export function IconHome(props:any){
        
        return <img height="25" alt="Home" src={ImageIconHome} />

}

export function IconPouch(props:any){
        
        return <img width="25" alt="Home" src={ImageIconPouch} />

}

export function IconCoin(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconCoin} />

}

export function IconCalendar(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconCalendar} />

}

export function IconCustom(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconCustom} />

}
export function IconHandGlobal(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconHandGlobal} />

}
export function IconPeople(props:any){
        
        return <img width="25" alt="Coin" src={ImageIconPeople} />

}

export function IconCharging(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconCharging} />

}
export function IconBussines(props:any){
        
        return <img width="25" alt="Coin" src={ImageIconBussines} />

}
export function IconLister(props:any){
        
        return <img width="25" alt="Coin" src={ImageIconList} />

}
export function IconProduct(props:any){
        
        return <img height="25" alt="Coin" src={ImageIconProduct} />

}
export function IconFolder(props:any){return <img width="25" alt="Folder" src={ImageIconFolder} />}
export function IconPplGear(props:any){return <img height="25" alt="People Gear" src={ImageIconPplGear} />}
export function IconCostCenter(props:any){return <img width="25" alt="Cost Center" src={ImageIconCostCenter} />}
export function IconBug(props:any){return <img width="25" alt="Coin" src={ImageIconCostCenter} />}
export function IconPlane(props:any){return <img width="25" alt="Plane" src={ImageIconPlane} />}
export function IconStar(props:any){return <img width="25" alt="Star" src={ImageIconStar} />}
export function IconBell(props:any){return <img height="38" width="25" alt="Bell" src={ImageIconBell} />}
export function IconTool(props:any){return <img width="25" alt="Tool" src={ImageIconTool} />}
export function IconBook(props:any){return <img height="38" alt="Book" src={ImageIconBook} />}
export function IconLight(props:any){return <img height="38" alt="Light" src={ImageIconLight} />}
export function IconLock(props:any){return <img height="38" alt="Lock" src={ImageIconLock} />}
export function IconGlobe(props:any){return <img width="25" alt="Globe" src={ImageIconGlobe} />}
export function IconLoop(props:any){return <img height="38" alt="Loop" src={ImageIconLoop} />}
export function IconArrow_right_up(props:any){return <img height="38" alt="Right Up" src={ImageIconArrow_right_up} />}
export function IconArrow_down(props:any){return <img height="38" alt="Down" src={ImageIconArrow_down} />}
export function IconArrow_wide(props:any){return <img height="38" alt="Wide" src={ImageIconArrow_wide} />}
export function IconArrowMin(props:any){return <img height="38" alt="Min" src={ImageIconArrowMin} />}
export function IconArrowSplit(props:any){return <img height="38" alt="Split" src={ImageIconArrowSplit} />}
export function IconInfo(props:any){return <img height="38" alt="Info" src={ImageIconInfo} />}
export function IconBank(props:any){return <img height="38" alt="Bank" src={ImageIconBank} />}
export function IconClipboard(props:any){return <img height="38" alt="Clipboard" src={ImageIconClipboard} />}
export function IconAlert(props:any){return <img height="38" alt="Alert" src={ImageIconAlert} />}
export function IconForm(props:any){return <img height="38" alt="Form" src={ImageIconForm} />}
export function IconBurger(props:any){return <img height="38" alt="Burger" src={ImageIconBurger} />}
export function IconWhiteBurger(props:any){return <img height="38" alt="Burger" src={ImageIconWhiteBurger} />}

export function IconTrash(props:any){return <img height="16" width={16} alt="Burger" src={ImageIconTrash} />}
export function IconEdit(props:any){return <img height="16" width={16} alt="Burger" src={ImageIconEdit} />}


export function IconPlus(props:any){return <img height="38" alt="Burger" src={ImageIconPlus} />}

const SpecialProps = styled.span<any>({
        '.LogMenu': {
                marginRight: '10px'
        },
        '.SideBarMenu': {
               
        }
})
const HudIcon = styled.span<any>({
        
        display: 'flex',
        justifyContent:'center',
        alignItems: 'center',
        width: '40px',
        height: '40px',
        borderRadius: '5px'
        
        }, props =>({
               border: props.White ? '1px solid white' :  '1px solid '+  props.Theme.Corporate.darkBlue,
}))       




export const IconList = [
    {name: 'Bug', comp: IconAlert('SideBarMenu')},
    {name: 'Infinite', comp:IconForm('SideBarMenu') },
    {name: 'Dash', comp: IconClipboard('SideBarMenu')},    
    {name: 'Public', comp: IconBank('SideBarMenu')},
    {name: 'Wrench', comp: IconTool('SideBarMenu')},
    {name: 'Bussines', comp: IconPouch('SideBarMenu')},
    {name: 'Star', comp: IconStar('SideBarMenu')},
    {name: 'Lock', comp: IconLock('SideBarMenu')},
    {name: 'Global', comp: IconGlobe('SideBarMenu')},
    {name: 'Plane', comp: IconPlane('SideBarMenu')},
    {name: 'Bell', comp: IconBell('SideBarMenu')},
    {name: 'Light', comp: IconLight('SideBarMenu')},
    {name: 'TrendUp', comp: IconArrow_right_up('SideBarMenu')},
    {name: 'TrendDown', comp: IconArrow_down('SideBarMenu')},    
    {name: 'Arrows', comp: IconArrow_wide('SideBarMenu')},
    {name: 'Merge', comp: IconArrowMin('SideBarMenu')},
    {name: 'Split', comp: IconArrowSplit('SideBarMenu')},
    {name: 'Loop', comp: IconLoop('SideBarMenu')},
    {name: 'Info', comp: IconInfo('SideBarMenu')},
    {name: 'Book', comp: IconBook('SideBarMenu')}
]


