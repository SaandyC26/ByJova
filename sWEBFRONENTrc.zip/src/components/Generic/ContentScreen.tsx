import React from 'react';
import styled from "@emotion/styled"; 


// this component styles the main screen workarea
export default function ContentScreen(props:any){    
    return(                          
        <Contenedor id="ContentScreen">  
            {props.children}
        </Contenedor>         
    )
}

const Contenedor = styled.div({    
    padding: '10px',
    position: 'relative',   
    height: '100%',
    width: '100%',
    backgroundColor: 'white',   
    'a': {textDecoration: 'none'}    
});
