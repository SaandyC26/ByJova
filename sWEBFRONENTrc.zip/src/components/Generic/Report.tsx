import React  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import TooltipedItem from './TooltipedItem';
import {Megaphone} from './Icons'
import {Link } from 'react-router-dom';
import {IconVoice} from '../Generic/Icons'
interface Themeprops {
    Theme: any
}


export default function Report(props:any){

    const Theme = useSelector( (state: any) => state.Theme); 
    
    const HelpContext = {Link: '../../../ticket-manager', Title: 'Ticket Manager'}
    


    return (
        <Content Theme={Theme} id="Report">
             <Contenedor>
                <TooltipedItem Trigger={IconVoice('LogMenu', true)} Interactive={false} Title="Ticket Manager" Position="bottom">
                    <Icon Theme={Theme} Id="Header Button Ticket Manager" className="Back">
                        <Link to={HelpContext.Link} >
                            {IconVoice('LogMenu', true)}
                        </Link>
                    </Icon>
                </TooltipedItem> 
            </Contenedor> 
        </Content>
    )
}



const Content = styled.div<Themeprops>({
    '.logToolTip + div > div' :{       
        
        fontFamily: '"Frutiger 45 Light"'
    },
    '.logToolTip + div .MuiTooltip-arrow':{
        left: '10px',
        
        transform: ' scale(1.5) translateY(-1px)'
    }

},props=>({    
    '.logToolTip + div > div' :{
        backgroundColor: props.Theme.Corporate.blue,
        
    }
}))

const Contenedor = styled.div({
    
    '.logToolTip + div > div' :{   
      
      fontFamily: '"Frutiger 45 Light"'
  },
  '.logToolTip + div .MuiTooltip-arrow':{
      left: '10px',
      
      transform: 'translateX(0)  scale(1.5) translateY(-1px)'
  },
     '.MuiTooltip-tooltip':{
         maxWidth: 'initial'
     }
  })
  const Icon = styled.div<any>({
  padding: '0px',
  height: '7vh',
  display: 'flex',
  justifyContent: 'space-around',
  alignItems: 'center',
  cursor: 'pointer',
  'svg':{
      fontSize: '40px',
      cursor: 'pointer',
      color: 'white',    
      borderRadius: '5px',
      strokeWidth: '0.6px',
      transition: 'all 100ms',
      marginTop:'0px'
  },
  '> div':{
  
  height: '40px',
  width: '40px',
  backgroundPosition: 'center',
  backgroundColor: '#e7eceb',
  backgroundSize: '35px',
  borderRadius: '50%',    
  },
  'p':{
      margin: '0px',
      color: 'grey'
  },
  'i':{
  backgroundImage: 'URL("../../../images/icons/profilearrow.png")',
  height: '10px',
  width: '10px',
  backgroundPosition: 'center',
  backgroundSize: 'cover',
  }
  }, props =>({
      'svg':{
          stroke: props.Theme.Corporate.darkBlue,
          border: '1px solid '+props.Theme.Corporate.darkBlue,
          
      }
  }))