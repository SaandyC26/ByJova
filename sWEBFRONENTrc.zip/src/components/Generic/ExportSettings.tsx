import React, {useState}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import { withStyles, Theme } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import ExportExcel from "../DemandTable/Views/ExportExcel";
import Popup from "../Generic/Popup";
import ExcelService from '../../services/ExcelService'
import {ToolbarButton} from './Styles'
interface Themeprops {
    Theme: any
}

interface Expected {
    Dataset: any;
}

// this component handles login/out operations
export default function ExportSettings(props:Expected){
   const TokenData = useSelector((state: any) => state.tokenData);
   const MainTheme = useSelector( (state: any) => state.Theme); 
   const [Status, SetStatus] = useState(false);  
   

   function SwitchStatus(){
    SetStatus(!Status);
}
   const handleTooltipClose = () => {
    SetStatus(false);
  };

  function Exporting(){
   
    SwitchStatus();
   
        ExcelService.getBlankDemandExcel().then((result:any) => {
            console.log(result)
            if(typeof result !== 'undefined'){
                const url = window.URL.createObjectURL(new Blob([result[0]]));
                const a = document.createElement('a');
                a.href = url;
                a.download = result[1] as string;
                a.click();
            }  
        })
  }

 
    
    
    const HtmlTooltip = withStyles((theme: Theme) => ({
        arrow: {
            color: MainTheme.Corporate.blue,
          },
          tooltip: {
              backgroundColor: MainTheme.Corporate.blue,
              color: 'white',  
              textShadow: '0px 0px 0px '+MainTheme.Corporate.darkBlue,   
              fontSize: '90%' ,
              minWidth: 220
          },
        
      }))(Tooltip);
   
   
   return(
        
           
    <Content Theme={MainTheme} id="Settings">    
    <ClickAwayListener onClickAway={handleTooltipClose}>
        <Contenedor>             
        
            <HtmlTooltip
            arrow
            PopperProps={{
                disablePortal: true,
            }}
            className='settingsToolTip'
            interactive
            open={Status}
            onClose={handleTooltipClose}
            disableFocusListener
            disableHoverListener
            disableTouchListener
            title={
                <Popup>
                    <ol>
                        <li id="Reset_column_all"><ExportExcel
                                token={TokenData.tokenId}
                                dataState={props.Dataset}
                                buttonText="Export with data"
                            /></li>
                        <li onClick={(e:any) => Exporting()} id="Reset_column_order">Export blank</li>                        
                    </ol>
                </Popup>
            }
        >
                
                <ToolbarButton style={{marginLeft:'15px'}} id="Export_settings" onClick={SwitchStatus} className="k-button k-primary rounded">Export</ToolbarButton>
            </HtmlTooltip>  
        </Contenedor>    
        </ClickAwayListener>
    </Content> 
             
        
        
    )
}


const Contenedor = styled.div({
   
    
   
    zIndex: 500
    
    })
    const Content = styled.div<Themeprops>({
        '.logToolTip + div > div' :{       
           
            fontFamily: '"Frutiger 45 Light"'
        },
        '.logToolTip + div .MuiTooltip-arrow':{
            left: '10px',
           
            transform: ' scale(1.5) translateY(-1px)'
        }
    
    },props=>({    
        '.logToolTip + div > div' :{
            backgroundColor: props.Theme.Corporate.blue,
            
        }
    }))


