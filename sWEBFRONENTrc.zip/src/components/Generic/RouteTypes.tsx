import React  from 'react';
import Demand from '../Navigation/Context/Demand';
import Finance from '../Navigation/Context/Financial';
import DataTables from '../Navigation/Context/DataTables';
import {Route, Navigate} from "react-router";
import PageCharts from '../Pages/Charts'
import PageProfile from '../Pages/Profile'
import PageDemand from '../Pages/DemandTable'
import PageFinancial from '../Pages/Financial'
import PageMasterDataTables from '../Pages/EditDataTables'
import PageCurrency from '../Pages/Currency'
import PageRoleAdmin from '../Pages/RoleAdmin'
import PageUserAdmin from '../Pages/UserAdmin'
import PageMonthBlocker from '../Pages/MonthBlocker'
import VisibleColumns from '../Generic/VisibleColumns'
import {getCookie} from '../Functions/Utils'
import PageTickets from '../Pages/TicketManager'
import SettingsIcon from '@material-ui/icons/Settings';
import UserGroupAdmin from '../Pages/GroupAdmin'
import {IconHome, IconCoin, IconPouch, IconGear} from '../Generic/Icons'

function IconiGear(){
    return IconGear('SideBarMenu')
}

function House(){
    return IconHome('SideBarMenu')
    return(
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M 19 9.3 V 4 h -3 v 2.6 L 12 3 L 2 12 h 3 v 8 h 5 v -6 h 4 v 6 h 5 v -8 h 3 l -3 -2.7 z z"></path></svg>
    )
} 
function Coins(){
    return IconPouch('SideBarMenu')
    return(
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 -3 20 25" aria-hidden="true"><path d="M 0 15.6041 V 17.248 c 0 1.359 3.311 2.464 7.392 2.464 s 7.392 -1.105 7.392 -2.464 v -1.644 C 13.194 16.7244 10.2872 17.248 7.392 17.248 S 1.59 16.7244 0 15.6041 z M 12.32 4.928 c 4.081 0 7.392 -1.105 7.392 -2.464 S 16.401 0 12.32 0 S 4.928 1.105 4.928 2.464 s 3.311 2.464 7.392 2.464 z M 0 11.5654 V 13.552 c 0 1.359 3.311 2.464 7.392 2.464 s 7.392 -1.105 7.392 -2.464 v -1.9866 c -1.59 1.309 -4.5007 1.9866 -7.392 1.9866 S 1.59 12.8744 0 11.5654 z m 16.016 0.4235 c 2.2061 -0.4274 3.696 -1.2205 3.696 -2.1329 v -1.644 c -0.8932 0.6314 -2.2061 1.0626 -3.696 1.3283 v 2.4486 z M 7.392 6.16 C 3.311 6.16 0 7.5383 0 9.24 s 3.311 3.08 7.392 3.08 s 7.392 -1.3783 7.392 -3.08 s -3.311 -3.08 -7.392 -3.08 z m 8.4431 2.1675 c 2.31 -0.4158 3.8769 -1.232 3.8769 -2.1675 v -1.644 c -1.3668 0.9664 -3.7153 1.4861 -6.1869 1.6093 c 1.1358 0.5506 1.9712 1.2897 2.31 2.2022 z"></path></svg>
    )
} 
function Bug(){
    return(
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true"><path d="M 20 8 h -2.81 c -0.45 -0.78 -1.07 -1.45 -1.82 -1.96 L 17 4.41 L 15.59 3 l -2.17 2.17 C 12.96 5.06 12.49 5 12 5 c -0.49 0 -0.96 0.06 -1.41 0.17 L 8.41 3 L 7 4.41 l 1.62 1.63 C 7.88 6.55 7.26 7.22 6.81 8 H 4 v 2 h 2.09 c -0.05 0.33 -0.09 0.66 -0.09 1 v 1 H 4 v 2 h 2 v 1 c 0 0.34 0.04 0.67 0.09 1 H 4 v 2 h 2.81 c 1.04 1.79 2.97 3 5.19 3 s 4.15 -1.21 5.19 -3 H 20 v -2 h -2.09 c 0.05 -0.33 0.09 -0.66 0.09 -1 v -1 h 2 v -2 h -2 v -1 c 0 -0.34 -0.04 -0.67 -0.09 -1 H 20 V 8 z v 2 z z"></path></svg>
    )
} 

function Financial(){
    return IconCoin('SideBarMenu')
    return(
        <svg className="MuiSvgIcon-root" focusable="false" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
           
        </svg>
    )
} 
function DemandWithOptions(){
    return (<PageDemand><VisibleColumns/></PageDemand>)
    
} 




// Array of aviable urls and their props
export const Navigation = [
    {Name: 'Home', IsContext : false, Dynamic: false, Path:'/home/' ,Icon: House, ToLoad : PageCharts, ContextBar: null, DisplayId: "Header_Button_Menu_Home", Permissions: ['All']},
    {Name: 'Demand', IsContext : false, Dynamic: true, Path:'/demand/:slug' ,Icon: House, ToLoad : DemandWithOptions, ContextBar: Demand , Permissions:['All']} ,
    {Name: 'Demand', IsContext : false, Dynamic: false, Path:'/demand/' ,Icon: Coins, ToLoad : DemandWithOptions, ContextBar: Demand , DisplayId: "Header_Button_Menu_Demand" , Permissions:['All']},
    {Name: 'Financial Management', IsContext : false, Dynamic: true, Path:'/financial/:slug' ,Icon: Financial, ToLoad : PageFinancial, ContextBar: null , Permissions:['All']},
    {Name: 'Financial Management', IsContext : false, Dynamic: false, Path:'/financial/' ,Icon: Financial, ToLoad : PageFinancial, ContextBar: Finance , DisplayId: "Header_Button_Menu_Financial", Permissions:['Barcelona Invoices','Rebookings','Customers Allocations', 'Monthly Report', 'Quarter Report']},    
    {Name: 'DataTables', IsContext : true, Dynamic: true, Path:'/administration/datatables/' ,Icon: IconiGear, ToLoad : PageMasterDataTables, ContextBar: DataTables , Permissions:['All']},
    {Name: 'Roles Administration', IsContext : false, Dynamic: true, Path:'/administration/roles/' ,Icon: House, ToLoad : PageRoleAdmin, ContextBar: null , Permissions:['All']},
    {Name: 'Users Administration', IsContext : false, Dynamic: true, Path:'/administration/users/' ,Icon: House, ToLoad : PageUserAdmin, ContextBar: null , Permissions:['All']},
    {Name: 'User Groups Administration', IsContext : false, Dynamic: true, Path:'/administration/user-groups/' ,Icon: House, ToLoad : UserGroupAdmin, ContextBar: null , Permissions:['All']},
    {Name: 'Month Blocker', IsContext : false, Dynamic: true, Path:'/administration/month/' ,Icon: House, ToLoad : PageMonthBlocker, ContextBar: null , Permissions:['All']},
    {Name: 'Currency', IsContext : false, Dynamic: true, Path:'/administration/currency/' ,Icon: House, ToLoad : PageCurrency, ContextBar: null , Permissions:['All']},
    {Name: 'Profile', IsContext : false, Dynamic: true, Path:'/profile/' ,Icon: House, ToLoad : PageProfile, ContextBar: null , Permissions:['All']},
    {Name: 'Ticket Manager', IsContext : false, Dynamic: true, Path:'/ticket-manager/' ,Icon: House, ToLoad : PageTickets, ContextBar: null , Permissions:['Read Ticket','Write Ticket','Delete Ticket','Other Manage Ticket']},
    
   

]



