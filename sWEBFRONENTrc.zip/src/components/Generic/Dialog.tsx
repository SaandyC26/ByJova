import React from 'react';
import styled from "@emotion/styled";
import HighlightOffIcon from '@material-ui/icons/HighlightOff';

export default function Dialog(props:any) {
   let message = props.Body.replaceAll('Line','@Line') 
   console.log(message)
   message = message.split('@')
    return(
        <Content id="Dialog">
            <div>
                <span onClick={()=>{props.CloseCallback()}}><HighlightOffIcon/></span>
                <h1>{props.Title}</h1>
                <p>{props.Subtitle}</p>
                {message.map((element:any)=>{
                    return(
                        <p>{element}</p>
                    )
                })}
               
            </div>
        </Content>
    )
}


const Content = styled.div({
    position: 'fixed',
    width: '100%',
    height: '100%',
    zIndex: 9000,
    top: '0px',
    left: '0px',
    'h1':{
        fontSize: '170%',
        fontWeight: 'bold'
    },
    'h1 + p':{
        borderBottom: '2px solid blue',
        paddingBottom: '5px',
    },
    'div' : {
        boxShadow: '0px 0px 0px 5000px rgb(0 0 0 / 0.3)',
        wordBreak: 'break-word',
        zIndex: 9000,
        padding: '20px',
        overflowY: 'scroll',
        backgroundColor: 'white',
        width: '70%',
        height: '50%',
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%,-50%)',
    },    
    'span':{
        position: 'absolute',
        top: '10px',
        right: '10px',
        cursor: 'pointer'

    },    
        })