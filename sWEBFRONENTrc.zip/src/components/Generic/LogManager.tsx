import React, {useState,useEffect}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import {parseJwt,getCookie, removeCookie, HasPermisionAny} from '../Functions/Utils'
import {Link } from 'react-router-dom';
import Settings from './Settings';
import {IconUser} from '../Generic/Icons'
import PersonIcon from '@material-ui/icons/Person';
import Help from "../Generic/Help";
import TooltipedItem from './TooltipedItem'
import {MenuList} from './Styles' 
import Report from './Report'
interface Themeprops {
    Theme: any
}

// this component handles login/out operations
export default function LogManager(props:any){
   const Theme = useSelector( (state: any) => state.Theme);   
   const PermissionCheck = useSelector((state: any) => state.userData.permissions)
   const [Granted, setGranted] = useState<any>({'Report': false});
   
   

   useEffect(() => { 
       
    let Permissions = {
        'Report': HasPermisionAny(['Read Ticket','Write Ticket','Delete Ticket','Other Manage Ticket']),
                  
    }      
  
    setGranted(Permissions) ;
},[PermissionCheck])

    function Logout(){   
        // delete mandatory cookies so the user is no longer logedin          
        removeCookie('ZurichCustomerPortal');
        removeCookie('ZurichCustomerPortalRefresh');            
        window.location.href = '../../../login/';
        
    }

    
    

   return(
       <Content Theme={Theme} id="LogManager">                      
            <Contenedor>   
            <FloatIcons>
            {Granted['Report'] ? <Report/> : null }
            <Settings/>
            <Help/>      
            <TooltipedItem Trigger={() => {return IconUser('LogMenu', true)}} Interactive={true} Title="User Options" Position="bottom">
                <MenuList>
                    <ol>
                        <li><Link to='../../profile/' id="Header_Button_Profile"><span><i ></i></span>Profile</Link></li>
                        <li onClick={Logout} id="Header_Button_Logout">Log Out</li>
                    </ol>
                </MenuList>
            </TooltipedItem>        
        </FloatIcons>                  
                <p>{getCookie("ZurichCustomerPortal") !== '' ? parseJwt(getCookie("ZurichCustomerPortal")).nameid : ''}</p>    
            </Contenedor> 
        </Content>
        
    )
}

const FloatIcons = styled.div({
    position: 'absolute',
    top: '0px',
    right: '200px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '100%'
})
const Content = styled.div<Themeprops>({
    
    '.logToolTip + div > div' :{       
       
        fontFamily: '"Frutiger 45 Light"'
    },
    '.logToolTip + div .MuiTooltip-arrow':{
        left: '10px',
       
        transform: ' scale(1.5) translateY(-1px)'
    }

},props=>({    
    '.logToolTip + div > div' :{
        backgroundColor: props.Theme.Corporate.blue,
        
    }
}))

const Contenedor = styled.div({
    'svg': {
        marginRight: '10px'
    },
    '> p':{
        margin: '0px',
        color: 'white'
    },
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    alignItems:'center',    
    height: '100%',
    position: 'absolute',
    top: '0',
    right: '0',
    zIndex: 500
    
    })

