
import styled from "@emotion/styled";
import store from '../../store'

export const AddButton = styled.div({
    cursor: 'pointer',
    height: '25px',
    width: '25px',
    display: 'flex',
    justifyContent:'center',
    alignItems:'center',
    img:{
        width: '100%',
        height: '100%'
    }

})

export const ToolbarButton = styled.button({ 
    marginLeft: '15px',
    fontFamily: '"Frutiger 45 Light", sans-serif !important;',
    textShadow: '0.4px 0.4px 1px white',
    padding: '2px 8px',
    fontSize: '15px',
    color: 'white !important',
    border:'none !important',
    textTransform: 'uppercase'
    
}, () =>({
    ':not(:disabled)' :{backgroundColor: store.getState().Theme.Corporate.darkBlue + '!important'},
    ':not(:disabled):hover':{
        backgroundColor: store.getState().Theme.Corporate.blue + '!important',
    }
}))  

export const FormPrimaryButton = styled.button({ 
   
    fontFamily: '"Frutiger 45 Light", sans-serif !important;',
    textShadow: '0.4px 0.4px 1px white',
    padding: '2px 8px',
    fontSize: '15px',
    color: 'white',
    border:'none !important',
    borderRadius: '3px',
    ':disabled':{
        backgroundColor: 'transparent !important',
        color: 'grey !important'

    }
}, () =>({
    backgroundColor: store.getState().Theme.Corporate.darkBlue,
})) 

export const FormSecondaryButton = styled.button({ 
    marginLeft: '15px',
    fontFamily: '"Frutiger 45 Light", sans-serif !important;',
    textShadow: '0.4px 0.4px 1px white',
    padding: '2px 8px',
    fontSize: '15px',
    color: 'white',
    backgroundColor: 'grey',
    borderRadius: '3px',
    border: 'none'
})  

export const ActionButton = styled.div({
    cursor: 'pointer',
    height: '16px',
    width: '16px',
    display: 'flex',
    justifyContent:'center',
    alignItems:'center',
    img:{
        width: '100%',
        height: '100%'
    }

})

export const DinamicInfo = styled.div({
    '.MuiAccordionDetails-root':{
        padding: '0px 0px 16px',
        marginBottom: '0px'
    },
    padding: '0px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    },    
    '.k-grid-content':{
        overflow: 'visible'
    }
}, () =>({
    'col.k-sorted, th.k-sorted':{
        backgroundColor: store.getState().Theme.Corporate.paleBlue,
    },
    '.k-pager-numbers .k-link.k-state-selected':{
        color: store.getState().Theme.Corporate.blue,
        backgroundColor: store.getState().Theme.Corporate.lightBlue,
    },
    '.k-pager-numbers .k-link':{
        color: store.getState().Theme.Corporate.blue,
    },
    '.k-grid th':{
        backgroundColor: store.getState().Theme.Corporate.lightBlue,
       
    },
    'th.k-header.active > div > div':{
        backgroundColor: store.getState().Theme.Corporate.darkBlue,
    },
    '.k-checkbox:checked':{
        borderColor: store.getState().Theme.Corporate.darkBlue,
        backgroundColor: store.getState().Theme.Corporate.darkBlue,
    }
    
 }))

 export const DataTableInfo = styled.div({
    '.MuiAccordionDetails-root':{
        padding: '0px 0px 16px',
        marginBottom: '0px'
    },
    '.MuiAccordionSummary-root.Mui-expanded':{
        minHeight: 'inherit',
        margin: '0px'
    },
    '.MuiAccordionSummary-content.Mui-expanded':{
        margin: '0px',
        marginTop: '10px',
        fontSize: '130%'
    },
    '.MuiIconButton-root':{
        display: 'none'
    },
    padding: '0px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    },    
    '.k-grid-content':{
        overflow: 'visible'
    }
}, () =>({
    'col.k-sorted, th.k-sorted':{
        backgroundColor: store.getState().Theme.Corporate.paleBlue,
    },
    '.k-pager-numbers .k-link.k-state-selected':{
        color: store.getState().Theme.Corporate.blue,
        backgroundColor: store.getState().Theme.Corporate.lightBlue,
    },
    '.k-pager-numbers .k-link':{
        color: store.getState().Theme.Corporate.blue,
    },
    '.k-grid th':{
        backgroundColor: store.getState().Theme.Corporate.lightBlue,
       
    },
    'th.k-header.active > div > div':{
        backgroundColor: store.getState().Theme.Corporate.darkBlue,
    },
    '.k-checkbox:checked':{
        borderColor: store.getState().Theme.Corporate.darkBlue,
        backgroundColor: store.getState().Theme.Corporate.darkBlue,
    }
    
 }))

export const DefineSection = styled.div({
    fontSize: '90%',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    textAlign: 'left',    
    fontWeight: 'bold'
}, () =>({
    color: store.getState().Theme.Corporate.darkBlue,
}))

export const FixedInfo = styled.div({
    marginTop: '5px',    
    paddingBottom: '20px',
    paddingTop: '20px',
    width: '100%',    
    display: 'flex',
    justifyContent: 'space-between',
     minHeight: '100px',   
    listStyle: 'none',
    textAlign: 'left',
    '*': {color: 'black'},
    'p':{
        color: '#605c58 !important',
        margin: '10px 0px',
        'b':{
            color: 'inherit',
            marginRight: '5px',
        }
    },      
    '> div' :{
        padding: '0px',
    },     
    'textarea':{
        width: '100%',
        minHeight: '150px',
        resize: 'none',
        fontSize: '80%',
        padding: '15px',
    },
   
    'ul':{
        margin: '0px',
        padding: '0px'
    }  ,
    'tr':{position:'relative'}      
}, () =>({
    backgroundColor: store.getState().Theme.Corporate.paleBlue,
}))  

export const Contenedor = styled.ul({
    paddingTop: '10px',
    width: '100%',            
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    left: '0',    
    padding: '5px 0px 5px 0px',
    color: 'white',
    listStyle: 'none',
    'span' : {
        display: 'flex' ,
        padding: '0px',
        margin: '0px',
        justifyContent: 'space-between',
        alignItems: 'center' ,
        marginLeft: '0px'     ,
        marginRight: '10px' ,
        width: '35px' ,
        maxWidth: '35px',

    },        
})

export const LinkItem = styled.li<any>({
    marginBottom: '0px',
     
    width: '100%',
    '>div':{
        display: 'flex',
        height: '100%',
        alignItems: 'center',
        width: '100%',
        color: '#003399',
        cursor: 'pointer'
    },
    'a':{
        display: 'flex',
        height: '100%',
        alignItems: 'center',
        width: '100%'
    },
    'i':{
         width: '5vw',
         height: '5vw',
         display: 'flex',
         justifyContent: 'center',
         alignItems: 'center',
         backgroundSize: 'cover',
         maxWidth: '40px',
         maxHeight: '40px',
         minWidth: '35px',
         minHeight: '35px',
         borderRadius: '5px',
         'svg':{
            fontSize: '30px',
            cursor: 'pointer',
            color: 'transparent',
           
           
            strokeWidth: '0.6px'
         },
     },
     'p':{
        margin: '0px',
        padding: '0px',
        fontSize: '90%',
        lineHeight: '1',
        opacity: '1'
     }
 }, (props:any) =>({
    'i':{
       
           border: '1px solid '+ store.getState().Theme.Corporate.darkBlue,
           stroke: store.getState().Theme.Corporate.darkBlue,   
       
    },
    'p': {
       color: store.getState().Theme.Corporate.blue
    },
    backgroundColor: typeof props.Selected !== 'undefined' && props.Selected ? store.getState().Theme.Corporate.lightBlue : 'inherit',
    ':hover':{
        i:{
            borderWidth: typeof props.Selected !== 'undefined' &&  props.Selected ? '1px' : '2px'
        },
        p:{
            fontWeight: typeof props.Selected !== 'undefined' &&  props.Selected ? 'inherit' : 'bold',
            color: typeof props.Selected !== 'undefined' && props.Selected ? 'inherit' : store.getState().Theme.Corporate.darkBlue,
            textShadow: typeof props.Selected !== 'undefined' &&  props.Selected ? 'inherit' : '0px 0px 0px rgb(0 0 0 / 36%)'
        }
    },
}))

export const Icon = styled.a({
    padding: '0px',
    
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'center',
    cursor: 'pointer',
    'svg':{
        fontSize: '40px',
        cursor: 'pointer',
        color: 'white',    
        borderRadius: '5px',
        strokeWidth: '0.6px',
        transition: 'all 100ms',
        marginTop:'0px'
    },
    '> div':{
    
    height: '40px',
    width: '40px',
    backgroundPosition: 'center',
    backgroundColor: 'transparent',
    backgroundSize: '35px',
    borderRadius: '50%',    
    },
    'p':{
        margin: '0px',
        color: 'grey'
    },
    'i':{
    backgroundImage: 'URL("../../../images/icons/profilearrow.png")',
    height: '10px',
    width: '10px',
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    }
    },()=>({       
        'svg':{        
            stroke: store.getState().Theme.Corporate.darkBlue,
            border: '1px solid ' + store.getState().Theme.Corporate.darkBlue
        }       
        
    })) 

export const MenuList = styled.div({
    padding: '5px',
    display: 'flex',
    color: 'white',    
    alignItems: 'center',
    
    width: '100%',
    '.logToolTip + div > div' :{   
    
        fontFamily: '"Frutiger 45 Light"'
    },
    '.logToolTip + div .MuiTooltip-arrow':{
        left: '10px',
        
        transform: 'translateX(0)  scale(1.5) translateY(-1px)'
    },
       '.MuiTooltip-tooltip':{
           maxWidth: 'initial'
       },
    ol : {
        
        listStyle: 'none',
        padding: '0px',
        margin: '0px',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-evenly',
        fontSize: '16px',
    },
    li : {
        padding: '5px 0px',
        cursor: 'pointer',
        color: 'white',
        
        'a, a:active':{
            textDecoration: 'none',
            color: 'inherit'
        }
    }},()=>({    
        
        'li:hover':{
            textShadow:'0px 0px 0px '+store.getState().Theme.Corporate.veryDarkBlue,
            color: store.getState().Theme.Corporate.veryDarkBlue,
        },
        backgroundColor: store.getState().Theme.Corporate.blue  
        
    }))
    