import React, {useState}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import {  withStyles,Theme, makeStyles } from '@material-ui/core/styles';
import {Icon} from "../Generic/Styles"


interface Themeprops {
    Theme: any
}



// this component handles Searcher
export default function TooltipedItem(props:any){
   
   
   const MainTheme = useSelector( (state: any) => state.Theme);   
   const [Status, SetStatus] = useState(false);    
   
   
   
   function SwitchStatus(){
       SetStatus(!Status);   
         
   }  

   const handleTooltipClose = () => {
      
    SetStatus(false);
    
  };


  const HtmlTooltip = withStyles((theme: Theme) => ({
    tooltip: {
      backgroundColor: 'white',
      color: 'white',    
      padding: '0px',  
      minWidth : props.Width ? props.Width : 220,
      border: '1px solid '+MainTheme.Corporate.blue,
      
    },
    arrow: {
        color: MainTheme.Corporate.blue,
      },
    
  }))(Tooltip);


const useStylesBootstrap = makeStyles((theme: Theme) => ({
    arrow: {
      color: MainTheme.Corporate.blue,
    },
    tooltip: {
        backgroundColor: MainTheme.Corporate.blue,
        color: 'white',  
        textShadow: '0px 0px 0px '+MainTheme.Corporate.darkBlue,   
        fontSize: '90%' 
    },
  }));

function BootstrapTooltip(subProps: TooltipProps) {
    const classes = useStylesBootstrap();
  
    return <Tooltip arrow placement="bottom-start" classes={classes} {...subProps} />;
} 
    
    
    if(props.Interactive !== true){
        return(        
            <Content Theme={MainTheme}>                 
                    <ClickAwayListener onClickAway={handleTooltipClose}>            
                    <Contenedor> 
                        <BootstrapTooltip title={typeof props.Title !== 'undefined' && props.Title !== '' ? props.Title : "no title"} placement={props.Position}>
                            {props.children}                    
                        </BootstrapTooltip>            
                    </Contenedor>  
                    </ClickAwayListener> 
            </Content>   
                
                
            )
    }else{
        return(
            <Content Theme={MainTheme}>                 
            <ClickAwayListener onClickAway={handleTooltipClose}>
            
            <Contenedor> 
            {
            !Status ? 
                <BootstrapTooltip title={props.Title} placement={props.Position}>
                    <Icon className="Back" onClick={SwitchStatus}>{<props.Trigger/>}</Icon>
                </BootstrapTooltip> 
                : 
                <HtmlTooltip
                className='logToolTip'
                arrow
                PopperProps={{
                    disablePortal: false,
                }}
                interactive
                open={Status}
                onClose={handleTooltipClose}
                disableFocusListener
                disableHoverListener
                disableTouchListener
                title={
                    props.children
                   
               } >
                 <Icon className="Back" onClick={SwitchStatus}>{<props.Trigger/>}</Icon>  
                
            </HtmlTooltip>  
                }  
            
            </Contenedor> 
            </ClickAwayListener> 
    </Content>  
        )
    }   
   
}

const Content = styled.div<Themeprops>({
 
 
},props=>({    
    '.logToolTip + div > div' :{
        backgroundColor: props.Theme.Corporate.blue,
        
    }
}))

const Contenedor = styled.div({


})
