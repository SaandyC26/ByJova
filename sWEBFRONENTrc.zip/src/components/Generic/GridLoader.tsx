import { Grid, GridColumn, GridSortChangeEvent } from '@progress/kendo-react-grid';
import React, { useState,useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {Static_Change_MonthBlocker } from '../../store/slices/user';
import { orderBy } from "@progress/kendo-data-query";

const initialSort: Array<any> = [
    { field: "year", dir: "asc" },
  ];

export default function GridLoader(props:any){
    
    const dispatch = useDispatch();
    
    const[modedList, setModedList] = useState<any>(null)
    const [sort, setSort] = useState(initialSort);

    useEffect(() => {  
   
       if(modedList === null){
           setModedList(props.List)
       }
       
    },[])


    function CheckBox(subProps:any){
       
        return(
            <td><input defaultChecked={subProps.dataItem[subProps.field]} onChange={() => {UpdateBox(subProps)}} type={'checkbox'}/></td>
        )
    }

    function UpdateBox(item:any){       
        item.dataItem[item.field] = !item.dataItem[item.field]
        props.UpdateBox(item)
        dispatch(Static_Change_MonthBlocker(true))
    }

    
    return(
        <div>
            <h1>{props.Title}</h1>
        {modedList !== null ?  <Grid
            
            data={orderBy(modedList, sort)}
            sortable={{
                allowUnsort: true,
                mode: 'single'
            }}            
           
            scrollable="none"
            editField="inEdit"
            sort={sort}
            onSortChange={(e: GridSortChangeEvent) => {
                setSort(e.sort);
              }}
            
        >
            <GridColumn field="year" title="Year" width="200px" editable={false} className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="january" title="Jan" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="february" title="Feb" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="march" title="Mar" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="april" title="Apr" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="may" title="May" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="june" title="Jun" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="july" title="Jul" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="august" title="Aug" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="september" title="Sep" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox}  field="october" title="Oct" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="november" title="Nov" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
            <GridColumn cell={CheckBox} field="december" title="Dec" sortable={false} editor="boolean" className={props.Granted.edit ? '' : 'Locked'} />
        </Grid> : null}
        </div>
    ) 
       
}



