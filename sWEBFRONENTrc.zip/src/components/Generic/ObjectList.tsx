import React,{useState,useEffect, useRef}  from "react";
import { DropDownList } from '@progress/kendo-react-dropdowns';
import { Button } from '@progress/kendo-react-buttons';
import styled from "@emotion/styled";

const ObjectList = (props:any) => { 
    let thisimp = useRef<any>(null)
    const setRender = useRef<any>(props.Renderer)
    const FormRef = useRef<any>(new Array())

    const [Orch, setOrch] = useState<any>( typeof props.Values !== 'undefined' ? props.Values.map((el:any) => {
       
        return {
                Name: el.name, 
                AppId: el.id, 
                Prefix: el.prefix
                
            }
    } ) : new Array )
    const [Load, setLoad] = useState(true)
    FormRef.current = new Array();

    useEffect(() => {  
      
        setRender.current.onChange( props.Name, { value: Orch.filter((ni:any) => ni.AppId !== '').map((el:any) => {
            console.log(el)
            return {prefix: el.Prefix || 'APP-', id: el.AppId , name: el.Name}
           }) }); 

        
        
   },[Orch])

   useEffect(() => {  
    setRender.current.onChange('table', { value: Orch });             
    setLoad(true)
},[Orch])

   function RemoveItem(target:any){

    let oldList:any = [...Orch]
    
    let NewList = new Array;

   
        oldList.forEach((ded:any, index:any) => {
           
            if(index !== target){
                NewList.push({...ded})
            }
           

        });
    
  
    oldList = NewList;
   
   
    
    setLoad(false)
    
    setOrch([...oldList])
   
}



    const Lista =  Orch.map((element:any,index:any) => {
       
        return(
            <li key={index}>
               <DropDownList name="Prefix" data={['APP-','COM-']} defaultValue={element.Prefix || 'APP-'} onChange={(response:any) => {let old = [...Orch]; old[index].Prefix = response.value;  setOrch(old)    }}/>
               <input name="AppId" required onChange={(re:any) => {let old = [...Orch]; old[index].AppId = re.target.value;  setOrch(old)}} defaultValue={element.AppId}/>
               <input name="Name" onChange={(re:any) => {let old = [...Orch]; old[index].Name = re.target.value;  setOrch(old)}} defaultValue={element.Name}/>
               <div className="decoration">
                    <Button 
                    icon="delete" 
                    onClick={(e:any) => {
                        e.preventDefault(); 
                        RemoveItem(index)
                        
                    }}
                    >
                    </Button> 
                </div>
            </li>
        )
    })

    const Titles = props.Defs.map((el:any, index:any) => { 
        let Mod = '';
        if(props.requiredList.includes(el)){
            Mod = '*'
        }
        return (<span key={index}>{el+Mod}</span>)
    })


    return (
        <Content >
            <p>{props.Title}</p>
            <RecibedStyles GivenStyles={props.GivenStyles}>
                <HeaderTitles key={'titles-index'}>
                    {Titles}
                </HeaderTitles>
                {Load ? Lista : null}
                <li key={'action-index'} className="Add" onClick={() => {setOrch([...Orch].concat({Name: '', AppId: ''}))}}>+ Add Item</li>
            </RecibedStyles>
        </Content>
    )
 }













export default ObjectList;

const RecibedStyles = styled.ol<any>({
    
     
 }, props =>({...props.GivenStyles
   
 }))

 const HeaderTitles = styled.li({
    color: 'grey',
    display: 'flex',
    span:{
       width: '140px',
       color: 'grey'
    }
 })

const Content = styled.div({
    '.Add':{
        cursor: 'pointer'
    },
   '.k-dropdown .k-dropdown-wrap':{
       border: '1px solid #80808082 !important',
   },
   '.k-input':{
       textIndent: '5px'
   },
   button:{
       marginLeft: '3px',
       backgroundColor: 'white',
       color: 'red',
       border: '1px solid red',
       boxShadow: 'none',
       ':hover':{
           backgroundColor: 'red',
           color: 'white'
       }
   },
   li:{
       marginBottom:'3px',
       display: 'flex',
       input: {
           width: '140px',
           border: '1px solid #80808082'
       }

   },
   ol: {
       width: '395px',
       maxHeight: '350px',
       overflowY: 'auto',
       overflowX: 'hidden',
       listStyle: 'none',
       padding: '0px'
   }
    
})