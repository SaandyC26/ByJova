import React, {useState,useRef}  from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import { withStyles, Theme } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Popup from "./Popup";
import {ToolbarButton} from './Styles'
import { Switch } from '@progress/kendo-react-inputs';
import {addHiddenColumn,removeHiddenColumn } from '../../store/slices/user';
import store from '../../store';
interface Themeprops {
    Theme: any
}

interface Expected {
   
}

// this component handles login/out operations
export default function VisibleColumns(props:Expected){   
   const MainTheme = useSelector( (state: any) => state.Theme); 
   const [Status, SetStatus] = useState(false);   
   const RefVisible = useRef(new Array);  
  

   function SwitchValue(mode:any,target:any){
    if(mode){
        store.dispatch(addHiddenColumn(target));
    }else{
        store.dispatch(removeHiddenColumn(target)); 
    }
   }

   let List = store.getState().userData.DemandSettings.Columns; 
   RefVisible.current = List;
   
   function SwitchStatus(){
    SetStatus(!Status);
}
   const handleTooltipClose = () => {
    SetStatus(false);
  };

  

    
    const HtmlTooltip = withStyles((theme: Theme) => ({
        arrow: {
            color: MainTheme.Corporate.blue,
          },
          tooltip: {
              backgroundColor: MainTheme.Corporate.blue,
              color: 'white',  
              textShadow: '0px 0px 0px '+MainTheme.Corporate.darkBlue,   
              fontSize: '90%' ,
              minWidth: 420
          },
        
      }))(Tooltip);
   
      const Override = {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        'li':{
            width: '200px',
            textAlign: 'end',
        },
        'li:nth-child(even)':{paddingRight: '10px'}
    
    }
   
   return(       
           
    <Content Theme={MainTheme} id="VisibleColumns">    
    <ClickAwayListener onClickAway={handleTooltipClose}>
        <Contenedor> 
        <Icon Theme={MainTheme} >  
        { 
        !Status ? 
            
                <ToolbarButton className="settingsToolTip k-button k-primary rounded " onClick={SwitchStatus} id="Header_Button_HideColumns">Hide Columns</ToolbarButton>
            
            : 
            <HtmlTooltip
            arrow
            PopperProps={{
                disablePortal: true,
            }}
            className='settingsToolTip'
            interactive
            open={Status}
            onClose={handleTooltipClose}
            disableFocusListener
            disableHoverListener
            disableTouchListener
            title={
                <Popup override={Override}>  
                    <ol>                        
                        <li><p>Line of Business</p><Switch  name="lineOfBusinessName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'lineOfBusinessName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Customer</p><Switch  name="customerName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'customerName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Customer Function</p><Switch  name="customerFunctionName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'customerFunctionName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Project</p><Switch  name="projectName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'projectName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Project Type</p><Switch  name="projectType" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'projectType').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>TOS</p><Switch  name="typeOfServiceName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'typeOfServiceName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Service Description</p><Switch  name="serviceDescription" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'serviceDescription').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>CModel</p><Switch  name="chargingModelCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'chargingModelCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>BU Code</p><Switch  name="businessUnitCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'businessUnitCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Product</p><Switch  name="productName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'productName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Currency</p><Switch  name="currencyCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'currencyCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        
                        <li><p>Plan LC</p><Switch  name="planLC" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'planLC').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Transfer LC</p><Switch  name="transferLC" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'transferLC').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Difference LC</p><Switch  name="differenceLC" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'differenceLC').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>

                        <li><p>FYFCLC</p><Switch  name="fyfclc" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'fyfclc').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>FYFCHF</p><Switch  name="fyfcchf" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'fyfcchf').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>FYFCHFVAT</p><Switch  name="fyfcchfvat" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'fyfcchfvat').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Customer CC</p><Switch  name="customerCostCenterCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'customerCostCenterCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Owner</p><Switch  name="ownerProjectManagerName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'ownerProjectManagerName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>

                        <li><p>Group Owner</p><Switch  name="groupOwnerName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'groupOwnerName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>

                        <li><p>Internal CC</p><Switch  name="internalCostCenterPerCostCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'internalCostCenterPerCostCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>ICode</p><Switch  name="internalCode" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'internalCode').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Testing Tool Name</p><Switch  name="testingToolName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'testingToolName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Testing Tool Project Name</p><Switch  name="testingToolProjectName" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'testingToolProjectName').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Testing Tool Detailed Info</p><Switch  name="testingToolDetailedInfo" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'testingToolDetailedInfo').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>

                        <li><p>Planned Start Date</p><Switch  name="plannedStartDate" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'plannedStartDate').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Planned End Date</p><Switch  name="plannedEndDate" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'plannedEndDate').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Project Planning It Apps Ids</p><Switch  name="projectPlanningItAppsIds" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'projectPlanningItAppsIds').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>Project Planning It Apps Names</p><Switch  name="projectPlanningItAppsNames" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'projectPlanningItAppsNames').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>

                        <li><p>January</p><Switch  name="january.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'january.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>February</p><Switch  name="february.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'february.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>March</p><Switch  name="march.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'march.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>April</p><Switch  name="april.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'april.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>May</p><Switch  name="may.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'may.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>June</p><Switch  name="june.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'june.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>July</p><Switch  name="july.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'july.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>August</p><Switch  name="august.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'august.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>September</p><Switch  name="september.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'september.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>October</p><Switch  name="october.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'october.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>November</p><Switch  name="november.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'november.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                        <li><p>December</p><Switch  name="december.amount" defaultChecked={!RefVisible.current.find((el:any) => el.field === 'december.amount').Show} onChange={(e:any) => SwitchValue(e.target.value, e.target.name)}  /></li>
                    </ol>
                </Popup>
            }
        >
                
                <ToolbarButton className="settingsToolTip k-button k-primary rounded " onClick={SwitchStatus} id="Header_Button_HideColumns">Hide Columns</ToolbarButton>
            </HtmlTooltip>  
        }
            
            </Icon>  
        </Contenedor>    
        </ClickAwayListener>
    </Content> 
             
        
        
    )
}



const Contenedor = styled.div({
   'p':{ color: 'white', display: 'inline', paddingRight: '15px'},    
   
    zIndex: 500
    
    })
const Content = styled.div<Themeprops>({ 
    color:'white',  
     marginLeft: '10px',
        '.logToolTip + div > div' :{       
           
            fontFamily: '"Frutiger 45 Light"'
        },
        '.logToolTip + div .MuiTooltip-arrow':{
            left: '10px',
           
            transform: ' scale(1.5) translateY(-1px)'
        }
    
},props=>({    
        '.logToolTip + div > div' :{
            backgroundColor: props.Theme.Corporate.blue,
            
        },
        '.k-switch-on .k-switch-container':{
            backgroundColor: props.Theme.Corporate.lightBlue
        },
        '.k-switch-on .k-switch-handle':{
            backgroundColor: props.Theme.Corporate.darkBlue
        }
}))

const Icon = styled.div<any>({
    padding: '0px',
    height: '7vh',
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'center',
    cursor: 'pointer',
    'svg':{
        fontSize: '36px',
        cursor: 'pointer',
       
        stroke: '#ffffff',       
        borderRadius: '5px',
        strokeWidth: '1px',        
        padding: '2px',
        transition: 'all 100ms'
    },
    '> div':{
   
    height: '40px',
    width: '40px',
    backgroundPosition: 'center',    
    backgroundSize: '35px',
    borderRadius: '50%',    
    },
    
    
}, props =>({
    'svg':{
        color: props.Theme.Corporate.darkBlue,
        border: '1px solid '+ props.Theme.Corporate.darkBlue,
        backgroundColor: props.Theme.Corporate.darkBlue,   
     }
 }))   



