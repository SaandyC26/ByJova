import * as React from "react";
import { Calendar } from "@progress/kendo-react-dateinputs";


export const CustomFilterUI = (props: any) => {
   
  const onChange = (event:any) => {
    const value = event.target.value
    const { firstFilterProps } = props;

    firstFilterProps.onChange({
      value,
      operator: "eq",
      syntheticEvent: event.syntheticEvent,
    });
  };

  const { firstFilterProps } = props;
  const value = firstFilterProps.value  ? new Date(firstFilterProps.value ) : null;

  return (
    <div>
        <Calendar defaultValue={value}  onChange={onChange} navigation={false} topView='decade' bottomView='decade' defaultActiveView='decade'
        min={new Date(2016, 1, 1)} max={new Date(2025, 12, 31)}
        />
      
    </div>
  );
};