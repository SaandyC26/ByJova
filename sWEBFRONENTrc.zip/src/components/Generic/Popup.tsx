import React from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';




interface Themeprops {
    Theme: any,
    override? : any
}


// this component handles login/out operations
export default function Popup(props:any){  
   const Theme = useSelector( (state: any) => state.Theme);  

   return(
        <Menu Theme={Theme} override={props.override}>
            {props.children}
        </Menu>
        
    )
}


const Menu = styled.div<Themeprops>({
    paddingLeft: '10px',
    display: 'flex',
    color: 'white',
    fontWeight: 500,
    alignItems: 'center',
    padding: '5px 0px',
    width: '100%',
    
    ol : {
        
        listStyle: 'none',
        padding: '0px',
        margin: '0px',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-evenly',
        fontSize: '16px',
    },
    li : {
        cursor: 'pointer',
        color: 'white',
        textAlign: 'left',
        padding: '5px 0px',
        'a, a:active':{
            textDecoration: 'none',
            color: 'inherit'
        }
    }},props=>({    
        'ol': props.override,
        'li:hover':{
            textShadow:'0px 0px 0px '+props.Theme.Corporate.veryDarkBlue,
            color: props.Theme.Corporate.veryDarkBlue,
        }    
        
    }))

