
import React, { SyntheticEvent,useState, useEffect } from 'react';
import styled from "@emotion/styled";
import { GridColumnMenuCheckboxFilter, GridColumn as Column, GridDataStateChangeEvent, Grid, GridColumnMenuFilter, GridExpandChangeEvent, GridCellProps, GridColumnResizeEvent,GridColumnReorderEvent } from '@progress/kendo-react-grid';
import {useSelector} from 'react-redux';

export const CheckboxFilter = (props: any) => {
  const Theme =  useSelector((state: any) => state.Theme) ;  
  console.log(props)
  let Field = props.column.field; 
    // aka
    const FilterContent = styled.div ({
       paddingTop: '50px',        
        '>div:first-of-type > div:first-of-type' :{
           
           pointerEvents: 'none',
           position:'absolute',
           top:'0px'
           
        },
        
    }, () => ({
        '*:checked, *:visited, *:active, *:selected, *:focus, *:active, *:activated': {
            borderColor: Theme.Corporate.blue,
        },
        'input:checked, input:visited, input:active': {
            backgroundColor: Theme.Corporate.blue,
            borderColor: Theme.Corporate.blue,
            outlineColor: Theme.Corporate.blue,
            boxShadow: 'none'
        },
        'button:not(:disabled)':{
            backgroundColor: Theme.Corporate.blue,
            borderColor: Theme.Corporate.blue,
        }
    }))


    
    const [FilteredData,setFilteredData] = useState(props.data);
   

    function Update(value:any){        
        let FilteredDatatemp = new Array; 
        if(value === null){ value = ''}
        value = value.toLowerCase();

        props.data.forEach((el:any) => {
            
            if(el[Field] !== null && el[Field].toLowerCase().includes(value)){                
                let Exists = FilteredDatatemp.filter((el2:any) => el2[Field].includes(el[Field]));               
                if(Exists.length === 0){                    
                    FilteredDatatemp.push(el)
                }   
            }
        })
        setFilteredData(FilteredDatatemp);  
       
    }


  const onChange = (event:any) => {
    const value = event.target.value ;
    const { firstFilterProps } = props;

    firstFilterProps.onChange({
      value,
      operator: "eq",
      syntheticEvent: event.syntheticEvent,
    });
  };

  const { firstFilterProps } = props;
  const value = firstFilterProps.value;

  return (
   <div>
            <input placeholder="Search" onChange={(e:any)=>{Update(e.target.value)}} style={{position:'absolute', top:'30px',width:'calc(100% - 20px)', marginLeft:'10px',paddingLeft:'5px'}} />
      <FilterContent>
      <GridColumnMenuCheckboxFilter {...props} 
        data={props.arrayValues[Field]} 
        expanded={true} searchBox={() => null} />
        
      </FilterContent>
      </div>
  );
};