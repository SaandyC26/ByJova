import  React, {SyntheticEvent,useState} from "react";
import { GridCellProps} from "@progress/kendo-react-grid";
import styled from "@emotion/styled";
import { LocalizationProvider} from "@progress/kendo-react-intl";
import { Button } from '@progress/kendo-react-buttons';
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import EditForm from "./EditForm";
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import {useSelector} from 'react-redux';
import MDTService from '../../services/MDTService';
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'
import {
    TreeList, orderBy, filterBy, mapTree, extendDataItem,   
} from '@progress/kendo-react-treelist';
import {AddButton,ActionButton} from './Styles'

interface DataExpected {
  DataSet : any; 
  TableDef: any;  
  TableSizes?: any;  
  Editable: boolean;
  Addable: boolean;
  callBack : any; 
  preSet: any;
  SpecialFields? : any;
  NoneRequired?: any;

} 



// this component renders grid tables in case it gets required props
export default function DataTableSpecial (props:DataExpected) {
  const Theme = useSelector( (state: any) => state.Theme);   
  const OriginalData = [...props.DataSet];
  const TableDef = props.TableDef;  
  const TokenData = useSelector((state: any) => state.tokenData);
 
  const locales = [
    {
      language: "en-US",
      locale: "en"
    },
    {
      language: "es-ES",
      locale: "es"
    }
  ];
  
  const initDataState: any = {   
    sort: [
      { field: 'year', dir: 'desc' }
  ],
  filter: []
    
};

const NewItem = {
    id: 60000,
    currency : 'USD',
    chf: 0,
    month: '',
    year: 2021, // to fix
    delete: false,
    new: true,
}

const [Expanded, setExpanded] = useState([props.preSet]);
const [dataState, setDataState] = useState(initDataState);
const Data = OriginalData;
const currentLocale = locales[0];
const [OpenForm,setOpenForm] = useState(false);
const [EditItem,setEditItem] = useState(NewItem);

const subItemsField = 'sublist';
const expandField = 'expanded';


const columns:any = [
  { field: 'year', title: 'Year',   expandable: true, width: '100px' },
  { field: 'month', title: 'Month',   width: '100px'},
  { field: 'currency', title: 'Currency',   width: '100px'},
  { field: 'chf', title: 'CHF',  width: '100px'},
 
  
];

if(props.Editable){
  columns.push({title: '', cell: MyEditCommandCell, width: '10px'});
}


function enterEdit(item : any){
    let convert = item
  
    if(!item.new){
    convert = {
      id: item.original.id,
      year: item.original.year,
      month: item.original.month === null ? 'All' : item.original.month,
      chf: item.original.rate,
      currency: item.original.from.code,
      delete: false,
      new: false
    }

  } 

    item.delete = false; 
    setOpenForm(true);
    setEditItem(convert);
}

function deleteConfirm(item : any){
   item.delete = true;       
   setOpenForm(true);
   setEditItem(item);
}



interface EditProps {
    enterEdit: Function,
    deleteConfirm: Function
}

function MyEditCommandCell(subProps: any){ 
    if(typeof subProps.dataItem.original !== 'undefined'){
    return(
        <EditCommandCell {...subProps} enterEdit={enterEdit} deleteConfirm={deleteConfirm}/>
    )
    }else{
      return null
    }
    }

const EditCommandCell = (subProps: GridCellProps & EditProps) => {
    return (
        <td className="adjust">
            <Actions>
            <ActionButton id={"Table_Button_Add_"+subProps.dataItem.original.year}
                
                onClick={() => subProps.enterEdit(subProps.dataItem)}
                >
                  {IconEdit('rowButton')}
            </ActionButton>  
            
            </Actions>     
        </td>
    );

};
function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>){

    
    let convert = {
      id: values.id,
      rate: values.chf,
      to: {name: 'Chief', code: 'CHF', symbol: "CHF", id:3},
      month: values.month === 'All' ? null : values.month,
      year: values.year,
      from: values.currency === 'USD' ? 
        {name: 'United States Dollar', code: 'USD', symbol: "US$", id:2} : 
        {name: 'Euro', code: 'EUR', symbol: "€", id:1}
    }

    
    if(EditItem.new){
      MDTService.postInsertMasterDataItem(convert,TokenData.tokenId,'postRequestCurrencyExchangeRate').then((result: any) => {           
        if(result.type === 'ok'){ 
          props.callBack();
          setOpenForm(false);
        }           
           
      })
      values.new = false;
    }else if(EditItem.delete){
      console.log('Delete Item');
    }else{
      MDTService.postEditMasterDataItem(convert,TokenData.tokenId,'postRequestCurrencyExchangeRate').then((result: any) => {           
        props.callBack();               
        setOpenForm(false);
      }).catch((error: any) => {
         
          console.log(error);
         
           
        });
    }
    
    
    }
    
function handleCancelEdit(event: DialogCloseEvent){  
    
    setOpenForm(false);
} 
 
 

  
const onExpandChange = (e:any) => {   

  setExpanded(e.value ?  Expanded.filter(id => id !== e.dataItem.id) :  [ ...Expanded, e.dataItem.id ])
}

const handleDataStateChange = (event:any) => {  
  setDataState(event.dataState);
}

const addExpandField = (dataTree:any) => {
  const expanded = Expanded;
  return mapTree(dataTree, subItemsField, (item) =>
      extendDataItem(item, subItemsField, {
          [expandField]: expanded.includes(item.id)
      })
  );
}

const processData = () => {  
  let data = Data;
  let DataState = dataState;
  let filteredData = filterBy(data, DataState.filter, subItemsField)
  let sortedData = orderBy(filteredData, DataState.sort, subItemsField)
  return addExpandField(sortedData);
}


  return (
    <Container id="DataTableSpecial" Theme={Theme} isEditable={props.Editable}>     
    <LocalizationProvider language={currentLocale.language}>
     
        <div>
                <Toolbar Theme={Theme} className="col-12">
                        {!props.Addable ? null : 
                        
                        <AddButton style={{marginBottom: '10px'}} id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton>
                         }
                        
                                       
                </Toolbar>
            <TreeList              
              style={{}}
                expandField={expandField}
                subItemsField={subItemsField}
                onExpandChange={onExpandChange}
                sortable={{ mode: 'multiple' }}
                {...dataState}
                data={processData()}
                onDataStateChange={handleDataStateChange}
                columns={columns}
             
            >
              
             
              
              
            </TreeList>
            {OpenForm && <EditForm NoneRequired={props.NoneRequired} SpecialFields={props.SpecialFields} Fields={TableDef} cancelEdit={handleCancelEdit}  onSubmit={handleSubmit} item={EditItem} />}
         
         
              
           
        </div>
     
    </LocalizationProvider>
    </Container>
  );
    
}

const Toolbar = styled.div<any>({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',
        color: '#003399',
        cursor: 'pointer',
        fill: '#003399'
    },
    padding: '0px',
    margin: '0px',
    backgroundColor: 'white'
    
     }, props =>({
      'svg':{
          color: props.Theme.Corporate.darkBlue,          
          fill: props.Theme.Corporate.darkBlue,   
       }
   }))

const Container = styled.div<any>({ 
  '.k-i-none + .k-icon':{
    display: 'none'
  },
  '.adjust':{
    position: 'absolute',
    right: '0px',
    marginTop: '5px',
    padding: '0px',
    margin: '0px',
    width: '50px',
    height: '100%',
    display: 'flex',
    justifyContent:'center',
    alignItems: 'center'
  },    
  width: '100%',
  justifyContenet: 'center',
  alignItems: 'center',
  display: 'flex',
  '.k-filtercell > span, .k-filtercell .k-filtercell-wrapper':{
    paddingLeft: '7px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  '.k-filtercell .k-filtercell-operator':{
    display: 'flex'
  },
  '.k-filtercell .k-filtercell-wrapper > .k-textbox':{
    backgroundColor: 'white',
    border: 'none',
    height: '25px',
    paddingLeft: '5px',
    color: 'grey',
    fontSize: '100%'
  },
  'tbody a':{
    textDecoration: 'underline',
    color: '#003399'
  },
  '.k-grid-content':{
    overflow: 'auto'
  },
  'div.k-grid-header':{
    padding: '0px !important'
  },
  '.k-grid tr':{
    textIndent: '10px',
    display: 'flex',
    width: '350px',
    '.k-icon::before':{
      marginLeft: '-7px'
    }
  },  
  'table td, table th':{
    width: '110px'
  },
  
  '.k-grid':{
    border: 'none'
  },
  '.k-grid-header .k-header > .k-link':{
    backgroundColor: 'white',
  },
  'a':{
    color: 'black',
  },
  'thead' :{   
    backgroundColor: 'white'
  },
  'thead th' :{   
    color: 'black',
    fontWeight: 'bold',
    textIndent: '8px',
    border: 'none',
    backgroundColor: '#e7eceb'
    
  },
  'tbody' :{   
   'tr:nth-of-type(even)':{
     backgroundColor: 'white',
   },   
  'td, th':{
    border: '0px solid white',
    textIndent: '7px'
  },  
  'th:first-of-type':{
      //textIndent: '7px'
    }
  },
  '.MuiTableSortLabel-root.MuiTableSortLabel-active':{
    //color : 'white'
  },
  '.k-master-row .k-button':{
      backgroundColor: 'transparent'
  }
  
}, props =>({
  'tr:nth-of-type(odd)':{
    backgroundColor: props.Theme.Corporate.paleBlue, 
  },
  'thead tr th:last-of-type' :{
    width: props.isEditable ? '0px' : '110px'
  },
}))
const Actions = styled.div({
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    
    'svg' : {
        
    },
    

    })  