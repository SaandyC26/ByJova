import React, {useState}  from 'react';
import styled from "@emotion/styled";
import {useSelector,useDispatch} from 'react-redux';
import {setNews} from '../../store/slices/user';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import { Checkbox } from '@progress/kendo-react-inputs';
import ReactHtmlParser from 'react-html-parser';
import UserService from '../../services/UserService'
interface Themeprops {
    Theme: any
}

// this component lays over all components and provides common interface for all pages
export default function NewsSplash(props:any){
    let dispatch = useDispatch();   
    const [Readed, setReaded] = useState(false);
    
    const News = useSelector( (state: any) => state.userData.News);    
    const Theme = useSelector( (state: any) => state.Theme);    
       
    function CloseNews(){
        dispatch(setNews({Show:false, Msg: ''}));   
        if(Readed){
            UserService.HideNews()
        }
    }  
   

    return(
              
        <div id="Dialog News">             
            {!News.Show ? null : 
            <Main Theme={Theme}>
                <span onClick={CloseNews}><HighlightOffIcon/></span>                
                <div className="splashContent">{ReactHtmlParser(News.Msg)}</div>
                <HideOption>
                    <label>Hide this until new patch notes are available<Checkbox onChange={(e:any) => {setReaded(e.value)}}/></label>
                </HideOption>
            </Main> }      
        </div>
        
    )
}


const HideOption = styled.div({
    position:'absolute',
    bottom:'0px',
    right: '0px',
    width: '100%',
    textAlign: 'right', 
    'label':{
        position: 'relative',
        paddingRight: '35px',
        fontSize: '12px',
        lineHeight: '1'
    },
    'span':{
        top: '-2px',
        right: '13px'
    }
})

const Main = styled.div<Themeprops>({
    '.splashContent':{
        maxHeight: '450px',
        overflowY: 'scroll'
    },
    padding: '20px',
    paddingBottom: '50px',
    backgroundColor: 'white',
    position: 'fixed',
    top: '50%',
    left: '50%',    
    width: '50%', 
    boxShadow: '0px 0px 0px 5000px rgb(0 0 0 / 0.4)',
    zIndex: 90000,
    borderRadius: '8px',    
    transform: 'translate(-50%, -50%)',
    'h1':{
        textAlign: 'center',
        
        fontSize: '24px'
    },
    'p':{
       
    },
    'span':{
        position: 'absolute',
        top: '10px',
        right: '10px',
        cursor: 'pointer',
        
       
        
    }
},props=>({    
    Color: props.Theme.Corporate.darkBlue,
     
    
}))