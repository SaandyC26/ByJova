
import React, { useState } from 'react';
import { State as DataState } from '@progress/kendo-data-query';
import { CircularProgress } from '@material-ui/core';
import ExcelService from '../../services/ExcelService'
import styled from "@emotion/styled";
import {ToolbarButton} from './Styles'
interface Props {
    token: string;
    dataState: DataState;
    downloadExcel?: Function;
    buttonText: string;
}

const ExportExcel: React.FC<Props> = ({ token, dataState, downloadExcel, buttonText }: Props): JSX.Element => {
    const [exporting, setExporting] = useState(false);

    const exportExcel = (): void => {
        setExporting(true);
        ExcelService.getExportedBarcelonaFile(JSON.stringify({TemplateName: "Revenues_Default",DataSourceRequest: {Filter : dataState.filter, Sort : dataState.sort}}), token).then((result: [Blob, string] | (string | Blob)[]) => {
            const url = window.URL.createObjectURL(new Blob([result[0]]));
            const a = document.createElement('a');
            a.href = url;
            a.download = result[1] as string;
            a.click();
            setExporting(false);
        });
    };

    return (
        <Content className="d-flex align-items-center float-right" id="ExportExcel">
            <ToolbarButton className="k-button k-primary rounded" onClick={exportExcel} id="Table_Button_ExportExcel">
                {buttonText}
            </ToolbarButton>
            {exporting && <CircularProgress />}
        </Content>
    );
};
export default ExportExcel;
const Content = styled.div({
    position: 'absolute',
    top: '-55px',
    right: '0'

    })  