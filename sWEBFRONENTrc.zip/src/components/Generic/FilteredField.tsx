
import React, { useState, useEffect } from "react";
import { FieldRenderProps } from "@progress/kendo-react-form";

import Filtered from "./FilteredItem"

export default function FilteredField(fieldRenderProps: FieldRenderProps) {

    const { validationMessage, visited, ...others } = fieldRenderProps;

    const [Filter, setFilter] = useState('')
    const [Options, setOptions] = useState(others.data)

    useEffect(() => {

        setOptions(others.data.filter((el: any) => el.toLowerCase().includes(Filter.toLowerCase())))

    }, [Filter, others.data])

    return (
        <div>
            <Filtered List={Options} setFilter={setFilter} Item={fieldRenderProps} />
        </div>
    )
};


