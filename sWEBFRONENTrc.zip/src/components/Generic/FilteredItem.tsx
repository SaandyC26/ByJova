
import React     from "react";
import { FieldRenderProps } from "@progress/kendo-react-form";
import {  ComboBox } from "@progress/kendo-react-dropdowns";
import { Error } from "@progress/kendo-react-labels";


export default function FilteredField(props: any ) {
 
        const { validationMessage, visited, ...others } = props.Item;

        
        let moded = {...others}
        moded.data = props.List;

        return ( 
        <div>
            <ComboBox data={props.List} onFilterChange={(e:any) => { props.setFilter(e.filter.value)} } filterable {...moded} />
            {visited && validationMessage && <Error>{validationMessage}</Error>}
        </div>            
        )
       
         
       
       
               
    };


