import  React, {SyntheticEvent,useState} from "react";
import { Grid, GridCellProps, GridColumn as Column,GridColumnMenuCheckboxFilter,GridExpandChangeEvent,GridDetailRowProps,GridFilterChangeEvent} from "@progress/kendo-react-grid";
import styled from "@emotion/styled";
import { LocalizationProvider} from "@progress/kendo-react-intl";
import {Link} from 'react-router-dom';
import 'hammerjs';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import { useDictionary as Dict} from "../Functions/Utils";
import { Button } from '@progress/kendo-react-buttons';
import { process, State } from "@progress/kendo-data-query";
import EditForm from "./EditForm";
import {useSelector} from 'react-redux';
import { CSVLink } from "react-csv";
import GetAppIcon from '@material-ui/icons/GetApp';
import Tooltiped from './TooltipedItem';
import { formatNumber } from '@telerik/kendo-intl';
import {AddButton} from './Styles'
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'
import {ActionButton} from '../Generic/Styles';

interface DataExpected {
  DataSet : any; // source of elements to list on the grid
  NavCol?: any; // wich column will have a link to detail page
  NavLink?: any; // defines NavCol link path
  BaseRoute? : string; // baseroute of NavLink
  TableDef: any;  // definition of column names
  TableSizes?: any; // definition of column sizes (0 size mean auto size)
  Filter? : boolean; // filters for this table    
  Editable? : boolean; // true if user can edit table items
  Addable? : boolean; // true if user can add items
  Deleteable? : boolean; // true if user can delete items
  SpecialFields?: any; // Array of columns that will have special components to render
  specialValues?: any;
  Override? : any; // combined with SpecialFields if any column render must be override by new info
  CallBackUpdate? : any; // Callback function from parent when an item is updated
  CallBackAdd? : any; // Callback function from parent when an item is created
  CallBackDelete?: any; // Callback function from parent when an item is deleted
  CallBackCheckUser?: any; // Callback function from parent when Checkuser function returns
  Origin?: any; // Info about the parent component  
  HiddenFields?: any; // columns that must not appear but need to exist
  HiddenFieldsMandatory? : any // set wich of hidden fields are mandatory
  HiddenFieldsEdit?:any,// set hidden fields on edit on form
  HiddenFieldsTable?:any, // set hidden fields on table
  HiddenFieldsEditNew?:any,
  CustomHeight?: any; // if any, grid will have minheight from prop instead of default styled one
  GivenList?: any; // given tag list
  Form? : any,
  Permissions? : any,
  Granted?: any,
  SpecialLists? : any,
  SavedFilters?:any,
  CallBackFilterUpdate?: any,
  Expand?: boolean,
  Download?: boolean,
  Columnable?: number,
  ColumnableNew?: number,
  Mandatory? : any,
  Windowed?: boolean,
  Virtual?:boolean,
  key?:any,
  PrevRend?: boolean,
  ModItem?: any,
  ConditionalEdit?: any,
  ConditionalDelete?: any,
  forcedText?: any,
  CustomFilters?: any,
  
  
} 

interface EditProps {
  enterEdit: Function,
  deleteConfirm: Function
}

interface NewItemData {
  name: string; // element name
  delete: boolean; // element is being deleted?
  new: boolean; // element is new?
  id: number; // element id
  Role? : string // element Role
} 

interface Themeprops {
  Theme: any
}

const BaseNewItem:any = {
  id: 60000,
  name : '',
  delete: false,
  new: true,
}



let NewItem:NewItemData = BaseNewItem;
interface PageState {
  skip: number;
  take: number;
}
let initDataState: State = {
  skip: 0,
  take: 20,
  sort: [{ field: 'orderDate', dir: 'desc' }],
  
};

// this component renders grid tables in case it gets required props
export default function DataTable2 (props:DataExpected) {
  const Theme = useSelector( (state: any) => state.Theme);
  const OriginalData = [...props.DataSet];
  const CustomHeight = props.CustomHeight;
  const TableDef = props.TableDef;
  const TableSizes = props.TableSizes;
  const BaseRoute = props.BaseRoute;  
  const NavLink = props.NavLink;  
  
  if(typeof props.ModItem !== 'undefined' && props.ModItem.length > 0){

    props.ModItem.forEach((element:any) => {
      BaseNewItem[element.Name] = element.Value;
    });
  }
  



  const Labels = {
    DownloadCSV : Dict("Generic Download CSV"),   
  }

  if(typeof props.Override !== 'undefined'){
    let ModItem = {...NewItem};
    props.Override.forEach((element:string) => {
      switch(element){
        case 'Role' : 
        case 'why2roles': 
        case 'why3roles':        
        ModItem.Role = props.SpecialFields[0][element].values[0] ;break;
      }
    });
    
    NewItem = ModItem;
  }
  
 
function handleCancelEdit(event: DialogCloseEvent){     
  setOpenForm(false);
} 

function IsRelatedEdit(item:any){
  
  if(typeof item !== 'undefined' && typeof item[props.ConditionalEdit.Prop] !== 'undefined'){
    return item[props.ConditionalEdit.Prop] === props.ConditionalEdit.Valid
  }
}
function IsRelatedDelete(item:any){
 
  if(typeof item !== 'undefined' && typeof item[props.ConditionalDelete.Prop] !== 'undefined'){
    return item[props.ConditionalDelete.Prop] === props.ConditionalDelete.Valid
  }
}

function MyEditCommandCell(subProps: GridCellProps){  
 
  return(
      <EditCommandCell {...subProps} enterEdit={enterEdit} deleteConfirm={deleteConfirm}/>
  )
  
}



  const EditCommandCell = (Subprops: GridCellProps & EditProps) => {

   

    
   
    let Found:any = null;
    if(typeof props.specialValues !== 'undefined' &&  typeof props.specialValues.find((el:any) => el.Value === Subprops.dataItem.Key) !== 'undefined' ){
      Found = props.specialValues.find((el:any) => el.Value === Subprops.dataItem.Key)     
    }
    let Editable = false;
    let Deleteable = false;

    if(typeof props.Editable !== 'undefined' && props.Editable === true){
      Editable = true;
    }
    if(typeof props.Deleteable !== 'undefined' && props.Deleteable === true){
      Deleteable = true;
   }

  
   if(Found !== null && Found.readonly){Editable = false}
   if(Found !== null && Found.mandatory){Deleteable = false}
   if(Found === null && typeof props.Editable === 'undefined' && typeof props.Deleteable === 'undefined'){
     Editable = true;
     Deleteable = true;
   }

   if(typeof props.ConditionalEdit !== 'undefined'){    
     if(typeof Subprops.dataItem[props.ConditionalEdit.Field] !== 'undefined' &&     
     Subprops.dataItem[props.ConditionalEdit.Field].find(IsRelatedEdit)
  ){ Editable = true

     }else{Editable = false}
     
   }

   if(typeof props.ConditionalDelete !== 'undefined'){
    if(typeof Subprops.dataItem[props.ConditionalDelete.Field] !== 'undefined' &&
    Subprops.dataItem[props.ConditionalDelete.Field].find(IsRelatedDelete)
 ){ Deleteable = true

    }else{Deleteable = false}
    
  }
   
   
    return (
        <td>
           <Actions>
            {Editable?
             
                <ActionButton 
               
                onClick={() => Subprops.enterEdit({...Subprops.dataItem})}
                >{IconEdit('rowButton')}
            </ActionButton>
            : null
            }
            {Deleteable ? 
              <ActionButton 
              
              onClick={() => Subprops.deleteConfirm({...Subprops.dataItem})}
              >{IconTrash('rowButton')}
              </ActionButton> 
              : null
            }            
              
             
            </Actions>   
            
             
        </td>
    );

};

if(typeof props.SavedFilters !== 'undefined' && JSON.stringify(props.SavedFilters) !== JSON.stringify(initDataState)){  
  initDataState = props.SavedFilters
}
const initialDataState: PageState = { skip: 0, take: 20 };
const [dataState, setDataState] = useState<State>(initDataState);
const [data, setData] = React.useState<any>(process(OriginalData, dataState));
const [largeData, setLargeData] = React.useState<any>(process(OriginalData, {...dataState, skip:0, take: OriginalData.length}));
const [OpenForm,setOpenForm] = useState(false);
const [EditItem,setEditItem] = useState(NewItem);
const [FilterRows, setFilterRows] = useState(new Array);
const [times, setTimes] = useState(false)
const [page, setPage] = useState<PageState>(initialDataState);





  if(typeof props.PrevRend !== 'undefined' && !times){
   
    if(data.total !== OriginalData.length){
      setData(process([...props.DataSet], dataState))
      setTimes(true)
    }
    
  }




  const handleDataStateChange = (event:any) => {
    
    
    setDataState(event.dataState);
    
    if(typeof props.Virtual !== 'undefined' && props.Virtual === false){
      setLargeData(process(OriginalData, {...event.dataState, skip: 0,take: OriginalData.length}));
      setPage({ skip: event.dataState.skip, take: event.dataState.take })
    }else{
      setData(process(OriginalData, event.dataState));
    }
    
    if(typeof props.CallBackFilterUpdate !== 'undefined'){
      props.CallBackFilterUpdate(event.dataState);
    }    
    let toinclude = new Array;
    let isfiltered = false;   
    
    if(typeof event.dataState.filter !== 'undefined'){   
      if(event.dataState.filter.filters.length > 0){
        event.dataState.filter.filters.map((element:any) => {           
          if(typeof element.filters[0] !== 'undefined' && typeof element.filters[0].field !== 'undefined')
          {toinclude.push(element.filters[0].field);}                    
        })
      }      
    }

    
    setFilterRows(toinclude)

  };

  function enterEdit(item : any){   
    item.delete = false; 
    setOpenForm(true);
    setEditItem(item);
}

function deleteConfirm(item : any){
   item.delete = true;       
   setOpenForm(true);
   setEditItem(item);
}

function UpdateEditItem(item : any){
    setOpenForm(true);
    setEditItem(item);
    
}
function isBeingfiltered(subProps:any){ 
  let name = 'unfiltered';    
  FilterRows.forEach(element => {
    if(element === subProps){name = 'filtering'}
  })
  return name
}


function ColumnMenuFilter(subprops:any) {  
  let Field = subprops.column.field; 
  const FilterContent = styled.div ({
     paddingTop: '50px',        
      '>div:first-of-type > div:first-of-type' :{
         
         pointerEvents: 'none',
         position:'absolute',
         top:'0px'
         
      },
      '*:checked, *:visited, *:active, *:selected, *:focus, *:active, *:activated': {
        borderColor: Theme.Corporate.blue,
    },
    'input:checked, input:visited, input:active': {
        backgroundColor: Theme.Corporate.blue,
        borderColor: Theme.Corporate.blue,
        outlineColor: Theme.Corporate.blue,
        boxShadow: 'none'
    },
    'button:not(:disabled)':{
        backgroundColor: Theme.Corporate.blue,
        borderColor: Theme.Corporate.blue,
    }
      
  })
  


  let Alldata = new Array;

  OriginalData.forEach((element:any) => {
    if(!Alldata.includes(element)){Alldata.push(element);}
    
  });

  

  const [FilteredData,setFilteredData] = useState(Alldata);
 

  function Update(value:any){        
      let FilteredDatatemp = new Array; 
      if(value===null){value = '';}
      value = value.toLowerCase();
      
      Alldata.forEach((el:any) => {
          
        if(el[Field] !== null && el[Field].toLowerCase().includes(value)){                
          let Exists = FilteredDatatemp.filter((el2:any) => el2[Field].includes(el[Field]));               
          if(Exists.length === 0){                    
              FilteredDatatemp.push(el)
          }else{
            if(Exists[0].Name !== el.Name){
              FilteredDatatemp.push(el)
            }
           
          } 
        }
      })
      setFilteredData(FilteredDatatemp);  
      
  }

  
  

  return (
      <div>
          <input placeholder="Search" onChange={(e:any)=>{Update(e.target.value)}} style={{position:'absolute', top:'30px',width:'calc(100% - 20px)', marginLeft:'10px',paddingLeft:'5px'}} />
    <FilterContent>     
    <GridColumnMenuCheckboxFilter 
      {...subprops} 
      data={FilteredData}  // .sort((a,b) => (a !== null && b !== null && a.toLowerCase() > b.toLowerCase()) ? 1 : ((a !== null && b !== null &&  b.toLowerCase() > a.toLowerCase()) ? -1 : 0))
      expanded={true} 
      searchBox={() => null} 
    />
      
    </FilterContent>
    </div>
  );



}




function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>){

  

  if(EditItem.new){
    props.CallBackAdd(values)
  }else if(EditItem.delete){
    props.CallBackDelete(EditItem)
  }else{
    props.CallBackUpdate(values)
  }
  setOpenForm(false);
  
  }

  function LinkOut(subprops:any){
    let Field = subprops.field;
    return(
      <td><a target="_blank" href={subprops.dataItem[Field]}>{subprops.dataItem[Field]}</a></td>
      )
  }
  function LinkCell(subprops:any){
    
    let AlterNavLink = NavLink;
    let Field = subprops.field;
    

    if(typeof subprops.dataItem.NavLink !== 'undefined'){
      AlterNavLink = subprops.dataItem.NavLink;
    }   
    let TargetRoute = BaseRoute+subprops.dataItem[AlterNavLink]+'/';
    if(Field === 'Subscription'){
      TargetRoute = '../../my-subscriptions/'+subprops.dataItem.Subkey+'/'
    }
    else if(typeof subprops.dataItem.BaseRoute !== 'undefined'){
      TargetRoute = BaseRoute+subprops.dataItem.BaseRoute+'/'+subprops.dataItem[AlterNavLink]+'/';
      if( subprops.dataItem.BaseRoute.includes('jira') ||
          subprops.dataItem.BaseRoute.includes('confluence') ||
          subprops.dataItem.BaseRoute.includes('alm') ||
          subprops.dataItem.BaseRoute.includes('sonarqube') ||
          subprops.dataItem.BaseRoute.includes('bitbucket') ||
          subprops.dataItem.BaseRoute.includes('bamboo') ||
          subprops.dataItem.BaseRoute.includes('bamboo-deployment')
       ){
        TargetRoute = subprops.dataItem.Route+'/'
      }      
    }
    
    if(subprops.dataItem.Route === ''){
      return (
        <td>{subprops.dataItem[Field]}</td>
      )
    }
    
    return(
      <td><Link to={TargetRoute}>{subprops.dataItem[Field]}</Link></td>
      )
  }


  function ErrorableCell(subprops:any){
   
    
    let usedValue:any;

    if(typeof subprops.dataItem.Value === 'object'){
      usedValue = subprops.dataItem.Value.value;
    }else{
      usedValue = subprops.dataItem.Value;
    }

    return(
      <td className={subprops.dataItem.warning ? 'Warn' : ''}>{usedValue}{subprops.dataItem.warningTxt !== '' ? <span className="WarnMsg">{subprops.dataItem.warningTxt}</span>: null}</td>
      )
  }
 

  const expandChange = (event: GridExpandChangeEvent) => {
    const isExpanded =
      event.dataItem.expanded === undefined
        ? event.dataItem.aggregates
        : event.dataItem.expanded;
    event.dataItem.expanded = !isExpanded;

    
    setData({...data});
  };

  const NumberFormat = (subProps: any) => {

   
    return(
      <td className="Currency">
          {
           formatNumber(subProps.dataItem[subProps.field], props.SpecialFields[0][subProps.field].Rules.format)
          }  
       </td>
    )
  }

 

  const DetailComponent = (subProps: GridDetailRowProps) => {
    let dataItem:any = {...subProps.dataItem};
    dataItem.delete = false;
    
    if(typeof dataItem.expandCall !== 'undefined'){
      return(
        <dataItem.expandCall Transfer={dataItem} Key={dataItem.Subscription}/>
      )
    }
    else{
      switch(dataItem.expandType){
        case 'table': case 'table2': case 'table3':
          return(
            <SubTable>
              <DataTable2 Download={false} Deleteable={false} TableSizes={[0,0,0]} DataSet={{...dataItem.expandContent}} TableDef={['Name','dete','seta']}/>
            </SubTable>
          )
        case 'comments':
          return (
            <SubTable>
              <DataTable2 Download={false} TableSizes={[0,0,0]} DataSet={{...dataItem.expandContent}} TableDef={['Username','DateTime','Text']}/>
            </SubTable>
          )  
      }
  }
    return null
    
  }

  
  let Extras:any
  let Paging = false;
  if(typeof props.Virtual !== 'undefined' && props.Virtual === false){
    Paging = true
    Extras = {
      take: page.take,
      skip: page.skip,
      total: largeData.data.length,     
      pageable: { buttonCount: 4, pageSizes: true },      
      
    }
  }else{
    Extras = {
      scrollable : 'virtual',
      pageSize:20,
      rowHeight:20,
            
    }
  }



 let CSVList:any = new Array

 if(typeof largeData.data[0] !== 'undefined' && typeof largeData.data[0].expandType !== 'undefined'){
  CSVList =  process(largeData.data, {...dataState, skip:0, take: largeData.data.length}).data.map((clean:any) =>  {
    return(
      {
        'Charging Model': clean['Charging Model'],
        'Cost Centre': clean['Cost Centre'],
        Description : clean.Description,
        Discount: clean.Discount,
        Name: clean.Name,
        'Resource Unit Code': clean['Resource Unit Code'],
        Status : clean.Status,
        Subscription: clean.Subscription,
 
     })
  })
 }else{
  CSVList = process(largeData.data, {...dataState, skip:0, take: largeData.data.length}).data
 }
 
 function isSpecialField(el:string, check:string){
  if(typeof props.SpecialFields !== 'undefined' 
  && typeof props.SpecialFields[0] !== 'undefined' 
  && typeof props.SpecialFields[0][el] !== 'undefined'
  && props.SpecialFields[0][el].type === check
    ){
    return true
  }
  return false
 }
 
 

  return (
    <Container Theme={Theme}>
     
    <LocalizationProvider language={'en-US'}>
     
        <div>            
            <Toolbar Theme={Theme} className="col-12">
             
            <div>
              {!props.Addable ? null : <AddButton id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton>}   
            </div> 
            <div>
              {OriginalData.length > 0 && ((typeof props.Download !== 'undefined' && props.Download !== false) || typeof props.Download === 'undefined') ? 
              
              <Tooltiped Position="bottom" Title={Labels.DownloadCSV} >
                <CSVLink data={CSVList}><GetAppIcon/></CSVLink>
              </Tooltiped>
              : null}              
            </div>        
                         
            </Toolbar>
            <Grid                           
              style={{height: 'initial', maxHeight: CustomHeight ? CustomHeight : 'auto' }}    
              {...Extras}
              detail={DetailComponent}
              expandField={props.Expand ? "expanded" : ""}
              onExpandChange={expandChange}  
              sortable 
              onDataStateChange={handleDataStateChange}          
              data={Paging ? largeData.data.slice(page.skip, page.take + page.skip):  data}
              {...dataState}
                          
            >
              
              {
                TableDef.map((element:any, index:number)=>{
                 
                  let visible = true
                  if(typeof props.HiddenFields !== 'undefined' && props.HiddenFields.includes(element)){visible = false}
                  if(typeof props.HiddenFieldsTable !== 'undefined' && props.HiddenFieldsTable.includes(element)){visible = false}
                  if(isSpecialField(element,'externalLink')){
                    return(<Column key={index} cell={LinkOut} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} columnMenu={!Paging ? ColumnMenuFilter : undefined} headerClassName={isBeingfiltered(element)} />)
                  }

                  if(visible)  {
                   

                    if( typeof props.SpecialFields !== 'undefined' 
                    && typeof props.SpecialFields[0] !== 'undefined' 
                    && typeof props.SpecialFields[0][element] !== 'undefined'
                    && props.SpecialFields[0][element].type === 'number'
                    && typeof props.SpecialFields[0][element].Rules !== 'undefined'
                    && typeof props.SpecialFields[0][element].Rules.format !== 'undefined'){
                     
                      return(<Column key={index} cell={NumberFormat} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} columnMenu={!Paging ? ColumnMenuFilter : undefined} headerClassName={isBeingfiltered(element)} />)

                    }else{
                   // define if column has link                    
                  if(element === 'Value'){
                   
                    return(<Column key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} cell={ErrorableCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} columnMenu={ColumnMenuFilter} headerClassName={isBeingfiltered(element)} />)
                    
                  }
                  else if(Array.isArray(props.NavCol)){                   
                    if(props.NavCol.includes(element)){
                      return(<Column key={index}  width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} cell={LinkCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} filter={'text'} columnMenu={ColumnMenuFilter} />)
                    }else{
                    return(<Column key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} columnMenu={ColumnMenuFilter} headerClassName={isBeingfiltered(element)} />)
                     } 
                  }
                  else if(element === props.NavCol){
                    return(<Column key={index}  width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} cell={LinkCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} filter={'text'} columnMenu={ColumnMenuFilter} />)
                  }else{
                                     
                    if(typeof props.CustomFilters !== 'undefined' 
                       && typeof props.CustomFilters.find((el:any) => el.field === element) !== 'undefined'
                       && props.CustomFilters.find((el:any) => el.field === element).type === 'date' 
                    ){
                      return(<Column key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} headerClassName={isBeingfiltered(element)} />)
                    }

                    return(<Column key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} columnMenu={ColumnMenuFilter} headerClassName={isBeingfiltered(element)} />)
                  } } 
                }})

              }
              {props.Editable || props.Deleteable ? 
                <Column cell={MyEditCommandCell} resizable={false} width={80}/> 
                : 
                 null
              }
              
            </Grid>

            {OpenForm && typeof props.Form !== 'undefined' ? 
            <props.Form SpecialLists={props.SpecialLists} Origin={props.Origin} Granted={props.Granted} Permissions={props.Permissions} Fields={TableDef} cancelEdit={handleCancelEdit} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={EditItem}/> 
            : null} 
             
            {OpenForm && typeof props.Form === 'undefined' ?             
            <EditForm 
              ConditionalEdit={props.ConditionalEdit} 
              Windowed={props.Windowed} 
              Mandatory={props.Mandatory} 
              ColumnableNew={props.ColumnableNew} 
              Columnable={props.Columnable} 
              GivenList={props.GivenList} 
              specialValues={props.specialValues} 
              HiddenFieldsEdit={props.HiddenFieldsEdit} 
              HiddenFieldsEditNew={props.HiddenFieldsEditNew} 
              HiddenFields={props.HiddenFields} 
              HiddenFieldsMandatory={props.HiddenFieldsMandatory} 
              SpecialFields={props.SpecialFields} 
              Override={props.Override} 
              CallBackCheckUser={props.CallBackCheckUser} 
              Fields={TableDef} 
              forcedText={props.forcedText}              
              cancelEdit={handleCancelEdit} 
              UpdateEditItem={UpdateEditItem} 
              onSubmit={handleSubmit} 
              item={EditItem} /> 
            : null} 
              
           
        </div>
     
    </LocalizationProvider>
    </Container>
  );
    
}



const FilterStyle = styled.div<Themeprops>({
 
},props=>({   
  '.k-button':{
    backgroundColor: props.Theme.Corporate.darkBlue, 
    borderColor: props.Theme.Corporate.darkBlue, 
  },
  'input:checked':{
    backgroundColor: props.Theme.Corporate.darkBlue, 
    borderColor: props.Theme.Corporate.darkBlue, 
  },
  'input:focus:checked':{
    outlineColor: props.Theme.Corporate.darkBlue, 
    borderColor: props.Theme.Corporate.darkBlue,
    boxShadow: 'none',
  }
 
  
}))

const SubTable  = styled.div({
  marginBottom:'10px',
  "*" :{
    textDecoration:'none !important',
    
  }
})
const Container = styled.div<Themeprops>({
  '.k-hierarchy-cell':{
    a:{
      textDecoration:"none",
      ":hover":{textDecoration:"none"}
    }
  },  
  '.Warn':{
    outline: '2px solid red',
    outlineOffset: '-4px',
    '.WarnMsg':{
      fontSize: '80%',
      float: 'right',
      marginRight: '5px',
      color: 'red'
    }
  },
  '.filtering .k-i-more-vertical::before':{
    content: "'\\e12a'"
  },
  
  width: '100%',
  justifyContenet: 'center',
  alignItems: 'center',
  display: 'flex',
  '.k-filtercell > span, .k-filtercell .k-filtercell-wrapper':{
    paddingLeft: '7px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  '.k-filtercell .k-filtercell-operator':{
    display: 'flex'
  },
  '.k-filtercell .k-filtercell-wrapper > .k-textbox':{
    backgroundColor: 'white',
    border: 'none',
    height: '25px',
    paddingLeft: '5px',
    color: 'grey',
    fontSize: '100%'
  },
  'tbody a':{
    textDecoration: 'underline',    
  },
  '.k-grid-content':{
    overflow: 'auto'
  },
  'div.k-grid-header':{
    padding: '0px !important'
  },
  '.k-grid tr':{
    textIndent: '10px',
  },
  '.k-grid':{
    border: 'none'
  },
  '.k-grid-header .k-header > .k-link':{
    backgroundColor: 'white',
  },
  'a':{
    color: 'black',
  },
  'thead' :{   
    backgroundColor: 'white'
  },
  'thead th' :{   
    color: 'black',
    fontWeight: 'bold',
    textIndent: '8px',
    border: 'none',
    backgroundColor: '#e7eceb'
    
  },
  'tbody' :{  
    '.k-button'  :{
      backgroundColor: 'transparent',
    }, 
   'tr:nth-of-type(even)':{
     backgroundColor: 'white',
   },   
  'td, th':{
    border: '0px solid white',
    textIndent: '7px'
  },  
  'th:first-of-type':{
      //textIndent: '7px'
    }
  },
  '.MuiTableSortLabel-root.MuiTableSortLabel-active':{
    //color : 'white'
  }

  
},props=>({   
  'tr:nth-of-type(odd)':{
    backgroundColor: props.Theme.Corporate.paleBlue, 
  },
  'tbody a':{  
    color: props.Theme.Corporate.darkBlue
  }
  
}))


const Actions = styled.div({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '50px',
  alignItems: 'center',
  '.k-button':{
    padding: '5px !important'
  },
  'svg' : {
      
  },
  padding: '0px',
  margin: '-5px 0px'

  })  

  const Toolbar = styled.div<Themeprops>({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',        
        cursor: 'pointer',       
    },
    padding: '0px',
    margin: '0px',
    marginBottom:'10px',
    backgroundColor: 'white'
    
     },props=>({   
      'svg' : {       
        color: props.Theme.Corporate.darkBlue,        
        fill: props.Theme.Corporate.darkBlue
    },   
      
  }))
