import  React, {SyntheticEvent,useState} from "react";
import { Grid, GridColumn as Column, GridColumnMenuFilter, GridColumnMenuCheckboxFilter} from "@progress/kendo-react-grid";
import styled from "@emotion/styled";
import { LocalizationProvider} from "@progress/kendo-react-intl";
import { Button } from '@progress/kendo-react-buttons';
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import EditForm from "./EditForm";
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import {useSelector} from 'react-redux';
import { Checkbox  } from "@progress/kendo-react-inputs";
import MDTService from '../../services/MDTService';
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'
import {AddButton,ActionButton} from './Styles'
import { useDictionary as Dict, findWithAttr} from "../Functions/Utils";
import { process, State,filterBy } from "@progress/kendo-data-query";
import FilterBoolean from "./FilterBoolean"

const FormatCHF = "{0:N2} CHF";
const FormatEuro = "{0:N2} €";
const FormatPercentage = "{0:N5} %";

const FormatIntEuro = {
  minimumFractionDigits : 2, 
  maximumFractionDigits : 2,
  
}

const filterOperators = {
  'text': [
      { text: 'grid.filterContainsOperator', operator: 'contains' },
      { text: 'grid.filterNotContainsOperator', operator: 'doesnotcontain' },
      { text: 'grid.filterEqOperator', operator: 'eq' },
      { text: 'grid.filterNotEqOperator', operator: 'neq' },
      { text: 'grid.filterStartsWithOperator', operator: 'startswith' },
      { text: 'grid.filterEndsWithOperator', operator: 'endswith' },
      { text: 'grid.filterIsNullOperator', operator: 'isnull' },
      { text: 'grid.filterIsNotNullOperator', operator: 'isnotnull' },
      //{ text: 'grid.filterIsEmptyOperator', operator: 'isempty' },
     // { text: 'grid.filterIsNotEmptyOperator', operator: 'isnotempty' }
  ],
  'numeric': [
      { text: 'grid.filterEqOperator', operator: 'eq' },
      { text: 'grid.filterNotEqOperator', operator: 'neq' },
      { text: 'grid.filterGteOperator', operator: 'gte' },
      { text: 'grid.filterGtOperator', operator: 'gt' },
      { text: 'grid.filterLteOperator', operator: 'lte' },
      { text: 'grid.filterLtOperator', operator: 'lt' },
      { text: 'grid.filterIsNullOperator', operator: 'isnull' },
      { text: 'grid.filterIsNotNullOperator', operator: 'isnotnull' }
  ],
  'date': [
      { text: 'grid.filterEqOperator', operator: 'eq' },
      { text: 'grid.filterNotEqOperator', operator: 'neq' },
      { text: 'grid.filterAfterOrEqualOperator', operator: 'gte' },
      { text: 'grid.filterAfterOperator', operator: 'gt' },
      { text: 'grid.filterBeforeOperator', operator: 'lt' },
      { text: 'grid.filterBeforeOrEqualOperator', operator: 'lte' },
      { text: 'grid.filterIsNullOperator', operator: 'isnull' },
      { text: 'grid.filterIsNotNullOperator', operator: 'isnotnull' }
  ],
  'boolean': [
      { text: 'grid.filterEqOperator', operator: 'eq' }
  ]
}

const FormatIntCHF = {
  minimumFractionDigits : 2, 
  maximumFractionDigits : 2,
}

interface DataExpected {
  DataSet : any; 
  TableDef: any;  
  TableSizes?: any;
  Filter? : boolean; 
  Editable: boolean;
  callBack? : any; 
  Form? : any;
  Origin?: any; // Info about the parent component 
  Permissions? : any;
  Deleteable? : boolean;
  Addable?: boolean; 
  SpecialColumns? : any;
  Footers?: any;
  HiddenFieldsTable?:any, // set hidden fields on table
  SpecialFields?: any; // Array of columns that will have special components to render
  specialValues?: any;
  HiddenFieldsEdit?:any,// set hidden fields on edit on form
  CrossRef?:any
 
} 



// this component renders grid tables in case it gets required props
export default function DataTable (props:DataExpected) { 
  const Theme = useSelector( (state: any) => state.Theme); 
  const OriginalData = [...props.DataSet]; 
  const SpCol = props.SpecialColumns;
  const Footers = props.Footers;
  
 
  const TableDef = props.TableDef;
  const TableSizes = props.TableSizes;
  const TokenData = useSelector((state: any) => state.tokenData);
  const OpenTable = useSelector((state: any) => state.MasterData.Table);
  const locales = [
    {
      language: "en-US",
      locale: "en"
    },
    {
      language: "es-ES",
      locale: "es"
    }
  ];

  
  const initDataState: State = {
    skip: 0,
    take: 20,
    sort: [{ field: 'orderDate', dir: 'desc' }],
    
};

const NewItem = {
    id: 60000,
    name : '',
    delete: false,
    new: true,
}


const [dataState, setDataState] = useState<State>(initDataState);



const [data, setData] = useState(process(OriginalData, initDataState));
const currentLocale = locales[0];
const [OpenForm,setOpenForm] = useState(false);
const [EditItem,setEditItem] = useState(NewItem);
const IsDeleteable = props.Deleteable || false;



function enterEdit(item : any){
    item.delete = false; 
    setOpenForm(true);
    setEditItem(item);
}

function deleteConfirm(item : any){
   item.delete = true;       
   setOpenForm(true);
   setEditItem(item);
}

function UpdateEditItem(item : any){
    setOpenForm(true);
    setEditItem(item);
    
}

const handleDataStateChange = (event:any) => { 
  //event.nativeEvent.target.id = 'test';
 
    

    setDataState(event.dataState);   
    setData(process(OriginalData, event.dataState));
  }


 


function MyEditCommandCell(subProps: any){   
    return(
        <EditCommandCell {...subProps} enterEdit={enterEdit} deleteConfirm={deleteConfirm}/>
    )
    ;}

const EditCommandCell = (subProps: any) => {
    return (
        <td>
            <Actions>
            <ActionButton 
                id={"Table_Button_Edit_"+subProps.dataItem.name}
                
                onClick={() => subProps.enterEdit(subProps.dataItem)}
                >
                  {IconEdit('rowButton')}
            </ActionButton>   
            { IsDeleteable? 
            <ActionButton 
            id={"Table_Button_Delete_"+subProps.dataItem.name}
               
                onClick={() => subProps.deleteConfirm(subProps.dataItem)}
                >
                  {IconTrash('rowButton')}
            </ActionButton> : null
              
            } 
            </Actions>     
        </td>
    );

};

function isColumnActive(field: string, dataStateprop: State){
    
  if(typeof dataStateprop !== 'undefined'){return GridColumnMenuFilter.active(field, dataStateprop.filter)?"active":"";}
  
  
}

function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>){


if(OpenTable.Request === 'CostCenter'){
  values.businessUnit = props.CrossRef.find((el:any) => el.name === values.businessUnit)
} 

if(OpenTable.Request === 'ChargingModel'){
  values.type = props.CrossRef.find((el:any) => el.type === values.type)
}

if(OpenTable.Request === 'Customer'){
  values.function = props.CrossRef.find((el:any) => el.name === values.function)
}


  if(typeof values.planningItApps !== 'undefined' && typeof values.type === 'undefined'){
    values.type = 'Waterfall'
  }
  
  let RawPermissions = values.permissions;
  if(typeof props.Permissions !== 'undefined' && !EditItem.delete){
    
   
     // convert to role schema
     let newList = new Array;
     values.permissions.map((element:any) => {
     
      
       newList.push({
         id: props.Permissions[findWithAttr(props.Permissions, 'name', element)].id
       })

     })
     values.permissions = newList;
  }
    
    if(EditItem.new){
      if(typeof props.Permissions !== 'undefined'){     
        
        MDTService.postNewRole(values).then((result: any) => {   
              
          if(result === ''){ 
            props.callBack();
            setOpenForm(false);
          }
        }).catch((error: any) => { console.log(error); values.permissions = RawPermissions; });
      }
      else{
        MDTService.postInsertMasterDataItem(values,TokenData.tokenId,OpenTable.Request).then((result: any) => {         
          
          if(result.type === 'ok'){ 
            props.callBack();
            setOpenForm(false);
          } 
          
        }).catch((error: any) => { 
          console.log(error); 

        });
      }
      



      values.new = false;
    }else if(EditItem.delete){
     
      if(typeof props.Permissions !== 'undefined'){
        
        
        MDTService.postDeleteRole(EditItem.id).then((result: any) => {         
          props.callBack(); 
          setOpenForm(false);
        }).catch((error: any) => { console.log(error); });
        
      }
    }else{
      if(typeof props.Permissions !== 'undefined'){
        MDTService.postEditRole(values).then((result: any) => {         
          if(result.type === 'ok'){ 
            props.callBack();
            setOpenForm(false);
          }
        }).catch((error: any) => { console.log(error); values.permissions = RawPermissions;});
      }
      else{
        MDTService.postEditMasterDataItem(values,TokenData.tokenId,OpenTable.Request).then((result: any) => {           
          props.callBack();               
          setOpenForm(false);
        }).catch((error: any) => { console.log(error); });
      }

      
    }
    
    
    }
    
function handleCancelEdit(event: DialogCloseEvent){  
    
    setOpenForm(false);
} 
 

function ColumnMenuCheckBox(subProps:any){
  return (
      <div style={{font:'inherit'}}>
          <GridColumnMenuFilter  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
}

function RemoveFilter(item:any, field: string){
  //
  let FL = {...item}


  
  let filtered = FL.filter.filters.map((lvl1:any) => {
   
    return {
    ...lvl1, filters: [...lvl1.filters.filter((lvl2:any) => lvl2.field !== field)]
    } 
})

  FL.filter.filters = filtered

 

  FL.filter.filters = filtered.filter((el:any) => el.filters.length > 0)

  return FL
}

function ObjectFilter(rawsubProps: any) {
 
  let refer = props.SpecialFields[0][rawsubProps.column.field]
  let subProps = {...rawsubProps}

  if(false){ // typeof subProps.filter !== 'undefined'
    subProps.filter.filters = subProps.filter.filters.map((lvl1:any) => {return {
     
      ...lvl1, filters: lvl1.filters.map((lvl2:any) => { console.log(lvl2); return {...lvl2, operator:  lvl2.originalfilter || lvl2.operator}})}})
  } 

   return (
      <div>
          <GridColumnMenuFilter 
         
          {...subProps} 
          data={OriginalData}  
          expanded={true}
          
          onFilterChange={(e: any) => {
           
           
            let updatedOperators;
            if(e !== null){
              updatedOperators = e.filters.map((firstLevel:any) => {
                
                return {
                    filters: firstLevel.filters.map((secondLevel: any) => {
                      let typeop = secondLevel.operator;
                     
                      
                      if(secondLevel.field === subProps.column.field){
                        return {
                          field: secondLevel.field, 
                          originalfilter: typeop,
                          operator: function (tags:any, value:any) {  
                           
                            if(tags !== null){
                             
                             
                            if(value === null || value === '' || typeof value === 'undefined' || value === undefined){
                              return true
                            }
                            if(tags[refer.subname] !== null && typeof tags[refer.subname] !== 'undefined' && value !== null){
                              // types of filters
                              switch(typeop){
                                case 'contains':
                                  if(tags[refer.subname].toLowerCase().includes(value.toLowerCase())){return true} break;
                                case 'doesnotcontain'  :
                                  if(!tags[refer.subname].toLowerCase().includes(value.toLowerCase())){return true} break;
                                 case 'eq':  
                                 if(tags[refer.subname].toLowerCase() === value.toLowerCase()){return true} break;
                                 case 'neq':  
                                 if(tags[refer.subname].toLowerCase() !== value.toLowerCase()){return true} break;
                                 case 'startswith':  
                                 if(tags[refer.subname].toLowerCase().startsWith(value.toLowerCase(),0)){return true} break;
                                 case 'endswith':  
                                 if(tags[refer.subname].toLowerCase().endsWith(value.toLowerCase())){return true} break;
                                 case 'endswith':  
                                 if(tags[refer.subname].toLowerCase().endsWith(value.toLowerCase())){return true} break;
                                 case 'isnull':  
                                 if(tags[refer.subname] === null || tags[refer.subname] === '' || tags[refer.subname] === undefined ){return true} break;
                                 case 'isnotnull':  
                                 if(tags[refer.subname] !== null && tags[refer.subname] !== '' && tags[refer.subname] !== undefined ){return true} break;
                              }
                            }
                           
                                
                            }
                                                 
                            return false;
                        },
                          value: secondLevel.value                                  
                      }
                      }else{
                        return secondLevel
                      }
                     }),
                    logic: "or",
                    
                }
            })
            }else{
             
             updatedOperators = {filters : [{filters: [{filter: {}}]}]}
            }
           
            let customEvent;

            if(e !== null){
              customEvent = {
                dataState: { ...dataState,
                    filter: {
                        ...e,
                        filters: updatedOperators
                    }
               ,}
            }
            }else{
              customEvent = {dataState: RemoveFilter({...dataState}, refer.alters)}
              
            }

            

            handleDataStateChange(customEvent)
        }}
          
          />
      </div>
  );
}
function OptionsFilter(subprops: any) {
       

  
  let Field = subprops.column.field;
  const FilterContent = styled.div({
      paddingTop: '50px',
      '>div:first-of-type > div:first-of-type': {
          pointerEvents: 'none',
          position: 'absolute',
          top: '0px',
      },
      '*:checked, *:visited, *:active, *:selected, *:focus, *:active, *:activated': {
          borderColor: Theme.Corporate.blue,
      },
      'input:checked, input:visited, input:active': {
          backgroundColor: Theme.Corporate.blue,
          borderColor: Theme.Corporate.blue,
          outlineColor: Theme.Corporate.blue,
          boxShadow: 'none',
      },
      'button:not(:disabled)': {
          backgroundColor: Theme.Corporate.blue,
          borderColor: Theme.Corporate.blue,
      },
  });

  let Alldatatemp = new Array();

  OriginalData.forEach((element: any) => {
      if(Array.isArray(element[Field])){
          element[Field].forEach((sub:any) => {                   
             
              if (!Alldatatemp.includes(sub)) {
                  Alldatatemp.push(sub);
              } 
              });
      }
  
      
  });

  const Alldata = Alldatatemp.map((data: any) =>( { [Field]: data }));

  const [FilteredData, setFilteredData] = useState(Alldata);

  function Update(value: any) {
      let FilteredDatatemp = new Array();
      if (value === null) {
          value = '';
      }
      value = value.toLowerCase();

      Alldata.forEach((el: any) => {
          if (
              typeof el[Field] !== 'undefined' &&
              el[Field] !== null &&
              el[Field].toString()
                  .toLowerCase()
                  .includes(value)
          ) {
              let Exists = FilteredDatatemp.filter((el2: any) => el2[Field].toString().includes(el[Field]));
              if (Exists.length === 0) {
                  FilteredDatatemp.push(el);
              } else {
                  if (Exists[0].Name !== el.Name) {
                      FilteredDatatemp.push(el);
                  }
              }
          }
      });
      setFilteredData(FilteredDatatemp);
  }

  
  return (
      <div>
          <input
              placeholder="Search"
              onChange={(e: any) => {
                  Update(e.target.value);
              }}
              style={{
                  position: 'absolute',
                  top: '30px',
                  width: 'calc(100% - 20px)',
                  marginLeft: '10px',
                  paddingLeft: '5px',
              }}
          />
          <FilterContent>
              <GridColumnMenuCheckboxFilter
                  {...subprops}                       
                  data={FilteredData}
                  onFilterChange={(e: any) => {
                    
                    let updatedOperators;
                    if(e !== null){
                      updatedOperators = e.filters.map((firstLevel:any) => {
                        return {
                            filters: firstLevel.filters.map((secondLevel: any) => ({
                                field: secondLevel.field, 
                                operator: function (tags:any, value:any) {  
                                  for (var i = 0; i < tags.length; i++) {
                                      var tag = tags[i];                                       
                                      if (tag.toLowerCase() === value.toLowerCase())
                                          return true;
                                  }                            
                                  return false;
                              },
                                value: secondLevel.value                                  
                            })),
                            logic: "or"
                        }
                    })
                    }else{
                      updatedOperators = []
                    }  
                  

                      const customEvent = {
                          dataState: {
                              filter: {
                                  ...e,
                                  filters: updatedOperators
                              }
                         ,}
                      }

                      handleDataStateChange(customEvent)
                  }}
                  expanded={true}
                  searchBox={() => null}
                 
              />
          </FilterContent>
      </div>
  );
}
function ColumnMenuRender(subProps:any){
  if(typeof props.SpecialFields !== 'undefined' &&
    typeof props.SpecialFields[0][subProps.column.field] !== 'undefined' 
  && props.SpecialFields[0][subProps.column.field].tableShow === 'object'){  
   
    return (
      <div style={{font:'inherit'}}>
          <ObjectFilter  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
  }
 
  if(Array.isArray(props.DataSet[0][subProps.column.field])){
   
    return (
      <div style={{font:'inherit'}}>
          <OptionsFilter  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
  }

  
  return (
      <div style={{font:'inherit'}}>
          <GridColumnMenuFilter  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
}



function ColumnMenuBoolean(subProps:any){
  return (
      <div style={{font:'inherit'}}>
          <GridColumnMenuFilter filterUI={FilterBoolean}  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
}


function ColumnMenuCurrency(subProps:any){
  return (
      <div>
          <GridColumnMenuFilter  {...subProps} data={OriginalData}  expanded={true}/>
      </div>
  );
}

function TranslateSpecialColumn(Name:string){
 if(typeof SpCol !== 'undefined'){
  let Find = SpCol.filter((El:any)=> El.Name === Name);
  if(Find.length !== 1){return {Exist:false, Type: Find }}else{return{Exist:true, Type: Find[0].Type }}
  }else{    
    let Find = typeof props.SpecialFields !== 'undefined' ? props.SpecialFields[0][Name] : undefined   
    if(typeof Find !== undefined && Find !== undefined){      
      return {Exist:true,  Type: Find.type  }
    }else{      
      return{Exist:false}
    }
    
  }
  
}

function TranslateFooter(Name:string, subData:any, model:string){   
 
  if(typeof Footers !== 'undefined'){
   let Find = Footers.filter((El:any)=> El.Name === Name);   
   if(Find.length !== 1){return {Exist:false, Type: Find }}else{
    let CompToCall = () => {console.log('test')}; 
    
    switch(Find[0].Type){
      case 'Sum': 
      case 'why2':
      case 'why3':
      CompToCall = () => {return SumColumn(props,Name,subData,model)}; break;
    }
     return{Exist:true, Type: CompToCall }
    }
   }
   return {Exist:false}
 }
 
function RenderCell(cellProps:any){  

 
  let text = ""

  if(typeof cellProps.dataItem[cellProps.field] === 'object' &&  cellProps.dataItem[cellProps.field] !== null && !Array.isArray(cellProps.dataItem[cellProps.field])){
    
    text = cellProps.dataItem[cellProps.field][cellProps.field] || cellProps.dataItem[cellProps.field].name || cellProps.dataItem[cellProps.field];
  }else if(Array.isArray(cellProps.dataItem[cellProps.field])){
    
    text = cellProps.dataItem[cellProps.field].map((li:any, index:any) => {
      if(index !== 0){return ', '+li }
      else {return li }
    } )
  }
  else{
   
    text = cellProps.dataItem[cellProps.field];
  }

  return (<td>
    {text}
  </td>)
}

function BooleanCell(cellProps:any){    

  return (<td className="Boolean">
    <Checkbox disabled defaultChecked={cellProps.dataItem[cellProps.field]}/>
  </td>)
}

 function SumColumn(subProps:any, Name:any, subData:any, model?: any){
  
   let Icon = '';
   let Formating = FormatIntEuro;
   let NumFormat = 'es-Es';

   switch(model){
     case 'EUR' : Icon = " €"; break;
     case 'CHF' : Icon = " CHF"; Formating = FormatIntCHF; NumFormat = "sw-SW" ;break;
     default : Icon = " CHF"; break; 
   }

   let filteredProducts;
   if(typeof dataState.filter !== 'undefined'){
       filteredProducts = filterBy(OriginalData, dataState.filter)
   }else{filteredProducts = OriginalData}
  
  let total = filteredProducts.reduce((acc, current) => acc + current[Name], 0);

  return (
    <td colSpan={subProps.colSpan} style={subProps.style}>
      <TotalsStyled> {new Intl.NumberFormat(NumFormat, Formating).format(total)+Icon}</TotalsStyled>
    </td>
  );
}
  


  return (
    <Container id="DataTable" Theme={Theme}>     
    <LocalizationProvider language={currentLocale.language}>
     
        <div> 
              <Toolbar className="col-12" Theme={Theme}>                        
               {props.Addable !== true ?  null : <AddButton id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton> }                                                    
              </Toolbar>
                
            <Grid
             filterOperators={filterOperators}
              sortable             
              scrollable={'virtual'}
              pageSize={20}
              rowHeight={20}             
              data={data}              
              total={OriginalData.length}
              {...dataState}
              onDataStateChange={handleDataStateChange}
             
            >
              
              {
                TableDef.map((element:any, index:number)=>{  
                  let visible = true
                  if(typeof props.HiddenFieldsTable !== 'undefined' && props.HiddenFieldsTable.includes(element)){visible = false}

                 
                  if(visible){
                    if(TranslateSpecialColumn(element).Exist){
                      switch (TranslateSpecialColumn(element).Type){
                        case 'Percentage':
                          return(<Column headerClassName={isColumnActive(element, dataState)} className="Percentage" filter={'numeric'} format={FormatPercentage} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} columnMenu={ColumnMenuCurrency} />)                       
                        case 'CHF':
                          return(<Column footerCell={!TranslateFooter(element,data, 'CHF').Exist ? null : TranslateFooter(element,data, 'CHF').Type } headerClassName="CurrencyHead" className="Currency" filter={'numeric'} format={FormatCHF} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} columnMenu={ColumnMenuCurrency} />)                       
                        case 'EUR':
                          return(<Column footerCell={!TranslateFooter(element,data, 'EUR').Exist ? null : TranslateFooter(element,data, 'EUR').Type } headerClassName="CurrencyHead" className="Currency" filter={'numeric'} format={FormatEuro} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element} columnMenu={ColumnMenuCurrency} />)
                        case 'Unfiltered'  :
                          return(<Column headerClassName={isColumnActive(element, dataState)} sortable={false} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' } field={element}  />)
                        case 'boolean':
                          return (<Column cell={BooleanCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} headerClassName={isColumnActive(element, dataState)} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' }  field={element} columnMenu={ColumnMenuBoolean} />)  
                        default:
                          return(<Column cell={RenderCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} headerClassName={isColumnActive(element, dataState)} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' }  field={element} columnMenu={ColumnMenuRender} />)
                      }
                      
                    }
                    else{
                    
                      return(<Column cell={RenderCell} title={typeof props.Origin !== 'undefined' ? Dict("Tablenames-"+props.Origin+" "+element): Dict("Tablenames-"+element)} headerClassName={isColumnActive(element, dataState)} key={index} width={TableSizes[index] > 0 ? TableSizes[index] : 'auto' }  field={element} columnMenu={ColumnMenuRender} />)
                    }     
                 }
                })

              }
              {!props.Editable ? null : 
                 <Column cell={MyEditCommandCell} resizable={false} width={80}/>
              }
              
            </Grid>
            {OpenForm && typeof props.Form !== 'undefined' ? 
              <props.Form Permissions={props.Permissions} Fields={TableDef} cancelEdit={handleCancelEdit} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={EditItem}/>
            : null}
            {OpenForm && typeof props.Form === 'undefined' ? 
              <EditForm 
              HiddenFieldsEdit={props.HiddenFieldsEdit}
              specialValues={props.specialValues} 
              SpecialFields={props.SpecialFields}
              Fields={TableDef} cancelEdit={handleCancelEdit} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={EditItem} />
            : null}
           
           
         
              
           
        </div>
     
    </LocalizationProvider>
    </Container>
  );
    
}

const Toolbar = styled.div<any>({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',
        
        cursor: 'pointer',
       
    },
    padding: '0px',
    margin: '0px',
    marginBottom: '10px',
    backgroundColor: 'white'
    
     }, props =>({
      'svg':{
          color: props.Theme.Corporate.darkBlue,          
          fill: props.Theme.Corporate.darkBlue,   
       }
   }))

const Container = styled.div<any>({ 
  '.Boolean':{
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: '4px 24px',
    'span':{
      marign: '0px',
      padding: '0px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      opacity: 1
    }
  },
  '.Currency':{
    textAlign: 'right'
  },  
  '.Percentage':{
    textAlign: 'center',
    textIndent: '30%'
  },  
  '.CurrencyHead':{
    textIndent: '28%'
  },  
  width: '100%',
  justifyContenet: 'center',
  alignItems: 'center',
  display: 'flex',
  '.k-filtercell > span, .k-filtercell .k-filtercell-wrapper':{
    paddingLeft: '7px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  '.k-filtercell .k-filtercell-operator':{
    display: 'flex'
  },
  '.k-filtercell .k-filtercell-wrapper > .k-textbox':{
    backgroundColor: 'white',
    border: 'none',
    height: '25px',
    paddingLeft: '5px',
    color: 'grey',
    fontSize: '100%'
  },
  'tbody a':{
    textDecoration: 'underline',
    color: '#003399'
  },
  '.k-grid-content':{
    overflow: 'auto'
  },
  'div.k-grid-header':{
    padding: '0px !important'
  },
  '.k-grid tr':{
    textIndent: '10px',
  },
  '.k-grid':{
    border: 'none'
  },
  '.k-grid-header .k-header > .k-link':{
    backgroundColor: 'white',
  },
  'th.k-header.active > div > div':{
    width: '20px',
    textIndent: '1.5px',
      'span' : {
        color: 'white'
      }  
  },
  
  'a':{
    color: 'black',
  },
  'thead' :{   
    backgroundColor: 'white'
  },
  'thead th' :{   
    color: 'black',
    fontWeight: 'bold',
    textIndent: '8px',
    border: 'none',
    backgroundColor: '#e7eceb'
    
  },
  'tbody' :{   
   'tr:nth-of-type(even)':{
     backgroundColor: 'white',
   },   
  'td, th':{
    border: '0px solid white',
    textIndent: '7px'
  },  
  'th:first-of-type':{
      //textIndent: '7px'
    }
  },
  '.MuiTableSortLabel-root.MuiTableSortLabel-active':{
    //color : 'white'
  },
  '.k-master-row .k-button':{
      backgroundColor: 'transparent'
  }
  
}, props =>({
  'tr:nth-of-type(odd)':{
    backgroundColor: props.Theme.Corporate.paleBlue, 
  },
  'th.k-header.active > div > div':{
    backgroundColor: props.Theme.Corporate.darkBlue
  }
}))
const TotalsStyled = styled.span({
  position: 'absolute',
  right: '5px',
  bottom: '4px'
})
const Actions = styled.div({
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '50px',
    alignItems: 'center',
    '.k-button':{
      padding: '5px !important'
    },
    'svg' : {
        
    },
    padding: '0px',
    margin: '-5px 0px'

    })  