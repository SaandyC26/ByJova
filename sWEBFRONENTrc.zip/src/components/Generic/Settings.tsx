import React from 'react';
import styled from "@emotion/styled";
import {useSelector} from 'react-redux';
import {Link } from 'react-router-dom';
import SettingsIcon from '@material-ui/icons/Settings';
import TooltipedItem from './TooltipedItem'
import {MenuList} from './Styles' 
import {IconGear} from '../Generic/Icons'

interface Themeprops {
    Theme: any
}

// this component handles login/out operations
export default function Settings(){
   const Theme = useSelector( (state: any) => state.Theme);   
   
   return(     
    <Content Theme={Theme} id="Settings">  
        <Contenedor> 
            <TooltipedItem Trigger={() => {return IconGear('LogMenu', true)}} Interactive={true} Title="Settings" Position="bottom">
                    
                        <MenuList><ol>
                                <li><Link id="Settings_Toolbar_Button_Users" to='../../administration/users/'><span></span>User Admininstration</Link></li>
                                <li><Link id="Settings_Toolbar_Button_UserGroups" to='../../administration/user-groups/'><span></span>User Groups Administration</Link></li>
                                <li><Link id="Settings_Toolbar_Button_Month" to='../../administration/month/'><span></span>Month Administration</Link></li>
                                <li><Link id="Settings_Toolbar_Button_Datatables" to='../../administration/datatables/'><span></span>Master Datatables</Link></li>
                                <li><Link id="Settings_Toolbar_Button_Currency" to='../../administration/currency/'><span></span>Currency Conversion</Link></li>
                                <li><Link id="Settings_Toolbar_Button_RoleAdmin" to='../../administration/roles/'><span></span>Role Admininstration</Link></li>
                            </ol>
                        </MenuList>
                    
            </TooltipedItem>           
        </Contenedor>           
    </Content>         
    )
}

const Contenedor = styled.div({
   
    
   
    zIndex: 502
    
    })
const Content = styled.div<Themeprops>({
    '.logToolTip + div > div' :{       
        
        fontFamily: '"Frutiger 45 Light"'
    },
    '.logToolTip + div .MuiTooltip-arrow':{
        left: '10px',
        
        transform: ' scale(1.5) translateY(-1px)'
    }

},props=>({    
    '.logToolTip + div > div' :{
        backgroundColor: props.Theme.Corporate.blue,
        
    }
}))




