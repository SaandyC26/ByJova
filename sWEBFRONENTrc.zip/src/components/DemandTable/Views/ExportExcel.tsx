import React, { useState } from 'react';
import { State as DataState } from '@progress/kendo-data-query';
import { CircularProgress } from '@material-ui/core';
import ExcelService from '../../../services/ExcelService'

interface Props {
    token: string;
    dataState: DataState;
    downloadExcel?: Function;
    buttonText: string;
}

const ExportExcel: React.FC<Props> = ({ token, dataState, downloadExcel, buttonText }: Props): JSX.Element => {
    const [exporting, setExporting] = useState(false);


    let NewState:any = {...dataState}
    if(typeof NewState.filter !== 'undefined'){
        NewState.filter = {...NewState.filter}
        if(NewState.filter.filters.length > 0){



        NewState.filter.filters =   NewState.filter.filters.map((maps:any) => {
//
            let map1 = {...maps}
            if(typeof map1.filters !== 'undefined') {
                map1.filters = map1.filters.map((mapz:any) => {
                    let map2 = {...mapz}
                    if(map2.field === 'year'  && map2.operator !== 'neq'){
                        return {
                            ...map2 , value :  typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime() ? map2.value.getFullYear() : new Date(map2.value).getFullYear()
                        }
                    }
                    if(typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime()  ){
                    return {
                        ...map2 , value :  map2.value.getFullYear() + '-' + (map2.value.getMonth()+1) + '-'  + map2.value.getDate()
                    }}
                    else{
                        return map2
                    }
                })

                return map1
            }
            else{
                return map1
            }
        })
        
        
    }}

    const exportExcel = (): void => {
        setExporting(true);
        ExcelService.getExportedExcelFile(JSON.stringify({TemplateName: "Revenues_Default",DataSourceRequest: {Filter : NewState.filter, Sort : NewState.sort}}), token).then((result: [Blob, string] | (string | Blob)[]) => {
            console.log(result)
            if(typeof result !== 'undefined'){
                const url = window.URL.createObjectURL(new Blob([result[0]]));
                const a = document.createElement('a');
                a.href = url;
                a.download = result[1] as string;
                a.click();
            }            
            setExporting(false);
        });
    };

    return (
        <div className="d-flex align-items-center float-right" onClick={exportExcel} id="Table_Button_ExportExcel">            
                {buttonText}           
            {exporting && <CircularProgress />}
        </div>
    );
};
export default ExportExcel;
