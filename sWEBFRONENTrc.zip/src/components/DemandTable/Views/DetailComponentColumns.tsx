import React, {useState} from 'react';
import BusinessCenterIcon from '@material-ui/icons/BusinessCenter';
import QuarterInfoBox from './QuarterInfoBox';
import {teal} from '@material-ui/core/colors'
import {useSelector} from 'react-redux';
import styled from "@emotion/styled";
import { formatNumber, formatDate } from '@telerik/kendo-intl';
import AddComment from '../../Generic/AddComment';
import ViewComments from '../../Generic/ViewComments';
import {parseJwt,getCookie,CurrencyFormat} from '../../Functions/Utils';


export default function DetailComponentColumns(props:any){   
    const User = useSelector((state: any) => state.userData);    
    const Columns = useSelector((state: any) => state.userData).DemandSettings.Columns;
    const [Comments, setComments] = useState([...props.dataItem.comments].reverse())
    const [reversed, setReversed] = useState([...props.dataItem.comments]);   
    
    const dataItem = props.dataItem;
    let Info = new Array;
      
    const MaxItems = 3;
    let ItemCount = 0;

function Translate(oddword:string){
    let friendly = '';   
    switch(oddword){
        case 'lineOfBusinessName': friendly = 'LOB'; break;
        case 'customerName': friendly = 'Customer'; break;
        case 'projectName': friendly = 'Project'; break;
        case 'productName': friendly = 'Product'; break;
        case 'typeOfServiceName': friendly = 'TOS'; break;
        case 'serviceDescription': friendly = 'Service Description'; break;
        case 'ownerProjectManagerName': friendly = 'Owner'; break;
        case 'businessUnitCode': friendly = 'BU Code'; break;
        case 'customerCostCenterCode': friendly = 'Customer CC'; break;
        case 'chargingModelCode': friendly = 'CModel'; break;
        case 'internalCostCenterPerCostCode': friendly = 'Internal CC'; break;
        case 'internalCode': friendly = 'ICode'; break;
        case 'currencyCode': friendly = 'Currency'; break;
        case 'fyfclc': friendly = 'FYFCLC'; break;
        case 'fyfcchf': friendly = 'FYFCCHF'; break;
        case 'fyfcchfvat': friendly = 'FYFCCHFVAT'; break;
        case 'january.amount': friendly = 'January'; break;
        case 'february.amount': friendly = 'February'; break;
        case 'march.amount': friendly = 'March'; break;
        case 'april.amount': friendly = 'April'; break;
        case 'may.amount': friendly = 'May'; break;
        case 'june.amount': friendly = 'June'; break;
        case 'july.amount': friendly = 'July'; break;
        case 'august.amount': friendly = 'August'; break;
        case 'september.amount': friendly = 'September'; break;
        case 'october.amount': friendly = 'October'; break;
        case 'november.amount': friendly = 'November'; break;
        case 'december.amount': friendly = 'December'; break;        
        
       
    }

    return friendly;
}

function CommentCheck(item:any, action:Function){
    if(item.commentable){
        return(
            <CommentHolder style={{zIndex: 500}}><AddComment Callback={action} Revenue={item.id}/></CommentHolder>
        )
    }
    return null
   
}

function UpdateRevenue(item:any){
    
    console.log(User);

    let OldList = [...Comments];
    let OldReversed = [...reversed];
    OldList.unshift({userName: parseJwt(getCookie('ZurichCustomerPortal')).nameid, dateTime: formatDate(new Date(), "d") , text: item.Comments[0]})
    OldReversed.push({userName: parseJwt(getCookie('ZurichCustomerPortal')).nameid, dateTime: formatDate(new Date(), "d") , text: item.Comments[0]})
    setComments(OldList);
    setReversed(OldReversed);
    
}   

    Columns.map((El:any)=>{
        switch(El.field){
            case 'lineOfBusinessName': 
            case 'customerName': 
            case 'projectName': 
            case 'typeOfServiceName': 
            case 'serviceDescription':
            case 'ownerProjectManagerName': 
            case 'businessUnitCode': 
            case 'customerCostCenterCode': 
            case 'chargingModelCode': 
            case 'internalCostCenterPerCostCode': 
            case 'internalCode': 
            case 'currencyCode':
            case 'productName':
            case 'fyfclc': 
            case 'fyfcchf': 
            case 'fyfcchfvat':  Info.push(El); break;
            
        }
    })

   
    const VisibleInfo = Info.map((El:any)=>{
        if(!El.Show && El.field !== 'none'){
          let Format = CurrencyFormat(dataItem.currencyCode);

             
            if(El.field.includes('.')){                
                let raw = El.field.split('.');
                return(<li><b>{Translate(El.field)} : </b>{ formatNumber(dataItem[raw[0]][raw[1]], Format)} aa</li>)
            }
            if(El.field === 'fyfclc' || El.field ===  'fyfcchf' || El.field ===  'fyfcchfvat'){ 
                return(<li><b>{Translate(El.field)} : </b>{ formatNumber(dataItem[El.field], Format)} </li>)
            }
            
            return(
                <li><b>{Translate(El.field)} : </b>{dataItem[El.field]}</li>
            )}}
        )

        
        return (
            <section className="col-xs-2 col-sm-3 col-md-4 col-lg-7 col-xl-9" id="DetailComponentColumns">
                
                {Info.filter((el:any) => el.Show === false).length > 0 ? <HiddenProps>{VisibleInfo}</HiddenProps> : null}                              
                <Quarters>
                    
                        <QuarterInfoBox 
                            icon={BusinessCenterIcon}
                            color={teal[600]}
                            title="Q1"
                            values={{
                                January: dataItem.january,
                                February: dataItem.february,
                                March: dataItem.march,
                            }}
                            unit={dataItem.currencyCode}
                            loading={false}
                        />
                    
                    
                        <QuarterInfoBox 
                            icon={BusinessCenterIcon}
                            color={teal[600]}
                            title="Q2"
                            values={{
                                April: dataItem.april,
                                May: dataItem.may,
                                June: dataItem.june,
                            }}
                            unit={dataItem.currencyCode}
                            loading={false}
                        />
                    
                    
                        <QuarterInfoBox 
                            icon={BusinessCenterIcon}
                            color={teal[600]}
                            title="Q3"
                            values={{
                                July: dataItem.july,
                                August: dataItem.august,
                                September: dataItem.september,
                            }}
                            unit={dataItem.currencyCode}
                            loading={false}
                        />
                    
                        <QuarterInfoBox 
                            icon={BusinessCenterIcon}
                            color={teal[600]}
                            title="Q4"
                            values={{
                                October: dataItem.october,
                                November: dataItem.november,
                                December: dataItem.december,
                            }}
                            unit={dataItem.currencyCode}
                            loading={false}
                        />
                    
                </Quarters>
                {dataItem.comments.length > 0 ? 
                <Notes>
                    {CommentCheck(dataItem,UpdateRevenue)}
                    <CommentHolder2><ViewComments Comments={reversed}/></CommentHolder2>
                    <li><p>User</p><p>Time</p><p>Comment</p></li>                   
                    {Comments.map((el:any)=>{
                        if(!el.autoGenerated && ItemCount < MaxItems){
                            ItemCount++
                            return (
                                <li><p>{el.userName}</p><p>{formatDate(new Date(el.dateTime), "d")}</p><p>{el.text}</p></li>
                            )
                        }
                        
                    })}
                </Notes> : null }
            </section>
        );
    
}

const CommentHolder = styled.div({
    position: 'absolute',
    right: '10px',
    top: '10px',
    'button':{padding: '5px 10px'}
})
const CommentHolder2 = styled.div({
    position: 'absolute',
    right: '140px',
    top: '10px',
    'button':{padding: '5px 10px'}
})
const Notes = styled.ol({
    position: 'relative',
    padding: '10px 0px',
    flexWrap: 'wrap',
    display: 'flex',
    listStyle: 'none',
    margin: '10px 0px 10px 0px',
    justifyContent: 'space-between',
    maxWidth: '950px',
    flexDirection: 'column',
    width: '100%',
    WebkitFlexWrap: 'wrap',
    boxShadow: '0px 1px 5px -1px rgb(0 0 0 / 50%)',
    'li':{
        borderRadius: '3px',
        padding: '5px 10px',
        minWidth: '45%',
        fontSize: '110%',
        display: 'flex',
        justifyContent: 'space-between',
        ':first-of-type':{
            fontWeight: 'bold',
        },
        'p':{
            padding: '0px',
            margin: '0px',
            width: '10%',
            lineHeight: 1,
            display: 'flex',
            alignItems: 'center',
            ':first-of-type':{
                width: '25%'
            },
            ':last-of-type':{
                width: '60%'
            }
        }

    }
})
const Quarters = styled.ol({
    padding: '0px',
    flexWrap: 'wrap',
    display: 'flex',
    listStyle: 'none',
    margin: '10px 0px',
    justifyContent: 'space-between',
    maxWidth: '950px',
    width: '150%',
    WebkitFlexWrap: 'wrap',
    marginBottom: '10px',
})
const HiddenProps = styled.ol({
    padding: '10px 0px',
    flexWrap: 'wrap',
    display: 'flex',
    listStyle: 'none',
    margin: '10px 0px 0px 0px',
    justifyContent: 'space-between',
    maxWidth: '950px',
    width: '150%',
    WebkitFlexWrap: 'wrap',
    boxShadow: '0px 1px 5px -1px rgb(0 0 0 / 50%)',
    'li':{
        borderRadius: '3px',
        padding: '5px 10px',
        minWidth: '45%',
        fontSize: '110%',

    }
})