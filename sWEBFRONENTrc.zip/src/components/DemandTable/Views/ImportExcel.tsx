import React, { useState, useRef } from 'react';
import { State as DataState } from '@progress/kendo-data-query';
import { CircularProgress } from '@material-ui/core';   
import styled from "@emotion/styled";
import ExcelService from '../../../services/ExcelService';
import Tooltip, { TooltipProps } from '@material-ui/core/Tooltip';
import {Theme, makeStyles } from '@material-ui/core/styles';
import Dialog from '../../Generic/Dialog'
import {setError } from '../../../store/slices/user';
import {useSelector, useDispatch} from 'react-redux';
import {ParseToError} from '../../Functions/Utils'
import {ToolbarButton} from '../../Generic/Styles'
interface Props {
    token: string;
    dataState: DataState;
    downloadExcel?: Function;
    buttonText: string;
    Callback?: any;
}
const useStylesBootstrap = makeStyles((theme: Theme) => ({
    arrow: {
      color: '#FFA500',
    },
    tooltip: {
      backgroundColor: '#FFA500',
      fontSize: '15px'
    },
  }));

  function BootstrapTooltip(props: TooltipProps) {
    const classes = useStylesBootstrap();
  
    return <Tooltip arrow classes={classes} {...props} />;
  } 

const ImportExcel: React.FC<Props> = ({ token, dataState, downloadExcel, buttonText, Callback }: Props): JSX.Element => {
    let dispatch = useDispatch();   
    const MainTheme =  useSelector((state: any) => state.Theme) ;
    const [importing, setImporting] = useState(false);
    const TokenData = useSelector( (state: any) => state.tokenData);
    const MainTargetInput = useRef(null);
    const [ImportError, setImportError] = useState('no file chosen');
    const [HardError, setHardError] = useState(false);
    const [open, setOpen] = React.useState(false);
    let timer = setTimeout(() => setOpen(false), 4000);
    const [subtitle, setSubtitle] = React.useState("");
   

    function ShowErrors(message:any, hard?: any){        
        
       
        if(typeof hard === 'undefined'){
            setOpen(true);
            setImportError(message);
            setHardError(false);
            clearTimeout(timer);
            timer = setTimeout(() => {setOpen(false);}, 4000);
        }else{
            setHardError(true);
            setImportError(hard);
        }
        
    }
    function TransferClick(To:any){
        To.current.click();
    }
    function ImportExcelAction(event:any, TargetInput:any) {
        setImporting(true);       

          ExcelService.postFileAsync(event.target.files[0],event.target.files[0].name,TokenData.tokenId).then((result: any) => {                    
            console.log('result');  
            console.log(result);
            let Stringresult = result.toString();
            setImporting(false);            
            
            if(typeof result.ServerError !== 'undefined'){               
                
                dispatch(setError({Show:true, Msg: ParseToError(result.Desc).map((element:any) => {                   
                    return <p key={element}>{element}</p>
                }), Mode:'Close'}));
            }

            else if(!Stringresult.includes('Invalid')){               
                ShowErrors('File Imported')
                Callback();
            }
            else{
                
                setSubtitle("Fix those errors and try to upload again.")
                ShowErrors('Invalid file',result)
            }
            TargetInput.current.value = null;
            
         }).catch((error: Error) => {           
            console.log('salta el catch de importexcel')
            setImporting(false);
            console.log(error)
            TargetInput.current.value = null;
            ShowErrors('File imported')
            
            
         });
         
        //console.log(event.target.files[0].name)
       
           }

    return (
        <Content className="d-flex align-items-center float-right" id="ImportExcel">
            {!HardError ? null : 
                <Dialog appendTo={null} Title={"Error"} Subtitle={subtitle} Body={ImportError} CloseCallback={() => {setHardError(false)}}/>
                
            }
            <BootstrapTooltip open={open} title={ImportError} placement="bottom">
                <ToolbarButton id="Table_Button_ImportExcel" onClick={()=>{TransferClick(MainTargetInput)}} style={{backgroundColor: MainTheme.Corporate.darkBlue}} className="k-button k-primary mr-2 rounded" >
                {buttonText}
            </ToolbarButton></BootstrapTooltip>           
            <Hidden ref={MainTargetInput} type="file" onChange={(event) => {ImportExcelAction(event,MainTargetInput)}}/>
            {importing && <CircularProgress />}
        </Content>
    );
};
export default ImportExcel;

const Hidden = styled.input({
    width: '100%',
    height: '100%',
    position: 'absolute',
    zIndex: 1,
    cursor: 'pointer',
    opacity: 0,
    color: 'transparent',
    pointerEvents: 'none'
     })

const Content = styled.div({
   position: 'relative',
   'button':{
       zIndex: 10,
       pointerEvents: 'all'
   }
    })


        
    