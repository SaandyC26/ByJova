import React, { useEffect, useState } from "react";
import { Dialog } from "@progress/kendo-react-dialogs";
import { Form, Field, FormElement, FieldRenderProps, FormRenderProps } from "@progress/kendo-react-form";
import { Input, NumericTextBox, NumericTextBoxChangeEvent } from "@progress/kendo-react-inputs";
import { DropDownList, ComboBox } from "@progress/kendo-react-dropdowns";
import { Error } from "@progress/kendo-react-labels";
import { useSelector } from 'react-redux';
import Paper from '@material-ui/core/Paper';
import FilteredField from '../../Generic/FilteredField'
import styled from "@emotion/styled";
import { DatePicker, Calendar } from '@progress/kendo-react-dateinputs';
import YearDataService from '../../../services/YearDataService';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import EuroSymbolIcon from '@material-ui/icons/EuroSymbol';
import PersonIcon from '@material-ui/icons/Person';
import { getter } from '@progress/kendo-react-common';
import { Pound, Chufo, MatchIcon, IconInfo } from '../../Generic/Icons'
import AddComment from '../../Generic/AddComment';
import TooltipedItem from '../../Generic/TooltipedItem'
import { findWithAttr, GetRevenuesButtonText } from '../../Functions/Utils';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import FinpoCalendar from '../../Generic/FinpoCalenda'
import Loading from '../../Generic/Loading'
import { FormPrimaryButton, FormSecondaryButton } from '../../Generic/Styles'
const BaseMonths = {
    january: { locked: false },
    february: { locked: false },
    march: { locked: false },
    april: { locked: false },
    may: { locked: false },
    june: { locked: false },
    july: { locked: false },
    august: { locked: false },
    september: { locked: false },
    october: { locked: false },
    november: { locked: false },
    december: { locked: false },

}

const formatCurrency = {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
}



function alphabet(a: any, b: any) {
    if (a.toLowerCase() < b.toLowerCase()) {
        return -1;
    }
    if (a.toLowerCase() > b.toLowerCase()) {
        return 1;
    }
    return 0;
}


const Mandatory = (value: any) =>
    value !== null && typeof value !== 'undefined' && value !== '' ? "" : "Mandatory field";

const NonNegativeNumericInput = (fieldRenderProps: FieldRenderProps) => {
    const { validationMessage, visited, modified, touched, ...others } = fieldRenderProps;
    return (
        <div>
            <NumericTextBox {...others} />
            {visited && validationMessage && <Error>{validationMessage}</Error>}
        </div>
    );
};


function EditRevenueForm(props: any) {
    let Delete = false;

    if (typeof props.item.delete !== 'undefined' && props.item.delete !== false) { Delete = true }

    const Originals = { ...props.dropBoxValues };
    const Theme = useSelector((state: any) => state.Theme);
    const Restrictions = useSelector((state: any) => state.userData).DemandRestrictions;
    const Permissions = useSelector((state: any) => state.userData).permissions;

    const [currencyIcon, setCurrencyIcon] = useState(<EuroSymbolIcon />);
    const [changed, setChanged] = useState(false);
    const [showCalendar, setshowCalendar] = useState(false);
    const [fyfclc, setFyfclc] = useState(props.item.fyfclc);
    const [differenceLC, setDifferenceLC] = useState(props.item.differenceLC)
    const [fyfcchf, setFyfcchf] = useState(props.item.fyfcchf);
    const [fyfcchfvat, setFyfcchfvat] = useState(props.item.fyfcchfvat);
    const [Months, setMonths] = useState<any>(BaseMonths);
    const [startShow, setStartShow] = useState(false);
    const [endShow, setEndShow] = useState(false);
    const [projectInfo, setProjectInfo] = useState({ 'Project Type': props.item.projectType || '', 'APP-ID': props.item.projectPlanningItAppsIds || '', 'APP-Name': props.item.projectPlanningItAppsNames || '' })
    const [CustomerInfo, setCustomerInfo] = useState({ 'Customer Function': props.item.customerFunctionName || '' })
    const [IsLoading, setIsLoading] = useState(false)


    function HasBlockeds(item: any) {
        let blocked = false;
        for (const [key, value] of Object.entries<any>(Months)) {
            if (value.locked === true) {
                if (item[key].amount !== null && item[key].amount > 0) { blocked = true; }
            }
        }
        return blocked;
    }

    function UpdatePickerData(valuer: any, param: any, renderer: any) {
        renderer.onChange(param, { value: valuer });
    }

    function Filtered({ origin, formData }: { origin: string, formData: any }) {
        let Selected = formData.valueGetter(origin);

        let list = [...Originals[origin]];

        let ValidValues = new Array();

        if (findWithAttr(Restrictions, 'field', origin) !== -1) {
            let Item = Restrictions[findWithAttr(Restrictions, 'field', origin)];

            Item.filters.forEach((element: any) => {
                if (findWithAttr(element.values, 'name', formData.valueGetter(element.field)) !== -1) {
                    let subItem = element.values[findWithAttr(element.values, 'name', formData.valueGetter(element.field))];
                    subItem.options.forEach((option: any) => {
                        ValidValues.push(option);
                    });

                }
            });
        }

        const finalList = new Array();
        const invalidValues = new Array();

        if (!ValidValues.length && findWithAttr(Restrictions, 'field', origin) !== -1) {
            let Item = Restrictions[findWithAttr(Restrictions, 'field', origin)];
            Item.filters.forEach((filter: any) => filter.values.forEach((fv: any) => {
                if (!formData.valueGetter(filter.field)) { return }
                fv.options.forEach((fop: any) => {
                    if (invalidValues.indexOf(fop) === -1) {
                        invalidValues.push(fop)
                    }
                })
            }
            ))
        }

        list.forEach((el: any) => {
            if (ValidValues.length > 0) {
                if (ValidValues.includes(el)) {
                    finalList.push(el)
                }
            } else if (invalidValues.indexOf(el) === -1) {
                finalList.push(el)
            }

        });

        if (ValidValues.length > 0) {
            if (Selected !== null && !ValidValues.includes(Selected)) {
                formData.onChange(origin, {
                    value: ValidValues[0]
                });
            }
        }

        if (origin === "internalCostCenterPerCostCode") { console.log("FinalList", finalList)}

        return finalList
    }

    useEffect(() => {
        YearDataService.getYearData([{ "field": "year", "dir": "desc" }]).then((result: any) => {
            setMonths(result.data.find(((element: any) => element.year === props.item.year)))
        })

        HandleCurrencyChange(props.item.currencyCode)
    }, [props])


    const handleChange = (frp: FormRenderProps) => {
        const months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
        var total = 0.0;
        months.forEach((s: string) => {
            var value: number = parseFloat(frp.valueGetter(s.concat(".amount")));
            if (!isNaN(value)) {
                total = total + value;
            }
        });
        setFyfclc(total);
        setFyfcchf(0);
        setFyfcchfvat(0);
        setChanged(true);
        Update_differenceLC('refresh', total, frp)
    }

    function Update_differenceLC(field: string, value: any, form: any) {

        switch (field) {
            case 'planLC':
                setDifferenceLC((parseFloat(value || 0) + parseFloat(form.valueGetter('transferLC') || 0)) - parseFloat(fyfclc || 0))
                break;
            case 'transferLC':
                setDifferenceLC((parseFloat(value || 0) + parseFloat(form.valueGetter('planLC') || 0)) - parseFloat(fyfclc || 0))
                break;
            case 'refresh':
                setDifferenceLC((parseFloat(form.valueGetter('transferLC') || 0) + parseFloat(form.valueGetter('planLC') || 0)) - parseFloat(value))
                break;
        }
    }

    function isNegative(value: any) {
        if (parseFloat(value) < 0) { return true } else { return false }
    }

    function CheckDisabled(item: any, wichmonth: string) {
        let status = false;
        if (typeof Months !== 'undefined') {
            if (item.new) {
                if (Months[wichmonth].locked) { status = true }
            } else if (item[wichmonth].locked) { status = true }

        } else {
            status = true
        }

        return status
    }

    function UpdateProjectInfo(value: any) {
        let found = props.dropBoxValues.projectsRef[findWithAttr(props.dropBoxValues.projectsRef, 'name', value)]
        if (typeof found !== 'undefined' && found !== -1) {
            setProjectInfo(
                {
                    'Project Type': found.type,
                    'APP-ID': found.planningItAppsIds,
                    'APP-Name': found.planningItAppsNames
                })
        }
    }

    function UpdateCustomerInfo(value: any) {
        let found = props.dropBoxValues.customerRef[findWithAttr(props.dropBoxValues.customerRef, 'name', value)]

        if (typeof found !== 'undefined' && found !== -1) {
            setCustomerInfo(
                {
                    'Customer Function': found.function?.name || ''

                })
        }
    }

    function HandleCurrencyChange(value: any) {
        switch (value) {
            case 'EUR': setCurrencyIcon(<EuroSymbolIcon />); break;
            case 'USD': setCurrencyIcon(<AttachMoneyIcon />); break;
            case 'CHF': setCurrencyIcon(<Chufo />); break;
            case 'GBP': setCurrencyIcon(<Pound />); break;
        }
    }

    function DeleteItem() {
        props.DeleteItem(props.item);
    }

    function UpdateYear(entryyear: any) {
        let old = props.item;
        old.year = entryyear;
        props.UpdateEditItem(old)
    }

    function CheckBoundaries(target: any) {
        let valid = false;
        target.path?.forEach((el: any) => {

            if (typeof el.className !== 'undefined' && el.className !== undefined && typeof el.className === 'string' && el.className.includes('k-window')) {
                valid = true;
            }
        });

        return valid
    }

    function YearCalendar() {
        return (
            <Calendar navigation={false} defaultActiveView="decade" bottomView="decade" topView="decade" onChange={(event) => {
                UpdateYear(event.target.value?.getFullYear());
                setshowCalendar(false);
            }} />
        )
    }

    const DisplayTitle = props.item.new ?
        `Year ${props.item.year}` :
        `Edit ID: ${props.item.id} -- Year ${props.item.year}`

    const GetterBusinesUnit = getter('businessUnitCode');
    const GettercustomerCostCenter = getter('customerCostCenterCode');

    const Radio = (values: any) => {
        if (GetterBusinesUnit(values) || GettercustomerCostCenter(values)) {
            return {
                VALIDATION_SUMMARY: '',
                ['businessUnitCode']: '',
                ['customerCostCenterCode']: ''
            };
        }

        return {
            VALIDATION_SUMMARY: 'Please fill at least one of the following fields.',
            ['businessUnitCode']: 'At least one of those is mandatory.',
            ['customerCostCenterCode']: 'At least one of those is mandatory.'
        };
    };

    function CheckAddComment(item: any) {
        if (!item.new) {
            return (<AddComment Revenue={item.id} />)
        }
        return null

    }

    let changedstyle = "";
    if (changed) { changedstyle = " text-danger" }

    function PreSend(subProps: any) {
        setIsLoading(true)
        props.onSubmit(subProps);
    }

    return (
        <Content id="EditRevenueForm" Theme={Theme}>
            <Dialog appendTo={null} title={DisplayTitle} onClose={props.cancelEdit}>

                <Form
                    validator={Radio}
                    onSubmit={PreSend}
                    initialValues={props.item}
                    render={formRenderProps => (
                        <FormElement className={Delete ? 'Delete' : ''}>
                            <fieldset className={"k-form-fieldset"}>
                                {props.item.new ?
                                    <YearField onClick={() => { setshowCalendar(!showCalendar) }}>
                                        <DatePicker className="Calender" defaultValue={new Date()} calendar={YearCalendar} show={showCalendar} />
                                    </YearField> :
                                    null}
                                <OwnerField>
                                    <Field
                                        id={"Field_groupOwnerName"}
                                        name={"groupOwnerName"}
                                        component={FilteredField}
                                        disabled={Delete}
                                        data={Filtered({ origin: 'groupOwnerName', formData: formRenderProps })?.sort()}
                                        label={"User Group Owner *"}
                                    />
                                    <Field
                                        id={"Field_ownerProjectManagerName"}
                                        name={"ownerProjectManagerName"}
                                        component={FilteredField}
                                        disabled={Delete}
                                        data={Filtered({ origin: 'ownerProjectManagerName', formData: formRenderProps })?.sort()}
                                        label={"Owner / Project Manager *"}
                                        validator={Mandatory}
                                    />
                                </OwnerField>
                                {Delete ? null : <Legend>(* Mandatory field. ** At least one is Mandatory)</Legend>}
                                <Paper elevation={3} style={{ padding: '10px', marginBottom: '15px' }}>
                                    <div className="row">
                                        <div className="col-4">
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_lineOfBusinessName"}
                                                    name={"lineOfBusinessName"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'lineOfBusinessName', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Line Of Business *"}
                                                    validator={Mandatory}
                                                />
                                            </div>
                                            <div className="mb-2 Fold ExtraIcon">
                                                <Field
                                                    id={"Field_customerName"}
                                                    name={"customerName"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'customerName', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Customer Name *"}
                                                    validator={Mandatory}
                                                    onChange={(e: any) => {
                                                        formRenderProps.onChange("customerName", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                        UpdateCustomerInfo(e.value);
                                                    }}

                                                />
                                                <TooltipedItem Trigger={IconInfo} Interactive={false} Position="right"
                                                    Title={
                                                        <ExtraInfo>
                                                            <p><b>Customer Function:</b> {CustomerInfo['Customer Function']}</p>
                                                        </ExtraInfo>
                                                    }
                                                >
                                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', maxWidth: '50px' }}>{MatchIcon('Info')}</div>
                                                </TooltipedItem>

                                            </div>
                                            <div className="mb-2 Fold ExtraIcon" >
                                                <Field
                                                    id={"Field_projectName"}
                                                    name={"projectName"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'projectName', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Project Name *"}
                                                    validator={Mandatory}
                                                    onChange={(e: any) => {
                                                        formRenderProps.onChange("projectName", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                        UpdateProjectInfo(e.value);
                                                    }}
                                                />
                                                <TooltipedItem Trigger={IconInfo} Interactive={false} Position="right"
                                                    Title={
                                                        <ExtraInfo>
                                                            <p><b>Project Type:</b> {projectInfo['Project Type']}</p>
                                                            <p><b>APP-ID:</b> {projectInfo['APP-ID']}</p>
                                                            <p><b>APP-Name:</b> {projectInfo['APP-Name']}</p>
                                                        </ExtraInfo>
                                                    }
                                                >
                                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', maxWidth: '50px' }}>{MatchIcon('Info')}</div>
                                                </TooltipedItem>
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_testingToolName"}
                                                    name={"testingToolName"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'testingToolName', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Testing Tool"}

                                                />
                                            </div>
                                        </div>
                                        <div className="col-4">
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_businessUnitCode"}
                                                    name={"businessUnitCode"}
                                                    component={FilteredField}
                                                    disabled={!props.item.new && (Delete || HasBlockeds(props.item))}
                                                    data={Filtered({ origin: 'businessUnitCode', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"BU / RU Code **"}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_customerCostCenterCode"}
                                                    name={"customerCostCenterCode"}
                                                    component={FilteredField}
                                                    disabled={!props.item.new && (Delete || HasBlockeds(props.item))}
                                                    data={Filtered({ origin: 'customerCostCenterCode', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Customer CC **"}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_internalCostCenterPerCostCode"}
                                                    name={"internalCostCenterPerCostCode"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'internalCostCenterPerCostCode', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Internal CC *"}
                                                    validator={Mandatory}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_testingToolProjectName"}
                                                    name={"testingToolProjectName"}
                                                    component={Input}
                                                    disabled={Delete}
                                                    data={[...Originals.internalCode].sort(alphabet)}
                                                    label={"Testing Tool (Project Name)"}

                                                />
                                            </div>

                                        </div>
                                        <div className="col-4">
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_typeOfServiceName"}
                                                    name={"typeOfServiceName"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'typeOfServiceName', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Type Of Service *"}
                                                    validator={Mandatory}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_chargingModelCode"}
                                                    name={"chargingModelCode"}
                                                    component={FilteredField}
                                                    disabled={Delete}
                                                    data={Filtered({ origin: 'chargingModelCode', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Charging Model *"}
                                                    validator={Mandatory}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_internalCode"}
                                                    name={"internalCode"}
                                                    component={Input}
                                                    disabled={Delete}
                                                    data={[...Originals.internalCode].sort(alphabet)}
                                                    label={"Internal Code"}

                                                />
                                            </div>
                                            <div className="mb-2 Fold" >
                                                <Field
                                                    id={"Field_testingToolDetailedInfo"}
                                                    name={"testingToolDetailedInfo"}
                                                    component={Input}
                                                    disabled={Delete}
                                                    data={[...Originals.internalCode].sort(alphabet)}
                                                    label={"Testing Tool (Detailed Info)"}

                                                />
                                            </div>

                                        </div>
                                        <div className="col-4">
                                            <ClickAwayListener onClickAway={(e: any) => { if (CheckBoundaries(e)) { setStartShow(false) } }}>
                                                <DatePicker
                                                    onFocus={() => { if (!startShow) { setStartShow(true) } }}
                                                    show={startShow}
                                                    id={"Field_plannedStartDate"}
                                                    format="yyyy-MM-dd"
                                                    placeholder=""
                                                    label={'Planned Start Date'}
                                                    name={"plannedStartDate"}
                                                    validationMessage=""
                                                    calendar={() => { return (<FinpoCalendar param="plannedStartDate" callback={(e: any, b: any) => { UpdatePickerData(e, b, formRenderProps); setStartShow(false) }} />) }}

                                                    value={formRenderProps.valueGetter("plannedStartDate") === null ? null : new Date(formRenderProps.valueGetter("plannedStartDate"))}

                                                    validityStyles={false}
                                                    disabled={Delete}
                                                    required
                                                />
                                            </ClickAwayListener>
                                        </div>
                                        <div className="col-4">
                                            <ClickAwayListener onClickAway={(e: any) => { if (CheckBoundaries(e)) { setEndShow(false) } }}>
                                                <DatePicker
                                                    onFocus={() => { if (!startShow) { setEndShow(true) } }}
                                                    show={endShow}
                                                    id={"Field_plannedEndDate"}
                                                    format="yyyy-MM-dd"
                                                    placeholder=""
                                                    label={'Planned End Date'}
                                                    name={"plannedEndDate"}
                                                    validationMessage=""
                                                    calendar={() => { return (<FinpoCalendar param="plannedEndDate" callback={(e: any, b: any) => { UpdatePickerData(e, b, formRenderProps); setEndShow(false) }} />) }}

                                                    value={formRenderProps.valueGetter("plannedEndDate") === null ? null : new Date(formRenderProps.valueGetter("plannedEndDate"))}

                                                    validityStyles={false}
                                                    disabled={Delete}
                                                    required
                                                />
                                            </ClickAwayListener>
                                        </div>

                                        <div className="col-4">
                                            <Field
                                                id={"Field_productName"}
                                                name={"productName"}
                                                component={FilteredField}
                                                data={Filtered({ origin: 'productName', formData: formRenderProps })?.sort(alphabet)}
                                                label={"Product *"}
                                                disabled={Delete}
                                                validator={Mandatory}

                                            />
                                        </div>
                                    </div>
                                    <div className="row mb-2">
                                        <div className="col-12 Fold">
                                            <Field
                                                id={"Field_serviceDescription"}
                                                name={"serviceDescription"}
                                                component={Input}
                                                disabled={Delete}
                                                label={"Service description"}

                                            />
                                        </div>
                                    </div>
                                    {Delete ? null :
                                        <div className="row mb-2">
                                            <div className="col-2 Vertical">
                                                <InputDecorator>
                                                    <Field
                                                        format={formatCurrency}
                                                        id={"Field_planLC"}
                                                        name={"planLC"}
                                                        component={NonNegativeNumericInput}
                                                        onChange={(el: any) => { Update_differenceLC('planLC', el.target.value, formRenderProps) }}
                                                        disabled={Delete || !props.item.new && !Permissions.includes('Update Revenue Plan LC')}
                                                        label={"Plan LC"}

                                                    />
                                                </InputDecorator>
                                            </div>
                                            <div className="col-2 Vertical">
                                                <InputDecorator>
                                                    <Field
                                                        format={formatCurrency}
                                                        id={"Field_transferLC"}
                                                        name={"transferLC"}
                                                        component={NonNegativeNumericInput}
                                                        onChange={(el: any) => { Update_differenceLC('transferLC', el.target.value, formRenderProps) }}
                                                        disabled={Delete || !Permissions.includes('Create Update Revenue Transfer LC')}
                                                        label={"Transfer LC"}


                                                    />
                                                </InputDecorator>
                                            </div>

                                            <div className={isNegative(differenceLC) ? 'col RedWarn' : 'col'}>
                                                <p className={"m-1 border-bottom"}><strong>Difference LC :</strong></p>
                                                <p className={"m-1  border-bottom justify-content-end"}>{
                                                    new Intl.NumberFormat('es-ES', formatCurrency).format(differenceLC)
                                                }</p>

                                            </div>
                                            <div className="col">
                                                <p className={"m-1 border-bottom"}><strong>FYFCLC :</strong></p>
                                                <p className={"m-1  border-bottom justify-content-end"}>{
                                                    new Intl.NumberFormat('es-ES', formatCurrency).format(fyfclc)
                                                }</p>

                                            </div>
                                            <div className="col">

                                                <p className={"m-1 border-bottom".concat(changedstyle)}><strong>FYFCCHF :</strong></p>
                                                <p className={"m-1 border-bottom justify-content-end".concat(changedstyle)}>{
                                                    new Intl.NumberFormat('es-ES', formatCurrency).format(fyfcchf)
                                                }</p>

                                            </div>
                                            <div className="col">
                                                <p className={"m-1 border-bottom".concat(changedstyle)}><strong>FYFCCHFVAT :</strong></p>
                                                <p className={"m-1 border-bottom justify-content-end".concat(changedstyle)}>{
                                                    new Intl.NumberFormat('es-ES', formatCurrency).format(fyfcchfvat)
                                                }</p>
                                            </div>
                                            <div className="col" style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
                                                <Field
                                                    id={"Field_currencyName"}
                                                    name={"currencyCode"}
                                                    component={DropDownList}
                                                    data={Filtered({ origin: 'currencyCode', formData: formRenderProps })?.sort(alphabet)}
                                                    label={"Currency"}
                                                    disabled={Delete}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("currencyCode", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                        HandleCurrencyChange(e.value);
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    }
                                </Paper>
                                {Delete ? null :
                                    <div className="row wages">
                                        <div className="col-3 mb-1">
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"january.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Jan"}

                                                    disabled={CheckDisabled(props.item, 'january')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("january.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"february.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Feb"}

                                                    disabled={CheckDisabled(props.item, 'february')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("february.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator className="mb-6">
                                                <Field
                                                    format={formatCurrency}
                                                    name={"march.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Mar"}

                                                    disabled={CheckDisabled(props.item, 'march')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("march.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                        </div>
                                        <div className="col-3 mb-1">
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"april.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Apr"}

                                                    disabled={CheckDisabled(props.item, 'april')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("april.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"may.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"May"}

                                                    disabled={CheckDisabled(props.item, 'may')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("may.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator className="mb-6">
                                                <Field
                                                    format={formatCurrency}
                                                    name={"june.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Jun"}

                                                    disabled={CheckDisabled(props.item, 'june')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("june.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                        </div>
                                        <div className="col-3 mb-1">
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"july.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Jul"}

                                                    disabled={CheckDisabled(props.item, 'july')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("july.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"august.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Aug"}

                                                    disabled={CheckDisabled(props.item, 'august')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("august.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator className="mb-6">
                                                <Field
                                                    format={formatCurrency}
                                                    name={"september.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Sep"}

                                                    disabled={CheckDisabled(props.item, 'september')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("september.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                        </div>
                                        <div className="col-3 mb-1">
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"october.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Oct"}

                                                    disabled={CheckDisabled(props.item, 'october')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("october.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator>
                                                <Field
                                                    format={formatCurrency}
                                                    name={"november.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Nov"}

                                                    disabled={CheckDisabled(props.item, 'november')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("november.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                            <InputDecorator className="mb-6">
                                                <Field
                                                    format={formatCurrency}
                                                    name={"december.amount"}
                                                    component={NonNegativeNumericInput}
                                                    label={"Dec"}

                                                    disabled={CheckDisabled(props.item, 'december')}
                                                    onChange={(e: NumericTextBoxChangeEvent) => {
                                                        formRenderProps.onChange("december.amount", {
                                                            value: e.value
                                                        });
                                                        handleChange(formRenderProps);
                                                    }}
                                                />{currencyIcon}
                                            </InputDecorator>
                                        </div>
                                    </div>

                                }
                            </fieldset>
                            {Delete ?
                                <div className="k-form-buttons" style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                    <button
                                        type={"submit"}
                                        onClick={DeleteItem}
                                        className="k-button k-primary"
                                    >
                                        Delete
                                    </button>
                                </div>
                                :
                                <div className="k-form-buttons">
                                    <FormPrimaryButton
                                        type={"submit"}
                                        className="k-button k-primary"
                                        disabled={!formRenderProps.allowSubmit || IsLoading}
                                    >
                                        {IsLoading ? <Loading Name="ButtonFit" /> : GetRevenuesButtonText(props.item)}
                                    </FormPrimaryButton>
                                    <FormSecondaryButton
                                        type={"submit"}
                                        className="k-button"
                                        onClick={props.cancelEdit}
                                    >
                                        Cancel
                                    </FormSecondaryButton>
                                    {
                                        props.item.new ? null :
                                            <FormPrimaryButton style={{ position: 'absolute', right: '24px' }}>
                                                {CheckAddComment(props.item)}
                                            </FormPrimaryButton>
                                    }

                                </div>
                            }

                        </FormElement>
                    )}
                />
            </Dialog>
        </Content>
    );
}
export default EditRevenueForm;


const ExtraInfo = styled.div({
    p: {
        padding: '0px',
        margin: '0px'
    }
})
const OwnerField = styled.div({
    right: '55px',
    top: '-35px',
    width: '450px',
    display: 'flex',
    justifyContent: 'space-between',
    position: 'absolute',
    '> div:first-of-type': {
        marginRight: '10px'
    }
});

const YearField = styled.div({
    left: '120px',
    top: '-49px',
    width: '30px',
    position: 'absolute',
    'span::before': {
        fontSize: '25px',
        color: '#003399',
        opacity: 1
    }
});

const Legend = styled.div({
    fontSize: '11px',
    textAlign: 'left',
    color: 'grey'
});


const Content = styled.div<any>({
    '.RedWarn': {
        color: 'red'
    },
    '.Vertical': {
        paddingTop: '23px',
        'label:not(.k-empty)': {
            transform: 'translateY(-5px)'
        }
    },
    '.Calender': {
        width: '30px',
        marginTop: '10px',
        border: 'none'
    },
    '.k-floating-label-container': {
        paddingTop: '15px'
    },
    '.wages .k-floating-label-container': {
        paddingTop: '0px',
        marginTop: '10px'
    },
    '.k-textbox-container': {
        paddingTop: '10px'
    },
    '.Delete *': {
        opacity: 1,
        '.k-select': {
            display: 'none'
        }
    },
    '.k-text-disabled': {
        opacity: 1
    },
    '.k-content.k-window-content.k-dialog-content': {
        overflow: 'visible'
    },
    '.k-select': {
        opacity: '1 !important'
    },
    'svg': {
        pointerEvents: 'none'
    },
    '.k-form-error': {
        position: 'absolute',
        bottom: '-20px',
        marginTop: '15px'
    },
    '.Fold': {
        position: 'relative',
    },
    '.Fold.ExtraIcon': {
        display: 'flex',
        flexDirection: 'row',
        '> div:last-of-type': {
            maxWidth: '25px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            paddingLeft: '5px',
            paddingTop: '15px',
            cursor: 'help'
        },
        '> div:first-of-type': {
            width: '100%'
        },
        'img': {
            width: '100%',
            height: 'inherit'
        }


    }
}, props => ({
    '.k-button.k-primary:not(:disabled)': {
        borderColor: props.Theme.Corporate.darkBlue,
        backgroundColor: props.Theme.Corporate.darkBlue
    },
    'svg': {
        fill: props.Theme.Corporate.darkBlue
    }
}))
const InputDecorator = styled.div({
    position: 'relative',
    'svg': {
        position: 'absolute',
        top: '45%',
        right: 'calc(0.6vw + 15px)',
        fontSize: '125%',
        color: 'grey'
    },
    '.k-floating-label-container': {
        paddingTop: '5px',
    },
    '.k-label': {
        marginTop: '-10px'
    },
    'input': {
        textAlign: 'right',
        paddingRight: '25px !important',
        width: 'calc(100% - 20px)'

    }
});

