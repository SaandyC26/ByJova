import React from 'react';
import { Splitter } from '@progress/kendo-react-layout';



export default function DetailComponentSplitter(props:any){
 
        const panes  = [
                { size: '25%', min: '25%' },
                { size: '25%', min: '25%' },
                { },
                { size: '25%', min: '25%' },
            ]
        
       

 
        const dataItem = props.dataItem;
       
        return (
            <section className="col-sm-6 col-md-6" id="DetailComponentSplitter">
                <Splitter
                    style={{height: 200}}
                    panes={panes}
                >
                    <div>
                        <h3>Q1 : {dataItem.january.amount + dataItem.february.amount + dataItem.march.amount} {dataItem.currencyCode}</h3>
                        <p><strong>January:</strong>&#09;&#09;{dataItem.january.amount} {dataItem.currencyCode}</p>
                        <p><strong>February:</strong>&#09;&#09;{dataItem.february.amount} {dataItem.currencyCode}</p>
                        <p><strong>March:</strong>&#09;&#09;{dataItem.march.amount} {dataItem.currencyCode}</p>
                    </div>
                    <div>
                        <h3>Q2 : {dataItem.april.amount + dataItem.may.amount + dataItem.june.amount} {dataItem.currencyCode}</h3>
                        <p><strong>April:</strong>&#09;&#09;{dataItem.april.amount} {dataItem.currencyCode}</p>
                        <p><strong>May:</strong>&#09;&#09;{dataItem.may.amount} {dataItem.currencyCode}</p>
                        <p><strong>June:</strong>&#09;&#09;{dataItem.june.amount} {dataItem.currencyCode}</p>
                    </div>
                    <div>
                        <h3>Q3 : {dataItem.july.amount + dataItem.august.amount + dataItem.september.amount} {dataItem.currencyCode}</h3>
                        <p><strong>July:</strong>&#09;&#09;{dataItem.july.amount} {dataItem.currencyCode}</p>
                        <p><strong>August:</strong>&#09;&#09;{dataItem.august.amount} {dataItem.currencyCode}</p>
                        <p><strong>September:</strong>&#09;&#09;{dataItem.september.amount} {dataItem.currencyCode}</p>
                    </div>
                    <div>
                        <h3>Q3 : {dataItem.october.amount + dataItem.november.amount + dataItem.december.amount} {dataItem.currencyCode}</h3>
                        <p><strong>October:</strong>&#09;&#09;{dataItem.october.amount} {dataItem.currencyCode}</p>
                        <p><strong>November:</strong>&#09;&#09;{dataItem.november.amount} {dataItem.currencyCode}</p>
                        <p><strong>December:</strong>&#09;&#09;{dataItem.december.amount} {dataItem.currencyCode}</p>
                    </div>
                </Splitter>
            </section>
        );
    
}

