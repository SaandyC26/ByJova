import React from 'react';
import styled from "@emotion/styled";
import { formatNumber } from '@telerik/kendo-intl';


export default function QuarterInfoBox(props:any) {
  let Format = '';
  switch(props.unit){
    case 'CHF' : Format = "##,##.00 CHF"; break;
    case 'EUR' : Format = "##,##.00 €"; break;
    case 'USD' : Format = "##,##.00 $"; break;
  }
  
    var keys = Object.keys(props.values);
    var vals  = Object.values<any>(props.values);
    var total = 0;
    vals.forEach((val:any) => {total =  total + val.amount});
 

    return (
      
                <Group>
                    <span><b>{props.title}:</b>{formatNumber(total, Format)} </span>   
                    <ol>                
                    {
                      keys.map((key:any,index:any)=> {
                        return (
                          <li key={`QuarterInfoBox_${key}`}> 
                            <strong>{key} :</strong> {formatNumber(vals[index].amount, Format) } 
                          </li>
                        )
                      })
                    }
                    </ol> 
                </Group>
            
      );
  }


  const Group = styled.div({
    boxShadow: '0px 1px 5px -1px rgb(0 0 0 / 50%)',
    borderRadius: '3px',
    '> span:first-of-type' :{
      padding: '10px',
      fontSize: '125%',
      display: 'flex',
      justifyContent: 'space-between'

    },
    'ol':{
      display: 'flex',
      flexDirection: 'column',
      listStyle: 'none',
      padding: '0px',
      margin: '0px',
     
    },
    'li':{
      minWidth: '220px',
      padding: '5px 10px',
      display: 'flex',
      justifyContent: 'space-between'
    }
  })