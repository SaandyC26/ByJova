import LoginService from '../../services/LoginService';
import store from '../../store';
import {setTokenLife,setToken,setOnRefresh} from '../../store/slices/tokens'
import {setPermissions,saveGrid,setNews, setRestrictions}  from '../../store/slices/user'
import UserService from '../../services/UserService';



// clears caps and special chars // unfininished
export default function CleanChars(string:string){   
    return string;
  }

  export function useDictionary(text: string){
    const lang = store.getState().userData.lang; 
    const Dictionary = require('../Dictionary/'+lang)
    return Dictionary[text];
}

export function ParseToError(value:string){
  let result = new Array;
  let alter = value.split('. ')
  
  function isEven(n:any) {
    return n % 2 == 0;
 } 

  for (let index = 0; index < alter.length; index++) {
    if(isEven(index)){
      result.push(alter[index] + '. ' + alter[index+1]+'.');
     
    }    
  }
 
  if(result.length < 1){result.push(value)}
  
  return result;
}

export function HasPermision(value:string){
  let List = store.getState().userData.permissions;   
  let permission = false;
  if(List.includes(value)){permission = true} 
  return permission

}

export function HasPermisionAny(PermissionsToCheck:any){
  let List = store.getState().userData.permissions;     
  let valid = false;
  if(List.length > 0){ 
    PermissionsToCheck.forEach((element:any) => { 
        
       if(typeof List.find((el:any) => el === element) !== 'undefined'){valid = true}
    });
     
  }
  
  
  return valid

}

// parss Jwt to get user data  
export function parseJwt (token:any) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));    
    return JSON.parse(jsonPayload);
}

export function getCookie(cname:string) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let cookiearray = decodedCookie.split(';');
  let acookie;

  for(acookie of cookiearray){
    let mutable = acookie;
    while (mutable.charAt(0) === ' ') {
      mutable = mutable.substring(1);
    }
    if (mutable.indexOf(name) === 0) {
      return mutable.substring(name.length, mutable.length);
    }
  }
  return "";
}


export function setCookie(name:string, value:any){
  document.cookie = name+'='+value+";path=/" ;
  
}  
export function removeCookie(cname:string){
  document.cookie = cname +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

export function ReadObjProp(obj:any, prop:any) {
    return obj[prop];
}

export function AsureColumns(arr:any, pool?: any){
  let Mod = arr; 
  let Originals = store.getState().userData.OriginalDemandSettings.Columns;
   
  Originals.forEach((el:any) => {
    
     if(findWithAttr(Mod, 'field', el.field) === -1){
        Mod.push({field: el.field, width : el.width , orderIndex: el.orderIndex, Show: el.Show})
     }
  })


  return Mod;
}

// Calls refresh endpoint for token
export const RefreshToken2 = (Token:string, Refresh:string ) => {
  return new Promise((resolve, reject) => {
    store.dispatch(setOnRefresh(true));
    LoginService.Refresh({'token': Token ,'refreshToken': Refresh}).then((Mainresult: any) => {       
        document.cookie = 'ZurichCustomerPortalRefresh='+unParseChars(Mainresult.refreshToken)+";path=/" ;
        document.cookie = 'ZurichCustomerPortal='+Mainresult.token+";path=/" ;
        store.dispatch(setTokenLife(Mainresult.validTo))
        store.dispatch(setToken(Mainresult.token)) 
        store.dispatch(setOnRefresh(false)); 
        UserService.getMyUser().then((result: any) => {
          let List = new Array;
          result.user.permissions.forEach((element:any) => {
            List.push(element.name);
          });
            store.dispatch(setPermissions(List))
         
          if(typeof result.user.releaseNotes !== 'undefined' && result.user.releaseNotes !== null){
            store.dispatch(setNews({Show:true, Msg: result.user.releaseNotes }))
          }
          
          let Settings = JSON.parse(result.user.gridPreferences.revenues);
          let Filters = store.getState().userData.DemandSettings.Filters;
          let Columns = store.getState().userData.DemandSettings.Columns;
          let Asured:any = Columns; 
          if(Settings !== null){Asured = AsureColumns(Settings.Columns)}

          if(Settings?.Columns?.length > 0 && typeof Settings.Filters !== 'undefined'){                       
            store.dispatch(saveGrid({Filters: Settings.Filters,Columns: Asured}))
          }
          else if(Settings?.Columns?.length > 0 && typeof Settings.Filters === 'undefined' ){
            store.dispatch(saveGrid({Filters: Filters,Columns: Asured}))
          }else if(Settings?.Columns?.length === 0 && typeof Settings.Filters !== 'undefined' ){
            store.dispatch(saveGrid({Filters: Settings.Filters,Columns: Columns}))
          }

        })      

        UserService.getRestrictions().then((subResult:any)=>{
          
          store.dispatch(setRestrictions(subResult)) // change fake to result
        })
        resolve(Mainresult.token)
        
        
    }).catch(() => {
     
     
      document.cookie = "ZurichCustomerPortal=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      document.cookie = "ZurichCustomerPortalRefresh=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      
      window.location.href = './'
       
       
        
    });
    
  })
}

export function findWithAttr(array:any, attr:string, value:any) {
  for(var i = 0; i < array.length; i += 1) {
      if(array[i][attr] === value) {
          return i;
      }
  }
  return -1;
}

export function CurrencyFormat(currency:string){
  
  switch(currency){
    case 'CHF' : return "##,##.00 CHF";
    case 'EUR' : return '##,##.00 €';
    case 'USD' : return "##,##.00 $";
    default : return "##,##.00 CHF";
  } 
 
  
}
export const Waitfortoken = (data:any) => {  
  return new Promise((resolve, reject) => {    
    
    function Check(){
      setTimeout(function(){
        let onRefresh = store.getState().tokenData.onRefresh;       
        if(onRefresh){Check()}else{resolve(data)}
      },500)
    }
    Check();
    
  })
}

export function SortByProp(List: any, Prop:string){

  function compare(a:any, b:any) {
   
    if(a[Prop] === null || typeof a[Prop] === 'undefined'){return 0}
    else if(b[Prop] === null || typeof a[Prop] === 'undefined'){return 0}
    else if(a[Prop].toLowerCase() > b[Prop].toLowerCase()){return 1}
    else if(b[Prop].toLowerCase() > a[Prop].toLowerCase()){return -1}
    else{ return 0 }
    
    
  }
  return List.sort(compare)

}

export function GetButtonText(item:any, forced?: any){
  let text = '';
  if(item.new){text = 'New line'}else{text = 'Edit line'}
  if(item.delete){text = 'Delete line'}

  if(typeof forced !== 'undefined' && typeof forced.new !== 'undefined' && item.new){
    text = forced.new;
  }
  if(typeof forced !== 'undefined' && typeof forced.delete !== 'undefined' && item.delete){
    text = forced.delete;
  }
  if(typeof forced !== 'undefined' && typeof forced.update !== 'undefined' && !item.new && !item.delete){
    text = forced.update;
  }

  return text;
}

export function GetRevenuesButtonText(item:any){
  let text = '';
  if(item.new){text = 'Create'}else{text = 'Update'}
  if(item.delete){text = 'Delete'}
  return text;
}

// changes token chars to cookie friendly
export function ParseChars(toparse:string){
    let pattern = /\%3D/gi;
    let parsed = toparse.replace(pattern,'=');   
    pattern = /\%2B/gi;
    parsed = parsed.replace(pattern, '+');
    pattern = /\%2F/gi;
    parsed = parsed.replace(pattern, '/');
    return parsed;
}

// changes cookie chars to token friendly
export function unParseChars(toparse:string){
    let pattern = /\=/gi;
    let parsed = toparse.replace(pattern,'%3D');
    pattern = /\+/gi;
    parsed = parsed.replace(pattern, '%2B');
    pattern = /\//gi;
    parsed = parsed.replace(pattern, '%2F');
    return parsed;
}

export const MonthList = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
export const MonthListShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']