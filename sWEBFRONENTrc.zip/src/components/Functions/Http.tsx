import  React from "react";
import axios from 'axios';
import store from '../../store';
import {ParseChars,RefreshToken2,Waitfortoken,getCookie} from '../../components/Functions/Utils';
import {setError } from '../../store/slices/user';
// Axios Request Interceptor
axios.interceptors.request.use( async function (config) { 
    let onRefresh = store.getState().tokenData.onRefresh;
    
    if( typeof config?.url !== 'undefined' && 
        !config?.url?.includes('authentication') && 
        !config?.url?.includes('Authentication/Refresh') &&
        !config?.url?.includes('Authentication/Login') &&
        !config?.url?.includes('authentication/login')
        )
    {
        
        if(getCookie('ZurichCustomerPortal') === ''){
            window.location.reload()
        }
        let state = store.getState().tokenData.tokenLife;       
        
        // check if store has tokenlife data
        if(state !== null){
            
            //if so compare time and refresh ifs under 5minutes
            let time = new Date(Date.now());
            let TokenLife = new Date(state);          
            TokenLife.setMinutes(TokenLife.getMinutes()-9);                   
            if(time > TokenLife ){
              
                let Token = getCookie('ZurichCustomerPortal');
                let Refresh = getCookie('ZurichCustomerPortalRefresh');                 
                if(!onRefresh){
                    
                    await RefreshToken2(Token,ParseChars(Refresh))                    
                }else{
                    await Waitfortoken(config).then( () =>{
                        if(typeof config.headers !== 'undefined'){
                        config.headers.authorization = 'Bearer '+getCookie('ZurichCustomerPortal');}
                        
                        
                    }) 
                }
            }
        }else{
            // call refresh to store valid date            
            let Token = getCookie('ZurichCustomerPortal');
            let Refresh = getCookie('ZurichCustomerPortalRefresh'); 
            if(!onRefresh && Token !== '' && Refresh !== ''){                
                await RefreshToken2(Token,ParseChars(Refresh))
            }
        }

        if(onRefresh){
            await Waitfortoken(config).then( result =>{  
                if(typeof config.headers !== 'undefined'){             
                config.headers.authorization = 'Bearer '+getCookie('ZurichCustomerPortal'); }               
                
            }) 
        }else{
            if(typeof config.headers !== 'undefined'){
            config.headers.authorization = 'Bearer '+getCookie('ZurichCustomerPortal');}
            
        }
        
     }
     
     
     return config;
     
   }, function (error:any) {
    store.dispatch(setError({Show:true, Msg: 'The Site is not working right now, please try again later, Error may be: '+JSON.stringify(error), Mode:'Close'}));
     return Promise.reject(error);
   });


// Axios Response Interceptor
axios.interceptors.response.use((config:any) => {        
    return config;
}, (error) => {
    let BaseError = {...error.response};  
    // in case we can get an array of strings as errors 
    if(error.response.headers['content-type'].includes("application/json")){
        console.log('error is object'); 

        let FriendlyError = JSON.parse(BaseError.data).map((element:any) => {                   
            return <p key={element}>{element}</p>
        });

        store.dispatch(setError({Show:true, Msg: FriendlyError, Mode:'Close'}));
    }else{
        console.log(BaseError);
        console.log(error)
        console.log('error is string');
        if(typeof BaseError.data.size !== 'undefined'){
            console.log('es blob')
            console.log(BaseError)
            
        }else{
            store.dispatch(setError({Show:true, Msg: BaseError.data, Mode:'Close'}));
        }
        
    }     
    return error;    
   
});