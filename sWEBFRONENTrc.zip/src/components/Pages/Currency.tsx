import React, {useState,useEffect}  from 'react';
import {useSelector} from 'react-redux';
import ContentScreen from '../Generic/ContentScreen'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {HasPermision} from '../Functions/Utils'
import {DinamicInfo,DefineSection,FixedInfo,DataTableInfo} from '../Generic/Styles';
import DataTableSpecial from '../Generic/DataTableSpecial';
import Loading from "../Generic/Loading";
import MDTService from '../../services/MDTService';



export default function Currency(){   
   
    const TokenData = useSelector((state: any) => state.tokenData);
    const [List, setList] = useState(new Array);
    const [isLoading, setisLoading] = useState(false);
    const [TableDef,setTableDef] = useState(new Array);
    const [OldestYear, setOldestYear] = useState("0");
    const Months = ['All','January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const SpecialFields = {'currency': {type: 'select', values: ['USD', 'EUR'], selected: 'USD'},
                            'month' : {type: 'select', values: Months, selected: Months[0]}         };
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false, create: false, delete: false});

    useEffect(() => {  
        UpdateTable()       
    },[])

    useEffect(() => {  
        let Permissions = {
            edit: HasPermision('Manage Currency Exchange Rate'),
            create: HasPermision('Manage Currency Exchange Rate'),
            delete: HasPermision('Manage Currency Exchange Rate'),
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])

    
function find(Arr: any, property: string, value: any){
    let index = -1;  
    let ReturnArray = Arr;       
    
    ReturnArray.forEach((element: any, iterator: number) => {       
            for (const [key,thisvalue] of Object.entries(element)) {
                if(thisvalue=== value && key === property){
                    index = iterator; 
                    ReturnArray = Arr;                
                }
             }        
    });  

    if(index < 0 ){ 
        return {Empty: true, Array: ReturnArray}
    } 
    else{
        return {Empty: false, Array: ReturnArray}
    }
    
}


    function UpdateTable(){
        
        let Years = new Array;            
        let OldestId = "0";
        let NewestYear = '0';
        setisLoading(true);        
        let cca = MDTService.postRequestCurrencyConversion;
        cca(TokenData.tokenId).then((result: any) => {  

            result.map((Item:any) => {                
                let newItem = Item;
                newItem.name = typeof Item.name !== 'undefined' ? Item.name : Item.code; 
                if(Item.from.code !== 'GBP') {

                    if(parseInt(Item.year) > parseInt(NewestYear)){OldestId = Item.id; NewestYear = Item.year}
                    if(find(Years,'year',Item.year).Empty === true){
                        let newItem2 = {
                            year: Item.year,                           
                            sublist: new Array,
                            id: Item.id
                        }
                        result.map((SubItem1:any) => {
                            if(SubItem1.year === Item.year){
                                let MonthGap = SubItem1.month === 'None' ? 'All' : SubItem1.month;
                                if(find(newItem2.sublist,'month',MonthGap).Empty === true){
                                    let newItem3 = {
                                        id: Item.id,
                                        month: MonthGap,
                                        sublist: new Array
                                    }
                                    result.map((SubItem2:any) => { 
                                        if(SubItem2.month === 'None'){SubItem2.month = "All"}
                                        if(SubItem2.year === Item.year && newItem3.month === SubItem2.month){
                                        if(find(newItem3.sublist,'currency',SubItem2.from.code).Empty === true){
                                            let newItem4 = {
                                                currency: SubItem2.from.code,
                                                chf: SubItem2.rate,
                                                original: SubItem2
                                            }
                                           
                                            newItem3.sublist.push(newItem4);
                                        }}
                                    });
                                    newItem2.sublist.push(newItem3);
                                }
                            }
                        })                        
                        find(Years,'year',Item.year).Array.push(newItem2);  

                    }                        
                }
            });
           
            setOldestYear(OldestId);            
            setList([...Years].reverse());  
           
            setTableDef(['year','month','currency','chf'])
            setisLoading(false); 
        });
    }
   
    return(
        
        <ContentScreen id="Currency">  
        <DataTableInfo>          
            <DinamicInfo>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection>MasterData Tables Currency</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo style={{backgroundColor: 'transparent'}} className="col-12">                            
                            {
                                
                                isLoading ? <Loading/> : <DataTableSpecial NoneRequired={true} SpecialFields={[SpecialFields]} preSet={OldestYear} callBack={UpdateTable} Addable={Granted.create} Editable={Granted.edit} DataSet={List} TableDef={TableDef} TableSizes={[]}/>
                            }
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
            </DinamicInfo> 
            </DataTableInfo>        
        </ContentScreen>
    )
}



