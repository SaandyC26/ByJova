import React, {useState,useEffect}  from 'react';
import {useSelector} from 'react-redux';
import ContentScreen from '../Generic/ContentScreen'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import RolesForm from "../Generic/RolesForm";
import {HasPermision} from '../Functions/Utils'
import DataTable from '../Generic/DataTable';
import Loading from "../Generic/Loading";
import MDTService from '../../services/MDTService';
import {DinamicInfo,DefineSection,FixedInfo,AddButton,DataTableInfo} from '../Generic/Styles';
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'

export default function RoleAdmin(){
    
    const OpenTable = useSelector((state: any) => state.MasterData.Table);
    const TokenData = useSelector((state: any) => state.tokenData);
    const [List, setList] = useState(new Array);
    const [isLoading, setisLoading] = useState(false);
    const TableDef =['name','permissions'];
    const [PermissionList, setPermissionList] = useState(new Array)
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false, create: false, delete: false});
       
    useEffect(() => { 
              
       
         UpdateTable()
       
    },[OpenTable])

    useEffect(() => {  
        let Permissions = {
            edit: HasPermision('Manage Role'),
            create: HasPermision('Manage Role'),
            delete: HasPermision('Manage Role'),
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])
    

    function UpdateTable(){
        setisLoading(true);   
        
        MDTService.getRequestPermissions(TokenData.tokenId).then((result: any) => {  
                                 
            var tempList =  new Array;
            result.map((Item:any) => {                
                let newItem = Item;
                newItem.name = typeof Item.name !== 'undefined' ? Item.name : Item.code;                
                tempList.push(newItem);      
            });
            
            setPermissionList(tempList);   
            MDTService.getRequestRoles(TokenData.tokenId).then((subResult: any) => {  
                                     
                tempList =  new Array;
                subResult.map((Item:any) => {                
                    let newItem = Item;
                    let SubList = new Array();
                    newItem.name = typeof Item.name !== 'undefined' ? Item.name : Item.code;  
                    Item.permissions.map((element:any) => {
                        SubList.push(element.name)
                    })  
                    newItem.permissions = SubList;            
                    tempList.push(newItem);      
                });
                setList(tempList);            
                setisLoading(false); 
            });         
            
        });
        
       
    }
   
    return(
        
        <ContentScreen id="EditDataTables"> 
        <DataTableInfo>             
            <DinamicInfo>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection>Roles Management</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo style={{backgroundColor: 'transparent'}} className="col-12">                            
                            {
                                
                                isLoading ? <Loading/> : <DataTable Addable={Granted.create} Deleteable={Granted.delete} Permissions={PermissionList} Form={RolesForm} callBack={UpdateTable} Editable={Granted.edit} DataSet={List} TableDef={TableDef} TableSizes={[]}/>
                            }
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
            </DinamicInfo> 
            </DataTableInfo>        
        </ContentScreen>
    )
}

