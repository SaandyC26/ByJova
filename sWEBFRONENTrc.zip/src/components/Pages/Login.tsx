import React ,{useState} from 'react';
import Background from '../../assets/images/background_login.jpg';
import Logo from '../../assets/images/Zurich_rged_R_rgb.png';
import { createStyles, Theme, makeStyles } from '@material-ui/core/styles';
import styled from "@emotion/styled";
import {useForm,FormProvider} from 'react-hook-form';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl'
import Button from '@material-ui/core/Button';
import InputBase from '@material-ui/core/InputBase';
import LoginService from '../../services/LoginService';
import {useDispatch, useSelector} from 'react-redux';
import {setToken,setTokenLife, setRefresh} from '../../store/slices/tokens'
import Loading from "../Generic/Loading";
import {setPermissions,saveGrid, setNews, setRestrictions}  from '../../store/slices/user'
import UserService from '../../services/UserService';
import store from '../../store';
import PersonIcon from '@material-ui/icons/Person';
import VpnKeyIcon from '@material-ui/icons/VpnKey';
import {AsureColumns,setCookie} from '../Functions/Utils';



const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    margin: {
      margin: theme.spacing(1),
      width: '65%'
    },
  }),
);

type FormData = {
    username: string;
    password: string;
  };

export default function Login(){
    const MainTheme =  useSelector((state: any) => state.Theme) ;
    let dispatch = useDispatch();      
    const [Error, SetError] = useState(false);
    const classes = useStyles();
    const methods = useForm();    
    const {register, handleSubmit, formState: { errors } } = useForm<FormData>();
    const [Loads, setLoads] = useState(false);
    
    const onSubmit = (data:FormData) => {
        setLoads(true);
        SetError(false);
        LoginService.postLogin( {username: data.username, password: data.password}).then((overResult: any) => {                    
           setCookie('ZurichCustomerPortal', overResult.token);
           setCookie('ZurichCustomerPortalRefresh', overResult.refreshToken);
           dispatch(setToken(overResult.token));
           dispatch(setTokenLife(overResult.validTo));
           dispatch(setRefresh(overResult.token));
           UserService.getMyUser().then((result: any) => {
            let List = new Array;
            result.user.permissions.forEach((element:any) => {
              List.push(element.name);
            });
            dispatch(setPermissions(List))
            setLoads(false);
            
          dispatch(setPermissions(List))
         
          if(typeof result.user.releaseNotes !== 'undefined' && result.user.releaseNotes !== null){
            store.dispatch(setNews({Show:true, Msg: result.user.releaseNotes }))
          }         

         
          let Settings = JSON.parse(result.user.gridPreferences.revenues);
          let Filters = store.getState().userData.DemandSettings.Filters;
          let Columns = store.getState().userData.DemandSettings.Columns;
          let Asured = Columns;         
          if(Settings !== null){Asured =  AsureColumns(Settings.Columns)}
         

          UserService.getRestrictions().then((subResult:any)=>{
            dispatch(setRestrictions(subResult))
          })

          if(Settings?.Columns?.length > 0 && typeof Settings.Filters !== 'undefined'){              
            dispatch(saveGrid({Filters: Settings.Filters,Columns: Asured}))
          }
          else if(Settings?.Columns?.length > 0 && typeof Settings.Filters === 'undefined' ){
            dispatch(saveGrid({Filters: Filters,Columns: Asured}))
          }else if(Settings?.Columns?.length === 0 && typeof Settings.Filters !== 'undefined' ){
             
            dispatch(saveGrid({Filters: Settings.Filters,Columns: Columns}))
          }
          }) ;
         
         
          window.location.href = '../../../home/';
           
        }).catch((error: Error) => {           
           SetError(true);
            
            setLoads(false);
        });
        
    }

    return(
        <Contenedor id="Login" Theme={MainTheme}>
            <div>           
                   
                <Brand></Brand>
                <FormProvider {...methods}>
                    <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="Bg"></div>  
                    <div className="Loader">{Loads ? <Loading/> : null}</div>
                        <h1>Sign in</h1>
                        <Origin Theme={MainTheme}>Financial Portal</Origin>
                        <FormControl className={classes.margin}>            
                            <InputBase
                            inputProps={{ 'aria-label': 'naked' }}
                            id="username"            
                            placeholder="User"
                            {...register("username")}                            
                           
                            startAdornment={
                                <InputAdornment position="start">
                                    <InputIcon Theme={MainTheme}><PersonIcon/></InputIcon> 
                                </InputAdornment>
                            }
                            />{errors.username && <ErrorMsg>Username is mandatory</ErrorMsg>}    
                        </FormControl>
                        <FormControl className={classes.margin}>
                            
                            <InputBase
                            inputProps={{ 'aria-label': 'naked' }}
                            type="password"
                            id="password"   
                            
                            placeholder="Password"
                            {...register("password")}  
                            startAdornment={
                                <InputAdornment position="start">
                                    <InputIcon Theme={MainTheme}><VpnKeyIcon style={{fontSize:'32px', transform: 'rotate(-44deg)'}}/></InputIcon>
                                </InputAdornment>
                            }
                            />{errors.password && <ErrorMsg>Password is mandatory</ErrorMsg>}    
                        
                        </FormControl>
                        <FormControl className={classes.margin}>          
                            <Button id="Login_Button_Submit" type="submit" variant="contained" color="primary" onClick={handleSubmit(onSubmit)} >Login</Button>                   
                        </FormControl>
                    </form>
                    {Error && <ErrorMsgBig Theme={MainTheme}>User and/or password are incorrect</ErrorMsgBig> }
                </FormProvider>
            </div>              
        </Contenedor>
    )
}


const InputIcon = styled.div<any>({
    display:'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '37px',
    width: '40px',
    borderRadius: '5px 0px 0px 5px',   
    'svg':{
        fontSize: '40px',
        fill: 'white'
    }
}, props => ({
    backgroundColor: props.Theme.Corporate.darkBlue
}));

const ErrorMsg = styled.div({
    position: 'absolute',
    top: '0',
    right: '10px',
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'red',
    fontWeight: 'bold'
});
const ErrorMsgBig = styled.div<any>({
    position: 'absolute',
    bottom: '10px',
    left: '15px',
    height: '50px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    
    fontWeight: 'bold',
    width: '60%',
    textShadow: '0px 0px 0px rgb(236 172 27 / 50%)'
}, props => ({
    color: props.Theme.Corporate.darkBlue
}));
const Brand = styled.div({
    position: 'absolute',
    left: '0',
    top: '-11vh',
    height: '10vh',
    width: '40vw',   
    maxWidth: '460px',
    zIndex: 50,
    backgroundSize: 'contain',
    backgroundRepeat: 'no-repeat',
    backgroundImage: 'url('+Logo+')',
    backgroundPositionX: '50%',
    
    
})

const Contenedor = styled.div<any>({
    '.Bg':{
        position: 'absolute',
        width: '100%',
        height: '100%',
       
        borderRadius: '10px',
        opacity: '0.7'
    },
    position: 'fixed',
    left: '0',
    top: '0',
    height: '100vh',
    width: '100vw',     
    zIndex: 50,
    backgroundImage: 'url('+Background+')',
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',   
    backgroundBlendMode: 'luminosity',    
    '> div':{
       
        borderRadius: '8px',
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%,-60%)',
        width: '40vw',  
        boxShadow: '0px 0px 0px 5000px rgb(255 255 255 / 0.5)',
        height: '32vh',
        maxWidth: '450px',
        minHeight: '250px'

    },
    '.Loader':{
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 10
    },
    '.UserIcon':{
        backgroundImage: 'url(../../images/icons/User-Negative.png)',
    },
    '.PassIcon':{
        backgroundImage: 'url(../../images/icons/subscription2-negative.png)',
    },
    'form':{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        padding: '15px',
        height: '100%',
        'h1':{
            alignSelf: 'flex-start',
            color: 'white',           
            marginLeft: '8px',
            fontSize: '200%',
            zIndex: 1,
        },
        '> div:last-of-type':{
            margin: '0px '
         },
        '.MuiInputAdornment-positionStart':{
            margin: '0px'
        },
        'input':{
            color: 'black',
            backgroundColor: 'white',
            padding: '8px',
            borderRadius: '0px 4px 4px 0px'

        },
        '> div':{
            width: '95%',
            position: 'relative'
        },
       'button':{
           width: '30%',
           alignSelf: 'flex-end'
       } 
    }
}, props =>({
    '.MuiButton-containedPrimary':{
        backgroundColor: props.Theme.Corporate.darkBlue,
    },
    backgroundColor: props.Theme.Corporate.darkBlue,
    '.Bg':{
        backgroundColor: props.Theme.Corporate.darkBlue
    }
}))

const Origin = styled.span<any>({  
    color: 'white',  
  
    borderRadius: '5px',
    padding: '0px 10px',
    position: 'absolute',
    top: '30px',
    right: '27px',
    fontSize: '120%'
}, props =>({
    backgroundColor: props.Theme.Corporate.darkBlue,
}))