import { State as DataState } from '@progress/kendo-data-query';
import { Grid, GridCellProps, GridColumn, GridDataStateChangeEvent } from '@progress/kendo-react-grid';
import React, { useState ,SyntheticEvent, useEffect} from 'react';
import { GroupDto as group } from '../../dtos/groupDto';
import { UserDto as user } from '../../dtos/userDto';
import UserService from '../../services/UserService';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import styled from "@emotion/styled";
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import EditGroupForm from "../Generic/EditGroupForm";
import { Button } from '@progress/kendo-react-buttons';
import {findWithAttr,HasPermision} from '../Functions/Utils'

import ContentScreen from '../Generic/ContentScreen';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {useSelector} from 'react-redux';
import {AddButton,DataTableInfo,ActionButton} from '../Generic/Styles'
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'



const NewItem = {
    delete: false,
    new: true,
    id: 60000,
    name: '',
    users: new Array,
     
   
}
interface EditProps {
    enterEdit: Function,
    deleteConfirm: Function
}

const UsersCell = (props: GridCellProps): JSX.Element => {
    return (
        <td colSpan={props.colSpan} style={props.style}>
            {(props.field != null ? props.dataItem[props.field] as user[] : null)?.map(r => r.samAccountName)?.join(', ')}
        </td>
    );
}



export default function GroupAdmin (props:any, State:any) {
    const Theme =  useSelector((state: any) => state.Theme) ; 
    const users = {data:new Array, total:0};   
    const [dataState,setDataState] = useState<DataState>({take:0,skip:0})
    const [prevdataState,setprevDataState] = useState<DataState>({take:0,skip:0})
    const TokenData = useSelector( (state: any) => state.tokenData);
    const [openForm,setOpenForm] = useState(false);
    const [editItem,setEditItem] = useState<any>(NewItem); 
    const [UsersList, setUsersList] = useState(new Array)
    const [prevList,setprevList] = useState(new Array);
    const [List, setList] = useState(new Array);
    const [RawList, setRawList] = useState(new Array);
   
   
    
     
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false, create: false, delete: false});
   
    useEffect(() => {  
        let Permissions = {
            edit: HasPermision('Manage User'),
            create: HasPermision('Manage User'),
            delete: HasPermision('Manage User'),
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])


  
    useEffect(() => { 
        UpdateTable()
        UpdateUsers()
        },[])

        if(JSON.stringify(List) !== JSON.stringify(prevList)
            || JSON.stringify(dataState) !== JSON.stringify(prevdataState)
        ){
            setprevList(List)
            setprevDataState(dataState)
            UpdateTable();
        }

        function UpdateUsers(){


            UserService.getUsers(TokenData.tokenId, true, true, dataState, [{ field: "Roles", newField: "Roles.Name" }, { field: "Projects", newField: "Projects.Name"} ])
            .then((result: any) => {  
               
        
                result.data.forEach((element:any) => { // delete when DB returns those params
                    element.lineofbusiness = [];
                    element.projects = [];
                });    
        
                setUsersList(result.data)
            });   
        
        
           }
        

        function UpdateTable(){
           
            
            UserService.getUserGroups(TokenData.tokenId,dataState)
        .then((result: any) => {  
           

            result.data.forEach((element:any) => { // delete when DB returns those params
               
            });    

            setList(result.data)
        });        
        

       
        
       
        }
        const EditCommandCell = (subProps: GridCellProps & EditProps) => {           
            return (
                <td>
                    <Actions>
                    {!Granted.edit ? null :
                    <ActionButton 
                        id={"Button_edit_"+subProps.dataItem.id}
                       
                        onClick={() => subProps.enterEdit(subProps.dataItem)}
                        >{IconEdit('rowButton')}
                    </ActionButton>   
                    }
                    {!Granted.delete ? null :
                    <ActionButton 
                        id={"Button_delete_"+subProps.dataItem.id}
                        
                        onClick={() => subProps.deleteConfirm(subProps.dataItem)}
                        >{IconTrash('rowButton')}
                    </ActionButton>  
                    }
                    </Actions>     
                </td>
            );
        
        };
    function MyEditCommandCell(subProps: any){ 
        return(
            <EditCommandCell {...subProps} enterEdit={enterEdit} deleteConfirm={deleteConfirm}/>
        )
        ;}

    function onDataStateChange(event: GridDataStateChangeEvent){
              
        setDataState(event.dataState)
        UpdateTable();
    }
    function handleCancelEdit(event: DialogCloseEvent){
       
       
        setOpenForm(false);
    }   

    function enterEdit(item : any){
        item.delete = false; 
        setOpenForm(true);
        setEditItem(item);
    }

    function deleteConfirm(item : any){
       item.delete = true;       
       setOpenForm(true);
       setEditItem(item);
    }

    function UpdateEditItem(item : any){
        setOpenForm(true);
        setEditItem(item);
    }
    function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>){
     console.log('values' ,values)

     console.log('users list',UsersList)

        let newList = new Array;
        if(typeof values.users !== 'undefined'){
            values.users.map((element:any) => {          
                
                newList.push({Id: UsersList[findWithAttr(UsersList, 'samAccountName', element)].id})
                
         
              })
              values.users = newList;
        }
       
        


         if(editItem.new){
             // we only add to grid view this element until we can intert into DB
             values.new = false;  
             UserService.postGroupInsertSoft(JSON.stringify({group: values}),TokenData.tokenId).then((result: any) => {            
                if (typeof result !== 'object' || result.type === 'error'){
                    console.log('error')
                }else{
                    setOpenForm(false);
                    setprevList(new Array)
                }                
             });
         }
         else if(editItem.delete){
           UserService.postGroupDelete(JSON.stringify({id: editItem.id}),TokenData.tokenId).then((result: any) => {
              setprevList(new Array)
            })
            .catch((error: any) => {console.log(error);});
           setOpenForm(false);
            
        }
        else if (TokenData.tokenId !== ''){
               
            UserService.postGroupUpdateSoft(JSON.stringify({group: values}),TokenData.tokenId).then((result: any) => {
               console.log(result)
                if (typeof result !== 'object' || result.type === 'error'){
                   console.log('error 2')
                }else{
                    
                    let raw = {...users};      
                   
                    newList = new Array;
                    raw.data.forEach(item =>{
                        if(values.id === item.id){item = {...values}}
                        newList.push(item);
                    })

                    let grouplist = {
                        total: newList.length,
                        data: newList
                    }   

                    setList(grouplist.data);
                    setOpenForm(false);

                    UpdateTable()
                    
                }
           });
        }
        
        
     }

    
        return (
            <ContentScreen id="EditDataTables">  
             <DataTableInfo>           
            <DinamicInfo Theme={Theme}>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection Theme={Theme}>User Groups Management</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo className="col-12">                            
                       
                <div id="UsersGrid">
                            
                <Toolbar className="col-12" Theme={Theme}>
                {!Granted.create ? null : 
                        <AddButton id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton>
                }            
                </Toolbar>                   
                 <Grid
                 sortable={{
                     allowUnsort: true,
                     mode: 'multiple'
                 }}
                
                 {...dataState}
                 data={List} 
                 onDataStateChange={onDataStateChange}
             >
                
                 <GridColumn field="name" title="Name" />                 
                 <GridColumn field="users" title="Users" sortable={false} cell={UsersCell} />                             
                 <GridColumn cell={MyEditCommandCell} resizable={false} width={80}/>
                 
                 
             </Grid>
                    
           
            {openForm && <EditGroupForm List={List} ListUsers={UsersList} cancelEdit={handleCancelEdit} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={editItem} />}
            
        </div>           
            
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
            </DinamicInfo> 
           </DataTableInfo>       
        </ContentScreen>
           
        );
    
}

const Toolbar = styled.div<any>({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',
        color: '#003399',
        cursor: 'pointer',
    },
    padding: '0px',
    margin: '10px 0px'
    
     }, props =>({
        '.k-button-primary, .k-button.k-primary':{
            backgroundColor: props.Theme.Corporate.darkBlue,
            borderColor: props.Theme.Corporate.darkBlue,
        },
        'svg':{
            color: props.Theme.Corporate.darkBlue,          
            fill: props.Theme.Corporate.darkBlue,   
         }
     }))

     const Actions = styled.div({
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '50px',
        alignItems: 'center',
        '.k-button':{
          padding: '5px !important'
        },
        'svg' : {
            
        },
        padding: '0px',
        margin: '-5px 0px'
    
        })      
const DinamicInfo = styled.div<any>({
    '.MuiAccordionDetails-root':{
        padding: '0px 0px 16px',
        marginBottom: '0px'
    },
    '.k-grid-content':{
        overflow: 'visible'
    },
    padding: '0px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    }

}, props =>({
    'col.k-sorted, th.k-sorted':{
        backgroundColor: props.Theme.Corporate.paleBlue,
    },
    '.k-pager-numbers .k-link.k-state-selected':{
        color: props.Theme.Corporate.blue,
        backgroundColor: props.Theme.Corporate.lightBlue,
    },
    '.k-pager-numbers .k-link':{
        color: props.Theme.Corporate.blue,
    },
    '.k-grid th':{
        backgroundColor: props.Theme.Corporate.lightBlue,
       
    },
    'th.k-header.active > div > div':{
        backgroundColor: props.Theme.Corporate.darkBlue,
    }
    
 }))
const DefineSection = styled.div<any>({
    fontSize: '125%',
    textAlign: 'left',
    
    fontWeight: 'bold'
}, props =>({
   color: props.Theme.Corporate.darkBlue
 }))
const FixedInfo = styled.div({
    marginTop: '5px',
    
    paddingBottom: '20px',
    paddingTop: '20px',
    width: '100%',    
    display: 'flex',
    justifyContent: 'space-between',
        minHeight: '100px',   
    listStyle: 'none',
    textAlign: 'left',
    
    'p':{
        color: '#605c58 !important',
        margin: '10px 0px',
        'b':{
            color: 'inherit',
            marginRight: '5px',
        }
    },      
    '> div' :{
        padding: '0px',
    },     
    'textarea':{
        width: '100%',
        minHeight: '150px',
        resize: 'none',
        fontSize: '80%',
        padding: '15px',
    },
    
    'ul':{
        margin: '0px',
        padding: '0px'
    }     ,
    padding: '0px'   
})   