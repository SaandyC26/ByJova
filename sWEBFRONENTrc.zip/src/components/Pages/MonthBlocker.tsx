import styled from "@emotion/styled";
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { State as DataState } from '@progress/kendo-data-query';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { PageDto as page } from '../../dtos/pageDto';
import { YearCommandDataDTO as yearCommandData, YearDataDTO as yearData } from '../../entities/YearDataDTO';
import YearDataService from '../../services/YearDataService';
import { Static_Change_MonthBlocker } from '../../store/slices/user';
import { HasPermision } from '../Functions/Utils';
import ContentScreen from '../Generic/ContentScreen';
import GridLoader from '../Generic/GridLoader';
import SaveBtn from '../Generic/SaveBtn';
import { DataTableInfo, DefineSection, DinamicInfo, FixedInfo } from '../Generic/Styles';

interface State {
    years: page<yearData>;
    blocked : yearCommandData[];
    dataState: DataState;
    changed : boolean;
}

interface Props {
    set? : string
}





export default function MonthBlocker (props:Props, State:State) {
    const Theme = useSelector( (state: any) => state.Theme);    
    const dispatch = useDispatch();
    const[blocked, setBlocked] = useState(new Array);
    const [Loading, setLoading] = useState(false)
    const[changed, setChanged] = useState(false);
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false});
    const [List, setList] = useState<any>(new Array)   
    const [list1Loaded, setList1Loaded] = useState(false)


    const TokenData = useSelector( (state: any) => state.tokenData);

    useEffect(() => {  
        let Permissions = {
            edit: HasPermision('Edit Locked Revenues Years'),           
        }      
        setGranted(Permissions) ;
        dispatch(Static_Change_MonthBlocker(false))
   },[PermissionCheck])

   useEffect(() => {  
   
    UpdateList()
   
},[])

function UpdateList(){
    
    YearDataService.getYearData({ 
        take: 15, 
        skip: 0,
        sort: [
            {field:"year",dir:"desc"}
        ]
        
        
        
    
    }.sort).then((result:any) => {
        let newId = 0;
        let raw1 = {...result}
        
        raw1.data = [...raw1.data]
       
        raw1.data.forEach((el:any) => {
            el.Id = newId;
            newId++;
        });
 
 
         setList(raw1); setList1Loaded(true)
        
         
 
    })
}

    

  
   
    function UpdateBox(subProps:any){
        
       
       
        let rawList = {...List}
        let newItem = rawList.data.find((el:any) => el.Id === subProps.dataItem.Id)
        newItem = subProps.dataItem;    
        
       
       
    }
  
    function Submit(subProps:any){
        setLoading(true)
        YearDataService.putYearData(TokenData.tokenId, List).then(()=>{           
            dispatch(Static_Change_MonthBlocker(false))
            setLoading(false)
        });        
       
    }

  
        return (
            <Content>                
            <ContentScreen id="MonthBlocker">
            <DataTableInfo>
                <DinamicInfo>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection>Month Blocker</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                    
                        <FixedInfo style={{backgroundColor: 'transparent', margin: '0px', padding: '0px'}} className="col-12"> 
                            
                            <div id="MonthsGrid">
                            {!Loading ? <SaveBtn Submit={Submit} Granted={Granted}/> : <SaveBtn Loading  Submit={Submit} Granted={Granted}/>}
                            
                            {list1Loaded ? 
                            <GridLoader
                            Title="BCN Invoices"
                            UpdateBox={UpdateBox}
                            Granted={Granted}
                            List={List.data.filter((el:any) => el.chargingModelType.type === 'BI')}

                            />
                            : null} 

                            {list1Loaded ? 
                            <GridLoader
                            Title="MX Invoices"
                            UpdateBox={UpdateBox}
                            Granted={Granted}
                            List={List.data.filter((el:any) => el.chargingModelType.type === 'MX')}

                            />
                            : null} 

                            {list1Loaded ? 
                            <GridLoader
                            Title="Customer Allocations"
                            UpdateBox={UpdateBox}
                            Granted={Granted}
                            List={List.data.filter((el:any) => el.chargingModelType.type === 'CA')}

                            />
                            : null} 

                            {list1Loaded ? 
                            <GridLoader
                            Title="Rebookings"
                            UpdateBox={UpdateBox}
                            Granted={Granted}
                            List={List.data.filter((el:any) => el.chargingModelType.type === 'RB')}

                            />
                            : null} 
                            
                            
                        
                        </div> 
                        </FixedInfo>
                    
                </AccordionDetails>                            
                </Accordion>
                </DinamicInfo>  
                </DataTableInfo> 
            </ContentScreen>
            </Content>
        );
    
}

const Content = styled.div<any>({
    '#MonthsGrid':{
        width: '90%'
    },
    'h1':{
        fontSize:'130%',
        fontWeight:'bold'
    },
    '.k-grid':{
        marginBottom: '25px'
    },
    '.k-link':{
        textAlign: 'center'
    },
    'input[type=checkbox]':{
        width:'15px',
        height: '15px',
        position: 'absolute',
        left: '50%',
        top: '50',
        transform: 'translate(-50%, -50%)'
    },
    '.k-grid td':{
        paddingTop: '10px',
        paddingBottom: '10px' ,
        position: 'relative',
        textAlign:'center'
    }
    
     }, props =>({
       
     }))