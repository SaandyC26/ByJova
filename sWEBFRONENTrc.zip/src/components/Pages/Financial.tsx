import React, {useState,useEffect}  from 'react';
import styled from "@emotion/styled"
import ContentScreen from '../Generic/ContentScreen'
import { useParams } from "react-router-dom";
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import DataTable from '../Generic/DataTable';
import Loading from "../Generic/Loading";
import RevenueService from '../../services/RevenueService';
import { DatePicker, Calendar } from '@progress/kendo-react-dateinputs';
import { DropDownList, MultiSelect } from '@progress/kendo-react-dropdowns';
import {MonthList} from '../Functions/Utils'
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import MDTService from '../../services/MDTService';
import {useSelector,useDispatch} from 'react-redux';
import {setFilters, setSidebarStatus}  from '../../store/slices/user'
import ExportSettings from '../Generic/ExportMultiOption'


const Today = new Date();
const SpecialColumns = [
    {Name: 'Month', Type: 'Unfiltered'},{Name: 'Alloc %', Type: 'Percentage'}, 
    {Name: 'Debit Value', Type: 'CHF'},{Name: 'Credit Value', Type: 'CHF'},
    {Name: 'Total CHF', Type: 'CHF'},{Name: 'Total CHF VAT', Type: 'CHF'},
    {Name: 'Total', Type: 'EUR'}
]

const Footers = [
    {Name:'Total', Type: 'Sum', Icon: 'EUR'},
    {Name:'Total CHF VAT', Type: 'Sum', Icon: 'CHF'}
]

export default function Financial(){  
    const Theme =  useSelector((state: any) => state.Theme) ; 
    const { slug } = useParams(); 
    const TokenData = useSelector((state: any) => state.tokenData);
    const sidebarStatus = useSelector((state: any) => state.userData.sidebarDeploy);
    const FiltersSet = useSelector((state: any) => state.userData.filters);
    const [TableDef,setTableDef] = useState(['Charging Model', 'BU Code', 'Line of Service', 'Project', 'CC Customer','Month (MMM)','Total EUR', 'Description']);
    const [List, setList] = useState(new Array)
    const [isLoading, setisLoading] = useState(true);
    const [HasFilters, setHasFilters] = useState(false);
    const [Query, setQuery] = useState('');  
    const [FilterYear, setFilterYear] = useState(Today.getFullYear())
    const [FilterMonth, setFilterMonth] = useState(MonthList[Today.getMonth()])
    const [calendarOpen, setCalendarOpen] = useState(false);
    const [FilterLOB, setFilterLOB] = useState(new Array);
    const [FilterCustomer, setFilterCustomer] = useState(null);
    const [ListLOB, setListLOB] = useState(new Array);
    const [ListCustomers, setListCustomers] = useState(new Array);  
    const [TableSizes, setTableSizes] = useState(new Array);
   
    let dispatch = useDispatch();


    const OptionList= [
        {
            Name: 'Export',
            Action: () => { ExportExcel()}
        },
        {
            Name: 'Export with past and forecast',
            Action: () => { ExportExcel(true)}
        } 
    ]
   
    function YearCalendar(){
        
        return <Calendar min={new Date('2018-01-01')}  onChange={(e)=>{setFilterYear(e.value.getFullYear()); setCalendarOpen(false) }} defaultActiveView="decade"  bottomView="decade" />
    }
    useEffect(() => {
    MDTService.postRequestLineOfBusiness(TokenData.tokenId).then((result: any) => { 
                                  
        let NewList =  new Array;
        result.map((item:any) => {
            NewList.push(item.name);
           
        });
        setListLOB(NewList);
       
    });
    MDTService.postRequestCostCenter(TokenData.tokenId).then((result: any) => { 
                                  
        let NewList =  new Array;
        result.map((item:any) => {
           if(item.types.includes('Internal')) {NewList.push(item.code);}
           
        });
        setListCustomers(NewList);
       
    });

    
    if(sidebarStatus !== 'Open'){dispatch(setSidebarStatus('Open'));}
    },[])

    useEffect(() => {  
        setisLoading(true);
        switch(slug){
            case 'servizurich_intercompany_charges-out' :  setQuery('GetBarcelonaInvoicesQuery');  
            setTableDef(['Month', 'Charging Model', 'Cost Center', 'BU Code', 'Project','Description', 'CC Customer' ,'Total']) ;
            setTableSizes([80,130,110,90,125,0,125,90])
            break;
            case 'rebooking' :  setQuery('GetRebookingsQuery');  
            setTableDef(['Month', 'Charging Model', 'Revenue or Cost Element',  'Cost Center or Internal Order', 'Debit Value','Credit Value','Description']) ;
            setTableSizes([80,130,200,200,150,150,0])
            break;
            case 'customer_allocation' : setQuery('GetCustomersAllocationsQuery'); 
            setTableDef(['Month', 'Charging Model', 'Line of Business', 'Customer', 'Service Description', 'Internal CC', 'BU Code', 'Alloc %','Total CHF', 'Total CHF VAT']) ;
            setTableSizes([80,130,200,130,0,130,130,130,130,130])
            break;
           
        }
    },[slug])  

    useEffect(() => { 
        if(FilterLOB !== null &&  FilterCustomer !== null){           
            RefreshData()
        }
     },[Query,FilterYear,FilterMonth, FilterLOB,FilterCustomer])
    

    useEffect(() => { 
        if(FiltersSet.rebookings !== null && FiltersSet.rebookings !== ""){
            setFilterCustomer(FiltersSet.rebookings)
        }
        if(FiltersSet.barcelona !== null && FiltersSet.barcelona !== ""){
            setFilterLOB(FiltersSet.barcelona)
        }
        
     },[FiltersSet])


     useEffect(() => {         
        
        if( typeof ListCustomers[0] !== 'undefined' 
            && ListCustomers[0] !== ''
            && typeof ListLOB[0] !== 'undefined'  
            && ListLOB[0] !== ''){              
            setFilterCustomer(ListCustomers[0]);
            setFilterLOB( ListLOB);  
            setHasFilters(true)   ; 
        }
        
     },[ListCustomers,ListLOB])

function RefreshData(){
    if(Query !== ''){
        setisLoading(true);
        let newList = new Array;  
        let Total = 0;          
        RevenueService.GetFinancial({query: Query, year: FilterYear, month: FilterMonth, FilterLOB: FilterLOB, FilterCustomer: FilterCustomer}).then((response: any) => {
            response.results.forEach((element:any) => {
                let Item = {};
                switch(slug){
                    case 'servizurich_intercompany_charges-out' : 
                        Item = {
                            'Month' : element.shortMonth,                       
                            'Charging Model' : element.chargingModelCode,
                            'Cost Center' : element.internalCostCenterPerCostCode,
                            'BU Code' : element.businessUnitCode,                                
                            'Project': element.projectName, 
                            'Description' : element.description,
                            'CC Customer' : element.customerCostCenterCode,                      
                            'Total' : element.totalEur
                        }
                        Total = Total + element.totalEur;
                    break;
                    case 'rebooking' :
                        Item = {
                            'Month' : element.shortMonth,                       
                            'Charging Model' : element.chargingModelCode,
                            'Revenue or Cost Element' : element.revenueOrCostElement,
                            'Cost Center or Internal Order' : element.customerCostCenterCode,
                            'Debit Value' : element.debitValueChf,
                            'Credit Value': element.creditValueChf, 
                            'Description' : element.description
                        }
                    break;
                    case 'customer_allocation' :
                        Item = {
                            'Month' : element.shortMonth,                       
                            'Charging Model' : element.chargingModelCode,
                            'Line of Business' : element.lineOfBusinessName,
                            'Customer': element.customerName,
                            'Service Description': element.serviceDescription,
                            'BU Code' : element.businessUnitCode,
                            'Internal CC' : element.internalCostCenterPerCostCode ,
                            'Alloc %' : element.percentage,
                            'Total CHF': element.totalChf, 
                            'Total CHF VAT' : element.totalChfVat
                        }
                        Total = Total + element.totalChfVat;
                    break;
                    
                }
                
                newList.push(Item);
            });

           
            setList(newList)
            setisLoading(false)
        })
    }
    


}

function UpdateFilter(key:string, value:string){
    console.log(value)
    dispatch(setFilters({key:key,value:value}));
}

function ConditionalFilters(props:any){    
    switch(slug){
        case 'servizurich_intercompany_charges-out' :         
            return(
                <li>                
                <MultiSelect id="Financial_Filters_LOB"
                        data={ListLOB}
                        onChange={(e)=> {UpdateFilter('barcelona',e.value)}}
                        defaultValue={FilterLOB}
                    />
                </li>
            )
       
        case 'rebooking' :           
            return(
                <li>
                <DropDownList id="Financial_Filters_Customer" name="Filter_Customer" onChange={(e)=> {UpdateFilter('rebookings', e.value); }} data={ListCustomers} defaultValue={props.Filters.rebookings || ListCustomers[0]} />
                </li>
            )
        
        
    }
    return null
}  


function LoadStatus(){
    if(isLoading || !HasFilters){
        return (<Loading/>)
    }
    else if(!isLoading && HasFilters){
        return(
            <DataTable Footers={Footers} SpecialColumns={SpecialColumns} Editable={false} DataSet={List} TableDef={TableDef} TableSizes={TableSizes}/>
        )
    }
    return null

}

function ExportExcel(PastFuture?:boolean){
    
    RevenueService.DownloadFinancial({query: Query.replace('Get','Export'), PastFuture: PastFuture,  year: FilterYear, month: FilterMonth, FilterLOB: FilterLOB, FilterCustomer: FilterCustomer}).then((result: [Blob, string] | (string | Blob)[]) => {
        console.log(result);
        const url = window.URL.createObjectURL(new Blob([result[0]]));
            const a = document.createElement('a');
            a.href = url;
            a.download = result[1] as string;
            a.click();
           
    })
}



  
    return(
        
        <ContentScreen id="Financial">               
                 <DinamicInfo>      
                 {typeof slug === 'undefined' ?  
                 <div> 
                <Accordion expanded={true} >
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection Theme={Theme}>Financial Management</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                    <MoreServices Theme={Theme}><span></span><svg width="20" height="23">
                        <path  d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
                        </svg><p>Pick one table</p>
                     </MoreServices>
                    </AccordionDetails>                            
                </Accordion>
                     
                     
                 </div>
                 :
                 <Accordion expanded={true} >
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection Theme={Theme}>Financial Management {slug.replaceAll('_',' ').replace('zurich','Zurich')}</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo className="col-12">                         
                            <Filters>                            
                                <li onClick={(e)=>{
                                    let target = (e.target as HTMLElement);                                   
                                    if( target.tagName === 'INPUT' || target.className === 'k-icon k-i-calendar'){setCalendarOpen(!calendarOpen)}                                   
                                   
                                    }}>
                                <ClickAwayListener onClickAway={()=>{setCalendarOpen(false)}}>
                                    <div className="picker" style={{minWidth: '100px'}}>
                                    <DatePicker                            
                                        id="Financial_Filters_Year"                                        
                                        value={new Date(FilterYear+'-01-01')}                                      
                                        calendar={YearCalendar}                       
                                        format={{year: "numeric"}} 
                                        show={calendarOpen}                                                                                                                     
                                        />  
                                                                
                                    
                                    </div>
                                </ClickAwayListener>
                                </li>
                                
                                <li>
                                <DropDownList id="Financial_Filters_Month" onChange={(e)=> {setFilterMonth(e.value)}} data={MonthList} defaultValue={MonthList[Today.getMonth()]} />
                                </li>
                                <ConditionalFilters Filters={FiltersSet}/>
                                 <li className="Export">
                                    <ExportSettings Title="Export to Excel" OptionList={OptionList}/>
                                </li>
                                {
                                    /*
                                    <li className="Export">
                                        <button onClick={ExportExcel} style={{backgroundColor: Theme.Corporate.darkBlue}} className="k-button k-primary rounded">Export to Excel</button>
                                    </li>
                                    */
                                }
                            </Filters>   
                            {LoadStatus()}                              
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
                }   
                
            </DinamicInfo>  
        </ContentScreen>
    )
}

const Filters = styled.ol({   
    listStyle: 'none',
    padding: '0px 0px',
    margin: '0px',
    paddingBottom: '20px',
    backgroundColor: 'white',
    display: 'flex',
    '.Export':{
        width: '100%',
        display:'flex',
        justifyContent: 'flex-end'
    },
    '.k-multiselect':{
        minWidth: '450px'
    },
    '.k-datepicker':{
        width: 'auto'
    },  
    '.k-dropdown':{
        width: '130px'
    },
    '.picker':{
       
        '.k-picker-wrap':{ width: '75px'}
    },
    'li':{
        margin: '0px 15px',
        ':first-of-type':{
            marginLeft:' 0px'
        }
    }
})

const DinamicInfo = styled.div({
    '.MuiAccordionDetails-root':{
        padding: '0px 0px 16px',
        marginBottom: '0px'
    },
    padding: '0px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    }

})

const DefineSection = styled.div<any>({
    fontSize: '125%',
    textAlign: 'left',   
    fontWeight: 'bold',
    textTransform: 'capitalize'
}, props =>({
    color: props.Theme.Corporate.darkBlue,
}))
const FixedInfo = styled.div({
    marginTop: '5px',
    backgroundColor: '#f5f7f7',
    paddingBottom: '20px',
    paddingTop: '20px',
    width: '100%',    
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    minHeight: '100px',   
    listStyle: 'none',
    textAlign: 'left',
    '*': {color: 'black'},
    'p':{
        color: '#605c58 !important',
        margin: '10px 0px',
        'b':{
            color: 'inherit',
            marginRight: '5px',
        }
    },      
    '> div' :{
        padding: '0px',
    },     
    'textarea':{
        width: '100%',
        minHeight: '150px',
        resize: 'none',
        fontSize: '80%',
        padding: '15px',
    },
   
    'ul':{
        margin: '0px',
        padding: '0px'
    }     ,
    padding: '0px'   
})   

const MoreServices = styled.div<any>({
    fontSize:'40px',
    position: 'absolute',
    top: '30px',
    display: 'flex' ,
    height: '97px',
    width: '300px',
    justifyContent: 'center',
    alignItems: 'center',
    left: '5px',
    'p':{
        fontSize: '12px',
        lineHeight: '1',
        margin: '0px',
        marginTop: '25px',
        textAlign:'center',       
      
        fontWeight: 'bold',
        marginLeft: '-200px'
    },
   'span:first-of-type':{
        position: 'absolute',
        width: '26px',
        height: '4px',
        
        marginRight:'6px',
        left: '0px'
   },
   'svg':{
      position: 'absolute',
      transform: 'scale(2) rotate(-180deg)',
      left: '-3px',
      top:'38px'
   }
}, props =>({
    'p':{
        color: props.Theme.Corporate.darkBlue,
    },
    'span:first-of-type':{
        backgroundColor: props.Theme.Corporate.darkBlue
    },
    'svg':{
        fill: props.Theme.Corporate.darkBlue
    }
}))