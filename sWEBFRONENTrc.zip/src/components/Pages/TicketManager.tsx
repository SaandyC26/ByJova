import React, {useState,useEffect}  from 'react';
import ContentScreen from '../Generic/ContentScreen'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {DinamicInfo,DefineSection,DataTableInfo} from '../Generic/Styles';
import UserService from '../../services/UserService';
import DataTable from '../Generic/DataTable2';
import Loading from "../Generic/Loading";
import {useSelector} from 'react-redux';
import {HasPermision,SortByProp} from '../Functions/Utils';
import { Checkbox } from "@progress/kendo-react-inputs";
import styled from "@emotion/styled";
import ExpandComments from '../Generic/Expand_Comments'
import { formatDate } from '@telerik/kendo-intl';


export default function TicketManager(){      
    const Theme =  useSelector((state: any) => state.Theme) ; 
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState<any>({Addable: false});
    const [OnlyMimes, setOnlyMimes] = useState(false);
    const [IncludeHidden, setIncludeHidden] = useState(false)

    const SpecialFields = {
               
        'type': {type: 'combobox', values: [{key:'Suggestion'},{key:'Improvement'},{key:'Incident'}], display: 'key', key: 'key',alters: 'TypeVal'},
        'description':{ type: 'textarea', required : true},
        'status': {type: 'combobox', values: [{key:'Analysis'},{key:'Backlog'},{key:'Implementation'},{key:'Rejected'},{key:'Completed'}], display: 'key', key: 'key',alters: 'StatusVal'},
        'summary': {type: 'text', required: true},
        'reference': {type: 'externalLink'}
        
    };

   const CustomFilters = [
       {field:'created', type: 'date'},
       {field: 'updated', type: 'date'}
    ]; 

   const HiddenFieldsEditNew = ['status','reference','samAccountName','created','updated','id','reference']
   const HiddenFieldsTable = ['id']
   const HiddenFieldsEdit = ['id', 'created','updated','samAccountName']
   const ModItem = [{Name: 'description', Value: ''}]

   const ConditionalEdit = {Field: 'links', Valid: "update", Prop: 'rel'}
   const ConditionalDelete = {Field: 'links', Valid: "delete", Prop: 'rel'}
    
    useEffect(() => { 
       
        let Permissions = {
            Addable: HasPermision('Write Ticket'),
                      
        }      
      
        setGranted(Permissions) ;
    },[PermissionCheck])

    const [Tickets, setTickets] = useState(new Array);     
    const [isLoading, setisLoading] = useState(false);
    const TableDef = ['type', 'status','summary','description','reference','samAccountName','created','updated','id'];
    
       
    useEffect(() => {
        UpdateTable()
       
    },[OnlyMimes,IncludeHidden])

    function UpdateTable(){
        setisLoading(true);               
        
        UserService.Tickets_Get(OnlyMimes,IncludeHidden)
        .then((raw: any) => {    
            let result:any = {...raw}
            if(result.data.length > 6){
            result.data[0].links[1].properties = ['summary']
            delete result.data[3].links[1]
            delete result.data[6].links[0]
        }
        let NewArr:any = new Array();

        result.data.forEach((element:any) => {
            let NewItem:any = {...element, 
                created : formatDate(new Date(element.created), "d"),
                updated: formatDate(new Date(element.updated), "d"),
                expandCall: ExpandComments,              
                UpdateFunc: Control.Update,
                expandType: 'comments', 
                expandContent:[{listfor:'comments', list: [{Username:'hola', DateTime: '11', Text: 'que ase?'}]}]
        }
            NewItem.links.map((el:any) => {               
                if(el.properties !== null){                    
                el.properties = el.properties.map((el2:any) => {
                   return el2.toLowerCase();
                });}
            });

            
            NewArr.push(NewItem);
        }); 

           
            NewArr.length > 0 ?  setTickets(SortByProp(NewArr,'created')) : setTickets([]) ; 
            //result.data.length > 0 ? setTickets(result.data) : setTickets(new Array)
            setisLoading(false);
        });

    }

    const Control = {
        Add : function (props:any) {            
            UserService.Tickets_Add(props.summary, props.description, props.TypeVal || "Suggestion")
            .then(() => {UpdateTable()});
        },
        Update : function (props:any) {
            let Modded = {...props};
            Modded.status = props.StatusVal || props.status || "Analysis";
            Modded.type = props.TypeVal || props.type || "Suggestion";
            delete Modded.TypeVal;
            delete Modded.StatusVal;
            delete Modded.expandCall;
            delete Modded.expandContent;
            delete Modded.UpdateFunc;
            
            UserService.Tickets_Update(Modded)
            .then(() => {UpdateTable()});
        },
        Delete : function (props:any){
            UserService.Tickets_Delete(props.id)
            .then(() => {UpdateTable()});
        }
    }

   
    return(
        
        <ContentScreen id="TicketManager">  
        <DataTableInfo>                             
            <DinamicInfo>                   
                    <Accordion defaultExpanded>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel2a-content" id="panel2a-header">
                            <DefineSection>Tickets</DefineSection>                            
                        </AccordionSummary>
                            <Toolbar Theme={Theme}>
                                <Checkbox label={"Only Mines"} onChange={()=>{setOnlyMimes(!OnlyMimes);}} />
                                <Checkbox label={"Include Hidden / Closed"} onChange={()=>{setIncludeHidden(!IncludeHidden);}} />
                            </Toolbar> 
                        <AccordionDetails>
                           

                            {
                                
                                isLoading ? <Loading/> : 
                                <DataTable 
                                    ConditionalDelete={ConditionalDelete} 
                                    ConditionalEdit={ConditionalEdit} 
                                    ColumnableNew={1} 
                                    ModItem={ModItem} 
                                    HiddenFieldsEditNew={HiddenFieldsEditNew} 
                                    HiddenFieldsTable={HiddenFieldsTable}
                                    HiddenFieldsEdit={HiddenFieldsEdit}
                                    Virtual={false} 
                                    SpecialFields={[SpecialFields]} 
                                    CallBackAdd={Control.Add}  
                                    CallBackUpdate={Control.Update}
                                    CallBackDelete={Control.Delete}
                                    Addable={Granted.Addable} 
                                    Columnable={2} 
                                    Editable 
                                    DataSet={Tickets} 
                                    TableDef={TableDef} 
                                    TableSizes={[]}
                                    forcedText={{new: "New Ticket", delete: "Delete Ticket", update: "Edit Ticket"}}
                                    CustomFilters={CustomFilters}
                                    Expand
                                /> 
                            }                 
                            
                        </AccordionDetails>
                        
                    </Accordion>
                       
                    
                   
                </DinamicInfo>
                </DataTableInfo>  
        </ContentScreen>
    )
}

const Toolbar = styled.div<any>({
    width: '100%',
    marginTop: '0px',
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    'label' : {
        marginRight: '15px'
    }
    
     }, props =>({
         '.k-button-primary, .k-button.k-primary':{
             backgroundColor: props.Theme.Corporate.darkBlue,
             borderColor: props.Theme.Corporate.darkBlue,
         },
         'svg':{
             color: props.Theme.Corporate.darkBlue,          
             fill: props.Theme.Corporate.darkBlue,   
          }
      })) 

 