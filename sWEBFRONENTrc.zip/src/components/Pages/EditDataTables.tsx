import React, {useState,useEffect}  from 'react';
import {useSelector} from 'react-redux';
import ContentScreen from '../Generic/ContentScreen'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {HasPermision} from '../Functions/Utils'
import {DataTableInfo,DefineSection,FixedInfo} from '../Generic/Styles';
import DataTable from '../Generic/DataTable';
import Loading from "../Generic/Loading";
import MDTService from '../../services/MDTService';



export default function EditDataTables(){    
    const OpenTable = useSelector((state: any) => state.MasterData.Table);
    const TokenData = useSelector((state: any) => state.tokenData);
    const [List, setList] = useState(new Array);
    const [isLoading, setisLoading] = useState(false);
    const [TableDef,setTableDef] = useState(new Array);
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false, create: false, delete: false});
    const HiddenFieldsTable = ['planningItApps']
    const HiddenFieldsEdit = ['planningItAppsIds']   
    const [FieldValues, setFieldValues] = useState<any>(new Array)
    const [Crossing,setCrossing] = useState<any>(new Array)
    
   

    const SpecialFields = {
        'type': {type: 'combobox', 
        values: FieldValues, 
        display: 'key', key: 'key', alters: 'type', subname: 'type', tableShow: 'object'},
        
        'businessUnit': {type: 'combobox', 
        values: FieldValues, 
        display: 'key', key: 'key', alters: 'businessUnit', subname: 'name', tableShow: 'object'},

        'function': {type: 'combobox', 
        values: FieldValues, 
        nulleable: true,
        display: 'key', key: 'key', alters: 'function', subname: 'name', tableShow: 'object'},

        'planningItApps':{
            type: 'ObjectList', title: 'Apps', DefList: ['Prefix', 'AppId', 'Name'], ReqList : ['AppId']
        }, 
        'enabled' : {type : 'boolean'}
        
    }

    useEffect(() => {loadMDTs().then(() => { UpdateTable()})},[OpenTable])



    useEffect(() => {  
        
        let Permissions = {
            edit: OpenTable.Name === 'Product' ? false : HasPermision('Manage Master Data'),
            create: OpenTable.Name === 'Product' ? false : HasPermision('Manage Master Data'),
            delete: OpenTable.Name === 'Product' ? false : HasPermision('Manage Master Data'),
        }      
        setGranted(Permissions) ;
   },[PermissionCheck,OpenTable])
    
    

    function UpdateTable(){
        setisLoading(true);       
        
        MDTService.postRequestMasterDataTabletoEdit(OpenTable.Request,TokenData.tokenId).then((result: any) => {                         
            var tempList =  new Array;
            result.masterDatas.map((Item:any) => {                
                let newItem = Item;
                newItem.name = typeof Item.name !== 'undefined' ? Item.name : Item.code;                
                tempList.push(newItem);      
            });
            setList(tempList);            
                      
            let KeysList = new Array;
            if(result.masterDatas.length > 0){
                for (const [key] of Object.entries(result.masterDatas[0])) {
                    if(key!=='id'){KeysList.push(key);}
                }
            }else{
                result.fields.map((key:any) => {
                    KeysList.push(key.toLowerCase())
                })
                
            }
           
            setTableDef(KeysList)
            setisLoading(false); 
        });
    }
   
    function loadMDTs(){
        return new Promise((resolve, reject) => {
            
        let crossed = new Array;
       
        if (TokenData.tokenId !== ''){
            
                switch(OpenTable.Name){
                    case 'Charging model' :                     
                        MDTService.postRequestChargingModelType(TokenData.tokenId).then((result: any) => {               
                            setCrossing(result)
                            setFieldValues(result.map((el:any) => {return {key: el.type}} ))
                           
                        });
                    break
                    case 'Cost center' :                     
                    MDTService.postRequestBusinessUnit(TokenData.tokenId).then((result: any) => {    
                                  
                        setCrossing(result)
                        setFieldValues(result.map((el:any) => {return {key: el.name}} ))
                       
                    });
                break
                    case 'Customer':
                        MDTService.postRequestCustomerFunctions(TokenData.tokenId).then((result: any) => {               
                            setCrossing(result)
                            setFieldValues(result.map((el:any) => {                                
                                return {key: el !== null ? el.name : ''}
                               
                            } ))                            
                        });
                    break
                    case 'Project':
                        setFieldValues([{key:'Waterfall'},{key:'Agile'},{key:'Hybrid'},{key:'NA'}])
                    break
                }
                
               
               
                
                
                
              
            
        }
        resolve(crossed)
        })
    }

    return(
        
        <ContentScreen id="EditDataTables">                   
            <DataTableInfo>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection>MasterData Tables {OpenTable.Name}</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo style={{backgroundColor: 'transparent'}} className="col-12">    
                            {isLoading ? 
                            <Loading/> 
                            : null }

                            {!isLoading ? 
                            <DataTable CrossRef={Crossing} HiddenFieldsEdit={HiddenFieldsEdit} SpecialFields={[SpecialFields]} HiddenFieldsTable={HiddenFieldsTable} callBack={UpdateTable} Addable={Granted.create} Editable={Granted.edit} DataSet={List} TableDef={TableDef} TableSizes={[]}/>
                            : null}                        
                            
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
            </DataTableInfo>        
        </ContentScreen>
    )
}
