import React, {useState,useEffect}  from 'react';
import ContentScreen from '../Generic/ContentScreen'
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {DinamicInfo,DefineSection,FixedInfo} from '../Generic/Styles';
import { useCookies } from 'react-cookie';
import UserService from '../../services/UserService';
import DataTable from '../Generic/DataTable';
import Loading from "../Generic/Loading";

export default function Profile(){    
    
    const BaseRole = [{name: 'Unassigned', permissions: 'none'}];
    const [Item, setItem] = useState<any>(new Object); 
    const [Roles, setRoles] = useState(BaseRole);
    const [cookies] = useCookies();  
    const [isLoading, setisLoading] = useState(false);
    const TableDef = ['name', 'permissions'];
       
    useEffect(() => {
        setisLoading(true);        

        UserService.getMyUser()
        .then((result: any) => {  
           
            setItem({...result.user});   
            if(result.user.roles.length > 0){
                let List = result.user.roles;
                List.forEach((element:any) => {
                    
                    element.permissions = element.permissions.map((sub:any) => {return sub.name});
                });
                setRoles(result.user.roles); 
            }
                      
           console.log(result);
           setisLoading(false);
        });
    },[cookies])
   
    return(
        
        <ContentScreen id="Profile">                       
            <DinamicInfo>
                    <Accordion defaultExpanded>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                            <DefineSection>User Data</DefineSection>
                        </AccordionSummary>
                        <AccordionDetails>
                            {isLoading ? <Loading/> : 
                            <FixedInfo  className="col-12">
                            <div className="col-6">                                                    
                                        <p><b>User name:</b>{Item.samAccountName}</p>
                                        <p><b>Email:</b>{Item.mail}</p>                                        
                                        <p><b>Name:</b>{Item.displayName}</p>                            
                            </div>
                            <div className="col-5">                                                    
                                        <p><b>Domain:</b>{Item.domain}</p>                                                                 
                            </div>                    
                            </FixedInfo>
                            }
                            
                        </AccordionDetails>
                        
                    </Accordion>
                    <Accordion defaultExpanded>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel2a-content" id="panel2a-header">
                            <DefineSection>Roles</DefineSection>
                        </AccordionSummary>
                        <AccordionDetails>
                            
                            {
                                
                                isLoading ? <Loading/> : <DataTable Editable={false} DataSet={Roles} TableDef={TableDef} TableSizes={[]}/> 
                            }                 
                            
                        </AccordionDetails>
                        
                    </Accordion>
                       
                    
                   
                </DinamicInfo>
        </ContentScreen>
    )
}



 