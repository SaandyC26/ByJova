import React,  {  useState, useEffect } from 'react';
import styled from "@emotion/styled";
import RevenueService from '../../services/RevenueService';
import {useSelector} from 'react-redux';
import { DateRangePicker } from '@progress/kendo-react-dateinputs';
import { MultiSelect } from '@progress/kendo-react-dropdowns';
import LoadSpinner from "../Generic/Loading"
import MDTService from '../../services/MDTService';
import ContentScreen from '../Generic/ContentScreen'

import {
    Chart,
    ChartValueAxis,
    ChartValueAxisItem,
    ChartSeries,
    ChartSeriesItem,  
    ChartCategoryAxis,
    ChartCategoryAxisItem,
    ChartCategoryAxisTitle,
    ChartLegend,
    ChartTooltip,
    ChartSeriesItemTooltip        
    
} from '@progress/kendo-react-charts';
import 'hammerjs';



const FormatCHF = "{0:N0} CHF";

const ObjectMonths = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

function Charts(){   
    const TokenData = useSelector( (state: any) => state.tokenData); 
    const Theme =  useSelector((state: any) => state.Theme) ;
    const [loading, setLoading] = useState(true); 
    const [Series, setSeries] = useState<any>(new Object);
    const CleanSeries:any = new Object;
    const [SeriesCustomers, setSeriesCustomers] = useState(new Array); 
    const [SeriesProducts, setSeriesProducts] = useState(new Array); 
    const ThisYearStart = new Date().setMonth(0);  
    const ThisYearEnd = new Date().setMonth(11);  
    const [DateRanges, setDateRanges] = useState({start: new Date(ThisYearStart), end: new Date(ThisYearEnd)})
    const [ChartDates, setChartDates] = useState(new Array);
    const [LOBfilterOptions, setLOBfilterOptions] = useState(new Array)
    const [LOBfilter, setLOBfilter] = useState(new Array)
    const QuarterCalendarOn = false

    useEffect(() => { 
        setLoading(true)
        RefreshChart()       
       
      }, [DateRanges,LOBfilter]);

      useEffect(() => { 
        let LOBfilterList = new Array; 
        
        MDTService.postRequestLineOfBusiness(TokenData.tokenId).then((results: any) => { 
            results.map((element:any) => {
                if(!LOBfilterList.includes(element.name))
                    {LOBfilterList.push(element.name)}
            })

            setLOBfilterOptions(LOBfilterList);
            setLOBfilter(LOBfilterList);
            
           
        });
        
         
       
      }, []);

      useEffect(() => { 
        UpdateRange({start: new Date(ThisYearStart),end:new Date(ThisYearEnd) })    
        
      }, []);



function RefreshChart(){
    RevenueService.postRequest('',TokenData).then((results:any) => {
       
        let LOBSeries = {...CleanSeries}; 
        let CustomerSeries = {...CleanSeries};  
        let ProductSeries = {...CleanSeries}; 
              
        results.revenues.map((element:any) => {
            let YearToDate = new Date(element.year+'-01-01');   
            
            if(
                // date filter
                YearToDate.getFullYear() >= DateRanges.start.getFullYear() 
                && YearToDate.getFullYear() <= DateRanges.end.getFullYear()
                && LOBfilter.includes(element.lineOfBusinessName) 
                // LOB filter
                
            ){              
                
                // Chart 1            
                if(!Object.keys(LOBSeries).includes(element.lineOfBusinessName)){ 
                    LOBSeries[element.lineOfBusinessName] = new Array;                   
                }
                for(let i = 1; i < 13; i++){                    
                    if(ChartDates.includes(element.year+'-'+i)){
                        let amount = element[ObjectMonths[i-1]].amount;       
                        if (amount !== null){  
                            if(typeof LOBSeries[element.lineOfBusinessName][ChartDates.indexOf(element.year+'-'+i)] === 'undefined'){
                                LOBSeries[element.lineOfBusinessName][ChartDates.indexOf(element.year+'-'+i)] = amount
                            }else{
                                LOBSeries[element.lineOfBusinessName][ChartDates.indexOf(element.year+'-'+i)] = parseInt(LOBSeries[element.lineOfBusinessName][ChartDates.indexOf(element.year+'-'+i)]+amount)
                            }             
                        
                        }
                    }
                }
                              
               // Chart 2               
                if(!Object.keys(CustomerSeries).includes(element.customerName)){                    
                    CustomerSeries[element.customerName] = new Array;
                }
                for(let i = 1; i < 13; i++){    
                    if(ChartDates.includes(element.year+'-'+i)){
                        let amount = element[ObjectMonths[i-1]].amount; 
                        if (amount !== null){ 
                            if(typeof CustomerSeries[element.customerName][0] === 'undefined'){
                                CustomerSeries[element.customerName][0] = amount ;
                            }else{
                                CustomerSeries[element.customerName][0] = parseInt(CustomerSeries[element.customerName][0] + amount)
                            }
                           
                         }
                    
                    }
                 }
                 // Chart 3               
                if(!Object.keys(ProductSeries).includes(element.productName)){                    
                    ProductSeries[element.productName] = new Array;
                }
                for(let i = 1; i < 13; i++){    
                    if(ChartDates.includes(element.year+'-'+i)){
                        let amount = element[ObjectMonths[i-1]].amount; 
                        if (amount !== null){ 
                            if(typeof ProductSeries[element.productName][0] === 'undefined'){
                                ProductSeries[element.productName][0] = amount
                            }else{
                                ProductSeries[element.productName][0] = parseInt(ProductSeries[element.productName][0] + amount) 
                            }
                            
                         }
                    
                    }
                 }
            }
        });

       
       
        setLoading(false) 
        setSeries(LOBSeries)  
        setSeriesCustomers(CustomerSeries);
        setSeriesProducts(ProductSeries);
        setLoading(false)
    })
}

function UpdateRange(value:any){
    if(value.end !== null){
        setDateRanges({start: value.start, end: value.end })
        let List = new Array;   
        let Start = value.start
        let End = value.end
        let InitYear = Start.getFullYear(); let EndYear = End.getFullYear();
        let InitMonth = Start.getMonth(); let EndMonth = End.getMonth();
        let CurrentYear = InitYear; let CurrentMonth = InitMonth;

        List.push(CurrentYear+'-'+parseInt(CurrentMonth+1))
    
        if(InitYear !== EndYear || InitMonth !== EndMonth){populate();}else{
            setChartDates(List)
        }
        
        function populate(){           
            if(CurrentMonth === 11){ CurrentMonth = 0; CurrentYear = CurrentYear+1;}
            else{CurrentMonth = CurrentMonth +1;}
            List.push(CurrentYear+'-'+parseInt(CurrentMonth+1))
            if(CurrentMonth !== EndMonth || CurrentYear !== EndYear){populate();}
            else{setChartDates(List)}
        }
    }
    // set Chart 1 date labels
    

    

    
}


    return (
       
        <ContentScreen id="Charts">           
            <ToolBar id="Filter_Tools" Theme={Theme}>   
                    <li className="">
                        {!QuarterCalendarOn ? <DateRangePicker 
                        id="Filters_DateRange" 
                        onChange={(e)=>{UpdateRange(e.value)}}
                        defaultValue={{start: new Date(ThisYearStart) , end: new Date(ThisYearEnd)}}                                      
                        calendarSettings={{
                            bottomView: 'year',
                            topView: 'decade',
                            views: 2
                            
                        }}
                        format={{
                                year: "numeric",
                                month: "short"                            
                            }} />:
                        <DateRangePicker 
                        id="Filters_DateRange" 
                        onChange={(e)=>{UpdateRange(e.value)}}
                        defaultValue={{start: new Date(ThisYearStart) , end: new Date(ThisYearEnd)}}                   
                        calendarSettings={{
                            bottomView: 'year',
                            topView: 'decade',
                            views: 2,
                        }}
                        format={{
                                year: "numeric",
                                month: "short"
                            }} /> }
                    </li> 
                                
                    <li className="LobFilters"><MultiSelect id="Filters_LOB"
                            data={LOBfilterOptions}
                            onChange={(e)=> {setLOBfilter(e.value)}}
                            defaultValue={LOBfilterOptions}
                        /></li>
                        
                </ToolBar>
            <div className="row">
                    <div className="col-12 mb-3 mt-lg-0 text-center text-lg-left">
                    {loading ? <LoaderHolder><LoadSpinner/></LoaderHolder>: 
                    <Chart>  
                        <ChartLegend position="bottom"/>                       
                        
                        <ChartValueAxis>
                            <ChartValueAxisItem labels={{ format: FormatCHF}} />
                        </ChartValueAxis>
                        <ChartLegend visible={true} position="bottom" />
                            <ChartTooltip />
                            <ChartCategoryAxis>
                                <ChartCategoryAxisItem categories={ChartDates} maxDivisions={6} labels={{ format: 'd', rotation: 'auto' }}>
                                    <ChartCategoryAxisTitle text="Months" />
                                </ChartCategoryAxisItem>
                            </ChartCategoryAxis> 
                                <ChartSeries>
                                {
                                    Object.entries(Series).map((element:any,index:any) => {  
                                        return (
                                            <ChartSeriesItem key={element[0]} type="column" name={element[0]} stack={true} data={element[1]} >
                                                <ChartSeriesItemTooltip format={FormatCHF}  />
                                            </ChartSeriesItem>
                                        )
                                    })
                                }
                                </ChartSeries>
                        </Chart> }
                        
                    </div>
                    <div className="col-12 mb-3 mt-lg-0 text-center text-lg-left">
                    {loading ? <LoaderHolder><LoadSpinner/></LoaderHolder>:
                    <Chart>
                        <ChartValueAxis>
                            <ChartValueAxisItem labels={{ format: FormatCHF}} />
                        </ChartValueAxis>      
                        <ChartLegend visible={true} position="bottom" /> 
                        <ChartTooltip />                    
                            <ChartCategoryAxis>
                                <ChartCategoryAxisItem categories={['Product']} maxDivisions={1} labels={{ format: 'd', rotation: 'auto' }} >
                                    <ChartCategoryAxisTitle text="" />
                                </ChartCategoryAxisItem>
                            </ChartCategoryAxis> 
                                <ChartSeries >   
                                {
                                    Object.entries(SeriesProducts).map((element:any) => {  
                                       
                                        return (
                                            <ChartSeriesItem  key={element[0]} type="column" name={element[0]}  data={element[1]} >
                                                <ChartSeriesItemTooltip format={FormatCHF}  />
                                            </ChartSeriesItem>
                                        )
                                    })
                                }                         
                                                                
                                </ChartSeries>
                        </Chart>  }   
                    </div>
                                   
            </div>
            <div className="row">
            <div className="col-12 mb-3 mt-lg-0 text-center text-lg-left">
                    {loading ? <LoaderHolder><LoadSpinner/></LoaderHolder>:
                    <Chart>
                        <ChartValueAxis>
                            <ChartValueAxisItem labels={{ format: FormatCHF}} />
                        </ChartValueAxis>      
                        <ChartLegend visible={true} position="bottom" /> 
                        <ChartTooltip />                    
                            <ChartCategoryAxis>
                                <ChartCategoryAxisItem categories={['Customers']} maxDivisions={1} labels={{ format: 'd', rotation: 'auto' }} >
                                    <ChartCategoryAxisTitle text="" />
                                </ChartCategoryAxisItem>
                            </ChartCategoryAxis> 
                                <ChartSeries >   
                                {
                                    Object.entries(SeriesCustomers).map((element:any) => {                                          
                                        return (
                                            <ChartSeriesItem  key={element[0]} type="column" name={element[0]}  data={element[1]} >
                                                
                                                <ChartSeriesItemTooltip format={FormatCHF}  />
                                            </ChartSeriesItem>
                                        )
                                    })
                                }                        
                                                                
                                </ChartSeries>
                        </Chart>  }   
                    </div>
            </div>            
        </ContentScreen>
    );
}

export default Charts;

const ToolBar = styled.ol<any>({
    display: 'flex',
    listStyle: 'none',
    margin: '0px -10px',
    padding: '0px',
    alignItems: 'flex-end',
    '.k-textbox-container':{
        width: '75px'
    },    
    '> li':{
        padding: '0px 10px',
        width: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    },
    '> li:first-of-type':{
        width: '350px',
        '> span > span':{
            width: '110px',
            marginRight: '15px',
            '> span' :{
                width: '100%'
            }
        }

    },
    '> li:last-of-type':{width: 'calc(100% - 200px)'}
}, props =>({
    '.LobFilters li ':{
        backgroundColor: props.Theme.Corporate.lightBlue + ' !important',
    },
}))

const LoaderHolder = styled.div({
    height: '400px'
    
})