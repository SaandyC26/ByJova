
import React, { SyntheticEvent, useState, useEffect } from 'react';
import { GridColumnMenuCheckboxFilter, GridColumn as Column, GridDataStateChangeEvent, Grid, GridColumnMenuFilter, GridExpandChangeEvent, GridCellProps, GridColumnResizeEvent, GridColumnReorderEvent } from '@progress/kendo-react-grid';
import { Button } from '@progress/kendo-react-buttons';
import { useSelector, useDispatch } from 'react-redux';
import RevenueDTO, { RevenuesDTO } from '../../entities/RevenueDTO';
import { State as DataState, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import MDTService from '../../services/MDTService';
import DetailComponentColumns from '../DemandTable/Views/DetailComponentColumns'
import EditRevenueForm from "../DemandTable/Views/EditRevenueForm";
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import ImportExcel from "../DemandTable/Views/ImportExcel";
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import styled from "@emotion/styled";
import RevenueService from '../../services/RevenueService';
import { useParams } from "react-router-dom";
import { findWithAttr, HasPermision, ReadObjProp, SortByProp, CurrencyFormat, MonthListShort } from '../Functions/Utils'
import { formatNumber } from '@telerik/kendo-intl';
import { saveGrid } from '../../store/slices/user';
import userService from '../../services/UserService'
import ResetDemandGridSettings from '../Generic/ResetDemandGridSettings'
import ExportSettings from '../Generic/ExportSettings'
import ContentScreen from '../Generic/ContentScreen'
import { Calendar } from "@progress/kendo-react-dateinputs";
import { CustomFilterUI } from "../Generic/YearCalendar"
import { IconTrash, IconEdit, IconPlus } from '../Generic/Icons'
import { AddButton, ActionButton, ToolbarButton } from '../Generic/Styles'
import Loading from '../Generic/Loading'

interface Props {
    tokenId?: string,
    loadRevenues?: Function,
    loadMDT?: Function,
    predefinedFilter?: CompositeFilterDescriptor,
}

interface HeaderValues {
    lineOfBusinessArray: string[],
    customerArray: string[],
    projectArray: string[],
    typeOfServiceArray: string[],
    chargingModelArray: string[],
    businessUnitArray: string[],
    currencyArray: string[],
    usersArray: string[],
    costCenterArray: string[],
    CustomercostCenterArray: string[],
    InternalcostCenterArray: string[],
}

interface State {
    revenueList: RevenuesDTO,
    dataState: DataState,
    prevDataState: DataState,
    lineOfBusinesses?: {}[],
    customers?: {}[],
    projects?: {}[],
    typeOfServices?: {}[],
    chargingModels?: {}[],
    businessUnits?: {}[],
    users?: {}[],
    currencies?: {}[],
    customerCostCenters?: {}[],
    internalCostCenters?: {}[],
    internals?: {}[],
    arrayValues?: any
    openForm?: boolean,
    editItem: RevenueDTO,
}

let Today = new Date;

const NewItem = {
    new: true,
    id: 60000,
    year: Today.getFullYear(),
    lineOfBusiness: '',
    customerName: '',
    projectName: '',
    projectType: '',
    typeOfServiceName: '',
    ownerProjectManagerName: '',
    businessUnitCode: '',
    productName: '',
    customerCodeCenterCode: '',
    serviceDescription: '',
    chargingModelCode: '',
    internalCostCenterPertCostCode: '',
    internalCode: '',
    testingToolName: '',
    testingToolProjectName: '',
    testingToolDetailedInfo: '',
    currencyCode: 'EUR',
    planLC: 0,
    transferLC: 0,
    differenceLC: 0,
    fyfclc: 0,
    fyfcchf: 0,
    fyfcchfvat: 0,
    editable: true,
    plannedStartDate: null,
    plannedEndDate: null,
    january: { amount: 0, locked: false },
    february: { amount: 0, locked: false },
    march: { amount: 0, locked: false },
    april: { amount: 0, locked: false },
    may: { amount: 0, locked: false },
    june: { amount: 0, locked: false },
    july: { amount: 0, locked: false },
    august: { amount: 0, locked: false },
    september: { amount: 0, locked: false },
    october: { amount: 0, locked: false },
    november: { amount: 0, locked: false },
    december: { amount: 0, locked: false },
}
interface EditProps {
    enterEdit: Function,
    Delete: Function
}

const EditCommandCell = (props: GridCellProps & EditProps) => {
    return (
        <td>
            <Actions>
                {!props.dataItem.editable ? null :

                    <ActionButton
                        id={"Table_Button_Edit_" + props.dataItem.name}

                        onClick={() => props.enterEdit(props.dataItem)}
                    >
                        {IconEdit('rowButton')}
                    </ActionButton>
                }
                {!props.dataItem.deletable ? null :
                    <ActionButton
                        id={"Table_Button_Delete_" + props.dataItem.name}

                        onClick={() => props.Delete(props.dataItem)}

                    >
                        {IconTrash('rowButton')}
                    </ActionButton>
                }
            </Actions>
        </td>
    );

};


function DemandTable(props: any, State: State) {

    const { slug } = useParams();
    let dispatch = useDispatch();
    const Theme = useSelector((state: any) => state.Theme);


    const OriginalrevenueList = {
        count: 0,
        revenues: new Array
    }
    //s

    const ShowSave = useSelector((state: any) => state.userData).ShowSave;
    const PrevSettings = useSelector((state: any) => state.userData).DemandSettings;
    const OriginalSettings = useSelector((state: any) => state.userData).OriginalDemandSettings;
    const [prevDataState, setprevDataState] = useState(PrevSettings.Filters);
    const [openForm, setOpenForm] = useState(false);
    const [editItem, setEditItem] = useState<RevenueDTO>(NewItem);
    const [revenueList, setrevenueList] = useState(OriginalrevenueList);
    const [BaseRevenues, setBaseRevenues] = useState({ count: 0, revenues: new Array })
    const [prevSlug, setPrevSlug] = useState<any>('all');
    const [prevRevenueList, setPrevRevenueList] = useState(OriginalrevenueList);
    const [prevExpandList, setPrevExpandList] = useState(new Array)
    const [dataState, setdataState] = useState(PrevSettings.Filters);
    const TokenData = useSelector((state: any) => state.tokenData);
    const [lineOfBusinesses, setlineOfBusinesses] = useState(new Array);
    const [ExpandList, setExpandList] = useState(new Array);
    const [arrayValues, setArrayValues] = useState(new Array);
    const [IsLoading, setIsLoading] = useState(false);
    const [BaseLoaded, setBaseLoaded] = useState(false)
    const [MDTSLoaded, setMDTSLoaded] = useState(false);
    const [AutoSave, setAutoSave] = useState(false);
    const [Refreshing, setRefreshing] = useState(false);

    const [GridPreferences, setGridPreferences] = useState(PrevSettings)
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({ edit: false, create: false, delete: false, import: false });
    const TimerResponse = 500;
    let timer1 = setTimeout(() => { console.log('timer on') }, TimerResponse);

    useEffect(() => {
        let Permissions = {
            edit: HasPermision('Manage Revenue'),
            create: HasPermision('Manage Revenue'),
            delete: HasPermision('Manage Revenue'),
            import: HasPermision('Import Revenues'),
        }
        setGranted(Permissions);

    }, [PermissionCheck])

    useEffect(() => {
        UpdateFilters().then((e: any) => {
            setdataState(e);
        })
    }, [slug]);

    useEffect(() => {
        if (AutoSave) {
            SaveGridSettings()
            setAutoSave(false);
        }
    }, [AutoSave]);

    useEffect(() => {

        if (Refreshing) {
            loadRevenues();
            setRefreshing(false);
        }
    }, [Refreshing]);


    function UpdateFilters() {
        return new Promise((resolve, reject) => {

            let mod = { ...dataState };
            let OldFilters = [...dataState.filter.filters];

            let ToRemove = 0;
            OldFilters.forEach((element: any, index) => {
                if ((typeof element.filters !== 'undefined' && element.filters[0].field === 'lineOfBusinessName')
                    || typeof element.field !== 'undefined' && element.field === 'lineOfBusinessName'
                ) { ToRemove = index; }
            })
            if (ToRemove > 0) { OldFilters.splice(ToRemove, 1) }

            if (typeof slug !== 'undefined' && slug !== '') {
                let slugFilter =
                {
                    operator: "eq",
                    field: "lineOfBusinessName",
                    value: typeof slug !== 'undefined' ? slug.replaceAll("%20", " ") : ''
                }

                OldFilters.push(slugFilter);
            }

            resolve({ skip: mod.skip, take: mod.take, sort: mod.sort, filter: { logic: 'and', filters: OldFilters } })
        })
    }

    useEffect(() => {
        setGridPreferences(PrevSettings);

        if (JSON.stringify(dataState) !== JSON.stringify(PrevSettings.Filters) && (prevSlug === slug || prevSlug === 'all' && slug === undefined)) {
            setdataState(PrevSettings.Filters)
        }

    }, [PrevSettings, slug])

    useEffect(() => {
        if (!MDTSLoaded) { loadMDTs(); setMDTSLoaded(true); }
    }, [MDTSLoaded])


    function CompareData() {
        let hasChanged = false;

        if (JSON.stringify(dataState) !== JSON.stringify(prevDataState)) {

            hasChanged = true;
        }
        if (JSON.stringify(revenueList) !== JSON.stringify(prevRevenueList)) {

            hasChanged = true;
        }
        if (JSON.stringify(ExpandList) !== JSON.stringify(prevExpandList)) {

            hasChanged = true;
        }
        if (slug !== prevSlug) {

            hasChanged = true;
        }

        return hasChanged
    }

    useEffect(() => {
        if (TokenData && BaseLoaded && !IsLoading) {
            if (CompareData()) {
                setIsLoading(true)

                UpdateFilters().then((e: any) => {
                    loadRevenues(e).then((b: any) => {
                        setIsLoading(false)
                        setprevDataState(dataState);
                        setPrevRevenueList(b);
                        setPrevExpandList(ExpandList);
                        setPrevSlug(slug)
                        setrevenueList(b);
                    });
                })
            }
        }
    }, [BaseLoaded, dataState, revenueList, ExpandList, slug])

    useEffect(() => {
        if (!BaseLoaded) {
            loadBase().then((e: any) => {
                setBaseRevenues(e)
                setBaseLoaded(true)
            })
        }
    }, [BaseLoaded])

    function loadBase() {
        //aka
        return new Promise((resolve, reject) => {
            if (BaseRevenues.revenues.length === 0) {
                let TempBaseRevenues = new Array;
                RevenueService.postRequest(JSON.stringify({
                    DataSourceRequest: {
                        filter: {
                            logic: 'and',
                            filters: [
                                {
                                    operator: 'neq',
                                    field: 'year',
                                    value: '0'
                                }
                            ]
                        },
                        sort: [
                            { field: "year", dir: "desc" }
                        ],
                        take: 15,
                        skip: 0


                    }
                }), TokenData.tokenId).then((result: any) => {

                    result.revenues.forEach((element: any) => {
                        let valid = true
                        if (
                            typeof TempBaseRevenues.find((seek: any) => seek.customerName == element.customerName) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.typeOfServiceName == element.typeOfServiceName) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.projectName == element.projectName) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.ownerProjectManagerName == element.ownerProjectManagerName) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.lineOfBusinessName == element.lineOfBusinessName) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.internalCostCenterPerCostCode == element.internalCostCenterPerCostCode) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.customerCostCenterCode == element.customerCostCenterCode) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.chargingModelCode == element.chargingModelCode) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.businessUnitCode == element.businessUnitCode) !== 'undefined'
                            && typeof TempBaseRevenues.find((seek: any) => seek.currencyCode == element.currencyCode) !== 'undefined'


                        ) { valid = false }
                        if (valid) {
                            TempBaseRevenues.push(element)
                        }
                    });

                    resolve({ count: TempBaseRevenues.length, revenues: TempBaseRevenues })
                });
            }
        })
    }

    function dataStateChange(e: any) {
        setdataState({
            skip: typeof e.dataState.skip === 'undefined' ? 0 : e.dataState.skip,
            take: typeof e.dataState.take === 'undefined' ? 15 : e.dataState.take,
            sort: typeof e.dataState.sort === 'undefined' ? dataState.sort : e.dataState.sort,
            filter: typeof e.dataState.filter === 'undefined' ? dataState.filter : e.dataState.filter,

        });
        setGridPreferences({ Filters: e.dataState, Columns: GridPreferences.Columns })
    }

    function GridSizeChange(e: GridColumnResizeEvent) {
        setGridPreferences({ Filters: GridPreferences.Filters, Columns: Convert(e.columns, e.index, e) })
    }

    function Convert(list: any, index?: any, event?: any) {
        let newList = [...GridPreferences.Columns];
        let CopyList = new Array;

        newList.forEach(OldEl => {
            let subNewItem: any;
            let original = list.find((NewEl: any) => NewEl.field === OldEl.field);

            if (typeof original !== 'undefined') {
                subNewItem = { field: OldEl.field, width: original.width, orderIndex: original.orderIndex || OldEl.orderIndex, Show: true }
            } else {
                subNewItem = { field: OldEl.field, width: OldEl.width, orderIndex: OldEl.orderIndex, Show: false }
            }

            CopyList.push({ field: subNewItem.field || 'none', width: Math.floor(subNewItem.width), orderIndex: subNewItem.orderIndex || 0, Show: subNewItem.Show })
        });

        return CopyList
    }

    function GridOrderChange(e: GridColumnReorderEvent) {
        setGridPreferences({ Filters: GridPreferences.Filters, Columns: Convert(e.columns) })
    }

    function TimeHandle(todo: Function, e: GridColumnResizeEvent) {
        clearTimeout(timer1);
        timer1 = setTimeout(() => { todo(e) }, TimerResponse)
    }

    function loadMDTs() {
        // aka
        var lists: any = {
            lineOfBusinessName: [],
            customerName: [],
            projectName: [],
            projectType: [],
            typeOfServiceName: [],
            chargingModelCode: [],
            businessUnitCode: [],
            currencyCode: [],
            ownerProjectManagerName: [],
            productName: [],
            internalCode: [],
            testingToolName: [],
            customerCostCenterCode: [],
            internalCostCenterPerCostCode: [],
            projectsRef: [],
            customerRef: [],
            costcenterRef: [],
            customerFunctionName: [],
            groupOwnerName: [],
        };

        if (TokenData.tokenId !== '') {
            if (!lineOfBusinesses || lineOfBusinesses.length === 0) {

                userService.getUserGroups(TokenData.tokenId, { take: 0, skip: 0 }).then((result: any) => {
                    result.data.map((userGroup: any) => {
                        lists.groupOwnerName.push(userGroup.name);
                    });
                });

                MDTService.postRequestLineOfBusiness(TokenData.tokenId).then((resultup: any) => {
                    var sublineOfBusinesses: {}[] = [];
                    resultup.map((lineOfBusinessitem: any) => {
                        sublineOfBusinesses.push({ lineOfBusinessName: lineOfBusinessitem.name });
                        lists.lineOfBusinessName.push(lineOfBusinessitem.name);
                    });
                    setlineOfBusinesses(sublineOfBusinesses);

                });

                MDTService.postRequestCustomer(TokenData.tokenId).then((result: any) => {
                    result.map((customer: any) => {
                        lists.customerName.push(customer.name);
                        lists.customerRef.push(customer)
                    });

                });

                MDTService.postRequestCustomerFunctions(TokenData.tokenId).then((result: any) => {
                    result.map((functions: any) => {
                        lists.customerFunctionName.push(functions);
                    });

                });

                MDTService.postRequestProject(TokenData.tokenId).then((result: any) => {
                    result.map((project: any) => {
                        lists.projectName.push(project.name);
                        lists.projectsRef.push(project)
                    });

                });

                MDTService.postRequestProjectType(TokenData.tokenId).then((result: any) => {
                    result.map((element: any) => {
                        lists.projectType.push(element);
                    });
                });

                MDTService.postRequestTypeOfService(TokenData.tokenId).then((result: any) => {
                    result.map((typeOfService: any) => {
                        lists.typeOfServiceName.push(typeOfService.name);
                    });

                });

                MDTService.postRequestChargingModel(TokenData.tokenId).then((result: any) => {
                    result.map((cm: any) => {
                        lists.chargingModelCode.push(cm.code);
                    });
                });

                MDTService.postRequestBusinessUnit(TokenData.tokenId).then((result: any) => {
                    result.map((bu: any) => {
                        lists.businessUnitCode.push(bu.code);
                    });

                });

                MDTService.postRequestCurrency(TokenData.tokenId).then((result: any) => {
                    result.map((cu: any) => {
                        lists.currencyCode.push(cu.code);
                    });
                });

                MDTService.postRequestUsers(TokenData.tokenId).then((result: any) => {
                    result.map((user: any) => {
                        lists.ownerProjectManagerName.push(user.name);
                    });
                });

                MDTService.postRequestProducts(TokenData.tokenId).then((result: any) => {
                    result.map((element: any) => {
                        lists.productName.push(element.name);
                    });
                });

                MDTService.postRequestCostCenter(TokenData.tokenId).then((result: any) => {
                    result.map((cc: any) => {

                        if (cc.types.includes("Customer")) { lists.customerCostCenterCode.push(cc.code); }
                        if (cc.types.includes("Internal")) { lists.internalCostCenterPerCostCode.push(cc.code); }

                        lists.costcenterRef.push(cc)
                        lists.internalCode.push(cc.code);
                    });
                });

                MDTService.postRequestTestingTool(TokenData.tokenId).then((result: any) => {
                    result.map((element: any) => {
                        lists.testingToolName.push(element.name);
                    });
                });

                setArrayValues(lists);
            }
        }
    }

    function loadRevenues(rawfilters?: any) {
        //aka
        return new Promise((resolve, reject) => {
            let filters: any = Array.isArray(rawfilters) ? [...rawfilters] : []
            let NewState: any = { ...dataState }

            if (typeof NewState.filter !== 'undefined') {
                NewState.filter = { ...NewState.filter }
                if (NewState.filter.filters.length > 0) {

                    NewState.filter.filters = NewState.filter.filters.map((maps: any) => {

                        let map1 = { ...maps }
                        if (typeof map1.filters !== 'undefined') {
                            map1.filters = map1.filters.map((mapz: any) => {
                                let map2 = { ...mapz }
                                if (map2.field === 'year' && map2.operator !== 'neq') {
                                    return {
                                        ...map2, value: typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime() ? map2.value.getFullYear() : new Date(map2.value).getFullYear()
                                    }
                                }
                                if (typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime()) {
                                    return {
                                        ...map2, value: map2.value.getFullYear() + '-' + (map2.value.getMonth() + 1) + '-' + map2.value.getDate()
                                    }
                                }
                                else {
                                    return map2
                                }
                            })

                            return map1
                        }
                        else {
                            return map1
                        }
                    })

                    if (Array.isArray(rawfilters)) {
                        filters = filters.map((maps: any) => {

                            let map1 = { ...maps }
                            if (typeof map1.filters !== 'undefined') {
                                map1.filters = map1.filters.map((mapz: any) => {
                                    let map2 = { ...mapz }
                                    if (map2.field === 'year' && map2.operator !== 'neq') {
                                        return {
                                            ...map2, value: typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime() ? map2.value.getFullYear() : new Date(map2.value).getFullYear()
                                        }
                                    }
                                    if (typeof map2.value === 'object' && map2.value.getTime() === map2.value.getTime()) {
                                        return {
                                            ...map2, value: map2.value.getFullYear() + '-' + (map2.value.getMonth() + 1) + '-' + map2.value.getDate()
                                        }
                                    }
                                    else {
                                        return map2
                                    }
                                })

                                return map1
                            }
                            else {
                                return map1
                            }
                        })
                    }
                }
            }

            RevenueService.postRequest(JSON.stringify({ DataSourceRequest: Array.isArray(rawfilters) ? filters : NewState }), TokenData.tokenId).then((result: any) => {
                result.revenues.map((Item: any) => {

                    Item.expanded = false;

                    Item.plannedEndDate = TimyUTC(new Date(Date.parse(Item.plannedEndDate)).toUTCString())
                    Item.plannedStartDate = TimyUTC(new Date(Date.parse(Item.plannedStartDate)).toUTCString())

                    if (ExpandList.includes(Item.id)) { Item.expanded = true }

                })
                resolve(result)
            });
        })
    }

    function isColumnActive(field: string, dataStateprop: DataState) {
        if (typeof dataStateprop !== 'undefined') { return GridColumnMenuFilter.active(field, dataStateprop.filter) ? "active" : ""; }
    }

    function expandChange(event: GridExpandChangeEvent) {

        let ExpandedItems = [...ExpandList];
        let modlist = { ...revenueList };
        let copyItem = { ...event.dataItem }
        let Lookfor = 0;
        copyItem.expanded = !copyItem.expanded;

        modlist.revenues.forEach((Item) => {
            if (Item.id === copyItem.id) {
                Item.expanded = true;
                Lookfor = copyItem.id;
            }
        })

        if (copyItem.expanded) {
            ExpandedItems.push(event.dataItem.id)
        } else {
            ExpandedItems = ExpandedItems.filter(val => val !== Lookfor)
        }

        setExpandList(ExpandedItems);
    }

    function enterEdit(item: any) {
        item.delete = false;
        setOpenForm(true);
        setEditItem(item);
    }

    function DeleteItem(item: any) {
        item.delete = true;
        setOpenForm(true);
        setEditItem(item);
    }

    function UpdateEditItem(item: any) {
        setOpenForm(true);
        setEditItem(item);
        setRefreshing(true)
    }

    function DeleteItemConfirmed(item: any) {
        RevenueService.postDeleteSoft(item, TokenData.tokenId).then((result: any) => {
            loadRevenues().then((e: any) => {
                setrevenueList(e);
            });
            setOpenForm(false);
        })
    }

    function TimyUTC(a: any) {
        let b = a.split(' ')
        return new Date(Date.UTC(b[3], MonthListShort.findIndex((el: any) => el === b[2]), b[1]))
    }

    function TimyParsy(a: any) {
        function pad(d: any) {
            return (d < 10) ? '0' + d.toString() : d.toString();
        }

        let month = a.getMonth() + 1

        return a.getFullYear() + '-' + pad(month) + '-' + a.getDate();
    }

    function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>) {
        values.year = editItem.year;
        values.plannedStartDate = TimyParsy(new Date(values.plannedStartDate))
        values.plannedEndDate = TimyParsy(new Date(values.plannedEndDate))


        if (editItem.new) {
            // we only add to grid view this element until we can intert into DB

            values.new = false;
            let temp = { ...revenueList };
            temp.revenues.unshift(values);
            temp.revenues.pop();

            setrevenueList(temp)
            delete (values.id);
            RevenueService.postInsertSoft(JSON.stringify({ revenue: values }), TokenData.tokenId).then((result: any) => {
                if (result.type === 'ok') {
                    let newrevenueslist = {
                        count: revenueList.revenues.length,
                        revenues: revenueList.revenues
                    }
                    setrevenueList(newrevenueslist)
                    loadRevenues().then((e: any) => {
                        setrevenueList(e);
                    });
                    setOpenForm(false);
                }
            })
        } else {
            if (TokenData.tokenId !== '') {
                RevenueService.postUpdateSoft(JSON.stringify({ revenue: values }), TokenData.tokenId).then((result: any) => {
                    if (result.type === 'ok') {
                        let newrevenueslist = {
                            count: revenueList.revenues.length,
                            revenues: [...revenueList.revenues]
                        }
                        newrevenueslist.revenues.forEach((item: any, index: any) => {
                            if (result.item.revenue.id === item.id) {
                                newrevenueslist.revenues[index] = { ...result.item.revenue };
                            }
                        })

                        setrevenueList(newrevenueslist);
                        loadRevenues().then((e: any) => {
                            setrevenueList(e);
                        });
                        setOpenForm(false);
                    }
                });
            }
        }
    }

    function handleCancelEdit(event: DialogCloseEvent) {
        setOpenForm(false);
    }

    function SimpleFilter(subProps: any) {
        return (
            <div>
                <GridColumnMenuFilter {...subProps} data={props.data} expanded={true} />
            </div>
        );
    }

    function ColumnMenu(subProps: any) {
        return (
            <div>
                <GridColumnMenuFilter   {...subProps} data={subProps.data} expanded={true} />
            </div>
        );
    }
    function DateMenu(subProps: any) {
        return (
            <div>
                <GridColumnMenuFilter onFilterChange={(e: any) => { }} {...subProps} data={subProps.data} expanded={true} />
            </div>
        );
    }

    function YearMenu(subProps: any) {
        return (
            <div style={{ width: '350px', position: 'absolute' }}>
                <GridColumnMenuFilter
                    filterUI={CustomFilterUI}
                    onFilterChange={(e: any) => { }}
                    {...subProps}
                    data={subProps.data}
                    expanded={true}
                />
            </div>
        );
    }

    function ColumnMenuFilter(subProps: any) {
        let Field = subProps.column.field;
        // aka
        const FilterContent = styled.div({
            paddingTop: '50px',
            '>div:first-of-type > div:first-of-type': {

                pointerEvents: 'none',
                position: 'absolute',
                top: '0px'

            },

        }, () => ({
            '*:checked, *:visited, *:active, *:selected, *:focus, *:active, *:activated': {
                borderColor: Theme.Corporate.blue,
            },
            'input:checked, input:visited, input:active': {
                backgroundColor: Theme.Corporate.blue,
                borderColor: Theme.Corporate.blue,
                outlineColor: Theme.Corporate.blue,
                boxShadow: 'none'
            },
            'button:not(:disabled)': {
                backgroundColor: Theme.Corporate.blue,
                borderColor: Theme.Corporate.blue,
            }
        }))

        let prodata = arrayValues[Field].map((el: any) => {
            if (el !== null && el !== undefined) {
                return { pepe: 'wta', [Field]: typeof el === 'object' ? el.name || el.type : el }
            }
        })

        const [FilteredData, setFilteredData] = useState(prodata);

        function Update(value: any) {
            let FilteredDatatemp = new Array;
            if (value === null) { value = '' }
            value = value.toLowerCase();

            prodata.forEach((el: any) => {

                if (el[Field] !== null && el[Field].toLowerCase().includes(value)) {
                    let Exists = FilteredDatatemp.filter((el2: any) => el2[Field].includes(el[Field]));
                    if (Exists.length === 0) {
                        FilteredDatatemp.push(el)
                    }
                }
            })
            setFilteredData(FilteredDatatemp);
        }

        return (
            <div>
                <input placeholder="Search" onChange={(e: any) => { Update(e.target.value) }} style={{ position: 'absolute', top: '30px', width: 'calc(100% - 20px)', marginLeft: '10px', paddingLeft: '5px' }} />
                <FilterContent>
                    <GridColumnMenuCheckboxFilter {...subProps}
                        data={SortByProp(FilteredData, Field)}
                        expanded={true} searchBox={() => null} />

                </FilterContent>
            </div>
        );
    }

    function MyEditCommandCell(subProps: Props & GridCellProps) {
        return (
            <EditCommandCell {...subProps} enterEdit={enterEdit} Delete={DeleteItem} />
        );
    }

    function cellConditionalCurrency(subProps: Props & GridCellProps) {

        let val = 0
        if (typeof subProps.field !== 'undefined') { val = subProps.dataItem[subProps.field] }
        return (
            <td className="Currency">
                {
                    formatNumber(val, CurrencyFormat(subProps.dataItem.currencyCode))
                }
            </td>
        );
    }

    function cellConditionalMonth(subProps: Props & GridCellProps) {
        let value = ReadObjProp(subProps.dataItem, subProps.field?.replace('.amount', '')).amount;

        return (
            <td className="Currency">
                {
                    formatNumber(value, CurrencyFormat(subProps.dataItem.currencyCode))
                }
            </td>
        );
    }

    function SaveGridSettings() {
        dispatch(saveGrid(GridPreferences));
        userService.UpdateGrid(GridPreferences)
    }

    function ResetOrder(type: string) {
        let NewList = new Array;
        switch (type) {
            case 'All':
                setdataState(OriginalSettings.Filters);
                setGridPreferences(OriginalSettings);
                break;
            case 'Order':
                GridPreferences.Columns.forEach((element: any) => {
                    let Item = { field: element.field, width: element.width, orderIndex: OriginalSettings.Columns[findWithAttr(OriginalSettings.Columns, 'field', element.field)].orderIndex, Show: element.Show }
                    NewList.push(Item)
                });
                setGridPreferences({ Filters: GridPreferences.Filters, Columns: NewList });
                break;
            case 'Width':
                GridPreferences.Columns.forEach((element: any) => {
                    let Item = { field: element.field, width: OriginalSettings.Columns[findWithAttr(OriginalSettings.Columns, 'field', element.field)].width, orderIndex: element.orderIndex, Show: element.Show }
                    NewList.push(Item)
                });
                setGridPreferences({ Filters: GridPreferences.Filters, Columns: NewList });
                break;
            case 'Filter':
                setdataState(OriginalSettings.Filters);
                setGridPreferences({ Filters: { sort: GridPreferences.Filters.sort, filter: OriginalSettings.Filters.filter, take: GridPreferences.Filters.take, skip: GridPreferences.Filters.skip }, Columns: GridPreferences.Columns });
                break;
            case 'Sort':
                setdataState(OriginalSettings.Filters);
                setGridPreferences({ Filters: { sort: OriginalSettings.Filters.sort, filter: GridPreferences.Filters.filter, take: GridPreferences.Filters.take, skip: GridPreferences.Filters.skip }, Columns: GridPreferences.Columns });
                break;
            case 'Visible':
                GridPreferences.Columns.forEach((element: any) => {
                    let Item = { field: element.field, width: element.width, orderIndex: element.orderIndex, Show: true };
                    NewList.push(Item)
                })
                setGridPreferences({ Filters: GridPreferences.Filters, Columns: NewList });
                break;
        }

        setAutoSave(true);
    }

    function MaybeItem() {
        if (typeof slug === 'undefined') { return (ColumnMenuFilter) }
        return null
    }

    function MaybeTrue() {
        if (typeof slug === 'undefined') { return true }
        return false
    }

    return (
        <ContentScreen id="DemandTable">

            <style>
                {`.k-animation-container {
                        z-index: 10003;
                    }`}
            </style>
            <div className="row" >
                <Toolbar className="col-12" Theme={Theme}>
                    <div className="col">
                        {!Granted.create ? null : <AddButton id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton>}
                        <ResetDemandGridSettings CallBack={(e: any) => { ResetOrder(e) }} />
                        {props.children}
                        {ShowSave || JSON.stringify(GridPreferences) !== JSON.stringify(PrevSettings) ? <ToolbarButton style={{ marginLeft: '15px' }} id="Grid_Save_Settings" onClick={SaveGridSettings} className="k-button k-primary rounded">Save Grid Settings</ToolbarButton> : null}
                    </div>
                    <div className="col">
                        {!Granted.import ? null :
                            <ImportExcel
                                token={TokenData.tokenId}
                                dataState={dataState}
                                buttonText="Import from Excel"
                                Callback={() => {
                                    loadRevenues().then((e: any) => {
                                        setrevenueList(e);
                                    });
                                }}
                            />
                        }
                        <ExportSettings Dataset={dataState} />
                    </div>
                </Toolbar>
            </div>
            <Container className="row" id="DemandTable" Theme={Theme}>
                <div className="col-12">
                    {MDTSLoaded ?
                        <Grid
                            data={[...revenueList.revenues]}
                            {...dataState}
                            pageable={{ buttonCount: 8, pageSizes: [5, 10, 15, 20, 30, 50] }}
                            onDataStateChange={dataStateChange}
                            total={revenueList.count}
                            resizable={true}
                            onColumnReorder={GridOrderChange}
                            onColumnResize={(e: GridColumnResizeEvent) => TimeHandle(GridSizeChange, e)}
                            scrollable="scrollable"
                            reorderable={true}
                            sortable={{
                                allowUnsort: true,
                                mode: 'multiple'
                            }}
                            detail={DetailComponentColumns}
                            expandField="expanded"
                            onExpandChange={expandChange}
                        >
                            <Column orderIndex={0} cell={MyEditCommandCell} reorderable={false} resizable={false} width={70} />

                            <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'year').orderIndex} format="{0:yyyy}" field={"year"} title="Year" width={GridPreferences.Columns.find((el: any) => el.field === 'year').width} filter={'date'} columnMenu={YearMenu} headerClassName={isColumnActive("year", dataState)} />
                            {GridPreferences.Columns.find((el: any) => el.field === 'lineOfBusinessName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'lineOfBusinessName').orderIndex} field="lineOfBusinessName" title="LOB" width={GridPreferences.Columns.find((el: any) => el.field === 'lineOfBusinessName').width} columnMenu={MaybeItem() || undefined} sortable={MaybeTrue()} headerClassName={isColumnActive("lineOfBusinessName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'customerName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'customerName').orderIndex} field="customerName" title="Customer" width={GridPreferences.Columns.find((el: any) => el.field === 'customerName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("customerName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'customerFunctionName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'customerFunctionName').orderIndex} field="customerFunctionName" title="Customer Function" width={GridPreferences.Columns.find((el: any) => el.field === 'customerFunctionName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("customerFunctionName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'projectName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'projectName').orderIndex} field="projectName" title="Project" width={GridPreferences.Columns.find((el: any) => el.field === 'projectName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("projectName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'projectType').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'projectType').orderIndex} field="projectType" title="Project Type" width={GridPreferences.Columns.find((el: any) => el.field === 'projectType').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("projectType", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'typeOfServiceName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'typeOfServiceName').orderIndex} field="typeOfServiceName" title="TOS" width={GridPreferences.Columns.find((el: any) => el.field === 'typeOfServiceName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("typeOfServiceName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'serviceDescription').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'serviceDescription').orderIndex} field="serviceDescription" title="Service Description" width={GridPreferences.Columns.find((el: any) => el.field === 'serviceDescription').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("serviceDescription", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'chargingModelCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'chargingModelCode').orderIndex} field="chargingModelCode" title="CModel" width={GridPreferences.Columns.find((el: any) => el.field === 'chargingModelCode').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("chargingModelCode", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'businessUnitCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'businessUnitCode').orderIndex} field="businessUnitCode" title="BU Code" width={GridPreferences.Columns.find((el: any) => el.field === 'businessUnitCode').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("businessUnitCode", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'productName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'productName').orderIndex} field="productName" title="Product" width={GridPreferences.Columns.find((el: any) => el.field === 'productName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("productName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'currencyCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'currencyCode').orderIndex} field="currencyCode" title="Currency" width={GridPreferences.Columns.find((el: any) => el.field === 'currencyCode').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("currencyCode", dataState)} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'planLC').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'planLC').orderIndex} width={GridPreferences.Columns.find((el: any) => el.field === 'planLC').width} columnMenu={ColumnMenu} filter={'numeric'} field="planLC" title="Plan LC" headerClassName={isColumnActive("planLC", dataState)} cell={cellConditionalCurrency} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'transferLC').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'transferLC').orderIndex} width={GridPreferences.Columns.find((el: any) => el.field === 'transferLC').width} columnMenu={ColumnMenu} filter={'numeric'} field="transferLC" title="Transfer LC" headerClassName={isColumnActive("transferLC", dataState)} cell={cellConditionalCurrency} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'differenceLC').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'differenceLC').orderIndex} width={GridPreferences.Columns.find((el: any) => el.field === 'differenceLC').width} columnMenu={ColumnMenu} filter={'numeric'} field="differenceLC" title="Difference LC" headerClassName={isColumnActive("differenceLC", dataState)} cell={cellConditionalCurrency} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'fyfclc').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'fyfclc').orderIndex} width={GridPreferences.Columns.find((el: any) => el.field === 'fyfclc').width} columnMenu={ColumnMenu} filter={'numeric'} field="fyfclc" title="FYFCLC" headerClassName={isColumnActive("fyfclc", dataState)} cell={cellConditionalCurrency} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'fyfcchf').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'fyfcchf').orderIndex} className="Currency" field="fyfcchf" title="FYFCCHF" width={GridPreferences.Columns.find((el: any) => el.field === 'fyfcchf').width} format="{0:##,###.00} CHF" headerClassName={isColumnActive("fyfcchf", dataState)} columnMenu={ColumnMenu} filter={'numeric'} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'fyfcchfvat').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'fyfcchfvat').orderIndex} className="Currency" field="fyfcchfvat" title="FYFCCHFVAT" width={GridPreferences.Columns.find((el: any) => el.field === 'fyfcchfvat').width} format="{0:##,###.00} CHF" headerClassName={isColumnActive("fyfcchfvat", dataState)} columnMenu={ColumnMenu} filter={'numeric'} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'customerCostCenterCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'customerCostCenterCode').orderIndex} field="customerCostCenterCode" title="Customer CC" width={GridPreferences.Columns.find((el: any) => el.field === 'customerCostCenterCode').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("customerCostCenterCode", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'ownerProjectManagerName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'ownerProjectManagerName').orderIndex} field="ownerProjectManagerName" title="Owner" width={GridPreferences.Columns.find((el: any) => el.field === 'ownerProjectManagerName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("ownerProjectManagerName", dataState)} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'groupOwnerName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'groupOwnerName').orderIndex} field="groupOwnerName" title="Group Owner" width={GridPreferences.Columns.find((el: any) => el.field === 'groupOwnerName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("groupOwnerName", dataState)} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'internalCostCenterPerCostCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'internalCostCenterPerCostCode').orderIndex} field="internalCostCenterPerCostCode" title="Internal CC" width={GridPreferences.Columns.find((el: any) => el.field === 'internalCostCenterPerCostCode').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("internalCostCenterPerCostCode", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'internalCode').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'internalCode').orderIndex} field="internalCode" title="ICode" width={GridPreferences.Columns.find((el: any) => el.field === 'internalCode').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("internalCode", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'testingToolName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'testingToolName').orderIndex} field="testingToolName" title="Testing Tool" width={GridPreferences.Columns.find((el: any) => el.field === 'testingToolName').width} columnMenu={ColumnMenuFilter} headerClassName={isColumnActive("testingToolName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'testingToolProjectName').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'testingToolProjectName').orderIndex} field="testingToolProjectName" title="Testing Tool Project Name" width={GridPreferences.Columns.find((el: any) => el.field === 'testingToolProjectName').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("testingToolProjectName", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'testingToolDetailedInfo').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'testingToolDetailedInfo').orderIndex} field="testingToolDetailedInfo" title="Testing Tool Detailed Info" width={GridPreferences.Columns.find((el: any) => el.field === 'testingToolDetailedInfo').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("testingToolDetailedInfo", dataState)} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'plannedStartDate').Show ? <Column format="{0:yyyy-MM-dd}" orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'plannedStartDate').orderIndex} field="plannedStartDate" title="Planned Start Date" width={GridPreferences.Columns.find((el: any) => el.field === 'plannedStartDate').width} filter={'date'} columnMenu={DateMenu} headerClassName={isColumnActive("plannedStartDate", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'plannedEndDate').Show ? <Column format="{0:yyyy-MM-dd}" orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'plannedEndDate').orderIndex} field="plannedEndDate" title="Planned End Date" width={GridPreferences.Columns.find((el: any) => el.field === 'plannedEndDate').width} filter={'date'} columnMenu={DateMenu} headerClassName={isColumnActive("plannedEndDate", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsIds').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsIds').orderIndex} field="projectPlanningItAppsIds" title="Project Planning It Apps Ids" width={GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsIds').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("projectPlanningItAppsIds", dataState)} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsNames').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsNames').orderIndex} field="projectPlanningItAppsNames" title="Project Planning It Apps Names" width={GridPreferences.Columns.find((el: any) => el.field === 'projectPlanningItAppsNames').width} columnMenu={SimpleFilter} headerClassName={isColumnActive("projectPlanningItAppsNames", dataState)} /> : null}

                            {GridPreferences.Columns.find((el: any) => el.field === 'january.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'january.amount').orderIndex} field="january.amount" title="January" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("january.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'february.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'february.amount').orderIndex} field="february.amount" title="February" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("february.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'march.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'march.amount').orderIndex} field="march.amount" title="March" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("march.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'april.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'april.amount').orderIndex} field="april.amount" title="April" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("april.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'may.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'may.amount').orderIndex} field="may.amount" title="May" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("may.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'june.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'june.amount').orderIndex} field="june.amount" title="June" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("june.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'july.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'july.amount').orderIndex} field="july.amount" title="July" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("july.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'august.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'august.amount').orderIndex} field="august.amount" title="August" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("august.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'september.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'september.amount').orderIndex} field="september.amount" title="September" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("september.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'october.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'october.amount').orderIndex} field="october.amount" title="October" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("october.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'november.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'november.amount').orderIndex} field="november.amount" title="November" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("november.amount", dataState)} cell={cellConditionalMonth} /> : null}
                            {GridPreferences.Columns.find((el: any) => el.field === 'december.amount').Show ? <Column orderIndex={GridPreferences.Columns.find((el: any) => el.field === 'december.amount').orderIndex} field="december.amount" title="December" width={130} filter={'numeric'} columnMenu={ColumnMenu} headerClassName={isColumnActive("december.amount", dataState)} cell={cellConditionalMonth} /> : null}

                        </Grid>
                        : null
                    }

                    {openForm && <EditRevenueForm cancelEdit={handleCancelEdit} DeleteItem={DeleteItemConfirmed} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={editItem} dropBoxValues={arrayValues} />}
                </div>
            </Container>
        </ContentScreen>
    );

}

export default DemandTable;

const Toolbar = styled.div<any>({
    marginTop: '-8px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    '>div > svg': {
        fontSize: '30px',

        cursor: 'pointer',
    },
    '.col:first-of-type': {
        padding: '0px',
        display: 'flex',
        justifyContent: 'start',
        alignItems: 'center'
    },
    '.col:last-of-type': {
        padding: '0px',
        display: 'flex',
        justifyContent: 'flex-end'
    }
}, props => ({
    '.k-button-primary, .k-button.k-primary': {
        backgroundColor: props.Theme.Corporate.darkBlue,
        borderColor: props.Theme.Corporate.darkBlue,
    },
    'svg': {
        color: props.Theme.Corporate.darkBlue,
        fill: props.Theme.Corporate.darkBlue,
    }
}))


const Actions = styled.div({
    display: 'flex',
    width: '45px',
    flexDirection: 'row',
    justifyContent: 'space-between',
    'button': {
        padding: '0px',
        'span': {

        }
    },

})
const Container = styled.div<any>({
    'div.k-grid-header': { width: 'calc(100% + 16px)' },
    '.k-grid-content.k-virtual-content': {
        overflowY: 'hidden',
    },
    '.Currency': {
        textAlign: 'right',
        paddingRight: '10px'
    },
    '.k-grid td': {
        paddingBottom: '0px',
        paddingTop: '0px'
    },

}, props => ({
    'col.k-sorted, th.k-sorted': {
        backgroundColor: props.Theme.Corporate.paleBlue,
    },
    '.k-pager-numbers .k-link.k-state-selected': {
        color: props.Theme.Corporate.blue,
        backgroundColor: props.Theme.Corporate.lightBlue,
    },
    '.k-pager-numbers .k-link': {
        color: props.Theme.Corporate.blue,
    },
    '.k-grid th': {
        backgroundColor: props.Theme.Corporate.lightBlue,

    },
    'th.k-header.active > div > div': {
        backgroundColor: props.Theme.Corporate.darkBlue,
    }

}))

