import { State as DataState } from '@progress/kendo-data-query';
import { Grid, GridCellProps, GridColumn, GridDataStateChangeEvent } from '@progress/kendo-react-grid';
import React, { useState ,SyntheticEvent, useEffect} from 'react';
import { ProjectDto as project } from '../../dtos/masterDataDto';
import { RoleDto as role } from '../../dtos/roleDto';
import { UserDto as user } from '../../dtos/userDto';
import UserService from '../../services/UserService';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import styled from "@emotion/styled";
import { DialogCloseEvent } from "@progress/kendo-react-dialogs";
import EditUserForm from "../Generic/EditUserForm";
import { Button } from '@progress/kendo-react-buttons';
import {findWithAttr,HasPermision} from '../Functions/Utils'
import MDTService from '../../services/MDTService';
import ContentScreen from '../Generic/ContentScreen';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {useSelector} from 'react-redux';
import {AddButton,DataTableInfo,ActionButton} from '../Generic/Styles'
import {IconTrash,IconEdit, IconPlus} from '../Generic/Icons'



const NewItem = {
    delete: false,
    new: true,
    id: 60000,
    samAccountName: '',
    name: '',
    roles: new Array,
    projects: new Array,    
   
}
interface EditProps {
    enterEdit: Function,
    deleteConfirm: Function
}



const GroupsCell = (props: GridCellProps): JSX.Element => {
    return (
        <td colSpan={props.colSpan} style={props.style}>
            {(props.field != null ? props.dataItem[props.field] as role[] : null)?.map(r => r.name)?.join(', ')}
        </td>
    );
}

const RolesCell = (props: GridCellProps): JSX.Element => {
    return (
        <td colSpan={props.colSpan} style={props.style}>
            {(props.field != null ? props.dataItem[props.field] as role[] : null)?.map(r => r.name)?.join(', ')}
        </td>
    );
}

const ProjectsCell = (props: GridCellProps): JSX.Element => {
    return (
        <td colSpan={props.colSpan} style={props.style}>
            {(props.field != null ? props.dataItem[props.field] as project[] : null)?.map(p => p.name)?.join(', ')}
        </td>
    );
}

function UserAdmin (props:any, State:any) {
    const Theme =  useSelector((state: any) => state.Theme) ; 
    const users = {data:new Array, total:0};   
    const [dataState,setDataState] = useState<DataState>({take:0,skip:0})
    const [prevdataState,setprevDataState] = useState<DataState>({take:0,skip:0})
    const TokenData = useSelector( (state: any) => state.tokenData);
    const [openForm,setOpenForm] = useState(false);
    const [editItem,setEditItem] = useState<user>(NewItem); 
    const [UserList, setUserList] = useState(new Array)
    const [prevUserList,setprevUserList] = useState(new Array);
    const [List, setList] = useState(new Array);
    const [RawList, setRawList] = useState(new Array);
    const [GroupsList, setGroupsList] = useState(new Array);
    const [RawGroupsList, setRawGroupsList] = useState(new Array);
    const [RawRolesList, setRawRolesList] = useState(new Array)
    const [ListProjects, setListProjects] = useState(new Array);
    const [RelatedLoaded, setRelatedLoaded] = useState(false)
    const [ListLOB, setListLOB] = useState(new Array);    
    const PermissionCheck = useSelector((state: any) => state.userData.permissions)
    const [Granted, setGranted] = useState({edit: false, create: false, delete: false});
   
    useEffect(() => {  
        let Permissions = {
            edit: HasPermision('Manage User'),
            create: HasPermision('Manage User'),
            delete: HasPermision('Manage User'),
        }      
        setGranted(Permissions) ;
   },[PermissionCheck])


    useEffect(() => { 
        UpdateTable()
        },[])

        if(JSON.stringify(UserList) !== JSON.stringify(prevUserList)
            || JSON.stringify(dataState) !== JSON.stringify(prevdataState)
        ){
            setprevUserList(UserList)
            setprevDataState(dataState)
            UpdateTable();
        }


        function UpdateRelated(){
            UserService.getUserGroups(TokenData.tokenId, dataState)
            .then((result: any) => {  
                console.log(result)
                var tempList =  new Array;
                let rawlist = new Array;
    
                result.data.map((Item:any) => {                
                    let newItem = Item;  
                    tempList.push(newItem.name);  
                    rawlist.push(newItem)    
                });   
    
                setGroupsList(tempList)
                setRawGroupsList(rawlist)
            });   
    
    
            MDTService.getRequestRoles(TokenData.tokenId).then((result: any) => {  
                  
                                     
                var tempList =  new Array;
                result.map((Item:any) => {                
                    let newItem = Item;  
                    tempList.push(newItem.name);      
                });
                setRawRolesList(result);            
                setList(tempList);            
               
            });  
    
            MDTService.postRequestProject(TokenData.tokenId).then((result: any) => {                  
                var tempList =  new Array;
                result.map((Item:any) => {                
                    let newItem = Item;  
                    tempList.push(newItem.name);      
                });
                           
                setListProjects(tempList);            
                
            }); 
            
            MDTService.postRequestLineOfBusiness(TokenData.tokenId).then((result: any) => {                                
                var tempList =  new Array;
                result.map((Item:any) => {                
                    let newItem = Item;  
                    tempList.push(newItem.name);      
                });
                            
                setListLOB(tempList); 
                
            });
        }
        function UpdateTable(){
           
            
            UserService.getUsers(TokenData.tokenId, true, true, dataState, [{ field: "Roles", newField: "Roles.Name" }, { field: "Projects", newField: "Projects.Name"} ] ,true)
        .then((result: any) => {  
           

            result.data.forEach((element:any) => { // delete when DB returns those params
                element.lineofbusiness = [];
                element.projects = [];
            });    
            
            setUserList(result.data)
        });   
        
        if(!RelatedLoaded){
            UpdateRelated()
            setRelatedLoaded(true)
        }
       
        

        }
        const EditCommandCell = (subProps: GridCellProps & EditProps) => {           
            return (
                <td>
                    <Actions>
                    {!Granted.edit ? null :
                    <ActionButton 
                        id={"Button_edit_"+subProps.dataItem.id}
                        
                        onClick={() => subProps.enterEdit(subProps.dataItem)}
                        >{IconEdit('rowButton')}
                    </ActionButton>   
                    }
                    {!Granted.delete ? null :
                    <ActionButton 
                        id={"Button_delete_"+subProps.dataItem.id}
                       
                        onClick={() => subProps.deleteConfirm(subProps.dataItem)}
                        >{IconTrash('rowButton')}
                    </ActionButton>  
                    }
                    </Actions>     
                </td>
            );
        
        };
    function MyEditCommandCell(subProps: any){ 
        return(
            <EditCommandCell {...subProps} enterEdit={enterEdit} deleteConfirm={deleteConfirm}/>
        )
        ;}

    function onDataStateChange(event: GridDataStateChangeEvent){
              
        setDataState(event.dataState)
        UpdateTable();
    }
    function handleCancelEdit(event: DialogCloseEvent){
       
       
        setOpenForm(false);
    }   

    function enterEdit(item : any){
        item.delete = false; 
        setOpenForm(true);
        setEditItem(item);
    }

    function deleteConfirm(item : any){
       item.delete = true;       
       setOpenForm(true);
       setEditItem(item);
    }

    function UpdateEditItem(item : any){
        setOpenForm(true);
        setEditItem(item);
    }
    function handleSubmit(values: { [name: string]: any; }, event?: SyntheticEvent<any, Event>){
    
     values = {...values}
     values.roles = Array.isArray(values.roles)  ? [...values.roles] : []
     values.groups = Array.isArray(values.groups)  ? [...values.groups] : [] 
        let newList = new Array;
        if(typeof values.roles !== 'undefined'){
            values.roles.forEach((element:any) => {          
                
                if(typeof element.id === 'undefined'){
                    newList.push({id: RawRolesList[findWithAttr(RawRolesList, 'name', element)].id})
                }else if(typeof element === 'object'){
                    newList.push({id: RawRolesList[findWithAttr(RawRolesList, 'id', element.id)].id})
                }else{
                    newList.push({id: RawRolesList[findWithAttr(RawRolesList, 'name', element)].id})
                }
                
         
              })
              values.roles = newList;
        }
        if(typeof values.groups !== 'undefined'){
            
            newList = new Array;
            values.groups.forEach((element:any) => {  
                       
                
                newList.push({id: RawGroupsList[findWithAttr(RawGroupsList, 'name', element)].id})
                
         
              })
              values.groups = newList;
        }
       
        


         if(editItem.new){
             // we only add to grid view this element until we can intert into DB
             values.new = false;  
             UserService.postInsertSoft(JSON.stringify({user: values}),TokenData.tokenId).then((result: any) => {            
                if (typeof result !== 'object' || result.type === 'error'){
                    console.log('error')
                }else{
                    setOpenForm(false);
                    setprevUserList(new Array)
                }                
             });
         }
         else if(editItem.delete){
           UserService.postDelete(JSON.stringify({id: editItem.id}),TokenData.tokenId).then((result: any) => {
              setprevUserList(new Array)
            })
            .catch((error: any) => {console.log(error);});
           setOpenForm(false);
            
        }
        else if (TokenData.tokenId !== ''){
               
            UserService.postUpdateSoft(JSON.stringify({user: values}),TokenData.tokenId).then((result: any) => {
               
                if (typeof result !== 'object' || result.type === 'error'){
                  
                }else{
                    
                    let raw = {...users};      
                   
                    newList = new Array;
                    raw.data.forEach(item =>{
                        if(values.id === item.id){item = {...values}}
                        newList.push(item);
                    })

                    let userslist = {
                        total: newList.length,
                        data: newList
                    }   

                    setUserList(userslist.data);
                    setOpenForm(false);


                    
                }
           });
        }
        
        
     }

    
        return (
            <ContentScreen id="EditDataTables">  
            <DataTableInfo>         
            <DinamicInfo Theme={Theme}>
                <Accordion defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                        <DefineSection Theme={Theme}>User Management</DefineSection>
                    </AccordionSummary>
                    <AccordionDetails>
                        <FixedInfo className="col-12">                            
                       
                <div id="UsersGrid">
                            
                <Toolbar className="col-12" Theme={Theme}>
                {!Granted.create ? null : 
                        <AddButton id="Table_Button_Add" onClick={() => enterEdit(NewItem)}>{IconPlus('Floating')}</AddButton>
                }            
                </Toolbar>                   
                 <Grid
                 sortable={{
                     allowUnsort: true,
                     mode: 'multiple'
                 }}
                
                 {...dataState}
                 data={UserList} 
                 onDataStateChange={onDataStateChange}
             >
                 <GridColumn field="samAccountName" title="samAccountName" />
                 <GridColumn field="name" title="Name" />
                 <GridColumn field="lineofbusines" title="Line of business" />
                 <GridColumn field="roles" title="Roles" sortable={false} cell={RolesCell} />
                 <GridColumn field="projects" title="Projects" sortable={false} cell={ProjectsCell} />
                 <GridColumn field="groups" title="Groups" sortable={false} cell={GroupsCell} />                   
                 <GridColumn cell={MyEditCommandCell} resizable={false} width={80}/>
                 
                 
             </Grid>
                    
           
            {openForm && <EditUserForm RawRoles={RawRolesList} RawGroupsList={RawGroupsList} ListGroups={GroupsList} List={List} ListLOB={ListLOB} ListProjects={ListProjects} cancelEdit={handleCancelEdit} UpdateEditItem={UpdateEditItem} onSubmit={handleSubmit} item={editItem} />}
            
        </div>           
            
                        </FixedInfo>
                    </AccordionDetails>                            
                </Accordion>
            </DinamicInfo>  
        </DataTableInfo>        
        </ContentScreen>
           
        );
    
}

export default UserAdmin;



const Toolbar = styled.div<any>({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    'svg' : {
        fontSize: '30px',
        color: '#003399',
        cursor: 'pointer',
    },
    padding: '0px',
    margin: '10px 0px'
    
     }, props =>({
        '.k-button-primary, .k-button.k-primary':{
            backgroundColor: props.Theme.Corporate.darkBlue,
            borderColor: props.Theme.Corporate.darkBlue,
        },
        'svg':{
            color: props.Theme.Corporate.darkBlue,          
            fill: props.Theme.Corporate.darkBlue,   
         }
     }))

     const Actions = styled.div({
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '50px',
        alignItems: 'center',
        '.k-button':{
          padding: '5px !important'
        },
        'svg' : {
            
        },
        padding: '0px',
        margin: '-5px 0px'
    
        })     
const DinamicInfo = styled.div<any>({
    '.MuiAccordionDetails-root':{
        padding: '0px 0px 16px',
        marginBottom: '0px'
    },
    '.k-grid-content':{
        overflow: 'visible'
    },
    padding: '0px',
    '.MuiPaper-root':{backgroundColor: 'transparent'},
    '.MuiPaper-elevation1':{
        boxShadow: 'none'
    },
    '.MuiAccordionSummary-root':{
        padding: '0px'
    }

}, props =>({
    'col.k-sorted, th.k-sorted':{
        backgroundColor: props.Theme.Corporate.paleBlue,
    },
    '.k-pager-numbers .k-link.k-state-selected':{
        color: props.Theme.Corporate.blue,
        backgroundColor: props.Theme.Corporate.lightBlue,
    },
    '.k-pager-numbers .k-link':{
        color: props.Theme.Corporate.blue,
    },
    '.k-grid th':{
        backgroundColor: props.Theme.Corporate.lightBlue,
       
    },
    'th.k-header.active > div > div':{
        backgroundColor: props.Theme.Corporate.darkBlue,
    }
    
 }))
const DefineSection = styled.div<any>({
    fontSize: '125%',
    textAlign: 'left',
    
    fontWeight: 'bold'
}, props =>({
   color: props.Theme.Corporate.darkBlue
 }))
const FixedInfo = styled.div({
    marginTop: '5px',
    
    paddingBottom: '20px',
    paddingTop: '20px',
    width: '100%',    
    display: 'flex',
    justifyContent: 'space-between',
        minHeight: '100px',   
    listStyle: 'none',
    textAlign: 'left',
    
    'p':{
        color: '#605c58 !important',
        margin: '10px 0px',
        'b':{
            color: 'inherit',
            marginRight: '5px',
        }
    },      
    '> div' :{
        padding: '0px',
    },     
    'textarea':{
        width: '100%',
        minHeight: '150px',
        resize: 'none',
        fontSize: '80%',
        padding: '15px',
    },
    
    'ul':{
        margin: '0px',
        padding: '0px'
    }     ,
    padding: '0px'   
})   