import { GridColumnProps } from '@progress/kendo-react-grid';

export default interface TableColumn extends TableColumnSimple, GridColumnProps, Field {
    show: boolean;
    expanded: boolean;
}

export interface TableColumnSimple {
    field?: string;
    title?: string;
    type?: string;
    width?: string | number;
    masterDataTable?: string;
}

export interface Field {
    code?: string;
    labelOnFile?: string;
    fieldType?: string;
    masterDataTable?: string;
    isEditable?: boolean;
    isMandatory?: boolean;
    serverApplicationReference?: string;
    field?: string;
    entity?: string;
    serverAppEditIndex?: number;
    serverEditIndex?: number;
    serverAppExpandIndex?: number;
    serverExpandIndex?: number;
    editIndex?: number;
    expandIndex?: number;
}

export interface UpdatedFieldDTO {
    field?: string;
    isEditable?: boolean;
    isMandatory?: boolean;
    serverAppEditIndex?: number;
    serverEditIndex?: number;
    serverAppExpandIndex?: number;
    serverExpandIndex?: number;
}
