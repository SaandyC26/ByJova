export interface LoginDTO {
    samAccountName: string;
    token: string;
    validFrom: Date;
    validTo: Date;
}