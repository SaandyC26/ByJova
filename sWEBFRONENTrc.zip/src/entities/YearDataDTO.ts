export interface MonthDataDTO {
    lockedCount : number,
    unlockedCount : number,
}

export interface YearDataDTO {
    [key: string]: any,
    year : number,
    revenuesCount : number,
    january : MonthDataDTO,
    february : MonthDataDTO,
    march : MonthDataDTO,
    april : MonthDataDTO,
    may : MonthDataDTO,
    june : MonthDataDTO,
    july : MonthDataDTO,
    august : MonthDataDTO,
    september : MonthDataDTO,
    october : MonthDataDTO,
    november : MonthDataDTO,
    december : MonthDataDTO,
}

export interface MonthCommandDataDTO {
    locked : boolean,
}

export interface YearCommandDataDTO {
    [key: string]: any,
    year : number,
    january? : MonthCommandDataDTO,
    february? : MonthCommandDataDTO,
    march? : MonthCommandDataDTO,
    april? : MonthCommandDataDTO,
    may? : MonthCommandDataDTO,
    june? : MonthCommandDataDTO,
    july? : MonthCommandDataDTO,
    august? : MonthCommandDataDTO,
    september? : MonthCommandDataDTO,
    october? : MonthCommandDataDTO,
    november? : MonthCommandDataDTO,
    december? : MonthCommandDataDTO,
}