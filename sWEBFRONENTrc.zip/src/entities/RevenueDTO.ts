export default interface RevenueDTO{
    new?: boolean;
    id?: number;
    year?: number;
    lineOfBusiness?: string;
    customerName?: string;
    projectName?: string;
    typeOfServiceName?: string;
    subTypeOfServiceName?: string;
    ownerProjectManagerName?: string;
    businessUnitCode?: string;
    serviceDescription?: string;
    customerCodeCenterCode?: string;
    chargingModelCode?: string;
    internalCostCenterPertCostCode?: string;
    internalCode?: string;
    currencyCode?: string;
    fyfclc?: number;
    fyfcchf?: number;
    fyfcchfvat?: number;
    editable?: boolean;
    january?: MonthlyRevenueDTO;
    february?: MonthlyRevenueDTO;
    march?: MonthlyRevenueDTO;
    april?: MonthlyRevenueDTO;
    may?: MonthlyRevenueDTO;
    june?: MonthlyRevenueDTO;
    july?: MonthlyRevenueDTO;
    august?: MonthlyRevenueDTO;
    september?: MonthlyRevenueDTO;
    october?: MonthlyRevenueDTO;
    november?: MonthlyRevenueDTO;
    december?: MonthlyRevenueDTO;
}

export interface MonthlyRevenueDTO{
    amount?: number;
    locked?: boolean;
}

export interface RevenuesDTO{
    count: number,
    revenues: RevenueDTO[],
}

export interface RevenueUpdateResult {
    errors: string[],
    revenue : RevenueDTO
}

export interface RevenueInsertResult {
    errors: string[],
    revenue : RevenueDTO
}