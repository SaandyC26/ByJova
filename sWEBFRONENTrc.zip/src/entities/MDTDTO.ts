export interface LOBDTO{
    id: number;
    name: string;
}
export interface CustomerDTO{
    id: number;
    name: string;
}

export interface UserDTO{
    id: number;
    name: string;
    samAccountName: string;
}

export interface ProjectDTO{
    id: number;
    name: string;
    customerId : number;
}

export interface TypeOfServiceDTO{
    id: number;
    name: string;
}
export interface SubTypeOfServiceDTO{
    id: number;
    name: string;
}

export interface ChargingModelDTO{
    id: number;
    name: string;
    code : string;
}

export interface BusinessUnitDTO{
    id: number;
    name: string;
    code : string;
}

export interface CurrencyDTO{
    id: number;
    name: string;
    code : string;
    symbol : string;
}

export interface CostCenterDTO{
    id: number;
    code : string;
    types : string;
}


export default interface MDTDTO<T>{
    count: number,
    masterDatas: T[],
}
