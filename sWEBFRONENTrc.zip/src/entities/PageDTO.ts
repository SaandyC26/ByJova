export default interface PageDTO<T> {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data: T[];
    total: number;
}
