import service from './Service';
import { Login } from '../constants/api_constants';
import { LoginDTO } from '../entities/LoginDTO';


export default {
    postLogin: async function(
        loginData: { username: string; password: string },
    ): Promise<LoginDTO> {
        return service.postLoginEndpointAsync(Login, loginData,  {withCredentials: false,}).then(response => {
           return JSON.parse(response);
        });
    },
    Refresh: async function(
        refreshData: { token: string; refreshToken: string },
    ): Promise<LoginDTO> {
        return service.postLoginEndpointAsync('Authentication/Refresh', refreshData, {withCredentials: false,}).then(response => {            
            return JSON.parse(response);
        });
    },
};
