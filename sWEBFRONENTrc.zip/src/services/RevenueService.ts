import service from './Service';
import { Request } from '../constants/api_constants';
import RevenueDTO, {RevenueUpdateResult,RevenueInsertResult}  from '../entities/RevenueDTO';
import {getCookie} from '../components/Functions/Utils';

export default {
    GetFinancial: async function(
        query: any,      
    ): Promise<RevenueDTO> {
        console.log(query)
        let Mod = '';
        switch (query.query){           
            case 'GetBarcelonaInvoicesQuery':  Mod = ', LinesOfBusinessNames : '+JSON.stringify(query.FilterLOB)  ; break;
            case 'GetRebookingsQuery': Mod = ', InternalCostCenterCode : "'+query.FilterCustomer+'"' ; break;
        }
        let requestData = {
            Type: query.query,
            Content: '{year: '+query.year+', month: "'+query.month+'" '+Mod+'}'
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            return JSON.parse(response);
        });
    },
    DownloadFinancial: async function(
        query: any,      
    ): Promise<any> {
        console.log(query)
        let Mod = '';
        switch (query.query){
            case 'ExportBarcelonaInvoicesQuery':  Mod = ', LinesOfBusinessNames : '+JSON.stringify(query.FilterLOB)  ; break;
            case 'ExportRebookingsQuery':  Mod = ', InternalCostCenterCode : '+JSON.stringify(query.FilterCustomer)  ; break;
        }
        if(typeof query.PastFuture !== 'undefined' && query.PastFuture){
            Mod += ', IncludePastFuture: \"true\",'
        }
        let requestData = {
            Type: query.query,
            Content: '{year: '+query.year+', month: "'+query.month+'" '+Mod+'}'
        }

        console.log(requestData)
        let Token = getCookie('ZurichCustomerPortal');
        return service.postFileEndpointAsync(Request, requestData, Token).then((response:any) => {
            let filename = response[1] as string;            
            const splittedFilename = filename.split(';');           
            if (splittedFilename !== undefined)
                {
                    filename = splittedFilename.find((n: string) => n.includes('filename="')) as string;
                }

            response[1] = filename.replace('filename="', '').replace('xlsx"', 'xlsx').trim();
            

            return response;
        });
    },
    addComment: async function(
        item: {Id: number, Comments: any},        
    ): Promise<any> {
        let requestData = {
            Type: "CreateRevenueCommentsCommand",
            Content: JSON.stringify(item)
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            return response;
        });
    },
    postRequest: async function(
        query: string,
        token : string
    ): Promise<RevenueDTO> {
        let requestData = {
            Type: "GetRevenuesQuery",
            Content: query
        }
        return service.postEndpointAsync(Request, requestData, token).then(response => {
            return JSON.parse(response);
        });
    },
    postUpdate: async function(
        query: string,
        token : string
    ): Promise<RevenueUpdateResult> {
        let requestData = {
            Type: "EditRevenueCommand",
            Content: query
        }
        return service.postEndpointAsync(Request, requestData, token).then(response => {
            return JSON.parse(response);
        });
    },
    postInsert: async function(
        query: string,
        token : string
    ): Promise<RevenueInsertResult> {
        let requestData = {
            Type: "CreateRevenueCommand",
            Content: query
        }
        console.log(query);
        
        return service.postEndpointAsync(Request, requestData, token).then(response => {
            return JSON.parse(response);
        });
    },
    postUpdateSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "EditRevenueCommand",
            Content: query
        }
        return service.postEndpointAsyncSoft(Request, requestData, token).then(response => {
            let data;           

            if(typeof response === 'object' && response !== null){                
                data = {type: 'ok', item: JSON.parse(response.item)};
            }else{               
                data = {type: 'error', item: response};
            }
            
            return data;
        });
    },
    postDeleteSoft: async function(
        item: any,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "DeleteRevenueCommand",
            Content: JSON.stringify({Id: item.id})
        }
        return service.postEndpointAsyncSoft(Request, requestData, token).then(response => {
           
           
            
            
            return response;
        });
    },
    postInsertSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "CreateRevenueCommand",
            Content: query
        }      
        return service.postEndpointAsyncSoft(Request, requestData, token).then(response => {           
            let data;
            if(typeof response === 'object' && response !== null){                
                data = {type: 'ok', item: response};
            }else{               
                data = {type: 'error', item: response};
            }
            
            return data;
        });
    },
};

