import Service from './Service';
import { YearDataDTO as yearData, YearCommandDataDTO as yearCommandData } from '../entities/YearDataDTO';
import { PageDto as page } from '../dtos/pageDto';
import { Request } from '../constants/api_constants';
import {getCookie} from '../components/Functions/Utils';


export default {
    getYearData: async function (        
        years : any
    ): Promise<page<yearData>> {
        let Token = getCookie('ZurichCustomerPortal');
        let data = {
            Type: "GetYearLocksSummaryQuery",
            Content: JSON.stringify({dataSourceRequest:{sort: years, skip: 0 , take: 0}})
        };

        return Service.postEndpointAsync(Request, data, Token).then(response => {          
            const subData = JSON.parse(response);
            return { data: subData.summaries, total: subData.count };
        });
    },
    putYearData: async function (
        token: string,
        blocked : any
    ): Promise<string> {
        let data = {
            type: "EditYearLocksCommand",
            content: JSON.stringify({YearLocks:blocked.data})
        };

        return Service.postEndpointAsync(Request, data, token).then(response => {
            return response;
        });
    }
}