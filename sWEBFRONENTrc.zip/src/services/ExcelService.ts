import { Excel } from '../constants/api_constants';
import service from './Service';

export default {    
    getBlankDemandExcel: async function(
             
    ): Promise<[Blob, string] | (string | Blob)[]> {
        let requestData = {
            Type: "GetRevenuesTemplateQuery",
            Content: ''
        }
        return service.postFileEndpointAsyncClean(requestData).then(response => {


            if(typeof response !== 'undefined'){
            let filename = response[1] as string;
            const splittedFilename = filename.split(';');
            if (splittedFilename !== undefined)
                filename = splittedFilename.find((n: string) => n.includes('filename=')) as string;
            response[1] = filename.replace('filename=', '').trim();

//            response[1] = "FinpoData.xlsx"
            return response;
        }else{return response}
        });
    },
    getExportedExcelFile: async function(
        query: string,
        token: string
    ): Promise<any> {
        let requestData = {
            Type: "ExportRevenuesTemplateQuery",
            Content: query
        }
        return service.postFileEndpointAsync(Excel, requestData, token).then(response => {

            console.log(response)
            if(typeof response !== 'undefined'){
            let filename = response[1] as string;
            const splittedFilename = filename.split(';');
            if (splittedFilename !== undefined)
                filename = splittedFilename.find((n: string) => n.includes('filename=')) as string;
            response[1] = filename.replace('filename=', '').trim();

//            response[1] = "FinpoData.xlsx"
            return response;
        }else{return response}
        });
    },
    getExportedBarcelonaFile: async function(
        query: string,
        token: string
    ): Promise<[Blob, string] | (string | Blob)[]> {
        let requestData = {
            Type: "ExportRevenuesTemplateQuery",
            Content: query
        }
        return service.postFileEndpointAsync(Excel, requestData, token).then(response => {

            let filename = response[1] as string;
            const splittedFilename = filename.split(';');
            if (splittedFilename !== undefined)
                filename = splittedFilename.find((n: string) => n.includes('filename=')) as string;
            response[1] = filename.replace('filename=', '').trim();

//            response[1] = "FinpoData.xlsx"
            return response;
        });
    },
    postFileAsync: async function(file: File, comments: string, token: string): Promise<string[]> {
        const formData = new FormData();
        formData.append('File', file);
        formData.append('comments', comments);
        formData.append('type', 'ImportRevenuesTemplateCommand')

        return service
            .putEndpointAsyncNoError(Excel, formData, token, {
                headers: {
                    'Content-Type': 'multipart/from-data',
                },
            })
            .then((response:any) => {  
                return response;
               
                
               
            })
            .catch(error => {
              
                
                return error;
            });
    },
};
