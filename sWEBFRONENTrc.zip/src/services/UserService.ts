import Service from './Service';
import { UserDto as user } from '../dtos/userDto';
import { PageDto as page } from '../dtos/pageDto';
import { State as DataState } from '@progress/kendo-data-query';
import { Request } from '../constants/api_constants';
import {getCookie} from '../components/Functions/Utils';


export default {    
    UpdateGrid: async function (
        query:any
        ): Promise<any> {          
            let data = {
                type: "EditCurrentUserProfileCommand",
                content: JSON.stringify({GridPreferences:{Revenues: JSON.stringify(query)}})
            };    
            
            let Token = getCookie('ZurichCustomerPortal');
    
            return Service.postEndpointAsync(Request, data, Token).then(response => {
                if(response === ""){
                    
                    return {errors:0, status: 'success'};
                }else{
                   return JSON.parse(response);
                }
                
            });
        },
    getMyUser: async function (
       
    ): Promise<any> {          
        let data = {
            type: "GetCurrentUserProfileQuery",
            content: JSON.stringify({               
                Content: ""
            })
        };    
        
        let Token = getCookie('ZurichCustomerPortal');

        return Service.postEndpointAsync(Request, data, Token).then(response => {
            return JSON.parse(response);
        });
    },
    getRestrictions: async function (
       
        ): Promise<any> {          
            let data = {
                Type: "GetRevenuesRestrictionsQuery",
                Content: JSON.stringify({})
            };    
            
            let Token = getCookie('ZurichCustomerPortal');
    
            return Service.postEndpointAsync(Request, data, Token).then(response => {
                return JSON.parse(response);
            });
        },
    HideNews: async function (
       
        ): Promise<any> {          
            let data = {
                type: "EditUserLastSeenReleaseNotesCommand",
                content: JSON.stringify({               
                    Content: ""
                })
            };    
            
            let Token = getCookie('ZurichCustomerPortal');
    
            return Service.postEndpointAsync(Request, data, Token).then(response => {
                return response;
            });
        },     
    getUsers: async function (
        token: string,
        includeRoles: boolean,
        includeProjects: boolean,
        dataState: DataState,
        replaces?: { field: string, newField: string }[],
        includeGroups?: boolean
    ): Promise<page<user>> {
        let dtos: string[] = [];
        if (includeRoles === true) dtos.push('Role');
        if (includeProjects === true) dtos.push('Project');
        if (includeGroups === true) dtos.push('Group');
        let data = {
            type: "GetUsersQuery",
            content: JSON.stringify({
                dtos: dtos,
                dataSourceRequest: dataState
            })
        };

        if (replaces) replaces.forEach(r => {
            data.content = data.content.replace("\"field\":" + "\"" + r.field.toLowerCase() + "\"", "\"field\":" + "\"" + r.newField.toLowerCase() + "\"")
        });

        return Service.postEndpointAsync(Request, data, token).then(response => {
            const subData = JSON.parse(response);
            return { data: subData.users, total: subData.count };
        });
    },
    getUserGroups: async function (
        token: string,       
        dataState: DataState,       
    ): Promise<page<user>> {
        let dtos: string[] = [];
         dtos.push('User');
      
        let data = {
            type: "GetGroupsQuery",
            content: JSON.stringify({
                dtos: dtos,
                dataSourceRequest: {take:0, skip: 0}
            })
        };


        return Service.postEndpointAsync(Request, data, token).then(response => {
            const subData = JSON.parse(response);
            return { data: subData.groups, total: subData.count };
        });
    },
    postInsert: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "CreateUserCommand",
            Content: query
        }
        
        
        return Service.postEndpointAsync(Request, requestData, token).then(response => {
           
                return response;
            
        });
    },
    postInsertSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "CreateUserCommand",
            Content: query
        }       
        
        return Service.postEndpointAsyncSoft(Request, requestData, token).then(response => {  
                 
                return response;            
        }).catch(error => {
          
            return {type: 'error', item: error.response};
        });
    },
    postGroupInsertSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "CreateGroupCommand",
            Content: query
        }       
        
        return Service.postEndpointAsyncSoft(Request, requestData, token).then(response => {  
                   
                return response;            
        }).catch(error => {
          
            return {type: 'error', item: error.response};
        });
    },
    postDelete: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "DeleteUserCommand",
            Content:  query             
           
        }
        
        
        return Service.postEndpointAsync(Request, requestData, token).then(response => {
            
            return response;
        });
    },
    postGroupDelete: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "DeleteGroupCommand",
            Content:  query             
           
        }
        
        
        return Service.postEndpointAsync(Request, requestData, token).then(response => {
            
            return response;
        });
    },
    postUpdate: async function(
        query: string,
        token : string
    ): Promise<user> {
        let requestData = {
            Type: "EditUserCommand",
            Content: query
        }
        return Service.postEndpointAsync(Request, requestData, token).then((response:any) => {
            if(response === "" && response !== 'not equal'){
                
                return {errors:0, status: 'success'};
            }else{
                return JSON.parse(response);
            }
            
        });
    },
    postUpdateSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "EditUserCommand",
            Content: query
        }
        return Service.postEndpointAsyncSoft(Request, requestData, token).then(response => {
            
            return response;
            
        }).catch(error => {
            return {type: 'error', item: error.response};
        });
    },
    postGroupUpdateSoft: async function(
        query: string,
        token : string
    ): Promise<any> {
        let requestData = {
            Type: "EditGroupCommand",
            Content: query
        }
        return Service.postEndpointAsyncSoft(Request, requestData, token).then(response => {
           
            return response;
            
        }).catch(error => {
            return {type: 'error', item: error.response};
        });
    },
    Tickets_Get: async function (OnlyMimes: boolean,IncludeHidden:boolean): Promise<any> 
    {        
        let requestData = {
            Type: "GetTicketsQuery",
            Content: "{ OnlyMines: "+OnlyMimes+", IncludeHidden: "+IncludeHidden+", DataSourceRequest: { Take: 10, Skip: 0, Sort: [{ Field: \"id\", Dir: 1 } ] } }"
        }
        return Service.postEndpointAsync(Request, requestData).then(response => {
            
            const regex = new RegExp("(id\":)(.*?)(?:,)", 'mg')
            let starter = 0;
            const result:any = JSON.parse(response, (key, value) => { 
               
                if (typeof value === 'number' && !Number.isSafeInteger(value)) {                  
                    
                    let strBig:any;
                    let regie = response.match(regex);  
                                  
                    if(regie !== null){
                        
                        strBig = regie[starter] 
                        strBig = strBig.split(":");
                        strBig = strBig[1];
                        starter++
                        // get the original value using regex expression 
                    }
                    return strBig.replace(',','').toString() //should be BigInt(strBig) - BigInt function is not working in this snippet
                }
                return value
            })
           
            
           
            return { data: result.tickets, total: result.count };
        });
    },
    Tickets_Add: async function (summary:any, description:any, type:any): Promise<any> 
    {        
            let requestData = {
                Type: "CreateTicketCommand",
                Content: "{ Ticket: { Summary: \""+summary+"\", Description: \""+description+"\", Type: \""+type+"\" } }"
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                return response
            });
    },
    Tickets_Comment_Add: async function (id:number, text:any): Promise<any> 
    {        
            let requestData = {
                Type: "CreateTicketCommentCommand",
                Content: "{TicketId: "+id+" , TicketComment: {Text: \""+text+"\"}}"
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                return response
            });
    },
    Tickets_Comment_Get: async function (id:number): Promise<any> 
    {        
            let requestData = {
                Type: "GetTicketCommentsQuery",
                Content: "{TicketId: "+id+" }"
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                
                const regex = new RegExp("(id\":)(.*?)(?:,)", 'mg')
                let starter = 0;
                const result:any = JSON.parse(response, (key, value) => { 
                   
                    if (typeof value === 'number' && !Number.isSafeInteger(value)) {                  
                        
                        let strBig:any;
                        let regie = response.match(regex);  
                                        
                        if(regie !== null){
                            
                            strBig = regie[starter] 
                            strBig = strBig.split(":");
                            strBig = strBig[1];
                            starter++
                            // get the original value using regex expression 
                        }
                        return strBig.replace(',','').toString() //should be BigInt(strBig) - BigInt function is not working in this snippet
                    }
                    return value
                })
               
                
               
                return { data: result.ticketComments, total: result.count };
            });
    },
    Tickets_Comment_Delete: async function (id:number, ticketId:number): Promise<any> 
    {        
            let requestData = {
                Type: "DeleteTicketCommentCommand",
                Content: "{id: "+id+", TicketId: "+ticketId+"}"
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                return response
            });
    },
    Tickets_Update: async function (props:any): Promise<any> 
    {        
        function Convert(){
            let Line = "{Ticket: {";
            for (const [key, value] of Object.entries(props)) {
               if(key !== 'links' && key !== 'comments'){ 
                if(Line !== "{Ticket: {"){Line += ', '}
                    if(key === 'id'){
                        Line += key + ': '+value
                    }
                    else if(value === null){
                        Line += key + ': '+value;
                    }
                    else{
                        Line += key + ': \"'+value+'\"'     
                    }
                    
                }
            }
            Line += "}}"

            return Line

        }

            let requestData = {
                Type: "UpdateTicketCommand",
                Content: Convert()
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                return response
            });
    },
    Tickets_Delete: async function (id:any): Promise<any> 
    {        
            let requestData = {
                Type: "DeleteTicketCommand",
                Content: "{ id: "+id+"  }"
            }
            return Service.postEndpointAsync(Request, requestData).then(response => {                
                return response
            });
    },
}