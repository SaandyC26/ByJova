import service from './Service';
import { Request } from '../constants/api_constants';
import MDTDTO, {
    LOBDTO, 
    CustomerDTO, 
    ProjectDTO, 
    TypeOfServiceDTO, 
    BusinessUnitDTO, 
    ChargingModelDTO,
    CurrencyDTO,
    UserDTO,
    CostCenterDTO,
    SubTypeOfServiceDTO
} from '../entities/MDTDTO';
import {getCookie} from '../components/Functions/Utils';


 const MDTService:any = {
    postInsertMasterDataItem: async function(
                query: string,
                token : string,
                table: string,
            ): Promise<string[]> {

                let contentData = {
                    Type: table.replace('postRequest',''),
                    MasterData: query                    
                }
                let requestData = {
                    Type: "CreateMasterDataCommand",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsyncSoft(Request, requestData, Token).then((response:any) => {
                    
                    return response;
                });
            },
    postEditMasterDataItem: async function(
                query: string,
                token : string,
                table: string,
            ): Promise<string[]> {

                

                let contentData = {                   
                    Type: table.replace('postRequest','') ,
                    MasterData: query                
                }
               

                let requestData = {
                    Type: "EditMasterDataCommand",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request, requestData, Token).then((response:any) => {
                    
                    return response;
                });
            }, 
    getRequestRoles: async function(                
                token : string
            ): Promise<any> {                 
                let requestData = {
                    Type: "GetRolesQuery",
                    Content: JSON.stringify({ Dtos: ["Permission"] })
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request,requestData, Token).then(response => {                    
                    var data : any;
                    var result : any = new Array;
                    data = JSON.parse(response);
                    data.roles.forEach((entity: any) => {
                        result.push(entity);
                    });
                    return result.sort();
                });
            }, 
    getRequestPermissions: async function(      
                token : string
            ): Promise<string[]> {                
                let requestData = {
                    Type: "GetPermissionsQuery",
                    
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request,requestData, Token).then(response => {
                    var data : any;
                    var result : any = new Array;
                    data = JSON.parse(response);
                    data.permissions.forEach((entity: any) => {
                        result.push(entity);
                    });
                    return result.sort();
                });
            }, 
    postNewRole: async function(
                query: string                
            ): Promise<string> {                
                let requestData = {
                    Type: "CreateRoleCommand",
                    Content: JSON.stringify({role : query}),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request,requestData, Token).then(response => {                 
                   
                    return response;
                });
            },
    postEditRole: async function(
        query: string                
    ): Promise<string> {        
        let requestData = {
            Type: "EditRoleCommand",
            Content: JSON.stringify({role : query}),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsyncSoft(Request,requestData, Token).then(response => {                 
            
            return response;
        });
    },
    postDeleteRole: async function(
        query: string                
    ): Promise<string> {       
        let requestData = {
            Type: "DeleteRoleCommand",
            Content: JSON.stringify({id: query}),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request,requestData, Token).then(response => {                 
            
            return response;
        });
    },                        
    postRequestLineOfBusiness: async function(
//        query: string,
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "LineOfBusiness",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<LOBDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: LOBDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestProducts: async function(
        //        query: string,
                token : string
            ): Promise<string[]> {
                let contentData = {
                    Type: "Product",
                    DataSourceRequest: {
                        Take: 0,
                        Skip: 0,
                    }
                }
                let requestData = {
                    Type: "GetMasterDatasQuery",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request, requestData, Token).then((response:any) => {
                    var result: any = new Array;
                    JSON.parse(response).masterDatas.forEach((entity: LOBDTO) => {
                        result.push(entity);
                    });
                    return result.sort();
                });
            },
    postRequestProjectType: async function(
        //        query: string,
                token : string
            ): Promise<string[]> {
                let contentData = {
                    Type: "ProjectType",
                    DataSourceRequest: {
                        Take: 0,
                        Skip: 0,
                    }
                }
                let requestData = {
                    Type: "GetEnumValuesQuery",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request, requestData, Token).then((response:any) => {
                    var result: any = new Array;                   
                    JSON.parse(response).values.forEach((entity: LOBDTO) => {
                        result.push(entity);
                    });
                    return result.sort();
                });
            },   
    postRequestTestingTool: async function(
        //        query: string,
                token : string
            ): Promise<string[]> {
                let contentData = {
                    Type: "TestingTool",
                    DataSourceRequest: {
                        Take: 0,
                        Skip: 0,
                    }
                }
                let requestData = {
                    Type: "GetMasterDatasQuery",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request, requestData, Token).then((response:any) => {
                    var result: any = new Array;
                    JSON.parse(response).masterDatas.forEach((entity: LOBDTO) => {
                        result.push(entity);
                    });
                    return result.sort();
                });
            },                    
    postRequestMasterDataTabletoEdit: async function(
                query: string,
                token : string
            ): Promise<string[]> {
                let contentData:any = {
                    Type: query,
                    DataSourceRequest: {
                        Take: 0,
                        Skip: 0,
                    }
                }
               
                if(query === 'CostCenter'){
                    contentData.IncludeDisabled = true
                }
                let requestData = {
                    Type: "GetMasterDatasQuery",
                    Content: JSON.stringify(contentData),
                }
                let Token = getCookie('ZurichCustomerPortal');
                return service.postEndpointAsync(Request, requestData, Token).then(response => {                                       
                    return JSON.parse(response)
                });
            },
    postRequestCustomer: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "Customer",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : any;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: CustomerDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestProject: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "Project",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<ProjectDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: ProjectDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestTypeOfService: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "TypeOfService",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<TypeOfServiceDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: TypeOfServiceDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestSubTypeOfService: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "SubTypeOfService",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<SubTypeOfServiceDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: TypeOfServiceDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestChargingModel: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "ChargingModel",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<ChargingModelDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: ChargingModelDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestChargingModelType: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "ChargingModelType",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<ChargingModelDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: ChargingModelDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestCustomerFunctions: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "CustomerFunction",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<ChargingModelDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: ChargingModelDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestBusinessUnit: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "BusinessUnit",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<BusinessUnitDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: BusinessUnitDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestCurrency: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "Currency",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<CurrencyDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: CurrencyDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestCurrencyConversion: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "CurrencyExchangeRate",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then((response:any) => {           
            var result : any = new Array;           
            JSON.parse(response).masterDatas.forEach((entity: any) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestUsers: async function(
        token : string
    ): Promise<string[]> {        
        let requestData = {Type: "GetUsersQuery"}
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            
            var result : any = new Array;
            let data = JSON.parse(response);            
            data.users.forEach((entity: UserDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
    postRequestCostCenter: async function(
        token : string
    ): Promise<string[]> {
        let contentData = {
            Type: "CostCenter",
            DataSourceRequest: {
                Take: 0,
                Skip: 0,
            }
        }
        let requestData = {
            Type: "GetMasterDatasQuery",
            Content: JSON.stringify(contentData),
        }
        let Token = getCookie('ZurichCustomerPortal');
        return service.postEndpointAsync(Request, requestData, Token).then(response => {
            var data : MDTDTO<CostCenterDTO>;
            var result : any = new Array;
            data = JSON.parse(response);
            data.masterDatas.forEach((entity: CostCenterDTO) => {
                result.push(entity);
            });
            return result.sort();
        });
    },
};

export default MDTService