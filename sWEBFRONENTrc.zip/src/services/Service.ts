import axios, { AxiosResponse, AxiosRequestConfig } from 'axios';
import Configuration from '../configuration/configuration';


const API_ENDPOINT = Configuration.value('API_ENDPOINT');
const REACT_APP_API_LOGIN_ENDPOINT = Configuration.value('API_LOGIN_ENDPOINT');

 
export default {
    getEndpointAsync: async function (endpoint: string, token: string): Promise<string> {
        if (API_ENDPOINT !== undefined) {
            return axios
                .get(API_ENDPOINT + endpoint, {
                    transformResponse: (r: string) => {
                        return r;
                    },
                    headers: {
                       
                    },
                })
                .then(response => {
                    return this.handleResponse(response);
                })
                .catch(error => {
                    return this.handleResponse(error.response);
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    getFileEndpointAsync: async function (endpoint: string, token: string): Promise<[Blob, string] | (string | Blob)[]> {
        if (API_ENDPOINT !== undefined) {
            return axios
                .get(API_ENDPOINT + endpoint, {
                    transformResponse: (r: string) => {
                        return r;
                    },
                    headers: {
                       
                    },
                    responseType: 'blob',
                })
                .then(response => {
                    return [
                        (this.handleResponse(response) as unknown) as Blob,
                        response.headers['content-disposition'] as string,
                    ];
                })
                .catch(error => {
                    return [
                        (this.handleResponse(error.response) as unknown) as Blob,
                        error.response.headers['content-disposition'] as string,
                    ];
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    postEndpointAsync: async function (
        endpoint: string,
        data: any,
        token?: any,
        options?: AxiosRequestConfig,
    ): Promise<string> {
        
        if (API_ENDPOINT !== undefined) {
            
            options = { ...options, headers: { ...options?.headers } };           
            return axios
                .post(API_ENDPOINT + endpoint, data, {
                    transformResponse: (r: string) => {
                       
                        return r;
                    },
                    ...options,
                })
                .then(response => {
                    
                    return this.handleResponse(response);
                })
                .catch(error => {
                    
                    return this.handleResponse(error.response);
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    postEndpointAsyncSoft: async function (
        endpoint: string,
        data: any,
        token: any,
        options?: AxiosRequestConfig,
    ): Promise<any> {        
        if (API_ENDPOINT !== undefined) {
            
            options = { ...options, headers: { ...options?.headers } };           
            return axios
                .post(API_ENDPOINT + endpoint, data, {
                    transformResponse: (r: any) => {                      
                        return r;
                    },
                    ...options,
                })
                .then(response => {
                    console.log('no es error')
                    return {type: 'ok', item: this.handleResponse(response)}
                }).catch(error => {
                    console.log('Es error!')
                    console.log(error)
                    return false;
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    postLoginEndpointAsync: async function (
        endpoint: string,
        data: object,       
        options?: AxiosRequestConfig,
    ): Promise<string> {
        if (REACT_APP_API_LOGIN_ENDPOINT !== undefined) {
            options = { ...options, headers: { ...options?.headers} };
            return axios
                .post(REACT_APP_API_LOGIN_ENDPOINT + endpoint, data, {
                    transformResponse: (r: string) => {
                        return r;
                    },
                    ...options,
                })
                .then(response => {
                    return this.handleResponse(response);
                })
                .catch(error => {
                    return this.handleResponse(error.response);
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    postFileEndpointAsync: async function (
        endpoint: string,
        data: object,
        token: string,
        options?: AxiosRequestConfig,
    ): Promise<any> {
        if (API_ENDPOINT !== undefined) {
            options = { ...options, headers: { ...options?.headers } };          
           
            return axios
                .post(API_ENDPOINT + endpoint, data, {
                    transformResponse: (r: any) => { 
                        return r;
                    },
                    responseType: 'blob',                    
                    ...options,
                })
                .then(response => {   
                      
                        return [
                            (this.handleResponseSoft(response) as unknown) as Blob,                            
                            response.headers['content-disposition'] as string,
                        ];
                    
                    
                })
                .catch(() => {  
                    return axios
                    .post(API_ENDPOINT + endpoint, data, {
                        transformResponse: (r: any) => { 
                            return r;
                        },                                           
                        ...options,
                    }).then(response => {                         
                       return this.handleResponseSoft(response);
                    
                })
                    
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    postFileEndpointAsyncClean: async function (
       
        data: object,       
        options?: AxiosRequestConfig,
    ): Promise<[any, string] | (string | any)[]> {
        if (API_ENDPOINT !== undefined) {
            options = { ...options, headers: { ...options?.headers } };
            return axios
                .post(API_ENDPOINT + 'request', data, {
                    transformResponse: (r: string) => {
                        
                        return r;
                    },
                    responseType: 'blob',
                    ...options,
                })
                .then((response:any) => {                   
                     console.log('not equal...')
                        return [
                            (this.handleResponseSoft(response) as unknown) as Blob,
                            response.headers['content-disposition'] as string,
                        ];
                    
                    
                })
                .catch(error => {                    
                    return (this.handleResponseSoft(error.response))
                    
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    putEndpointAsync: async function (
        endpoint: string,
        data: object | string,
        token: string,
        options?: AxiosRequestConfig,
    ): Promise<string> {
        if (API_ENDPOINT !== undefined) {
            options = { ...options, headers: { ...options?.headers} };
            return axios
                .put(API_ENDPOINT + endpoint, data, {
                    transformResponse: (r: string) => {
                        return r;
                    },
                    ...options,
                })
                .then(response => {
                    return this.handleResponse(response);
                })
                .catch(error => {
                    return this.handleResponse(error.response);
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    putEndpointAsyncNoError: async function (
        endpoint: string,
        data: object | string,
        token: string,
        options?: AxiosRequestConfig,
    ): Promise<string> {
        if (API_ENDPOINT !== undefined) {
            let rawresponse = '';
            options = { ...options, headers: { ...options?.headers } };
            return axios
                .put(API_ENDPOINT + endpoint, data, {
                    transformResponse: (r: any) => {                       
                        rawresponse = r; 
                        return r;
                    },
                    ...options,
                })
                .then((response:any) => {                   
                    return response;
                }).catch(error => {
                   
                    if(error.response.status === 400){
                        return {ServerError : true, Desc: rawresponse}
                    }
                    if(error.response.status === 500){
                        return {ServerError : true, Desc: rawresponse}
                    }
                    else{return rawresponse;}
                });
                
        } else {
            throw Error('No API URL defined');
        }
    },
    deleteEndpointAsync: async function (
        endpoint: string,
        data: object | string,
        token: string,
        options?: AxiosRequestConfig,
    ): Promise<string> {
        if (API_ENDPOINT !== undefined) {
            options = { ...options, headers: { ...options?.headers } };
            return axios
                .delete(API_ENDPOINT + endpoint, {
                    transformResponse: (r: string) => {
                        return r;
                    },
                    ...options,
                    data: data,
                })
                .then(response => {
                    return this.handleResponse(response);
                })
                .catch(error => {
                    return this.handleResponse(error.response);
                });
        } else {
            throw Error('No API URL defined');
        }
    },
    handleResponse: function (response: AxiosResponse<string> | undefined): any {
        if (response) {
            if (response.status === 200 || response.status === 201 || response.status === 204) {
                return response.data;
            } else if (
                response.status === 400 ||
                response.status === 401 ||
                response.status === 409 ||
                response.status === 404 ||
                response.status === 415
            ) {
                throw Error(JSON.stringify(response));
                //HTTP Request error
            } else if (response.status === 500) {
                
                throw Error(JSON.stringify(response.data));
                //Server error
            } else {
                throw Error('Unknown error');
                //Error
            }
        }
       
    },
    handleResponseSoft: function (response: AxiosResponse<string> | undefined): any {
        
        if (response) {
           
            if (response.status !== 500) {   
                          
                return response.data;
            } else{  
                console.log('buen status')
                return (JSON.stringify(response.data));}
        }
        
    },
};
