import React from 'react';
import './components/Generic/transitions.css';
import './App.css';
import {Navigate , Route, Routes} from 'react-router-dom';
import {Navigation} from './components/Generic/RouteTypes';
import Login from './components/Pages/Login';
import { withCookies } from 'react-cookie';
import {getCookie} from './components/Functions/Utils'

function CheckLoginStatus(){   
  // look for mandatory cookies          
  return getCookie('ZurichCustomerPortal') !== '' ? true : false;
}

function App() {

  let IsLogged = CheckLoginStatus();  
  
  // we read Navigation array to get posible routes
  const DinamicRoutes = Navigation.map((element:any) => {     
       return(
        <Route key={'route-'+element.Name} path={element.Path} element={IsLogged 
          ? <element.ToLoad/> 
          : <Navigate to={{pathname: '/login/'}}/> }
           />

       
       )
  }) 
  


  return (
    
    <div className="App">
      <Routes>
          <Route path="/" element={<Navigate to="/home/" />} />          
          <Route path="/login/" element={!IsLogged ? <Login/> : <Navigate to={{pathname: '/home/'}}/>}  />
          {DinamicRoutes} 
      </Routes>
    </div>
    
  );
}

export default withCookies(App);
