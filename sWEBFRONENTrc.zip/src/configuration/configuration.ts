import * as dotenv from 'dotenv';
dotenv.config();

export default class Configuration {
    static get CONFIG(): { [key: string]: string } {
        return {
            API_ENDPOINT: '$REACT_APP_API_ENDPOINT',
            TENANT_ID: '$REACT_APP_TENANT_ID',
            CLIENT_ID: '$REACT_APP_CLIENT_ID',
            REDIRECT_URI: '$REACT_APP_REDIRECT_URI',
            AUTHORITY: '$REACT_APP_AUTHORITY',
            API_LOGIN_ENDPOINT: '$REACT_APP_API_LOGIN_ENDPOINT',
            MODE: '$REACT_APP_MODE',
            HEADER: '$REACT_APP_HEADER',
        };
    }

    static value(name: string): string {
        if (!(name in this.CONFIG)) {           
            throw Error();
        }

        const value = this.CONFIG[name];

        if (!value) {           
            throw Error();
        }

        if (value.startsWith('$REACT_APP_')) {
            // value was not replaced, it seems we are in development.
            // Remove $ and get current value from process.env
            const envName = value.substring(1);
            const envValue = process.env[envName];
            if (envValue) {
                return envValue;
            } else {
                throw Error();
            }
        } else {
            // value was already replaced, it seems we are in production.
            return value;
        }
    }
}
