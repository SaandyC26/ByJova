﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class MasterDataFrontEndRepository : BaseRepository, IMasterDataFrontEndRepository
    {
        #region --- CONSTRUCTORS ---

        internal MasterDataFrontEndRepository(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        // MasterData Generic
        public async Task<(int Count, IEnumerable<TDto> MasterDatas)> GetMasterDatasByEntityAsync<TDto, TEntity>(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, CancellationToken cancellationToken = default) where TDto : MasterDataDto where TEntity : MasterData =>
            await GetAsync<TDto, TEntity>(
                DbContext.Set<TEntity>(includeNavigationPropertyPaths: MasterDataRepository.GetIncludeNavigationPropertyPaths<TEntity>(true, dtos), true),
                dataSourceRequest: dataSourceRequest,
                includeCount: includeCount,
                cancellationToken: cancellationToken
            ).ConfigureAwait(false);

        public async Task<(int Count, IEnumerable<object> MasterDatas)> GetMasterDatasByEntityAsync(Type dtoType, Type entityType, string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, CancellationToken cancellationToken = default)
        {
            var method = GetType().GetMethod(nameof(GetMasterDatasByEntityAsync), new Type[] { typeof(string[]), typeof(DataSourceRequest), typeof(bool), typeof(CancellationToken) });
            var parameters = new object[]
            {
                dtos,
                dataSourceRequest,
                includeCount,
                cancellationToken
            };

            var task = (Task)method.MakeGenericMethod(dtoType, entityType).Invoke(this, parameters);
            await task.ConfigureAwait(false);
            return ((int)((dynamic)task).Result.Item1, ((dynamic)task).Result.Item2);
        }

        #endregion
    }
}
