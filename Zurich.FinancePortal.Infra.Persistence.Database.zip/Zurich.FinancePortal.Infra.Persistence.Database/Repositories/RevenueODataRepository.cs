﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using System;
using System.Linq;

internal sealed class RevenueODataRepository : BaseRepository, IRevenueODataRepository
{
    #region --- CONSTRUCTORS ---

    internal RevenueODataRepository(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public IQueryable<RevenueODataDto> GetQueryable() => DbContext.RevenuesODataDto.AsQueryable();

    #endregion
}
