﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class RoleRepository : BaseRepository, IRoleRepository
    {
        #region --- CONSTRUCTORS ---

        internal RoleRepository(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public void AddRole(Role role) =>
            DbContext.Roles.Add(role);

        public void RemoveRole(Role role) =>
            DbContext.Roles.Remove(role);

        public async Task<Role> GetRoleByIdAsync(int id, bool asNoTracking = false, bool includeUsers = false, bool includePermissions = false, CancellationToken cancellationToken = default) =>
            await (await DbContext.GetRoleBaseQueryAsync(asNoTracking, includeUsers: includeUsers, includePermissions: includePermissions, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(r => r.Id.Equals(id), cancellationToken: cancellationToken).ConfigureAwait(false);

        public async Task<(int Count, IEnumerable<Role> Result)> GetRolesAsync(bool asNoTracking = false, bool includeUsers = false, bool includePermissions = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
        {
            var (count, result) = await DbContext.GetRoleBaseQueryAsync(asNoTracking, includeUsers: includeUsers, includePermissions: includePermissions, dataSourceRequest: dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return (count, await result.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
        }

        public async Task<(int Count, IEnumerable<Permission> Result)> GetPermissionsAsync(bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
        {
            var (count, result) = await DbContext.GetPermissionBaseQueryAsync(asNoTracking, dataSourceRequest: dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return (count, await result.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
        }

        #endregion
    }

    internal static class RoleRepositoryExtensions
    {
        #region --- INTERNAL METHODS ---

        internal async static Task<(int Count, IQueryable<Role> Result)> GetRoleBaseQueryAsync(this ApplicationDbContext dbContext, bool asNoTracking, bool includeUsers = false, bool includePermissions = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
        {
            var (count, query) = (0, asNoTracking ? dbContext.Roles.AsNoTracking() : dbContext.Roles);
            if (includeUsers) query = query.Include(r => r.Users);
            if (includePermissions) query = query.Include(r => r.Permissions);
            (count, query) = await query.HandleDataSourceRequestAsync(dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return (count, query);
        }

        internal async static Task<(int Count, IQueryable<Permission> Result)> GetPermissionBaseQueryAsync(this ApplicationDbContext dbContext, bool asNoTracking, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default) =>
            await (asNoTracking ? dbContext.Permissions.AsNoTracking() : dbContext.Permissions).HandleDataSourceRequestAsync(dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);

        #endregion
    }
}
