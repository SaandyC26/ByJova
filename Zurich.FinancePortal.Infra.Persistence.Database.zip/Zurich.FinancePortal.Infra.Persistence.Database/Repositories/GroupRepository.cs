﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class GroupRepository : BaseRepository, IGroupRepository
{
    #region --- CONSTRUCTORS ---

    internal GroupRepository(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public void AddGroup(Group group) => DbContext.Groups.Add(group);

    public void RemoveGroup(Group group) => DbContext.Groups.Remove(group);

    public async Task<Group> GetGroupByIdAsync(int id, bool asNoTracking = false, bool includeUsers = false, CancellationToken cancellationToken = default) => await (await DbContext.GetGroupBaseQueryAsync(asNoTracking, includeUsers: includeUsers, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(r => r.Id.Equals(id), cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<(int Count, IEnumerable<Group> Result)> GetGroupsAsync(bool asNoTracking = false, bool includeUsers = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
    {
        var (count, result) = await DbContext.GetGroupBaseQueryAsync(asNoTracking, includeUsers: includeUsers, dataSourceRequest: dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
        return (count, await result.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
    }

    public async Task<Group> GetGroupByNameAsync(string name, bool asNoTracking = false, bool includeUsers = false, CancellationToken cancellationToken = default) => await(await DbContext.GetGroupBaseQueryAsync(asNoTracking, includeUsers: includeUsers, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(r => r.Name.ToUpper().Equals(name.ToUpper()), cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<bool> IsBeingUsedAsync(Group group, CancellationToken cancellationToken = default) => await DbContext.Revenues.AsNoTracking().Include(x => x.GroupOwner).AnyAsync(x => x.GroupOwner.Id.Equals(group.Id), cancellationToken: cancellationToken).ConfigureAwait(false);

    #endregion
}

internal static class GroupRepositoryExtensions
{
    #region --- INTERNAL METHODS ---

    internal async static Task<(int Count, IQueryable<Group> Result)> GetGroupBaseQueryAsync(this ApplicationDbContext dbContext, bool asNoTracking, bool includeUsers = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
    {
        var (count, query) = (0, asNoTracking ? dbContext.Groups.AsNoTracking() : dbContext.Groups);
        if (includeUsers) query = query.Include(r => r.Users);
        (count, query) = await query.HandleDataSourceRequestAsync(dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
        return (count, query);
    }

    #endregion
}
