﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class RevenueRepository : BaseRepository, IRevenueRepository
{
    #region --- CONSTRUCTORS ---

    internal RevenueRepository(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    public void AddRevenue(Revenue revenue) =>
        DbContext.Revenues.Add(revenue);

    public void RemoveRevenue(Revenue revenue) =>
        DbContext.Revenues.Remove(revenue);

    public async Task<IEnumerable<Revenue>> GetRevenuesAsync(int year = -1, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default)
    {
        var query = DbContext.GetRevenueBaseQuery(asNoTracking, includeComments: includeComments);
        if (year > -1) query = query.Where(r => r.Year.Equals(year));
        return await (await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).SetCurrencyExchangeRates(DbContext, asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false);
    }

    public async Task<Revenue> GetRevenueByIdAsync(long id, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default) =>
        await (await DbContext.GetRevenueBaseQuery(asNoTracking, includeComments: includeComments).SingleOrDefaultAsync(r => r.Id.Equals(id), cancellationToken: cancellationToken).ConfigureAwait(false))
            .SetCurrencyExchangeRates(DbContext, asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<IEnumerable<Revenue>> GetRevenuesByYearAndCurrencyAsync(int year, Currency currency, CurrencyExchangeRate exclude = default, CurrencyExchangeRate include = default, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default) =>
        await (await DbContext.GetRevenueBaseQuery(asNoTracking, includeComments: includeComments).Where(r => r.Year.Equals(year) && r.Currency.Id.Equals(currency.Id)).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false))
            .SetCurrencyExchangeRates(DbContext, asNoTracking, include: include, exclude: exclude, cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<IEnumerable<Revenue>> GetRevenuesByYearAndUniqueIndexAsync(int year, (string LineOfBusinessName, string CustomerName, string ProjectName, string TypeOfServiceName, string ServiceDescription)[] uniques, bool includeComments = false, bool asNoTracking = false, CancellationToken cancellationToken = default)
    {
        var result = await DbContext.GetRevenueBaseQuery(asNoTracking, includeComments: includeComments).Where(r => r.Year.Equals(year)).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        return (await result.Where(r => uniques.Any(r2 =>
            r.LineOfBusiness.Name.EqualsICIC(r2.LineOfBusinessName)
            && r.Customer.Name.EqualsICIC(r2.CustomerName)
            && r.Project.Name.EqualsICIC(r2.ProjectName)
            && r.TypeOfService.Name.EqualsICIC(r2.TypeOfServiceName)
            && (string.IsNullOrWhiteSpace(r.ServiceDescription) ? string.IsNullOrWhiteSpace(r2.ServiceDescription) : r.ServiceDescription.EqualsICIC(r2.ServiceDescription))))
        .SetCurrencyExchangeRates(DbContext, asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false));
    }

    public async Task<IEnumerable<int>> GetRevenuesYearsAsync(CancellationToken cancellationToken = default) => await DbContext.Revenues.AsNoTracking().Select(x => x.Year).Distinct().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

    public void AddYearLock(YearLocks yearLock) => DbContext.YearLocks.Add(yearLock);

    public void RemoveYearLock(YearLocks yearLock) => DbContext.YearLocks.Remove(yearLock);

    public async Task<IEnumerable<YearLocks>> GetYearLocksAsync(bool asNoTracking = false, CancellationToken cancellationToken = default)
    {
        var query = asNoTracking ? DbContext.YearLocks.AsNoTracking() : DbContext.YearLocks;
        return await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
    }

    #endregion
}

internal static class RevenueRepositoryExtensions
{
    #region --- INTERNAL METHODS ---

    internal async static Task<Revenue> SetCurrencyExchangeRates(this Revenue revenue, ApplicationDbContext dbContext, bool asNoTracking, CancellationToken cancellationToken = default) =>
        revenue == null ? null : (await (new Revenue[] { revenue }).SetCurrencyExchangeRates(dbContext, asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false)).Single();

    internal async static Task<IEnumerable<Revenue>> SetCurrencyExchangeRates(this IEnumerable<Revenue> revenues, ApplicationDbContext dbContext, bool asNoTracking, CurrencyExchangeRate exclude = default, CurrencyExchangeRate include = default, CancellationToken cancellationToken = default)
    {
        var currencyExchangeRates = await (asNoTracking ? dbContext.CurrenciesExchangeRates.AsNoTracking() : dbContext.CurrenciesExchangeRates).Include(cer => cer.To).Include(cer => cer.From).ToListAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        if (include != null) currencyExchangeRates.Add(include);
        if (exclude != null) currencyExchangeRates.Remove(exclude);
        revenues.ForEach(r => r.SetCurrencyExchangeRates(currencyExchangeRates));
        return revenues;
    }

    internal static IQueryable<Revenue> GetRevenueBaseQuery(this ApplicationDbContext dbContext, bool asNoTracking, bool includeComments = false)
    {
        var query = asNoTracking ? dbContext.Revenues.AsNoTracking() : dbContext.Revenues;
        if (includeComments) query = query.Include(r => r.Comments);
        return query
            .Include(r => r.LineOfBusiness)
            .Include(r => r.Customer).ThenInclude(x => x.Function)
            .Include(r => r.Project)
            .Include(r => r.GroupOwner).ThenInclude(g => g.Users)
            .Include(r => r.TypeOfService)
            .Include(r => r.OwnerProjectManager)
            .Include(r => r.BusinessUnit)
            .Include(r => r.CustomerCostCenter)
            .Include(r => r.ChargingModel)
            .Include(r => r.InternalCostCenterPerCost)
            .Include(r => r.Currency)
            .Include(p => p.ValueAddedTax);
    }

    internal static IQueryable<RevenueModel> GetRevenueFrontEndBaseQuery(this ApplicationDbContext dbContext, bool asNoTracking, bool includeComments = true)
    {
        var query = asNoTracking ? dbContext.RevenuesFrontEnd.AsNoTracking() : dbContext.RevenuesFrontEnd;
        if (includeComments) query = query.Include(r => r.Comments);
        return query;
    }

    internal static DataSourceRequest HandleRevenueDataSourceRequest(this DataSourceRequest dataSourceRequest)
    {
        dataSourceRequest ??= new DataSourceRequest();
        dataSourceRequest.Sort ??= Enumerable.Empty<Sort>();
        if (!dataSourceRequest.Sort.Any(x => x.Field.Equals(nameof(RevenueModel.Id))))
        {
            dataSourceRequest.Sort = dataSourceRequest.Sort.Append(new Sort() { Field = nameof(RevenueModel.Id), Dir = SortDir.desc });
        }

        if (dataSourceRequest.Filter is not null)
        {
            dataSourceRequest.Filter.HandleRevenueFilter();
        }

        if (dataSourceRequest.Sort is not null)
        {
            dataSourceRequest.Sort.HandleRevenueSort();
        }

        return dataSourceRequest;
    }

    internal static Filter HandleRevenueFilter(this Filter filter)
    {
        var months = Revenue.GetMonths().Select(m => m.ToString());
        if (filter.Filters != null && filter.Filters.Any())
        {
            foreach (var f in filter.Filters)
            {
                f.HandleRevenueFilter();
            }
        }

        if (!string.IsNullOrWhiteSpace(filter.Field))
        {
            var month = months.SingleOrDefault(m => filter.Field.ContainsICIC(m));
            if (!string.IsNullOrWhiteSpace(month))
            {
                filter.Field = $"{month}{nameof(MonthRevenue.Amount)}";
            }
        }

        return filter;
    }

    internal static IEnumerable<Sort> HandleRevenueSort(this IEnumerable<Sort> sort)
    {
        var months = Revenue.GetMonths().Select(m => m.ToString());
        foreach (var s in sort)
        {
            var month = months.SingleOrDefault(m => s.Field.ContainsICIC(m));
            if (!string.IsNullOrWhiteSpace(month))
            {
                s.Field = $"{month}{nameof(MonthRevenue.Amount)}";
            }
        }

        return sort;
    }

    #endregion
}
