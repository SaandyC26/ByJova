﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal class FieldRepository : BaseRepository, IFieldRepository
    {
        #region --- CONSTRUCTORS ---

        internal FieldRepository(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<IEnumerable<Field>> GetFieldsByEntityAsync<T>(bool asNoTracking = false, CancellationToken cancellationToken = default) =>
            await DbContext.GetFieldBaseQuery(asNoTracking).Where(f => f.Entity.ToUpper().Equals(typeof(T).Name.ToUpper())).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        #endregion
    }

    internal static class FieldRepositoryExtensions
    {
        #region --- INTERNAL METHODS ---

        internal static IQueryable<Field> GetFieldBaseQuery(this ApplicationDbContext dbContext, bool asNoTracking)
        {
            if (asNoTracking) return dbContext.Fields.AsNoTracking();
            return dbContext.Fields;
        }

        #endregion
    }
}
