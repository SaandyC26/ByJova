﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using Domain;
    using DevOps.CrossCutting;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Caching.Memory;
    using Newtonsoft.Json;
    using System;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class ApplicationConfigurationRepository : BaseRepository, IApplicationConfigurationRepository
    {
        #region --- REFERENCES ---

        private readonly MemoryCacheEntryOptions _memoryCacheEntryOptions;

        #endregion

        #region --- CONSTRUCTORS ---

        internal ApplicationConfigurationRepository(IServiceProvider services) : base(services)
        {
            _memoryCacheEntryOptions = new MemoryCacheEntryOptions()
            {
                Size = 12,
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(3600)
            };
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<T> GetApplicationConfigurationByTypeAsync<T>(bool asNoTracking = true, CancellationToken cancellationToken = default)
        {
            var (query, cache) = (DbContext.GetApplicationConfigurationBaseQuery(asNoTracking), asNoTracking && DbContext.CacheEnabled);
            if (cache)
            {
                query = (await DbContext.GetOrCreateMemoryCacheAsync<ApplicationConfiguration>(
                    nameof(ApplicationConfiguration),
                    async (ct) => await query.ToArrayAsync(cancellationToken: ct).ConfigureAwait(false),
                    _memoryCacheEntryOptions,
                    cancellationToken: cancellationToken).ConfigureAwait(false)).AsQueryable();
            }

            var ac = cache ? query.SingleOrDefault(x => x.Name.EqualsICIC(typeof(T).Name)) : await query.SingleOrDefaultAsync(x => x.Name.ToUpper().Equals(typeof(T).Name.ToUpper()), cancellationToken: cancellationToken).ConfigureAwait(false);
            if (ac == null) return default;
            return JsonConvert.DeserializeObject<T>(ac.Value);
        }

        public async Task CreateApplicationConfigurationAsync<T>(T applicationConfiguration, CancellationToken cancellationToken = default)
        {
            var ac = new ApplicationConfiguration(typeof(T).Name, JsonConvert.SerializeObject(applicationConfiguration));
            DbContext.ApplicationConfigurations.Add(ac);
            await DbContext.SaveChangesAsync(cacheKeysCleanup: new object[] { nameof(ApplicationConfiguration) }, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        #endregion
    }

    internal static class ApplicationConfigurationRepositoryExtensions
    {
        #region --- INTERNAL METHODS ---

        internal static IQueryable<ApplicationConfiguration> GetApplicationConfigurationBaseQuery(this ApplicationDbContext dbContext, bool asNoTracking)
        {
            if (asNoTracking) return dbContext.ApplicationConfigurations.AsNoTracking();
            return dbContext.ApplicationConfigurations;
        }

        #endregion
    }
}
