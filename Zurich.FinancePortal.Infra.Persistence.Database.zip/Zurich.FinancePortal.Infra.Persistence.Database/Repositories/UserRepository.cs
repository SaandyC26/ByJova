﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class UserRepository : BaseRepository, IUserRepository
{
    #region --- REFERENCES ---

    private readonly MemoryCacheEntryOptions _memoryCacheEntryOptionsReleaseNotes;

    #endregion

    #region --- CONSTRUCTORS ---

    internal UserRepository(IServiceProvider services) : base(services)
    {
        _memoryCacheEntryOptionsReleaseNotes = new MemoryCacheEntryOptions()
        {
            Size = 12,
            AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24)
        };
    }

    #endregion

    #region --- PUBLIC METHODS ---

    public void AddUser(User user) =>
        DbContext.Users.Add(user);

    public async Task<User> GetUserBySAMAccountNameAsync(string sAMAccountName, bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, bool includeGridPreferences = false, CancellationToken cancellationToken = default) =>
        await (await DbContext.GetUserBaseQueryAsync(asNoTracking, includeDeleted: includeDeleted, includeRoles: includeRoles, includeGroups: includeGroups, includeGridPreferences: includeGridPreferences, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(u => u.AdAccount.SAMAccountName.ToUpper().Equals(sAMAccountName.ToUpper()), cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<User> GetUserByIdAsync(int id, bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, CancellationToken cancellationToken = default) => await (await DbContext.GetUserBaseQueryAsync(asNoTracking, includeDeleted: includeDeleted, includeRoles: includeRoles, includeGroups: includeGroups, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(u => u.Id.Equals(id), cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<(int Count, IEnumerable<User> Result)> GetUsersAsync(bool asNoTracking = false, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, bool includeGridPreferences = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
    {
        var (count, result) = await DbContext.GetUserBaseQueryAsync(asNoTracking, includeDeleted: includeDeleted, includeRoles: includeRoles, includeGroups: includeGroups, includeGridPreferences: includeGridPreferences, dataSourceRequest: dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
        return (count, await result.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
    }

    // ReleaseNotes
    public async Task<(int Count, IEnumerable<ReleaseNotes> Result)> GetReleasesNotesAsync(bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
    {
        var (count, query, cache) = (default(int), DbContext.GetReleaseNotesBaseQuery(asNoTracking), asNoTracking && DbContext.CacheEnabled);
        if (cache)
        {
            query = (await DbContext.GetOrCreateMemoryCacheAsync<ReleaseNotes>(
                nameof(ReleaseNotes),
                async (ct) => await query.ToArrayAsync(cancellationToken: ct).ConfigureAwait(false),
                _memoryCacheEntryOptionsReleaseNotes,
                cancellationToken: cancellationToken).ConfigureAwait(false)).AsQueryable();
        }

        (count, query) = await query.HandleDataSourceRequestAsync(dataSourceRequest, countAsync: !cache, cancellationToken: cancellationToken).ConfigureAwait(false);
        return (count, cache ? query.ToArray() : await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
    }

    public async Task<ReleaseNotes> GetLastReleaseNotesAsync(bool asNoTracking = false, CancellationToken cancellationToken = default)
    {
        var result = (await GetReleasesNotesAsync(asNoTracking: asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false)).Result;
        return result.OrderByDescending(rn => rn.Major).ThenByDescending(rn => rn.Minor).ThenByDescending(rn => rn.Revision).FirstOrDefault();
    }

    #endregion
}

internal static class UserRepositoryExtensions
{
    #region --- INTERNAL METHODS ---

    internal async static Task<(int Count, IQueryable<User> Result)> GetUserBaseQueryAsync(this ApplicationDbContext dbContext, bool asNoTracking, bool includeDeleted = false, bool includeRoles = false, bool includeGroups = false, bool includeGridPreferences = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
    {
        var (count, query) = (0, asNoTracking ? dbContext.Users.AsNoTracking() : dbContext.Users);
        if (!includeDeleted) query = query.Where(u => !u.IsDeleted);
        if (includeRoles) query = query.Include(u => u.Roles).ThenInclude(r => r.Permissions);
        if (includeGroups) query = query.Include(u => u.Groups);
        if (includeGridPreferences) query = query.Include(u => u.GridPreferences);
        (count, query) = await query.HandleDataSourceRequestAsync(dataSourceRequest?.HandleUserDataSourceRequest(), cancellationToken: cancellationToken).ConfigureAwait(false);
        return (count, query);
    }

    internal static IQueryable<ReleaseNotes> GetReleaseNotesBaseQuery(this ApplicationDbContext dbContext, bool asNoTracking) =>
        asNoTracking ? dbContext.ReleasesNotes.AsNoTracking() : dbContext.ReleasesNotes;

    #endregion

    #region --- PRIVATE METHODS ---

    internal static DataSourceRequest HandleUserDataSourceRequest(this DataSourceRequest dataSourceRequest)
    {
        if (dataSourceRequest == null) return dataSourceRequest;
        if (dataSourceRequest.Filter != null) dataSourceRequest.Filter.HandleUserFilter();
        if (dataSourceRequest.Sort != null) dataSourceRequest.Sort.HandleUserSort();
        return dataSourceRequest;
    }

    internal static Filter HandleUserFilter(this Filter filter)
    {
        if (filter.Filters != null && filter.Filters.Any()) foreach (var f in filter.Filters) f.HandleUserFilter();
        if (!string.IsNullOrWhiteSpace(filter.Field) && filter.Field.EqualsICIC(nameof(UserDto.SAMAccountName))) filter.Field = $"{nameof(AdAccount)}.{nameof(AdAccount.SAMAccountName)}";
        return filter;
    }

    internal static IEnumerable<Sort> HandleUserSort(this IEnumerable<Sort> sort)
    {
        foreach (var s in sort.Where(x => x.Field.EqualsICIC(nameof(UserDto.SAMAccountName)))) s.Field = $"{nameof(AdAccount)}.{nameof(AdAccount.SAMAccountName)}";
        return sort;
    }

    #endregion
}
