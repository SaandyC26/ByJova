﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Caching.Memory;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class MasterDataRepository : BaseRepository, IMasterDataRepository
    {
        #region --- REFERENCES ---

        private readonly MemoryCacheEntryOptions _memoryCacheEntryOptionsChargingModels;

        #endregion

        #region --- CONSTRUCTORS ---

        internal MasterDataRepository(IServiceProvider services) : base(services)
        {
            _memoryCacheEntryOptionsChargingModels = new MemoryCacheEntryOptions()
            {
                Size = 8,
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(3600)
            };
        }

        #endregion

        #region --- PUBLIC METHODS ---

        // CurrencyExchangeRate
        public async Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesAsync(bool asNoTracking = false, CancellationToken cancellationToken = default) =>
            await DbContext.Set<CurrencyExchangeRate>(includeNavigationPropertyPaths: GetIncludeNavigationPropertyPaths<CurrencyExchangeRate>(asNoTracking, new string[] { nameof(Currency) }), asNoTracking: asNoTracking).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        public async Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesByFromAndYearAsync(int year, string currencyCodeFrom, bool asNoTracking = false, CancellationToken cancellationToken = default) =>
            await DbContext.Set<CurrencyExchangeRate>(includeNavigationPropertyPaths: GetIncludeNavigationPropertyPaths<CurrencyExchangeRate>(asNoTracking, new string[] { nameof(Currency) }), asNoTracking: asNoTracking).Where(cer => cer.Year.Equals(year) && cer.From.Code.Equals(currencyCodeFrom)).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        public async Task<IEnumerable<CurrencyExchangeRate>> GetCurrenciesExchangeRatesByToAsync(string currencyCodeTo, bool asNoTracking = false, CancellationToken cancellationToken = default) =>
            await DbContext.Set<CurrencyExchangeRate>(includeNavigationPropertyPaths: GetIncludeNavigationPropertyPaths<CurrencyExchangeRate>(asNoTracking, new string[] { nameof(Currency) }), asNoTracking: asNoTracking).Where(cer => cer.To.Code.Equals(currencyCodeTo)).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        // ChargingModel
        public async Task<IEnumerable<ChargingModel>> GetChargingModelsAsync(bool asNoTracking = true, CancellationToken cancellationToken = default)
        {
            var (query, cache) = (asNoTracking ? DbContext.ChargingModels.AsNoTracking() : DbContext.ChargingModels, asNoTracking && DbContext.CacheEnabled);
            if (cache)
            {
                query = (await DbContext.GetOrCreateMemoryCacheAsync<ChargingModel>(
                    nameof(ChargingModel),
                    async (ct) => await query.ToArrayAsync(cancellationToken: ct).ConfigureAwait(false),
                    _memoryCacheEntryOptionsChargingModels,
                    cancellationToken: cancellationToken).ConfigureAwait(false)).AsQueryable();
            }

            return cache ? query.ToArray() : await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        // MasterData Generic
        public void Add(MasterData masterData) =>
            DbContext.Add(masterData);

        public void Remove(MasterData masterData) =>
            DbContext.Remove(masterData);

        public async Task<IEnumerable<TEntity>> GetMasterDatasByEntityAsync<TEntity>(bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default) where TEntity : MasterData =>

            await DbContext.Set<TEntity>(includeNavigationPropertyPaths: GetIncludeNavigationPropertyPaths<TEntity>(asNoTracking, dtos), asNoTracking: asNoTracking).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        // MasterData Generic
        public async Task<IEnumerable<object>> GetMasterDatasByEntityAsync(Type type, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default)
        {
            var method = GetType().GetMethod(nameof(GetMasterDatasByEntityAsync), new Type[] { typeof(bool), typeof(IEnumerable<string>), typeof(CancellationToken) });
            var parameters = new object[]
            {
                asNoTracking,
                dtos,
                cancellationToken
            };

            var task = (Task)method.MakeGenericMethod(type).Invoke(this, parameters);
            await task.ConfigureAwait(false);
            return ((dynamic)task).Result;
        }

        public async Task<MasterData> GetMasterDataByIdAsync(Type type, int id, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default)
        {
            var method = GetType().GetMethod(nameof(GetMasterDataByIdAsync), new Type[] { typeof(int), typeof(bool), typeof(IEnumerable<string>), typeof(CancellationToken) });
            var parameters = new object[]
            {
                id,
                asNoTracking,
                dtos,
                cancellationToken
            };

            var task = (Task)method.MakeGenericMethod(type).Invoke(this, parameters);
            await task.ConfigureAwait(false);
            return ((dynamic)task).Result;
        }

        public async Task<T> GetMasterDataByIdAsync<T>(int id, bool asNoTracking = false, IEnumerable<string> dtos = default, CancellationToken cancellationToken = default) where T : MasterData =>
            await DbContext.Set<T>(includeNavigationPropertyPaths: GetIncludeNavigationPropertyPaths<T>(asNoTracking, dtos), asNoTracking: asNoTracking).Where(md => md.Id.Equals(id)).SingleOrDefaultAsync(cancellationToken: cancellationToken).ConfigureAwait(false);

        public async Task<bool> IsMasterDataBeingUsedAsync(Type type, MasterData masterData, CancellationToken cancellationToken = default)
        {
            var query = DbContext.Revenues.AsQueryable();
            switch (type.Name)
            {
                case nameof(BusinessUnit):
                    query = query.Where(r => r.BusinessUnit != null && r.BusinessUnit.Id.Equals(masterData.Id));
                    break;
                case nameof(ChargingModel):
                    query = query.Where(r => r.ChargingModel.Id.Equals(masterData.Id));
                    break;
                case nameof(CostCenter):
                    if (((CostCenter)masterData).Types.Any(t => t.Equals(CostCenterType.Customer)) && ((CostCenter)masterData).Types.Any(t => t.Equals(CostCenterType.Internal)))
                    {
                        query = query.Where(r => r.InternalCostCenterPerCost.Id.Equals(masterData.Id) || (r.CustomerCostCenter != null && r.CustomerCostCenter.Id.Equals(masterData.Id)));
                    }
                    else if (((CostCenter)masterData).Types.Any(t => t.Equals(CostCenterType.Customer)))
                    {
                        query = query.Where(r => r.CustomerCostCenter != null && r.CustomerCostCenter.Id.Equals(masterData.Id));
                    }
                    else if (((CostCenter)masterData).Types.Any(t => t.Equals(CostCenterType.Internal)))
                    {
                        query = query.Where(r => r.InternalCostCenterPerCost.Id.Equals(masterData.Id));
                    }

                    break;
                case nameof(Currency):
                    query = query.Where(r => r.Currency.Id.Equals(masterData.Id));
                    break;
                case nameof(CurrencyExchangeRate):
                    return false;
                case nameof(Customer):
                    query = query.Where(r => r.Customer.Id.Equals(masterData.Id));
                    break;
                case nameof(LineOfBusiness):
                    query = query.Where(r => r.LineOfBusiness.Id.Equals(masterData.Id));
                    break;
                case nameof(Project):
                    query = query.Where(r => r.Project.Id.Equals(masterData.Id));
                    break;
                case nameof(TestingTool):
                    query = query.Where(r => r.TestingTool.Id.Equals(masterData.Id));
                    break;
                case nameof(TypeOfService):
                    query = query.Where(r => r.TypeOfService.Id.Equals(masterData.Id));
                    break;
                case nameof(CustomerFunction):
                    return await DbContext.Set<Customer>().Include(x => x.Function).AnyAsync(x => x.Function != null && x.Function.Id.Equals(masterData.Id), cancellationToken: cancellationToken).ConfigureAwait(false);
                case nameof(ValueAddedTax):
                default:
                    throw new NotImplementedException($"{nameof(MasterData)} \"{type.Name}\" not implemented.");
            }

            return await query.AnyAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IEnumerable<string> GetIncludeNavigationPropertyPaths<TEntity>(bool asNoTracking, IEnumerable<string> dtos)
        {
            var result = new List<string>();
            switch (typeof(TEntity).Name)
            {
                case nameof(Customer):
                    result.Add(nameof(Customer.Function));
                    break;
                case nameof(ChargingModel):
                    result.Add(nameof(ChargingModel.Type));
                    break;
                case nameof(CurrencyExchangeRate):
                    result.Add(nameof(CurrencyExchangeRate.From));
                    result.Add(nameof(CurrencyExchangeRate.To));
                    break;
            }

            return result;
        }

        #endregion
    }
}
