﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class RevenueFrontEndRepository : BaseRepository, IRevenueFrontEndRepository, IPrivateRevenueFrontEndRepository
{
    #region --- CONSTRUCTORS ---

    internal RevenueFrontEndRepository(IServiceProvider services) : base(services)
    { }

    #endregion

    #region --- PUBLIC METHODS ---

    // Revenues
    public async Task<(int Count, IEnumerable<RevenueDto> Result)> GetRevenuesAsync(string[] dtos = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, int maxCount = -1, CancellationToken cancellationToken = default) =>
        await GetAsync<RevenueDto, RevenueModel>(DbContext.GetRevenueFrontEndBaseQuery(true), dataSourceRequest: dataSourceRequest.HandleRevenueDataSourceRequest(), includeCount: includeCount, maxCount: maxCount, cancellationToken: cancellationToken).ConfigureAwait(false);

    public async Task<RevenueDto> GetRevenueByIdAsync(long id, string[] dtos = default, CancellationToken cancellationToken = default) =>
        (await GetAsync<RevenueDto, RevenueModel>(DbContext.GetRevenueFrontEndBaseQuery(true).Where(r => r.Id.Equals(id)).AsNoTracking(), cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefault();

    // Financial Management
    public async Task<(int Count, IEnumerable<BarcelonaInvoiceDto> Result)> GetBarcelonaInvoicesAsync(int year, Month month, IEnumerable<string> linesOfBusinessNames, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, bool includePastFuture = false, string separator = default, IEnumerable<string> descriptionProperties = default, CancellationToken cancellationToken = default)
    {
        var chargingModelsCodes = chargingModels.Select(cm => cm.Code);
        // Get Barcelona Invoices
        var barcelonaInvoices = await DbContext.GetRevenueFrontEndBaseQuery(true)
            .Where(r => r.Year.Equals(year) && chargingModelsCodes.Contains(r.ChargingModelCode) && (linesOfBusinessNames == null || !linesOfBusinessNames.Any() || linesOfBusinessNames.Contains(r.LineOfBusinessName)))
            .ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Get Currency Exchange Rates
        var currencyExchangeRates = await MasterDataRepository.GetCurrenciesExchangeRatesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        // Split
        var invoicesSplit = barcelonaInvoices
            .GroupBy(r => new { r.ChargingModelCode, r.InternalCostCenterPerCostCode, r.BusinessUnitCode, r.ProjectName, r.CustomerCostCenterCode })
            .Select(gr =>
            {
                var amounts = gr.Select(r => r.GetMonthFYFCLC(month, Currency.EuroCode, currencyExchangeRates)).Where(a => a != null);
                if (!amounts.Any() || amounts.Sum().Equals((decimal?)0)) return null;
                var pastFutureAmounts = (!includePastFuture) ? null : Enum.GetValues<Month>().Where(x => ((month - 1) > Month.None && x.Equals(month - 1)) || (!month.Equals(Month.December) && x > month)).ToDictionary(x => x, x => gr.Select(y => y.GetMonthFYFCLC(x, Currency.EuroCode, currencyExchangeRates)));
                return new BarcelonaInvoiceDto(separator: separator, descriptionProperties: descriptionProperties)
                {
                    ChargingModelCode = gr.Key.ChargingModelCode,
                    BusinessUnitCode = gr.Key.BusinessUnitCode,
                    InternalCostCenterPerCostCode = gr.Key.InternalCostCenterPerCostCode,
                    ProjectName = gr.Key.ProjectName,
                    CustomerCostCenterCode = gr.Key.CustomerCostCenterCode,
                    ServicesDescriptions = gr.Select(r => r.ServiceDescription).Distinct(StringComparer.InvariantCultureIgnoreCase),
                    ShortMonth = Revenue.GetShortMonthName(month),
                    TotalEur = amounts.Sum().Value,
                    PastFutureTotalEur = pastFutureAmounts?.ToDictionary(x => x.Key, x => x.Value?.Sum() ?? decimal.Zero)
                };
            })
            .Where(bi => bi != null)
            .AsQueryable()
            .HandleQueryFilters(dataSourceRequest)
            .HandleQueryOrderBy(dataSourceRequest);
        // Count
        var count = includeCount ? invoicesSplit.Count() : -1;
        // Take && Skip
        if (dataSourceRequest?.Skip > 0) invoicesSplit = invoicesSplit.Skip(dataSourceRequest.Skip);
        if (dataSourceRequest?.Take > 0) invoicesSplit = invoicesSplit.Take(dataSourceRequest.Take);
        // Result
        return (count, invoicesSplit.AsEnumerable());
    }

    public async Task<(int Count, IEnumerable<RebookingDto> Result)> GetRebookingsAsync(int year, Month month, CostCenter internalCostCenter, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, string separator = default, IEnumerable<string> descriptionProperties = default, CancellationToken cancellationToken = default)
    {
        var chargingModelsCodes = chargingModels.Select(cm => cm.Code);
        // Get Rebookings
        var rebookings = await DbContext.GetRevenueFrontEndBaseQuery(true)
            .Where(r => r.Year.Equals(year) && r.InternalCostCenterPerCostCode.Equals(internalCostCenter.Code) && chargingModelsCodes.Contains(r.ChargingModelCode))
            .ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Get Currency Exchange Rates && VAT
        var currencyExchangeRates = await MasterDataRepository.GetCurrenciesExchangeRatesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        var valueAddedTax = (await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false))
            .Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry));
        if (year == 2024)
        {
            valueAddedTax = (await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false))
                .Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry2024));
        }
        // Split
        var rebookingsSplit = rebookings
            .GroupBy(r => new { r.ChargingModelCode, r.CustomerCostCenterCode, r.ProjectName, r.CustomerName })
            .Select(gr =>
            {
                var amounts = gr.Select(r => r.GetMonthFYFCLC(month, Currency.ChiefsCode, currencyExchangeRates)).Where(a => a != null);
                if (!amounts.Any() || amounts.Sum().Equals((decimal?)0)) return null;
                return new RebookingDto(separator: separator, descriptionProperties: descriptionProperties)
                {
                    ChargingModelCode = gr.Key.ChargingModelCode,
                    CustomerCostCenterCode = gr.Key.CustomerCostCenterCode,
                    CustomeName = gr.Key.CustomerName,
                    ProjectName = gr.Key.ProjectName,
                    ShortMonth = Revenue.GetShortMonthName(month),
                    DebitValueChf = Domain.RevenueService.Round(amounts.Select(a => Domain.RevenueService.AddVat(a, valueAddedTax)).Sum().Value).Value,
                    ServicesDescriptions = gr.Select(x => x.ServiceDescription)
                };
            })
            .Where(r => r != null)
            .AsQueryable()
            .HandleQueryFilters(dataSourceRequest)
            .HandleQueryOrderBy(dataSourceRequest);
        // Count
        var count = includeCount ? rebookingsSplit.Count() : -1;
        // Take && Skip
        if (dataSourceRequest?.Skip > 0) rebookingsSplit = rebookingsSplit.Skip(dataSourceRequest.Skip);
        if (dataSourceRequest?.Take > 0) rebookingsSplit = rebookingsSplit.Take(dataSourceRequest.Take);
        // Result
        return (count, rebookingsSplit);
    }

    [SuppressMessage("Major Code Smell", "S1121: Assignments should not be made from within sub-expressions", Justification = "N/A")]
    public async Task<(int Count, IEnumerable<CustomerAllocationDto> Result)> GetCustomersAllocationsAsync(int year, Month month, IEnumerable<ChargingModel> chargingModels, DataSourceRequest dataSourceRequest = default, bool includeCount = false, string separator = default, CancellationToken cancellationToken = default)
    {
        const decimal @var = 0.00001M;
        var chargingModelsCodes = chargingModels.Select(cm => cm.Code);
        // Get Customers Allocations
        var customersAllocations = await DbContext.GetRevenueFrontEndBaseQuery(true)
            .Where(r => r.Year.Equals(year) && chargingModelsCodes.Contains(r.ChargingModelCode))
            .ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Get Currency Exchange Rates && VAT
        var currencyExchangeRates = await MasterDataRepository.GetCurrenciesExchangeRatesAsync(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false);
        var valueAddedTax = (await MasterDataRepository.GetMasterDatasByEntityAsync<ValueAddedTax>(asNoTracking: true, cancellationToken: cancellationToken).ConfigureAwait(false))
            .Single(vat => vat.Country.EqualsICIC(ValueAddedTax.SwitzerlandCountry));
        // Split
        var customersAllocationsSplit = customersAllocations
            .GroupBy(r => new { r.ChargingModelCode, r.InternalCostCenterPerCostCode })
            .Select(gr =>
            {
                var amounts = gr.Select(r => r.GetMonthFYFCLC(month, Currency.ChiefsCode, currencyExchangeRates)).Where(a => a != null);
                if (!amounts.Any() || amounts.Sum().Equals((decimal?)0)) return null;
                var cas = gr
                    .GroupBy(r => new { r.ChargingModelCode, r.LineOfBusinessName, r.InternalCostCenterPerCostCode, r.BusinessUnitCode })
                    .Select((grInner, i) =>
                    {
                        var amountsInner = grInner.Select(r => r.GetMonthFYFCLC(month, Currency.ChiefsCode, currencyExchangeRates)).Where(a => a != null);
                        if (!amountsInner.Any() || amountsInner.Sum().Equals((decimal?)0)) return (0, null);
                        var amountsVatInner = amountsInner.Select(a => Domain.RevenueService.AddVat(a, valueAddedTax));
                        var percentage = (amountsInner.Sum() / amounts.Sum()).Value;
                        return (Percentage: percentage, CustomerAllocation: new CustomerAllocationDto(separator: separator)
                        {
                            ShortMonth = Revenue.GetShortMonthName(month),
                            TotalChf = amountsInner.Sum().Value,
                            TotalChfVat = Domain.RevenueService.Round(amountsVatInner.Sum().Value).Value,
                            Percentage = Domain.RevenueService.Round(percentage, decimals: 5).Value,
                            ChargingModelCode = grInner.Key.ChargingModelCode,
                            LineOfBusinessName = grInner.Key.LineOfBusinessName,
                            InternalCostCenterPerCostCode = grInner.Key.InternalCostCenterPerCostCode,
                            BusinessUnitCode = grInner.Key.BusinessUnitCode,
                            CustomersNames = grInner.Select(x => x.CustomerName).Distinct(StringComparer.InvariantCultureIgnoreCase),
                            ServicesDescriptions = grInner.Select(x => x.ServiceDescription).Distinct(StringComparer.InvariantCultureIgnoreCase)
                        });
                    });

                return cas.Where(ca => ca.CustomerAllocation != null);
            })
            .Where(gr => gr != null)
            .Select(gr =>
            {
                var percentageSum = GetPercentageSum(gr.Select(ca => ca.CustomerAllocation));
                if (percentageSum.Equals(decimal.One)) return gr;
                var grList = gr.ToList();
                do
                {
                    var val = grList.OrderByDescending(ca => Math.Abs(ca.CustomerAllocation.Percentage - ca.Percentage)).First().CustomerAllocation;
                    var add = @var * (percentageSum < decimal.One ? decimal.One : -decimal.One);
                    val.Percentage += add;
                } while (!(percentageSum = GetPercentageSum(grList.Select(ca => ca.CustomerAllocation))).Equals(decimal.One));

                return grList;
            })
            .SelectMany(ca => ca)
            .Select(ca => ca.CustomerAllocation)
            .Where(ca => ca != null)
            .AsQueryable()
            .HandleQueryFilters(dataSourceRequest)
            .HandleQueryOrderBy(dataSourceRequest);
        // Count
        var count = includeCount ? customersAllocationsSplit.Count() : -1;
        // Take && Skip
        if (dataSourceRequest?.Skip > 0) customersAllocationsSplit = customersAllocationsSplit.Skip(dataSourceRequest.Skip);
        if (dataSourceRequest?.Take > 0) customersAllocationsSplit = customersAllocationsSplit.Take(dataSourceRequest.Take);
        // Result
        return (count, customersAllocationsSplit);

        #region --- NESTED METHODS ---

        static decimal GetPercentageSum(IEnumerable<CustomerAllocationDto> customersAllocations) =>
            customersAllocations.Select(ca => ca.Percentage).Sum();

        #endregion
    }

    #endregion
}
