﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using AutoMapper;
    using AutoMapper.Internal;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.DependencyInjection;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using DevOps.CrossCutting;

    internal abstract class BaseRepository
    {
        #region --- REFERENCES ---

        protected private readonly IMemoryCache MemoryCache;

        private readonly IServiceProvider _services;

        protected private readonly ApplicationDbContext DbContext;

        protected private readonly IMapper Mapper;

        private MasterDataRepository _masterDataRepository;
        protected private MasterDataRepository MasterDataRepository => _masterDataRepository ??= _services.GetRequiredService<MasterDataRepository>();

        private RevenueRepository _revenueRepository;
        protected private RevenueRepository RevenueRepository => _revenueRepository ??= _services.GetRequiredService<RevenueRepository>();

        #endregion

        #region --- CONSTRUCTORS ---

        protected private BaseRepository(IServiceProvider services)
        {
            _services = Guard.Argument(services, nameof(services)).IsNotNull().Value;
            DbContext = services.GetRequiredService<ApplicationDbContext>();
            Mapper = services.GetRequiredService<IMapper>();
            MemoryCache = services.GetRequiredService<IMemoryCache>();
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected private async Task<(int Count, IEnumerable<TDto> Result)> GetAsync<TDto, TEntity>(IQueryable<TEntity> query, IDictionary<string, object> mapperParameters = default, DataSourceRequest dataSourceRequest = default, bool includeCount = false, int maxCount = -1, CancellationToken cancellationToken = default)
        {
            // Query
            query = query.HandleQueryFilters(dataSourceRequest);
            var count = includeCount ? await query.CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false) : -1;
            query = query.HandleQueryOrderBy(dataSourceRequest);
            if (dataSourceRequest?.Skip > 0) query = query.Skip(dataSourceRequest.Skip);
            if (dataSourceRequest?.Take > 0) query = query.Take(dataSourceRequest.Take);
            // MaxCount
            if (!maxCount.Equals(-1))
            {
                var queryCount = await query.CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (queryCount > maxCount) return (count, null);
            }
            // Execute
            IEnumerable<TDto> result;
            if (mapperParameters != null) result = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TDto>>(await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false), opts => mapperParameters?.ForEach(x => opts.Items.Add(x.Key, x.Value)));
            else result = Mapper.Map<IEnumerable<TEntity>, IEnumerable<TDto>>(await query.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
            // Result
            return (count, result);
        }

        #endregion
    }
}
