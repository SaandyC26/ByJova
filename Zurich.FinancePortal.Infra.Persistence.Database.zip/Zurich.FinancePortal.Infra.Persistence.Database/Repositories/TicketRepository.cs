﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class TicketRepository : BaseRepository, ITicketRepository
    {
        #region --- CONSTRUCTORS ---

        internal TicketRepository(IServiceProvider services) : base(services)
        { }

        #endregion

        #region --- PUBLIC METHODS ---

        public void Add(Ticket ticket) => DbContext.Tickets.Add(ticket);

        public void Remove(Ticket ticket) => DbContext.Tickets.Remove(ticket);

        public async Task<(int Count, IEnumerable<Ticket> Result)> GetAsync(User user = default, IEnumerable<TicketStatus> hiddenStatuses = default, bool asNoTracking = false, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
        {
            var (count, result) = await DbContext.GetTicketBaseQueryAsync(asNoTracking, user: user, hiddenStatuses: hiddenStatuses, dataSourceRequest: dataSourceRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            return (count, await result.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false));
        }

        public async Task<Ticket> GetByIdAsync(long id, bool asNoTracking = false, CancellationToken cancellationToken = default) =>
            await(await DbContext.GetTicketBaseQueryAsync(asNoTracking, cancellationToken: cancellationToken).ConfigureAwait(false)).Result.SingleOrDefaultAsync(x => x.Id.Equals(id), cancellationToken: cancellationToken).ConfigureAwait(false);

        #endregion
    }

    internal static class TicketRepositoryExtensions
    {
        #region --- INTERNAL METHODS ---

        internal async static Task<(int Count, IQueryable<Ticket> Result)> GetTicketBaseQueryAsync(this ApplicationDbContext dbContext, bool asNoTracking, bool countAsync = true, User user = default, IEnumerable<TicketStatus> hiddenStatuses = default, DataSourceRequest dataSourceRequest = default, CancellationToken cancellationToken = default)
        {
            var (count, query) = (0, asNoTracking ? dbContext.Tickets.Include(x => x.User).Include(x => x.Comments).AsNoTracking() : dbContext.Tickets.Include(x => x.User).Include(x => x.Comments));
            if (user != null) query = query.Where(x => x.User.Id.Equals(user.Id));
            if (hiddenStatuses != null && hiddenStatuses.Any()) query = query.Where(x => !hiddenStatuses.Contains(x.Status));
            (count, query) = await query.HandleDataSourceRequestAsync(dataSourceRequest, countAsync: countAsync, cancellationToken: cancellationToken).ConfigureAwait(false);
            return (count, query);
        }

        #endregion
    }
}
