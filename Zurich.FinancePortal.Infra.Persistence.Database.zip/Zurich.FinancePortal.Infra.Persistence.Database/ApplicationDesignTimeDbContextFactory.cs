﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Design;

    internal class ApplicationDesignTimeDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
    {
        #region --- PUBLIC METHODS ---

        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseNpgsql("Server=localhost;Port=5432;Database=financeportaldb;User Id=root;Password=yourStrong(!)Password;Timeout=15;CommandTimeout=30;");
            return new ApplicationDbContext(null, optionsBuilder.Options);
        }

        #endregion
    }
}
