﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using Dapper;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.AspNetCore.Http;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.ChangeTracking;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class ApplicationDbContext : DbContext, IApplicationDbContext
    {
        #region --- PROPERTIES ---

        internal bool CacheEnabled => _cache != null;

        #endregion

        #region --- REFERENCES ---

        private readonly PersistenceConfiguration _configuration;

        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IMemoryCache _cache;

        private readonly ILogger<ApplicationDbContext> _logger;

        #region --- ENTITIES ---

        internal DbSet<Revenue> Revenues { get; set; }

        internal DbSet<RevenueModel> RevenuesFrontEnd { get; set; }

        internal DbSet<RevenueODataDto> RevenuesODataDto { get; set; }

        internal DbSet<ApplicationConfiguration> ApplicationConfigurations { get; set; }

        internal DbSet<Field> Fields { get; set; }

        internal DbSet<User> Users { get; set; }

        internal DbSet<Role> Roles { get; set; }

        internal DbSet<Permission> Permissions { get; set; }

        internal DbSet<Ticket> Tickets { get; set; }

        internal DbSet<Group> Groups { get; set; }

        #region --- MASTER DATA ---

        internal DbSet<BusinessUnit> BusinessUnits { get; set; }

        internal DbSet<ChargingModelType> ChargingModelTypes { get; set; }

        internal DbSet<ChargingModel> ChargingModels { get; set; }

        internal DbSet<CostCenter> CostCenters { get; set; }

        internal DbSet<Currency> Currencies { get; set; }

        internal DbSet<Customer> Customers { get; set; }

        internal DbSet<CurrencyExchangeRate> CurrenciesExchangeRates { get; set; }

        internal DbSet<LineOfBusiness> LinesOfBusiness { get; set; }

        internal DbSet<Project> Projects { get; set; }

        internal DbSet<Product> Products { get; set; }

        internal DbSet<TypeOfService> TypesOfServices { get; set; }

        internal DbSet<ValueAddedTax> ValueAddedTaxes { get; set; }

        internal DbSet<TestingTool> TestingTools { get; set; }

        #endregion

        #endregion

        #region --- VALUE OBJECTS ---

        internal DbSet<ReleaseNotes> ReleasesNotes { get; set; }

        internal DbSet<YearLocks> YearLocks { get; set; }

        internal DbSet<ChangeModel> Changes { get; set; }

        internal DbSet<RevenueComment> RevenuesComments { get; set; }

        #endregion

        #endregion

        #region --- CONSTRUCTORS ---

        public ApplicationDbContext(IServiceProvider services, DbContextOptions<ApplicationDbContext> options = default) : base(options)
        {
            _configuration = services?.GetRequiredService<IOptions<PersistenceConfiguration>>()?.Value ?? PersistenceConfiguration.GetDefaultIConfiguration().Get<PersistenceConfiguration>();
            if (_configuration.ChangeTrackingEnabled) _httpContextAccessor = services?.GetService<IHttpContextAccessor>();
            _cache = services?.GetRequiredService<IMemoryCache>();
            _logger = services?.GetRequiredService<ILogger<ApplicationDbContext>>();
        }

        #endregion

        #region --- PUBLIC METHODS ---

        public async Task<int> SaveChangesAsync(bool changeTracking = true, User user = default, IEnumerable<object> cacheKeysCleanup = default, CancellationToken cancellationToken = default)
        {
            var now = DateTime.UtcNow;
            // Audit
            if (changeTracking && _configuration.ChangeTrackingEnabled) ChangeTracking(now, user);
            var result = await SaveChangesAsync(cancellationToken).ConfigureAwait(false);
            // Cache
            MemoryCacheCleanup(cacheKeysCleanup: cacheKeysCleanup);
            return result;
        }

        [SuppressMessage("Major Code Smell", "S3011: Reflection should not be used to increase accessibility of classes, methods, or fields", Justification = "Reflection")]
        public async Task SeedDatabase(SeedMode seedMode, CancellationToken cancellationToken = default)
        {
            var types = Assembly.GetExecutingAssembly().GetTypes().Where(t => t.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition().Equals(typeof(IEntityTypeConfiguration<>)))).ToList();
            var seededTypes = new List<Type>();
            var i = 0;
            while (i < types.Count)
            {
                // Get Configuration Type
                var type = types.ElementAt(i);
                // Get Seed Method
                var seedMethod = type.GetMethod(nameof(UserConfiguration.SeedDatabase), BindingFlags.NonPublic | BindingFlags.Static);
                // Seed Method
                if (seedMethod != null)
                {
                    // Get Dependant Configurations
                    var dependantMethod = type.GetMethod(nameof(RevenueConfiguration.GetDependantTypes), BindingFlags.NonPublic | BindingFlags.Static);
                    // Dependant Configurations
                    if (dependantMethod != null)
                    {
                        var dependantTypes = (Type[])dependantMethod.Invoke(null, null);
                        // No Dependant Configurations Found -> Increase Index and Continue
                        if (dependantTypes.Any(dt => !seededTypes.Any(st => st.Equals(dt))))
                        {
                            i++;
                            continue;
                        }
                    }
                    // No Dependant Configurations -> Execute, Dequeue and Continue
                    // All Dependant Configurations Found -> Execute, Dequeue and Continue
                    await ((Task)seedMethod.Invoke(null, new object[] { this, seedMode, cancellationToken })).ConfigureAwait(false);
                }
                // No Seed Method -> Dequeue and Continue
                // Seed Method Executed -> Dequeue and Continue
                seededTypes.Add(type);
                types.RemoveAt(i);
                i = 0;
            }
        }

        public async Task MigrateAsync(ILogger logger = default, CancellationToken cancellationToken = default)
        {
            const string sqlite = "--Sqlite--";
            // EF Core Migrations
            if (!Database.IsSqlite())
            {
                logger?.LogInformation("Starting MigrateAsync...");
                await Database.MigrateAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                logger?.LogInformation("Finished MigrateAsync...");
            }
            // Scripts
            logger?.LogInformation("Starting ScriptsAsync...");
            foreach (var scriptPath in Directory.GetFiles(Environment.CurrentDirectory, "*.sql", SearchOption.AllDirectories))
            {
                var sql = await File.ReadAllTextAsync(scriptPath, cancellationToken: cancellationToken).ConfigureAwait(false);
                if (sql.ContainsICIC(sqlite))
                {
                    if (Database.IsSqlite()) sql = sql[sql.IndexOf(sqlite, StringComparison.InvariantCultureIgnoreCase)..];
                    else sql = sql[..sql.IndexOf(sqlite, StringComparison.InvariantCultureIgnoreCase)];
                    logger?.LogInformation("Executed script \"{x}\".", Path.GetFileName(scriptPath));
                }

                await Database.GetDbConnection().ExecuteAsync(sql, commandTimeout: 300).ConfigureAwait(false);
            }

            logger?.LogInformation("Finished ScriptsAsync.");
            // Release Notes
            logger?.LogInformation("Starting ReleaseNotesAsync...");
            await ReleaseNotesAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            logger?.LogInformation("Finished ReleaseNotesAsync.");
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal async Task<IEnumerable<T>> GetOrCreateMemoryCacheAsync<T>(object key, Func<CancellationToken, Task<IEnumerable<T>>> func, MemoryCacheEntryOptions options, CancellationToken cancellationToken = default)
        {
            // NoTracking && Cache Hit
            if (CacheEnabled && _cache.TryGetValue<IEnumerable<T>>(key, out var item)) return item;
            // Cache Miss
            var result = await func(cancellationToken).ConfigureAwait(false);
            // Null Result -> Don't Store
            if (result != null && CacheEnabled)
            {
                using var entry = _cache.CreateEntry(key);
                entry.SetOptions(options).SetValue(result);
                _logger.LogDebug("{t} {m} for Key: {k}.", nameof(MemoryCache), nameof(MemoryCache.CreateEntry), key);
            }
            // Result
            return result;
        }

        #endregion

        #region --- PROTECTED METHODS ---

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            base.OnModelCreating(modelBuilder);
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private void MemoryCacheCleanup(IEnumerable<object> cacheKeysCleanup = default)
        {
            if (CacheEnabled && cacheKeysCleanup != null)
            {
                cacheKeysCleanup.Distinct().ForEach(k => _cache.Remove(k));
            }
        }

        private async Task ReleaseNotesAsync(CancellationToken cancellationToken = default)
        {
            var path = Path.Combine(".", "ReleaseNotes");
            // Check ./doc/ReleaseNotes
            if (Directory.Exists(path))
            {
                var releasesNotes = await ReleasesNotes.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var file in new DirectoryInfo(path).GetFiles("*.html", SearchOption.TopDirectoryOnly))
                {
                    // Check file
                    var numbers = file.Name.Split('.', StringSplitOptions.RemoveEmptyEntries)[0..^1];
                    if (!numbers.Length.Equals(3)) continue;
                    if (!int.TryParse(numbers[0], out var major) || !int.TryParse(numbers[1], out var minor) || !int.TryParse(numbers[2], out var revision)) continue;
                    var releaseNotes = releasesNotes.SingleOrDefault(rn => rn.Major.Equals(major) && rn.Minor.Equals(minor) && rn.Revision.Equals(revision));
                    var changes = (await File.ReadAllTextAsync(file.FullName, Encoding.UTF8, cancellationToken: cancellationToken).ConfigureAwait(false))?
                        .ReplaceICIC("{{version}}", $"{major}.{minor}.{revision}");
                    // Update
                    if (releaseNotes != null)
                    {
                        if (!releaseNotes.Changes.Equals(changes)) releaseNotes.Changes = changes;
                    }
                    //Create
                    else
                    {
                        releaseNotes = new ReleaseNotes(major, minor, revision, !string.IsNullOrEmpty(changes) ? changes : $"<h1>New version {major}.{minor}.{revision}</h1>");
                        ReleasesNotes.Add(releaseNotes);
                    }
                }
                // SaveChanges
                await SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            }
        }

        private void ChangeTracking(DateTime now, User user = default)
        {
            var states = new EntityState[] { EntityState.Added, EntityState.Modified, EntityState.Deleted };
            var entries = ChangeTracker.Entries().Where(e => states.Contains(e.State)).ToArray();
            entries.ForEach(ee =>
            {
                var t = ee.Entity.GetType();
                var change = new ChangeModel()
                {
                    DateTime = now,
                    RequestId = _httpContextAccessor?.HttpContext?.TraceIdentifier,
                    Username = user?.Name ?? _httpContextAccessor?.GetUsername(),
                    State = ee.State,
                    EntityType = t.Equals(typeof(Dictionary<string, object>)) ? string.Join(string.Empty, ((Dictionary<string, object>)ee.Entity).Select(x => x.Key.ReplaceICIC(nameof(Entity<int>.Id), string.Empty))) : t.Name,
                    EntityId = string.Join(", ", ee.Metadata.FindPrimaryKey()?.Properties?.Select(p => ee.OriginalValues[p]?.ToString())),
                    Changes = GetChanges(ee)
                };

                Changes.Add(change);
            });
        }

        private static string GetChanges(EntityEntry ee)
        {
            if (ee.State.Equals(EntityState.Deleted)) return null;
            var pkeys = ee.Metadata.FindPrimaryKey().Properties.Select(p => p.Name);
            return JsonConvert.SerializeObject(ee.Properties.Where(p => !pkeys.ContainsICIC(p.Metadata.Name) && (ee.State.Equals(EntityState.Added) || p.IsModified)).ToDictionary(p => p.Metadata.Name, p => p.OriginalValue));
        }

        #endregion
    }
}
