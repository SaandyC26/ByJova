﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;

public sealed class PersistenceConfiguration
{
    #region --- PROPERTIES ---

    public string ConnectionString { get; set; } = "Server=localhost;Database=financeportaldb;User Id=root;Password=yourStrong(!)Password;Timeout=15;CommandTimeout=30;";

    public bool ChangeTrackingEnabled { get; set; } = true;

    public int MemoryCacheSizeLimit { get; set; } = 32;

    #endregion

    #region --- PUBLIC METHODS ---

    public static IConfiguration GetDefaultIConfiguration()
    {
        var configuration = new PersistenceConfiguration();
        var data = configuration.GetType().GetProperties().Select(x => new KeyValuePair<string, string>(x.Name, x.GetValue(configuration)?.ToString()));
        return new ConfigurationBuilder().AddInMemoryCollection(data).Build();
    }

    #endregion
}
