﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class ReleaseNotesConfiguration : IEntityTypeConfiguration<ReleaseNotes>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<ReleaseNotes> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(ReleaseNotes), BaseConfiguration.ValueObjectSchema);
            // Properties
            builder.Property(rn => rn.Major).IsRequired();
            builder.Property(rn => rn.Minor).IsRequired();
            builder.Property(rn => rn.Revision).IsRequired();
            builder.Property(rn => rn.Version).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
            builder.Property(rn => rn.CreatedOn).IsRequired();
            builder.Property(rn => rn.Changes).IsRequired();
            // PK
            builder.HasKey(rn => new { rn.Major, rn.Minor, rn.Revision }).HasName(BaseConfiguration.GetPkName<ReleaseNotes>(new string[] { nameof(ReleaseNotes.Major), nameof(ReleaseNotes.Minor), nameof(ReleaseNotes.Revision) }));
            // IX
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, ReleaseNotes ReleaseNotes)> GetSeedData()
        {
            return new List<(SeedMode[], ReleaseNotes)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ReleaseNotes(0, 0, 0, "<h1>New features in version 0.0.0</h1>"))
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<ReleaseNotes>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.FirstOrDefault(rn => rn.Major.Equals(@object.Major) && rn.Minor.Equals(@object.Minor) && rn.Revision.Equals(@object.Revision));
                    if (dbItem == null) dbContext.Add(@object);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<ReleaseNotes>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(ReleaseNotes)}\".");
            }
        }

        #endregion
    }
}
