﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    internal sealed class TicketCommentConfiguration : IEntityTypeConfiguration<TicketComment>
    {
        #region --- PROPERTIES ---

        private static string TicketId => $"{nameof(Ticket)}{nameof(Ticket.Id)}";

        #endregion

        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<TicketComment> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(TicketComment), BaseConfiguration.ValueObjectSchema);
            // Properties
            builder.Property<long>(TicketId).IsRequired();
            builder.Property(x => x.Id).IsRequired();
            builder.Property(x => x.DateTime).IsRequired();
            builder.Property(x => x.Text).IsRequired();
            builder.Property(x => x.SAMAccountName).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            // PK
            builder.HasKey(nameof(TicketComment.Id), TicketId).HasName(BaseConfiguration.GetPkName<TicketComment>(new string[] { nameof(TicketComment.Id), TicketId }));
            // IX
            // FK
        }

        #endregion
    }
}
