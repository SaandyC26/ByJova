﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System;

    internal sealed class ChangeModelConfiguration : IEntityTypeConfiguration<ChangeModel>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<ChangeModel> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(Change), BaseConfiguration.ValueObjectSchema);
            // Properties
            builder.Property(c => c.Id).IsRequired().HasColumnType(BaseConfiguration.Uuid);
            builder.Property(c => c.EntityId).HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(c => c.EntityType).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
            builder.Property(c => c.DateTime).IsRequired();
            var r = EntityState.Detached;
            builder.Property(c => c.State).IsRequired().HasConversion(x => x.ToString(), x => Enum.TryParse(x, out r) ? r : EntityState.Detached);
            builder.Property(c => c.Username).HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(c => c.RequestId).HasMaxLength(BaseConfiguration.Nvarchar_128);
            builder.Property(c => c.Changes);
            // PK
            builder.HasKey(nameof(Entity<Guid>.Id)).HasName(BaseConfiguration.GetPkName<Change>(new string[] { nameof(Entity<Guid>.Id) }));
            // IX
            // FK
        }

        #endregion
    }
}
