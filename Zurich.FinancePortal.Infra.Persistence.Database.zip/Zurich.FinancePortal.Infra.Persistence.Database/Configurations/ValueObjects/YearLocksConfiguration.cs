﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    internal sealed class YearLocksConfiguration : IEntityTypeConfiguration<YearLocks>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<YearLocks> builder)
        {
            var chargingModelTypeId = $"{nameof(ChargingModelType)}{nameof(ChargingModelType.Id)}";
            // Schema - Table
            builder.ToTable(nameof(YearLocks), BaseConfiguration.ValueObjectSchema);
            // Properties
            builder.Property(x => x.Year).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property<int>(chargingModelTypeId).IsRequired();
            foreach (var month in Revenue.GetMonths()) builder.Property<bool>(month.ToString()).IsRequired();
            // PK
            builder.HasKey(nameof(YearLocks.Year), chargingModelTypeId).HasName(BaseConfiguration.GetPkName<YearLocks>(new string[] { nameof(YearLocks.Year), chargingModelTypeId }));
            builder.Navigation(x => x.ChargingModelType).AutoInclude();
            // IX
            // FK
            builder.HasOne(x => x.ChargingModelType).WithMany().IsRequired().HasPrincipalKey(x => x.Id).HasForeignKey(chargingModelTypeId).HasConstraintName(BaseConfiguration.GetFkName<YearLocks, ChargingModelType>(new string[] { chargingModelTypeId })).OnDelete(DeleteBehavior.Restrict);
        }

        #endregion
    }
}
