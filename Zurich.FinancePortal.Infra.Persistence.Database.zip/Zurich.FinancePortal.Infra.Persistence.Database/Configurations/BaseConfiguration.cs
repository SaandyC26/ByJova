﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using System.Collections.Generic;

    public static class BaseConfiguration
    {
        #region --- PROPERTIES ---

        internal const string ModelSufix = "Model";

        public const string AuthorizationSchema = "aut";

        public const string EntitySchema = "ent";

        public const string MasterDataSchema = "mdt";

        public const string RelationSchema = "rel";

        public const string ValueObjectSchema = "val";

        public const string InternalSchema = "int";

        internal const int Nvarchar_50 = 50;

        internal const int Nvarchar_10 = 10;

        internal const int Nvarchar_128 = 128;

        internal const int Nvarchar_255 = 255;

        internal const string Decimal_18_2 = "decimal(18, 2)";

        internal const string Decimal_18_5 = "decimal(18, 5)";

        internal const string Uuid = "uuid";

        internal const string Date = "date";

        #endregion

        #region --- INTERNAL METHODS ---

        internal static string GetPkName<T>(IEnumerable<string> properties) => $"PK_{typeof(T).Name}_{string.Join('_', properties)}";

        internal static string GetPkName(string type, IEnumerable<string> properties) => $"PK_{type}_{string.Join('_', properties)}";

        internal static string GetIxName<T>(IEnumerable<string> properties, bool unique = false) => $"{(unique ? "AK" : "IX")}_{typeof(T).Name}_{string.Join('_', properties)}";

        internal static string GetFkName<T1, T2>(IEnumerable<string> properties) => $"FK_{typeof(T1).Name}_{typeof(T2).Name}_{string.Join('_', properties)}";

        internal static string GetFkName<T>(string type, IEnumerable<string> properties) => $"FK_{type}_{typeof(T).Name}_{string.Join('_', properties)}";

        #endregion
    }
}
