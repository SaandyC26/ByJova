﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class PermissionConfiguration : IEntityTypeConfiguration<Permission>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<Permission> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(Permission), BaseConfiguration.AuthorizationSchema);
            // Properties
            builder.Property(p => p.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(p => p.Name).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(p => p.Description).HasMaxLength(BaseConfiguration.Nvarchar_255);
            // PK
            builder.HasKey(p => p.Id).HasName(BaseConfiguration.GetPkName<Permission>(new string[] { nameof(Permission.Id) }));
            // IX
            builder.HasIndex(p => p.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Permission>(new string[] { nameof(Permission.Name) }, unique: true));
            // FK
            var roleId = $"{nameof(Role)}{nameof(Role.Id)}";
            var permissionId = $"{nameof(Permission)}{nameof(Permission.Id)}";
            var rolePermission = $"{nameof(Role)}{nameof(Permission)}";
            builder
                .HasMany<Role>($"_{nameof(Role).ToLowerInvariant()}s")
                .WithMany(r => r.Permissions)
                .UsingEntity<Dictionary<string, object>>(
                    rolePermission,
                    rp => rp.HasOne<Role>().WithMany().HasForeignKey(roleId).HasConstraintName(BaseConfiguration.GetFkName<Role>(rolePermission, new string[] { roleId })),
                    rp => rp.HasOne<Permission>().WithMany().HasForeignKey(permissionId).HasConstraintName(BaseConfiguration.GetFkName<Permission>(rolePermission, new string[] { permissionId })),
                    rp =>
                    {
                        rp.ToTable(rolePermission, BaseConfiguration.RelationSchema);
                        rp.HasKey(roleId, permissionId).HasName(BaseConfiguration.GetPkName(rolePermission, new string[] { roleId, permissionId }));
                    });
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, Permission Permission)> GetSeedData()
        {
            return Type
                .GetType($"{nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Application)}.{nameof(Application.Constants)}, {nameof(Zurich)}.{nameof(FinancePortal)}.{nameof(Application)}", true, true)
                .GetFields(BindingFlags.Public | BindingFlags.Static)
                .Where(f => f.FieldType.Equals(typeof(Permission)))
                .Select(f => (new SeedMode[] { SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, (Permission)f.GetValue(null)))
                .ToList();
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<Permission>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.FirstOrDefault(p => p.Name.EqualsICIC(@object.Name));
                    if (dbItem == null) dbContext.Add(@object);
                }
                // Remove
                var roles = await dbContext.Roles.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var permission in dbItems.Where(p => !objects.Any(p2 => p2.Permission.Name.EqualsICIC(p.Name))))
                {
                    roles.ForEach(r => r.RemovePermission(permission.Id));
                    dbContext.Permissions.Remove(permission);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<Permission>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Permission)}\".");
            }
        }

        #endregion
    }
}
