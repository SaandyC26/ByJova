﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class CurrencyExchangeRateConfiguration : IEntityTypeConfiguration<CurrencyExchangeRate>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<CurrencyExchangeRate> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(CurrencyExchangeRate), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(cer => cer.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(cer => cer.Year).IsRequired();
            builder.Property(cer => cer.Month).HasConversion(cer => cer.ToString(), db => Enum.Parse<Month>(db, true)).HasDefaultValue(Month.None).HasMaxLength(BaseConfiguration.Nvarchar_10);
            builder.Property(cer => cer.Rate).IsRequired().HasColumnType(BaseConfiguration.Decimal_18_5);
            // PK
            builder.HasKey(cer => cer.Id).HasName(BaseConfiguration.GetPkName<CurrencyExchangeRate>(new string[] { nameof(CurrencyExchangeRate.Id) }));
            // FK
            var currencyIdFrom = $"{nameof(Currency)}{nameof(Currency.Id)}{nameof(CurrencyExchangeRate.From)}";
            builder.HasOne(cer => cer.From).WithMany().HasForeignKey(currencyIdFrom).HasPrincipalKey(c => c.Id).HasConstraintName(BaseConfiguration.GetFkName<CurrencyExchangeRate, Currency>(new string[] { currencyIdFrom })).IsRequired().OnDelete(DeleteBehavior.Restrict);
            var currencyIdTo = $"{nameof(Currency)}{nameof(Currency.Id)}{nameof(CurrencyExchangeRate.To)}";
            builder.HasOne(cer => cer.To).WithMany().HasForeignKey(currencyIdTo).HasPrincipalKey(c => c.Id).HasConstraintName(BaseConfiguration.GetFkName<CurrencyExchangeRate, Currency>(new string[] { currencyIdTo })).IsRequired().OnDelete(DeleteBehavior.Restrict);
            // IX
            builder.HasIndex(nameof(CurrencyExchangeRate.Year), nameof(CurrencyExchangeRate.Month), currencyIdFrom, currencyIdTo).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<CurrencyExchangeRate>(new string[] { nameof(CurrencyExchangeRate.Year), nameof(CurrencyExchangeRate.Month), $"{nameof(Currency)}{nameof(CurrencyExchangeRate.From)}", $"{nameof(Currency)}{nameof(CurrencyExchangeRate.To)}" }, unique: true));
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static Type[] GetDependantTypes() =>
            new Type[] { typeof(CurrencyConfiguration) };

        internal async static Task<IList<(SeedMode[] SeedModes, CurrencyExchangeRate CurrencyExchangeRate)>> GetSeedData(ApplicationDbContext dbContext, CancellationToken cancellationToken = default)
        {
            var currencies = await dbContext.Currencies.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            if (currencies.Length.Equals(0)) return new List<(SeedMode[] SeedModes, CurrencyExchangeRate CurrencyExchangeRate)>();
            var chfCurrency = currencies.SingleOrDefault(c => c.Code.EqualsICIC(Currency.ChiefsCode));
            var eurCurrency = currencies.SingleOrDefault(c => c.Code.EqualsICIC(Currency.EuroCode));
            var usdCurrency = currencies.SingleOrDefault(c => c.Code.EqualsICIC(Currency.DollarCode));
            var objects = new List<(SeedMode[], CurrencyExchangeRate)>();
            for (var year = DateTime.UtcNow.Year - 10; year < DateTime.UtcNow.Year + 1; year++)
            {
                objects.Add((new SeedMode[] { SeedMode.UnitTesting, SeedMode.Development }, new CurrencyExchangeRate(year, 0.9m, eurCurrency, chfCurrency)));
                objects.Add((new SeedMode[] { SeedMode.UnitTesting, SeedMode.Development }, new CurrencyExchangeRate(year, 0.85m, usdCurrency, chfCurrency)));
            }

            return objects;
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = (await GetSeedData(dbContext, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<CurrencyExchangeRate>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.SingleOrDefault(cer => cer.Year.Equals(@object.Year) && cer.Month.Equals(Month.None) && cer.From.Code.Equals(@object.From.Code) && cer.To.Code.Equals(@object.To.Code));
                    if (dbItem == null) dbContext.Add(@object);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<CurrencyExchangeRate>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(CurrencyExchangeRate)}\".");
            }
        }

        #endregion
    }
}
