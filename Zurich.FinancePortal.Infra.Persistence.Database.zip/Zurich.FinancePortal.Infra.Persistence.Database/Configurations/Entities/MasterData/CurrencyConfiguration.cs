﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class CurrencyConfiguration : IEntityTypeConfiguration<Currency>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<Currency> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(Currency), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(c => c.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(c => c.Name).HasField($"_{nameof(Currency.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
            builder.Property(c => c.Code).HasField($"_{nameof(Currency.Code).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
            builder.Property(c => c.Symbol).HasField($"_{nameof(Currency.Symbol).ToLowerInvariant()}").HasMaxLength(BaseConfiguration.Nvarchar_10);
            // PK
            builder.HasKey(c => c.Id).HasName(BaseConfiguration.GetPkName<Currency>(new string[] { nameof(Currency.Id) }));
            // IX
            builder.HasIndex(c => c.Code).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Currency>(new string[] { nameof(Currency.Code) }, unique: true));
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, Currency Currency)> GetSeedData()
        {
            return new List<(SeedMode[], Currency)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Currency(Currency.ChiefsName, Currency.ChiefsCode, Currency.ChiefsSymbol)),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Currency(Currency.DollarName, Currency.DollarCode, Currency.DollarSymbol)),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Currency(Currency.EuroName, Currency.EuroCode, Currency.EuroSymbol))
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<Currency>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.FirstOrDefault(d => d.Code.EqualsICIC(@object.Code));
                    if (dbItem == null) dbContext.Add(@object);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<Currency>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Currency)}\".");
            }
        }

        #endregion
    }
}
