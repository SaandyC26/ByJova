﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class TestingToolConfiguration : IEntityTypeConfiguration<TestingTool>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<TestingTool> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(TestingTool), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(p => p.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(p => p.Name).HasField($"_{nameof(TestingTool.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            // PK
            builder.HasKey(p => p.Id).HasName(BaseConfiguration.GetPkName<TestingTool>(new string[] { nameof(TestingTool.Id) }));
            // IX
            builder.HasIndex(p => p.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<TestingTool>(new string[] { nameof(TestingTool.Name) }, unique: true));
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, TestingTool TestingTool)> GetSeedData()
        {
            return new List<(SeedMode[], TestingTool)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new TestingTool("ALM")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new TestingTool("Azure")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new TestingTool("JIRA"))
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<TestingTool>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!dbItems.Any(dbi => !dbi.Name.EqualsICIC("N/A")))
                {
                    foreach (var (_, @object) in objects)
                    {
                        var dbItem = dbItems.FirstOrDefault(p => p.Name.EqualsICIC(@object.Name));
                        if (dbItem == null) dbContext.Add(@object);
                    }

                    await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                    if ((await dbContext.Set<TestingTool>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(TestingTool)}\".");
                }
            }
        }

        #endregion
    }
}
