﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class CostCenterConfiguration : IEntityTypeConfiguration<CostCenter>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<CostCenter> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(CostCenter), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(cc => cc.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(cc => cc.Code).HasField($"_{nameof(CostCenter.Code).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
            builder.Ignore(cc => cc.Types);
            builder.Property<string>($"_{nameof(CostCenter.Types)}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255).HasColumnName(nameof(CostCenter.Types));
            // PK
            builder.HasKey(cc => cc.Id).HasName(BaseConfiguration.GetPkName<CostCenter>(new string[] { nameof(CostCenter.Id) }));
            // IX
            builder.HasIndex(cc => cc.Code).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<CostCenter>(new string[] { nameof(CostCenter.Code) }, unique: true));
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, CostCenter CostCenter)> GetSeedData()
        {
            return new List<(SeedMode[], CostCenter)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C500045001", new CostCenterType[]{ CostCenterType.Internal })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C500045006", new CostCenterType[]{ CostCenterType.Internal })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("999072", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C500044002", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C100001127", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C500044051", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("C500040275", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("201000", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("999034", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("999033", new CostCenterType[]{ CostCenterType.Customer })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("ES00XGIT09", new CostCenterType[]{ CostCenterType.Internal })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("ES00XGIT10", new CostCenterType[]{ CostCenterType.Internal })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("ES00XGIT11", new CostCenterType[]{ CostCenterType.Internal })),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CostCenter("ES00XGIT12", new CostCenterType[]{ CostCenterType.Internal })),
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<CostCenter>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.FirstOrDefault(cc => cc.Code.EqualsICIC(@object.Code));
                    if (dbItem == null) dbContext.Add(@object);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<CostCenter>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(CostCenter)}\".");
            }
        }

        #endregion
    }
}
