﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class TypeOfServiceConfiguration : IEntityTypeConfiguration<TypeOfService>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<TypeOfService> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(TypeOfService), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(tos => tos.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(tos => tos.Name).HasField($"_{nameof(TypeOfService.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
            builder.Ignore(tos => tos.IsTrueUp);
            // PK
            builder.HasKey(tos => tos.Id).HasName(BaseConfiguration.GetPkName<TypeOfService>(new string[] { nameof(TypeOfService.Id) }));
            // IX
            builder.HasIndex(tos => tos.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<TypeOfService>(new string[] { nameof(TypeOfService.Name) }, unique: true));
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, TypeOfService TypeOfService)> GetSeedData()
        {
            return new List<(SeedMode[], TypeOfService)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new TypeOfService(TypeOfService.TrueUpName)),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new TypeOfService("Tools")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new TypeOfService("Development")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new TypeOfService("DevOps")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new TypeOfService("Test & QA Management")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new TypeOfService("BOP Ex"))
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<TypeOfService>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                foreach (var (_, @object) in objects)
                {
                    var dbItem = dbItems.FirstOrDefault(tos => tos.Name.EqualsICIC(@object.Name));
                    if (dbItem == null) dbContext.Add(@object);
                }

                await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                if ((await dbContext.Set<TypeOfService>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(TypeOfService)}\".");
            }
        }

        #endregion
    }
}
