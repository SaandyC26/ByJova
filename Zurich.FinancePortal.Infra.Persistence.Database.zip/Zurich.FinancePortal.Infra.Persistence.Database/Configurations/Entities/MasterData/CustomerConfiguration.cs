﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(Customer), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(c => c.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(c => c.Name).HasField($"_{nameof(Customer.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
        // PK
        builder.HasKey(c => c.Id).HasName(BaseConfiguration.GetPkName<Customer>(new string[] { nameof(Customer.Id) }));
        // IX
        builder.HasIndex(c => c.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Customer>(new string[] { nameof(Customer.Name) }, unique: true));
        // FK
        /* Function */
        var functionId = $"{nameof(Customer.Function)}{nameof(CustomerFunction.Id)}";
        builder.Property<int?>(functionId);
        builder.HasOne(r => r.Function).WithMany().HasForeignKey(functionId).HasPrincipalKey(x => x.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Customer, CustomerFunction>(new string[] { functionId }));
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Type[] GetDependantTypes() =>
        new Type[]
        {
            typeof(CustomerFunctionConfiguration)
        };

    internal static async Task<IList<(SeedMode[] SeedModes, Customer Customer)>> GetSeedData(ApplicationDbContext dbContext, CancellationToken cancellationToken = default)
    {
        var customerFunctions = await dbContext.Set<CustomerFunction>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        return new List<(SeedMode[], Customer)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Customer("Spain")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Customer("GF&SU Finance, Investment & Treasury")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Customer("EDA&A", function: customerFunctions.SingleOrDefault(x => x.Name.EqualsICIC("BTS")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Customer("GF&SU", function: customerFunctions.SingleOrDefault(x => x.Name.EqualsICIC("BTS")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Customer("Commercial Insurance", function: customerFunctions.SingleOrDefault(x => x.Name.EqualsICIC("GTO"))))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = (await GetSeedData(dbContext, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<Customer>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(c => c.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<Customer>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Customer)}\".");
        }
    }

    #endregion
}
