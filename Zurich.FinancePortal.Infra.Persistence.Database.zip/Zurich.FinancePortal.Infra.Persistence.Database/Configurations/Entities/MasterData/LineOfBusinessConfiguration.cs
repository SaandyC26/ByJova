﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class LineOfBusinessConfiguration : IEntityTypeConfiguration<LineOfBusiness>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<LineOfBusiness> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(LineOfBusiness), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(lob => lob.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(lob => lob.Name).HasField($"_{nameof(LineOfBusiness.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
        builder.Property(lob => lob.Icon).HasField($"_{nameof(LineOfBusiness.Icon).ToLowerInvariant()}").HasMaxLength(BaseConfiguration.Nvarchar_50);
        // PK
        builder.HasKey(lob => lob.Id).HasName(BaseConfiguration.GetPkName<LineOfBusiness>(new string[] { nameof(LineOfBusiness.Id) }));
        // IX
        builder.HasIndex(lob => lob.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<LineOfBusiness>(new string[] { nameof(LineOfBusiness.Name) }, unique: true));
        // FK
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static IList<(SeedMode[] SeedModes, LineOfBusiness LineOfBusiness)> GetSeedData()
    {
        return new List<(SeedMode[], LineOfBusiness)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new LineOfBusiness("DevOps")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new LineOfBusiness("Testing")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new LineOfBusiness("K2 && Guidewire"))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<LineOfBusiness>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(lob => lob.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<LineOfBusiness>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(LineOfBusiness)}\".");
        }
    }

    #endregion
}
