﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class CustomerFunctionConfiguration : IEntityTypeConfiguration<CustomerFunction>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<CustomerFunction> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(CustomerFunction), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(x => x.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(x => x.Name).HasField($"_{nameof(CustomerFunction.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        // PK
        builder.HasKey(x => x.Id).HasName(BaseConfiguration.GetPkName<CustomerFunction>(new string[] { nameof(CustomerFunction.Id) }));
        // IX
        builder.HasIndex(x => x.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<CustomerFunction>(new string[] { nameof(CustomerFunction.Name) }, unique: true));
        // FK
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static IList<(SeedMode[] SeedModes, CustomerFunction Function)> GetSeedData()
    {
        return new List<(SeedMode[], CustomerFunction)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CustomerFunction("BTS")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new CustomerFunction("GTO"))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<CustomerFunction>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(lob => lob.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<CustomerFunction>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(CustomerFunction)}\".");
        }
    }

    #endregion
}
