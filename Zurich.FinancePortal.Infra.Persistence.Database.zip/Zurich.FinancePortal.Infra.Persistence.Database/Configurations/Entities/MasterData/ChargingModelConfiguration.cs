﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class ChargingModelTypeConfiguration : IEntityTypeConfiguration<ChargingModelType>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<ChargingModelType> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(ChargingModelType), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(x => x.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(x => x.Type).HasField($"_{nameof(ChargingModelType.Type).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
        // PK
        builder.HasKey(x => x.Id).HasName(BaseConfiguration.GetPkName<ChargingModelType>(new string[] { nameof(ChargingModelType.Id) }));
        // IX
        builder.HasIndex(x => x.Type).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<ChargingModelType>(new string[] { nameof(ChargingModelType.Type) }, unique: true));
        // FK
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static IList<(SeedMode[] SeedModes, ChargingModelType ChargingModelType)> GetSeedData()
    {
        return new List<(SeedMode[], ChargingModelType)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModelType("BI")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModelType("RB")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModelType("CA"))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<ChargingModelType>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(x => x.Type.EqualsICIC(@object.Type));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<ChargingModelType>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(ChargingModelType)}\".");
        }
    }

    #endregion
}

internal sealed class ChargingModelConfiguration : IEntityTypeConfiguration<ChargingModel>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<ChargingModel> builder)
    {
        var chargingModelTypeId = $"{nameof(ChargingModelType)}{nameof(ChargingModelType.Id)}";
        // Schema - Table
        builder.ToTable(nameof(ChargingModel), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(cm => cm.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(cm => cm.Name).HasField($"_{nameof(ChargingModel.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
        builder.Property(cm => cm.Code).HasField($"_{nameof(ChargingModel.Code).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
        builder.Property<int>(chargingModelTypeId).IsRequired();
        // PK
        builder.HasKey(cm => cm.Id).HasName(BaseConfiguration.GetPkName<ChargingModel>(new string[] { nameof(ChargingModel.Id) }));
        // IX
        builder.HasIndex(cm => cm.Code).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<ChargingModel>(new string[] { nameof(ChargingModel.Code) }, unique: true));
        // FK
        builder.HasOne(x => x.Type).WithMany().IsRequired().HasPrincipalKey(x => x.Id).HasForeignKey(chargingModelTypeId).HasConstraintName(BaseConfiguration.GetFkName<ChargingModel, ChargingModelType>(new string[] { chargingModelTypeId })).OnDelete(DeleteBehavior.Restrict);
        builder.Navigation(x => x.Type).AutoInclude();
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Type[] GetDependantTypes() => new Type[]
    {
            typeof(ChargingModelTypeConfiguration)
    };

    internal async static Task<IList<(SeedMode[] SeedModes, ChargingModel ChargingModel)>> GetSeedDataAsync(ApplicationDbContext dbContext, CancellationToken cancellationToken = default)
    {
        var chargingModelTypes = await dbContext.ChargingModelTypes.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        return new List<(SeedMode[], ChargingModel)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.BicChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("BI")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.BieChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("BI")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.BiChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("BI")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.CaChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("CA")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.RbiChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("RB")))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new ChargingModel("TBC", ChargingModel.RbdChargingModelCode, chargingModelTypes.Single(x => x.Type.EqualsICIC("RB"))))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = (await GetSeedDataAsync(dbContext, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<ChargingModel>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(cm => cm.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<ChargingModel>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(ChargingModel)}\".");
        }
    }

    #endregion
}
