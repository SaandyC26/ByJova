﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Application;
    using DevOps.CrossCutting;
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    internal sealed class ProductConfiguration : IEntityTypeConfiguration<Product>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<Product> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(Product), BaseConfiguration.MasterDataSchema);
            // Properties
            builder.Property(p => p.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(p => p.Name).HasField($"_{nameof(Product.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            // PK
            builder.HasKey(p => p.Id).HasName(BaseConfiguration.GetPkName<Product>(new string[] { nameof(Product.Id) }));
            // IX
            builder.HasIndex(p => p.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Product>(new string[] { nameof(Product.Name) }, unique: true));
            // FK
        }

        #endregion

        #region --- INTERNAL METHODS ---

        internal static IList<(SeedMode[] SeedModes, Product Product)> GetSeedData()
        {
            return new List<(SeedMode[], Product)>()
            {
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("TCoE QA Mgmt & Functional Test")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("TCoE Load & Performance Test")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("TCoE Test Automation")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("TCoE Mobile Testing")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("TCoE Application Security Test")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("DevOps Testing Tools")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("DevOps Platform")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("DevOps Pipelines")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("DevOps Containers Platform")),
                (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Product("N/A"))
            };
        }

        internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
        {
            Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
            var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
            if (objects.Any())
            {
                var dbItems = await dbContext.Set<Product>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
                if (!dbItems.Any(dbi => !dbi.Name.EqualsICIC("N/A")))
                {
                    foreach (var (_, @object) in objects)
                    {
                        var dbItem = dbItems.FirstOrDefault(p => p.Name.EqualsICIC(@object.Name));
                        if (dbItem == null) dbContext.Add(@object);
                    }

                    await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
                    if ((await dbContext.Set<Product>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Product)}\".");
                }
            }
        }

        #endregion
    }
}
