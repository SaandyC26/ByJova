﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class ProjectConfiguration : IEntityTypeConfiguration<Project>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Project> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(Project), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(x => x.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(x => x.Name).HasField($"_{nameof(Project.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        var projectType = ProjectType.NA;
        builder.Property(x => x.Type).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_10).HasConversion(x => x.ToString(), x => Enum.TryParse(x, out projectType) ? projectType : ProjectType.NA);
        builder.OwnsMany(x => x.PlanningItApps, ownedBuilder =>
        {
            var projectId = $"{nameof(Project)}{nameof(Project.Id)}";
            // Schema - Table
            ownedBuilder.ToTable($"{nameof(Project)}{nameof(PlanningItApp)}", BaseConfiguration.ValueObjectSchema);
            // Properties
            var planningItAppPrefix = PlanningItAppPrefix.UNKNOWN;
            ownedBuilder.Property(x => x.Prefix).HasColumnName(nameof(PlanningItApp.Prefix)).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_10).HasConversion(x => x.ToString(), x => Enum.TryParse(x, out planningItAppPrefix) ? planningItAppPrefix : PlanningItAppPrefix.UNKNOWN);
            ownedBuilder.Property(x => x.Id).HasColumnName(nameof(PlanningItApp.Id)).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
            ownedBuilder.Property(x => x.Name).HasColumnName(nameof(PlanningItApp.Name)).HasMaxLength(BaseConfiguration.Nvarchar_255);
            // PK
            ownedBuilder.HasKey(new string[] { nameof(PlanningItApp.Prefix), nameof(PlanningItApp.Id), projectId }).HasName(BaseConfiguration.GetPkName<PlanningItApp>(new string[] { nameof(PlanningItApp.Prefix), nameof(PlanningItApp.Id), projectId }));
            // FK
            ownedBuilder.WithOwner().HasForeignKey(projectId).HasConstraintName(BaseConfiguration.GetFkName<Project>(nameof(PlanningItApp), new string[] { nameof(Project.Id) }));
        });
        // PK
        builder.HasKey(p => p.Id).HasName(BaseConfiguration.GetPkName<Project>(new string[] { nameof(Project.Id) }));
        // IX
        builder.HasIndex(p => p.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Project>(new string[] { nameof(Project.Name) }, unique: true));
        // FK
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static IList<(SeedMode[] SeedModes, Project Project)> GetSeedData()
    {
        return new List<(SeedMode[], Project)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Project("ALM_BU_SPAIN", ProjectType.NA, planningItApps: GetPlanningItApp())),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Project("ALM_CENTRAL_SHARED_SERVICES", ProjectType.NA)),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Project("ALM_COUPA", ProjectType.NA, planningItApps: GetPlanningItApp())),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Project("ALM_EDAA", ProjectType.NA, planningItApps: GetPlanningItApp())),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new Project("ALM_FNWL", ProjectType.NA, planningItApps: GetPlanningItApp()))
        };

        static IEnumerable<PlanningItApp> GetPlanningItApp() => new PlanningItApp[] { new PlanningItApp(PlanningItAppPrefix.APP, Guid.NewGuid().ToString(), Guid.NewGuid().ToString()), new PlanningItApp(PlanningItAppPrefix.COM, Guid.NewGuid().ToString(), Guid.NewGuid().ToString()) };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<Project>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(p => p.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<Project>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Project)}\".");
        }
    }

    #endregion
}
