﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class BusinessUnitConfiguration : IEntityTypeConfiguration<BusinessUnit>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<BusinessUnit> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(BusinessUnit), BaseConfiguration.MasterDataSchema);
        // Properties
        builder.Property(bu => bu.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(bu => bu.Name).HasField($"_{nameof(BusinessUnit.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_128);
        builder.Property(bu => bu.Code).HasField($"_{nameof(BusinessUnit.Code).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50);
        // PK
        builder.HasKey(bu => bu.Id).HasName(BaseConfiguration.GetPkName<BusinessUnit>(new string[] { nameof(BusinessUnit.Id) }));
        // IX
        builder.HasIndex(bu => bu.Code).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<BusinessUnit>(new string[] { nameof(BusinessUnit.Code) }, unique: true));
        // FK
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static IList<(SeedMode[] SeedModes, BusinessUnit BusinessUnit)> GetSeedData()
    {
        return new List<(SeedMode[], BusinessUnit)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999072", "999072")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU C100001127", "C100001127")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU C500044051", "C500044051")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 201000", "201000")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999034", "999034")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999033", "999033")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999031", "999031")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999032", "999032")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999081", "999081")),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development }, new BusinessUnit("BU 999082", "999082"))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = GetSeedData().Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<BusinessUnit>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(bu => bu.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<BusinessUnit>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(BusinessUnit)}\".");
        }
    }

    #endregion
}
