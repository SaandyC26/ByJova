﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class RevenueConfiguration : IEntityTypeConfiguration<Revenue>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Revenue> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(Revenue), BaseConfiguration.EntitySchema);
        // Properties
        builder.Property(r => r.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        /* Line of Business */
        var lineOfBusinessId = $"{nameof(Revenue.LineOfBusiness)}{nameof(LineOfBusiness.Id)}";
        builder.Property<int>(lineOfBusinessId).IsRequired();
        /* Customer */
        var customerId = $"{nameof(Revenue.Customer)}{nameof(Customer.Id)}";
        builder.Property<int>(customerId).IsRequired();
        /* Project */
        var projectId = $"{nameof(Revenue.Project)}{nameof(Project.Id)}";
        builder.Property<int>(projectId).IsRequired();
        /* Type of Service */
        var typeOfServiceId = $"{nameof(Revenue.TypeOfService)}{nameof(TypeOfService.Id)}";
        builder.Property<int>(typeOfServiceId).IsRequired();
        /* Owner/PM */
        var ownerProjectManagerId = $"{nameof(Revenue.OwnerProjectManager)}{nameof(User.Id)}";
        builder.Property<int>(ownerProjectManagerId).IsRequired();
        /* Group */
        var groupId = $"{nameof(Revenue.GroupOwner)}{nameof(Group.Id)}";
        builder.Property<int?>(groupId);
        /* Service Description */
        builder.Property(r => r.ServiceDescription).HasMaxLength(BaseConfiguration.Nvarchar_255);
        /* BU Code */
        var businessUnitId = $"{nameof(Revenue.BusinessUnit)}{nameof(BusinessUnit.Id)}";
        builder.Property<int?>(businessUnitId);
        /* CC Customer */
        var customerCostCenterId = $"{nameof(Revenue.CustomerCostCenter)}{nameof(CostCenter.Id)}";
        builder.Property<int?>(customerCostCenterId);
        /* Charging Model */
        var chargingModelId = $"{nameof(Revenue.ChargingModel)}{nameof(ChargingModel.Id)}";
        builder.Property<int>(chargingModelId).IsRequired();
        /* Internal CC Per Cost */
        var internalCostCenterPerCostId = $"{nameof(Revenue.InternalCostCenterPerCost)}{nameof(CostCenter.Id)}";
        builder.Property<int>(internalCostCenterPerCostId).IsRequired();
        /* Product */
        var productId = $"{nameof(Revenue.Product)}{nameof(Product.Id)}";
        builder.Property<int>(productId).IsRequired();
        /* TestingTool */
        var testingToolId = $"{nameof(Revenue.TestingTool)}{nameof(TestingTool.Id)}";
        builder.Property<int?>(testingToolId);
        /* Testing Tool Project Name */
        builder.Property(x => x.TestingToolProjectName).HasMaxLength(BaseConfiguration.Nvarchar_128);
        /* Testing Tool Detailed Info */
        builder.Property(x => x.TestingToolDetailedInfo).HasMaxLength(BaseConfiguration.Nvarchar_255);
        /* Internal Code */
        builder.Property(r => r.InternalCode).HasField($"_{nameof(Revenue.InternalCode)[..1].ToLowerInvariant()}{nameof(Revenue.InternalCode)[1..]}").HasMaxLength(BaseConfiguration.Nvarchar_50);
        /* Currency */
        var currencyId = $"{nameof(Revenue.Currency)}{nameof(Currency.Id)}";
        builder.Property<int>(currencyId).IsRequired();
        /* Year */
        builder.Property(r => r.Year).IsRequired();
        /* FYF */
        builder.Property(r => r.FYFCLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHF).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHFVAT).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Plan */
        builder.Property(x => x.PlanLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Transfer */
        builder.Property(x => x.TransferLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Difference */
        builder.Property(x => x.DifferenceLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Planned Dates */
        builder.Property(x => x.PlannedStartDate).IsRequired().HasColumnType(BaseConfiguration.Date);
        builder.Property(x => x.PlannedEndDate).IsRequired().HasColumnType(BaseConfiguration.Date);
        /* Months */
        foreach (var m in Revenue.GetMonths())
        {
            builder.OwnsOne(typeof(MonthRevenue), m.ToString(), ownBuilder =>
            {
                ownBuilder.Property(nameof(MonthRevenue.Amount)).HasColumnName($"{m}{nameof(MonthRevenue.Amount)}").HasColumnType(BaseConfiguration.Decimal_18_2);
            });

            builder.Navigation(m.ToString()).IsRequired();
        }
        // PK
        builder.HasKey(r => r.Id).HasName(BaseConfiguration.GetPkName<Revenue>(new string[] { nameof(Revenue.Id) }));
        // FK
        /* Line of Business */
        builder.HasOne(r => r.LineOfBusiness).WithMany().IsRequired().HasForeignKey(lineOfBusinessId).HasPrincipalKey(lob => lob.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, LineOfBusiness>(new string[] { lineOfBusinessId }));
        /* Customer */
        builder.HasOne(r => r.Customer).WithMany().IsRequired().HasForeignKey(customerId).HasPrincipalKey(c => c.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, Customer>(new string[] { customerId }));
        /* Project */
        builder.HasOne(r => r.Project).WithMany().IsRequired().HasForeignKey(projectId).HasPrincipalKey(p => p.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, Project>(new string[] { projectId }));
        /* Product */
        builder.HasOne(r => r.Product).WithMany().IsRequired().HasForeignKey(productId).HasPrincipalKey(p => p.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, Product>(new string[] { productId }));
        /* Testing Tool */
        builder.HasOne(r => r.TestingTool).WithMany().HasForeignKey(testingToolId).HasPrincipalKey(x => x.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, TestingTool>(new string[] { testingToolId }));
        /* Type of Service */
        builder.HasOne(r => r.TypeOfService).WithMany().IsRequired().HasForeignKey(typeOfServiceId).HasPrincipalKey(tos => tos.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, TypeOfService>(new string[] { typeOfServiceId }));
        /* Owner/PM */
        builder.HasOne(r => r.OwnerProjectManager).WithMany().IsRequired().HasForeignKey(ownerProjectManagerId).HasPrincipalKey(u => u.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, User>(new string[] { ownerProjectManagerId }));
        /* Group Owner */
        builder.HasOne(r => r.GroupOwner).WithMany().HasForeignKey(groupId).HasPrincipalKey(g => g.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, Group>(new string[] { groupId }));
        /* BU Code */
        builder.HasOne(r => r.BusinessUnit).WithMany().HasForeignKey(businessUnitId).HasPrincipalKey(bu => bu.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, BusinessUnit>(new string[] { businessUnitId }));
        /* CC Customer */
        builder.HasOne(r => r.CustomerCostCenter).WithMany().HasForeignKey(customerCostCenterId).HasPrincipalKey(cu => cu.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, CostCenter>(new string[] { customerCostCenterId }));
        /* Charging Model */
        builder.HasOne(r => r.ChargingModel).WithMany().IsRequired().HasForeignKey(chargingModelId).HasPrincipalKey(cm => cm.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, ChargingModel>(new string[] { chargingModelId }));
        /* Internal CC Per Cost */
        builder.HasOne(r => r.InternalCostCenterPerCost).WithMany().IsRequired().HasForeignKey(internalCostCenterPerCostId).HasPrincipalKey(cc => cc.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, CostCenter>(new string[] { internalCostCenterPerCostId }));
        /* Currency */
        builder.HasOne(r => r.Currency).WithMany().IsRequired().HasForeignKey(currencyId).HasPrincipalKey(c => c.Id).OnDelete(DeleteBehavior.Restrict).HasConstraintName(BaseConfiguration.GetFkName<Revenue, Currency>(new string[] { currencyId }));
        /* VAT */
        var valueAddedTax = $"{nameof(ValueAddedTax)}{nameof(ValueAddedTax.Id)}";
        builder.HasOne(r => r.ValueAddedTax).WithMany().HasForeignKey(valueAddedTax).HasPrincipalKey(vat => vat.Id).HasConstraintName(BaseConfiguration.GetFkName<Revenue, ValueAddedTax>(new string[] { valueAddedTax })).OnDelete(DeleteBehavior.Restrict);
        /* Exchange Rates */
        builder.Ignore(r => r.CurrencyExchangeRates);
        /* Comments */
        var commentsField = $"_{nameof(Revenue.Comments).ToLowerInvariant()}";
        builder.Metadata.FindNavigation(nameof(Revenue.Comments)).SetField(commentsField);
        builder.HasMany(r => r.Comments).WithOne().HasForeignKey(RevenueCommentConfiguration.RevenueId).HasPrincipalKey(r => r.Id).OnDelete(DeleteBehavior.Cascade).HasConstraintName(BaseConfiguration.GetFkName<Revenue, RevenueComment>(new string[] { RevenueCommentConfiguration.RevenueId }));
        /* Updates */
        builder.Ignore(r => r.Updates);
        // IX
        builder.HasIndex(nameof(Revenue.Year), lineOfBusinessId, customerId, projectId, typeOfServiceId, nameof(Revenue.ServiceDescription)).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Revenue>(new string[] { nameof(Revenue.Year), "LoB", nameof(Customer), nameof(Project), "ToS", nameof(Revenue.ServiceDescription) }, unique: true));
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Type[] GetDependantTypes() => new Type[]
    {
        typeof(LineOfBusinessConfiguration),
        typeof(ProjectConfiguration),
        typeof(CustomerConfiguration),
        typeof(TypeOfServiceConfiguration),
        typeof(BusinessUnitConfiguration),
        typeof(ChargingModelConfiguration),
        typeof(CostCenterConfiguration),
        typeof(CurrencyConfiguration),
        typeof(CurrencyExchangeRateConfiguration),
        typeof(ValueAddedTaxConfiguration),
        typeof(UserConfiguration),
        typeof(ProductConfiguration),
        typeof(TestingToolConfiguration),
        typeof(GroupConfiguration)
    };

    internal async static Task<IList<(SeedMode[] SeedModes, Revenue Revenue)>> GetSeedData(ApplicationDbContext dbContext, SeedMode seedMode, CancellationToken cancellationToken = default)
    {
        var seedModes = new SeedMode[] { SeedMode.Development };
        if (!seedModes.Any(sm => sm.Equals(seedMode))) return new List<(SeedMode[], Revenue)>() { (seedModes, null) };
        var objects = new List<(SeedMode[], Revenue)>();
        var random = new Random((int)DateTime.UtcNow.Ticks);
        var revenuesPerYear = 1000;
        // Master Datas
        var linesOfBusiness = await dbContext.LinesOfBusiness.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var projects = await dbContext.Projects.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var customers = await dbContext.Customers.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var typesOfServices = await dbContext.TypesOfServices.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var businessUnits = await dbContext.Set<BusinessUnit>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var costCenters = await dbContext.Set<CostCenter>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var chargingModels = await dbContext.Set<ChargingModel>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var currencies = await dbContext.Set<Currency>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var valueAddedTaxes = await dbContext.Set<ValueAddedTax>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var products = await dbContext.Set<Product>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var users = await dbContext.Users.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var testingTools = await dbContext.Set<TestingTool>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        var currenciesExchangesRates = await dbContext.Set<CurrencyExchangeRate>().Include(cer => cer.From).Include(cer => cer.To).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        // Loop
        for (var year = DateTime.UtcNow.Year - 2; year <= DateTime.UtcNow.Year; year++)
        {
            var dbItemsCount = await dbContext.Set<Revenue>().CountAsync(r => r.Year.Equals(year), cancellationToken: cancellationToken).ConfigureAwait(false);
            while (dbItemsCount < revenuesPerYear)
            {
                var lineOfBusiness = linesOfBusiness.ElementAt(random.Next(0, linesOfBusiness.Length));
                var project = projects.ElementAt(random.Next(0, projects.Length));
                var customer = customers.ElementAt(random.Next(0, customers.Length));
                var typeOfService = typesOfServices.ElementAt(random.Next(0, typesOfServices.Length));
                var businessUnit = businessUnits.ElementAt(random.Next(0, businessUnits.Length));
                var customerCostCenters = costCenters.Where(cc => cc.Types.Contains(CostCenterType.Customer));
                var customerCostCenter = customerCostCenters.ElementAt(random.Next(0, customerCostCenters.Count()));
                var chargingModel = chargingModels.ElementAt(random.Next(0, chargingModels.Length));
                var internalCostCenters = costCenters.Where(cc => cc.Types.Contains(CostCenterType.Internal));
                var internalCostCenter = internalCostCenters.ElementAt(random.Next(0, internalCostCenters.Count()));
                var product = products.ElementAt(random.Next(0, products.Length));
                var testingTool = testingTools.ElementAt(random.Next(0, testingTools.Length));
                var rCurrency = random.Next(0, 100);
                var currency = currencies.Single(c => rCurrency < 95 ? c.Code.Equals(Currency.ChiefsCode) : c.Code.Equals(Currency.EuroCode));
                var valueAddedTax = valueAddedTaxes.ElementAt(random.Next(0, valueAddedTaxes.Length));
                var ownerProjectManager = users.ElementAt(random.Next(0, users.Length));
                var currencyExchangeRates = currenciesExchangesRates.Where(cer => cer.Year.Equals(year) && cer.From.Code.EqualsICIC(currency.Code));
                var revenue = new Revenue(year, lineOfBusiness, project, customer, typeOfService, (businessUnit, customerCostCenter), chargingModel, internalCostCenter, currency, valueAddedTax, ownerProjectManager, product, new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc), new DateTime(year, 12, 31, 23, 59, 59, DateTimeKind.Utc), internalCode: Guid.NewGuid().ToString(), serviceDescription: Guid.NewGuid().ToString(), currencyExchangeRates: currencyExchangeRates, testingTool: testingTool, testingToolProjectName: Guid.NewGuid().ToString(), testingToolDetailedInfo: Guid.NewGuid().ToString());
                var randomMonth = random.Next(0, 12);
                var monthsRevenues = new Dictionary<Month, MonthRevenue>();
                for (var i = 0; i < Revenue.GetMonths().Count(); i++)
                {
                    monthsRevenues.Add((Month)(i + 1), new MonthRevenue(i <= randomMonth ? (random.Next(0, 9999) + (decimal)(random.Next(0, 99) / 100)) : null));
                }

                revenue.UpdateMonthsRevenues(monthsRevenues);
                revenue.UpdatePlanAndTransfer(plan: decimal.One * decimal.Parse(dbItemsCount.ToString()), transfer: decimal.One * decimal.Parse((dbItemsCount.Equals(0) ? 0 : dbItemsCount - 1).ToString()));
                objects.Add((seedModes, revenue));
                dbItemsCount++;
            }
        }

        return objects;
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = (await GetSeedData(dbContext, seedMode, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            foreach (var (_, @object) in objects)
            {
                var dbItem = await dbContext.Revenues.AsNoTracking().FirstOrDefaultAsync(r => r.Year.Equals(@object.Year) && r.LineOfBusiness.Id == @object.LineOfBusiness.Id && r.Customer.Id == @object.Customer.Id && r.Project.Id.Equals(@object.Project.Id) && r.TypeOfService.Id.Equals(@object.TypeOfService.Id) && r.ServiceDescription.ToUpper().Equals(@object.ServiceDescription.ToUpper()), cancellationToken: cancellationToken).ConfigureAwait(false);
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<Revenue>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Revenue)}\".");
        }
    }

    #endregion
}

internal sealed class RevenueModelConfiguration : IEntityTypeConfiguration<RevenueModel>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<RevenueModel> builder)
    {
        // Schema - Table
        builder.ToView("RevenueFrontEnd", BaseConfiguration.EntitySchema);
        // Properties
        builder.Property(r => r.Id).IsRequired();
        /* Year */
        builder.Property(r => r.Year).IsRequired();
        /* Internal Code */
        builder.Property(r => r.InternalCode).HasMaxLength(BaseConfiguration.Nvarchar_50);
        /* Service Description */
        builder.Property(r => r.ServiceDescription).HasMaxLength(BaseConfiguration.Nvarchar_255);
        /* FYF */
        builder.Property(r => r.FYFCLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHF).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHFVAT).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Plan */
        builder.Property(x => x.PlanLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Transfer */
        builder.Property(x => x.TransferLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Difference */
        builder.Property(x => x.DifferenceLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Line of Business */
        builder.Property(r => r.LineOfBusinessName).IsRequired();
        /* Customer */
        builder.Property(r => r.CustomerName).IsRequired();
        /* Project */
        builder.Property(r => r.ProjectName).IsRequired();
        /* Project Type */
        builder.Property(r => r.ProjectType).IsRequired();
        /* Type of Service */
        builder.Property(r => r.TypeOfServiceName).IsRequired();
        /* Owner/PM */
        builder.Property(r => r.OwnerProjectManagerName).IsRequired();
        /* Group */
        builder.Property(r => r.GroupOwnerName);
        /* BU Code */
        builder.Property(r => r.BusinessUnitCode);
        /* CC Customer */
        builder.Property(r => r.CustomerCostCenterCode);
        /* Charging Model */
        builder.Property(r => r.ChargingModelCode).IsRequired();
        /* Charging Model Type */
        builder.Property(r => r.ChargingModelType).IsRequired();
        /* Internal CC Per Cost */
        builder.Property(r => r.InternalCostCenterPerCostCode).IsRequired();
        /* Currency */
        builder.Property(r => r.CurrencyCode).IsRequired();
        /* Product */
        builder.Property(r => r.ProductName).IsRequired();
        /* Testing Tool */
        builder.Property(r => r.TestingToolName);
        /* Testing Tool Project Name*/
        builder.Property(r => r.TestingToolProjectName);
        /* Testing Tool Detailed Info */
        builder.Property(r => r.TestingToolDetailedInfo);
        /* Planned Dates */
        builder.Property(x => x.PlannedStartDate).IsRequired().HasColumnType(BaseConfiguration.Date).UsePropertyAccessMode(PropertyAccessMode.Property);
        builder.Property(x => x.PlannedEndDate).IsRequired().HasColumnType(BaseConfiguration.Date).UsePropertyAccessMode(PropertyAccessMode.Property);
        /* Comments */
        builder.HasMany(r => r.Comments).WithOne().HasForeignKey(RevenueCommentConfiguration.RevenueId).HasPrincipalKey(r => r.Id);
        /* Months */
        foreach (var m in Revenue.GetMonths())
        {
            builder.Property<decimal?>($"{m}{nameof(MonthRevenueDto.Amount)}").HasColumnType(BaseConfiguration.Decimal_18_2);
        }
        // PK
        builder.HasKey(r => r.Id);
    }

    #endregion
}

internal sealed class RevenueODataDtoConfiguration : IEntityTypeConfiguration<RevenueODataDto>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<RevenueODataDto> builder)
    {
        // Schema - Table
        builder.ToView("RevenueOData", BaseConfiguration.EntitySchema);
        // Properties
        builder.Property(r => r.Id).IsRequired();
        /* Year */
        builder.Property(r => r.Year).IsRequired();
        /* Internal Code */
        builder.Property(r => r.InternalCode).HasMaxLength(BaseConfiguration.Nvarchar_50);
        /* Service Description */
        builder.Property(r => r.ServiceDescription).HasMaxLength(BaseConfiguration.Nvarchar_255);
        /* FYF */
        builder.Property(r => r.FYFCLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHF).HasColumnType(BaseConfiguration.Decimal_18_2);
        builder.Property(r => r.FYFCCHFVAT).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Plan */
        builder.Property(x => x.PlanLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Transfer */
        builder.Property(x => x.TransferLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Difference */
        builder.Property(x => x.DifferenceLC).HasColumnType(BaseConfiguration.Decimal_18_2);
        /* Line of Business */
        builder.Property(r => r.LineOfBusinessName).IsRequired();
        /* Customer */
        builder.Property(r => r.CustomerName).IsRequired();
        /* Project */
        builder.Property(r => r.ProjectName).IsRequired();
        /* Type of Service */
        builder.Property(r => r.TypeOfServiceName).IsRequired();
        /* Owner/PM */
        builder.Property(r => r.OwnerProjectManagerName).IsRequired();
        /* BU Code */
        builder.Property(r => r.BusinessUnitCode);
        /* CC Customer */
        builder.Property(r => r.CustomerCostCenterCode);
        /* Charging Model */
        builder.Property(r => r.ChargingModelCode).IsRequired();
        builder.Property(r => r.ChargingModelType).IsRequired();
        /* Internal CC Per Cost */
        builder.Property(r => r.InternalCostCenterPerCostCode).IsRequired();
        /* Currency */
        builder.Property(r => r.CurrencyCode).IsRequired();
        /* Product */
        builder.Property(r => r.ProductName).IsRequired();
        builder.Property(x => x.PlannedStartDate).IsRequired().HasColumnType(BaseConfiguration.Date);
        builder.Property(x => x.PlannedEndDate).IsRequired().HasColumnType(BaseConfiguration.Date);
        /* Months */
        foreach (var m in Revenue.GetMonths())
        {
            builder.Property<decimal?>(m.ToString()).HasColumnName($"{m}{nameof(MonthRevenueDto.Amount)}").HasColumnType(BaseConfiguration.Decimal_18_2);
        }
        // PK
        builder.HasKey(r => r.Id);
    }

    #endregion
}
