﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    internal sealed class ApplicationConfigurationConfiguration : IEntityTypeConfiguration<ApplicationConfiguration>
    {
        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<ApplicationConfiguration> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(ApplicationConfiguration), BaseConfiguration.InternalSchema);
            // Properties
            builder.Property(c => c.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
            builder.Property(c => c.Name).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(c => c.Value);
            // PK
            builder.HasKey(c => c.Id).HasName(BaseConfiguration.GetPkName<ApplicationConfiguration>(new string[] { nameof(ApplicationConfiguration.Id) }));
            // IX
            builder.HasIndex(c => c.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<ApplicationConfiguration>(new string[] { nameof(ApplicationConfiguration.Name) }, unique: true));
            // FK
            // Filters
        }

        #endregion
    }
}
