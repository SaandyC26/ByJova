﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Role> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(Role), BaseConfiguration.AuthorizationSchema);
        // Properties
        builder.Property(r => r.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(r => r.Name).HasField($"_{nameof(Role.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(r => r.Description).HasField($"_{nameof(Role.Description).ToLowerInvariant()}").HasMaxLength(BaseConfiguration.Nvarchar_255);
        // PK
        builder.HasKey(r => r.Id).HasName(BaseConfiguration.GetPkName<Role>(new string[] { nameof(Role.Id) }));
        // IX
        builder.HasIndex(r => r.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Role>(new string[] { nameof(Role.Name) }, unique: true));
        // FK
        var roleId = $"{nameof(Role)}{nameof(Role.Id)}";
        var userId = $"{nameof(User)}{nameof(User.Id)}";
        var permissionId = $"{nameof(Permission)}{nameof(Permission.Id)}";
        var rolePermission = $"{nameof(Role)}{nameof(Permission)}";
        var userRole = $"{nameof(User)}{nameof(Role)}";
        builder
            .HasMany(r => r.Permissions)
            .WithMany($"_{nameof(Role).ToLowerInvariant()}s")
            .UsingEntity<Dictionary<string, object>>(
                rolePermission,
                rp => rp.HasOne<Permission>().WithMany().HasForeignKey(permissionId).HasConstraintName(BaseConfiguration.GetFkName<Permission>(rolePermission, new string[] { permissionId })),
                rp => rp.HasOne<Role>().WithMany().HasForeignKey(roleId).HasConstraintName(BaseConfiguration.GetFkName<Role>(rolePermission, new string[] { roleId })),
                rp =>
                {
                    rp.ToTable(rolePermission, BaseConfiguration.RelationSchema);
                    rp.HasKey(roleId, permissionId).HasName(BaseConfiguration.GetPkName(rolePermission, new string[] { roleId, permissionId }));
                });

        builder
            .HasMany(r => r.Users)
            .WithMany(u => u.Roles)
            .UsingEntity<Dictionary<string, object>>(
                userRole,
                ur => ur.HasOne<User>().WithMany().HasForeignKey(userId).HasConstraintName(BaseConfiguration.GetFkName<User>(userRole, new string[] { userId })),
                ur => ur.HasOne<Role>().WithMany().HasForeignKey(roleId).HasConstraintName(BaseConfiguration.GetFkName<Role>(userRole, new string[] { roleId })),
                ur =>
                {
                    ur.ToTable(userRole, BaseConfiguration.RelationSchema);
                    ur.HasKey(userId, roleId).HasName(BaseConfiguration.GetPkName(userRole, new string[] { userId, roleId }));
                }
            );
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Type[] GetDependantTypes() => new Type[]
    {
        typeof(PermissionConfiguration)
    };

    internal async static Task<IList<(SeedMode[] SeedModes, Role Role)>> GetSeedData(ApplicationDbContext dbContext, CancellationToken cancellationToken = default)
    {
        var excludedAdminPermissions = new string[]
        {
            Constants.Permission_BypassLockedRevenues.Name.ToUpperInvariant(),
            Constants.Permission_BypassPreviouslyBilledRevenues.Name.ToUpperInvariant(),
            Constants.Permission_BypassOwnedRevenues.Name.ToUpperInvariant(),
            Constants.Permission_BypassPlannedDatesRevenues.Name.ToUpperInvariant(),
            Constants.Permission_DeleteRevenue.Name.ToUpperInvariant(),
            Constants.Permission_RevenuesUpdatePlan.Name.ToUpperInvariant(),
            Constants.Permission_RevenuesCreateUpdateTransfer.Name.ToUpperInvariant()
        };

        var permissions = (await dbContext.Permissions.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false)).Where(p => !excludedAdminPermissions.Contains(p.Name.ToUpperInvariant()));
        return new List<(SeedMode[], Role)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Role(Role.SuperAdminName, description: Role.SuperAdminDescription, isSuperAdmin: true)),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new Role("Admin", description: $"Administrator {nameof(Role)}", permissions: permissions))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = (await GetSeedData(dbContext, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<Role>().Include(r => r.Permissions).ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            var dbPermissions = await dbContext.Permissions.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(r => r.Name.EqualsICIC(@object.Name));
                if (dbItem == null) dbContext.Add(@object);
                else
                {
                    dbPermissions.ForEach(dbp =>
                    {
                        if (@object.Permissions.Any(p => p.Name.EqualsICIC(dbp.Name))) dbItem.AddPermission(dbp);
                        else dbItem.RemovePermission(dbp.Id);
                    });
                }
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<Role>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(Role)}\".");
        }
    }

    #endregion
}
