﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class FieldConfiguration : IEntityTypeConfiguration<Field>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Field> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(Field), BaseConfiguration.InternalSchema);
        // Properties
        builder.Property(f => f.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(f => f.Type).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(f => f.Entity).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(f => f.EntityReference).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(f => f.Required).IsRequired();
        builder.Property(f => f.LabelOnFile).HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(f => f.WorksheetOnFile).HasMaxLength(BaseConfiguration.Nvarchar_255);
        // PK
        builder.HasKey(f => f.Id).HasName(BaseConfiguration.GetPkName<Field>(new string[] { nameof(Field.Id) }));
        // IX
        builder.HasIndex(f => new { f.Entity, f.EntityReference }).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Field>(new string[] { nameof(Field.Entity), nameof(Field.EntityReference) }, unique: true));
        // FK
        // Filters
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        // Field
        const string detailsWorksheet = "Details";
        var objects = new List<Field>()
        {
            // Line of Business
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(LineOfBusiness)}_{nameof(LineOfBusiness.Name)}",
                EntityReference = nameof(Revenue.LineOfBusiness),
                LabelOnFile = "Line of Business",
                WorksheetOnFile = detailsWorksheet
            },
            // Customer
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Customer)}_{nameof(Customer.Name)}",
                EntityReference = nameof(Revenue.Customer),
                LabelOnFile = "Customer",
                WorksheetOnFile = detailsWorksheet
            },
            // CustomerFunction
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(CustomerFunction)}_{nameof(CustomerFunction.Name)}",
                EntityReference = $"{nameof(Revenue.Customer)}{nameof(Customer.Function)}",
                LabelOnFile = "Customer Function (read only)",
                WorksheetOnFile = detailsWorksheet
            },
            // Project
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Project)}_{nameof(Project.Name)}",
                EntityReference = nameof(Revenue.Project),
                LabelOnFile = "Project",
                WorksheetOnFile = detailsWorksheet
            },
            // Project Type
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Project)}_{nameof(Project.Type)}",
                EntityReference = $"{nameof(Revenue.Project)}{nameof(Project.Type)}",
                LabelOnFile = "Project Type (read only)",
                WorksheetOnFile = detailsWorksheet
            },
            // Project Planning IT Apps Ids
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Project)}_{nameof(Project.PlanningItApps)}",
                EntityReference = $"{nameof(Revenue.Project)}{nameof(Project.PlanningItApps)}{nameof(PlanningItApp.Id)}",
                LabelOnFile = "Project Planning IT Apps Ids (read only)",
                WorksheetOnFile = detailsWorksheet
            },
            // Project Planning IT Apps Names
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Project)}_{nameof(Project.PlanningItApps)}",
                EntityReference = $"{nameof(Revenue.Project)}{nameof(Project.PlanningItApps)}{nameof(PlanningItApp.Name)}",
                LabelOnFile = "Project Planning IT Apps Names (read only)",
                WorksheetOnFile = detailsWorksheet
            },
            // Type of Service
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(TypeOfService)}_{nameof(TypeOfService.Name)}",
                EntityReference = nameof(Revenue.TypeOfService),
                LabelOnFile = "Type of Service",
                WorksheetOnFile = detailsWorksheet
            },
            // Service Description (Item)
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = nameof(Revenue.ServiceDescription),
                LabelOnFile = "Service Description",
                WorksheetOnFile = detailsWorksheet
            },
            // Owner/PM
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(User)}_{nameof(User.Name)}",
                EntityReference = nameof(Revenue.OwnerProjectManager),
                LabelOnFile = "Owner/PM",
                WorksheetOnFile = detailsWorksheet
            },
            // Group
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Group)}_{nameof(Group.Name)}",
                EntityReference = nameof(Revenue.GroupOwner),
                LabelOnFile = "GROUP OWNER",
                WorksheetOnFile = detailsWorksheet
            },
            // Product
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Product)}_{nameof(Product.Name)}",
                EntityReference = nameof(Revenue.Product),
                LabelOnFile = "Product",
                WorksheetOnFile = detailsWorksheet
            },
            // Testing Tool
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(TestingTool)}_{nameof(TestingTool.Name)}",
                EntityReference = nameof(Revenue.TestingTool),
                LabelOnFile = "Testing Tool",
                WorksheetOnFile = detailsWorksheet
            },
            // Testing Tool Project Name
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = nameof(Revenue.TestingToolProjectName),
                LabelOnFile = "Testing Tool (Project Name)",
                WorksheetOnFile = detailsWorksheet
            },
            // Testing Tool Detailed Info
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = nameof(Revenue.TestingToolDetailedInfo),
                LabelOnFile = "Testing Tool (Detailed Info)",
                WorksheetOnFile = detailsWorksheet
            },
            // BU Code
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(BusinessUnit)}_{nameof(BusinessUnit.Code)}",
                EntityReference = nameof(Revenue.BusinessUnit),
                LabelOnFile = "BU Code",
                WorksheetOnFile = detailsWorksheet
            },
            // CC Customer
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(CostCenter)}_{nameof(CostCenter.Code)}",
                EntityReference = nameof(Revenue.CustomerCostCenter),
                LabelOnFile = "CC Customer",
                WorksheetOnFile = detailsWorksheet
            },
            // Charging Model
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(ChargingModel)}_{nameof(ChargingModel.Code)}",
                EntityReference = nameof(Revenue.ChargingModel),
                LabelOnFile = "Charging Model",
                WorksheetOnFile = detailsWorksheet
            },
            // Internal CC per Cost
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(CostCenter)}_{nameof(CostCenter.Code)}",
                EntityReference = nameof(Revenue.InternalCostCenterPerCost),
                LabelOnFile = "Internal CC Per Cost",
                WorksheetOnFile = detailsWorksheet
            },
            // Internal Code
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = nameof(Revenue.InternalCode),
                LabelOnFile = "Internal Code (DEVOPS, CUSTOMER WO, CODE, ETC)",
                WorksheetOnFile = detailsWorksheet
            },
            // Currency
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = $"{nameof(MasterData).ToLowerInvariant()}={typeof(string).Name};{nameof(Currency)}_{nameof(Currency.Code)}",
                EntityReference = nameof(Revenue.Currency),
                LabelOnFile = "Currency",
                WorksheetOnFile = detailsWorksheet
            },
            // Year
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = typeof(int).Name,
                EntityReference = nameof(Revenue.Year),
                LabelOnFile = "Year",
                WorksheetOnFile = detailsWorksheet
            },
            // PlannedStartDate
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = "Date",
                EntityReference = nameof(Revenue.PlannedStartDate),
                LabelOnFile = $"Planned Start Date ({NewtonsoftDateFormatConverter.Format})",
                WorksheetOnFile = detailsWorksheet
            },
            // PlannedEndDate
            new Field()
            {
                Entity = nameof(Revenue),
                Required = true,
                Type = "Date",
                EntityReference = nameof(Revenue.PlannedEndDate),
                LabelOnFile = $"Planned End Date ({NewtonsoftDateFormatConverter.Format})",
                WorksheetOnFile = detailsWorksheet
            },
            // Plan
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(decimal).Name,
                EntityReference= nameof(Revenue.PlanLC),
                LabelOnFile = "Plan",
                WorksheetOnFile= detailsWorksheet
            },
            // Transfer
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(decimal).Name,
                EntityReference= nameof(Revenue.TransferLC),
                LabelOnFile = "Transfer",
                WorksheetOnFile= detailsWorksheet
            },
            // Comments
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = nameof(Revenue.Comments),
                LabelOnFile = "Comments",
                WorksheetOnFile = detailsWorksheet
            },
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = $"{nameof(Revenue.Comments)}{nameof(Revenue.Comments)}",
                LabelOnFile = "Automatic Comments",
                WorksheetOnFile = detailsWorksheet
            },
            new Field()
            {
                Entity = nameof(Revenue),
                Required = false,
                Type = typeof(string).Name,
                EntityReference = $"_{nameof(Revenue.Comments)}",
                LabelOnFile = "New Comment",
                WorksheetOnFile = detailsWorksheet
            }
        };

        foreach (var m in Revenue.GetMonths())
        {
            var nestedObjects = new List<Field>()
            {
                new Field()
                {
                    Entity = nameof(Revenue),
                    Required = false,
                    Type = typeof(decimal).Name,
                    EntityReference = $"{m}.{nameof(MonthRevenue.Amount)}",
                    LabelOnFile = Revenue.GetShortMonthName(Enum.Parse<Month>(m.ToString(), true)),
                    WorksheetOnFile = detailsWorksheet
                }
            };

            objects.AddRange(nestedObjects);
        }

        var dbItems = await dbContext.Fields.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        foreach (var @object in objects)
        {
            var dbItem = dbItems.FirstOrDefault(f => f.Entity.EqualsICIC(@object.Entity) && f.EntityReference.EqualsICIC(@object.EntityReference));
            if (dbItem == null) dbContext.Fields.Add(@object);
            else if (!Equals(dbItem, @object))
            {
                var ps = @object.GetType().GetProperties();
                foreach (var p in dbItem.GetType().GetProperties().Where(x => !x.Name.Equals(nameof(Entity<int>.Id)))) p.SetValue(dbItem, ps.Single(x => x.Name.Equals(p.Name)).GetValue(@object));
            }
        }

        await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
        if ((await dbContext.Fields.CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count) throw new DbUpdateException($"Failed to seed \"{nameof(Field)}\".");
    }

    #endregion
}
