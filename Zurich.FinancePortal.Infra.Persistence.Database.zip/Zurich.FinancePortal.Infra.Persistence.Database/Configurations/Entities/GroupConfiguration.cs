﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;

internal sealed class GroupConfiguration : IEntityTypeConfiguration<Group>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<Group> builder)
    {
        var groupId = $"{nameof(Group)}{nameof(Group.Id)}";
        // Schema - Table
        builder.ToTable(nameof(Group), BaseConfiguration.EntitySchema);
        // Properties
        builder.Property(r => r.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(r => r.Name).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        // PK
        builder.HasKey(r => r.Id).HasName(BaseConfiguration.GetPkName<Group>(new string[] { nameof(Group.Id) }));
        // IX
        builder.HasIndex(r => r.Name).IsUnique().HasDatabaseName(BaseConfiguration.GetIxName<Group>(new string[] { nameof(Group.Name) }, unique: true));
        // FK
        var userId = $"{nameof(User)}{nameof(User.Id)}";
        var userGroup = $"{nameof(User)}{nameof(Group)}";
        builder
            .HasMany(x => x.Users)
            .WithMany(x => x.Groups)
            .UsingEntity<Dictionary<string, object>>(
                userGroup,
                ur => ur.HasOne<User>().WithMany().HasForeignKey(userId).HasConstraintName(BaseConfiguration.GetFkName<User>(userGroup, new string[] { userId })),
                ur => ur.HasOne<Group>().WithMany().HasForeignKey(groupId).HasConstraintName(BaseConfiguration.GetFkName<Group>(userGroup, new string[] { groupId })),
                ur =>
                {
                    ur.ToTable(userGroup, BaseConfiguration.RelationSchema);
                    ur.HasKey(userId, groupId).HasName(BaseConfiguration.GetPkName(userGroup, new string[] { userId, groupId }));
                }
            );
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal static Type[] GetDependantTypes() => new Type[]
    {
        typeof(UserConfiguration)
    };

    #endregion
}
