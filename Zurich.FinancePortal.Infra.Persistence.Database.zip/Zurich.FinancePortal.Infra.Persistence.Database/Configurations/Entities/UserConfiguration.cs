﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using DevOps.CrossCutting;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

internal sealed class UserGridPreferencesConfiguration : IEntityTypeConfiguration<UserGridPreferences>
{
    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<UserGridPreferences> builder)
    {
        var userId = $"{nameof(User)}{nameof(User.Id)}";
        // Schema - Table
        builder.ToTable(nameof(UserGridPreferences), BaseConfiguration.ValueObjectSchema);
        // Properties
        builder.Property<int>(userId).IsRequired().ValueGeneratedOnAdd();
        // PK
        builder.HasKey(userId).HasName(BaseConfiguration.GetPkName<UserGridPreferences>(new string[] { userId }));
        // IX
        // FK
        builder.HasOne(typeof(User)).WithOne(nameof(User.GridPreferences)).HasForeignKey(typeof(UserGridPreferences), userId).HasPrincipalKey(typeof(User), nameof(User.Id)).HasConstraintName(BaseConfiguration.GetFkName<User, UserGridPreferences>(new string[] { userId })).IsRequired();
    }

    #endregion
}

internal sealed class UserConfiguration : IEntityTypeConfiguration<User>
{
    #region --- PROPERTIES ---

    internal const string LastSeenReleaseNotes = "LastSeenReleaseNotes";

    #endregion

    #region --- PUBLIC METHODS ---

    public void Configure(EntityTypeBuilder<User> builder)
    {
        // Schema - Table
        builder.ToTable(nameof(User), BaseConfiguration.AuthorizationSchema);
        // Properties
        builder.Property(u => u.Id).UseIdentityAlwaysColumn().IsRequired().ValueGeneratedOnAdd();
        builder.Property(u => u.Name).HasField($"_{nameof(User.Name).ToLowerInvariant()}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
        builder.Property(u => u.IsDeleted).IsRequired();
        builder.OwnsOne(u => u.AdAccount, uad =>
        {
            // Properties
            uad.Property(ad => ad.SAMAccountName).HasField($"_{nameof(AdAccount.SAMAccountName)[..1].ToLowerInvariant()}{nameof(AdAccount.SAMAccountName)[1..]}").IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255).HasColumnName(nameof(AdAccount.SAMAccountName));
            // IX
            uad.HasIndex(ad => ad.SAMAccountName).HasDatabaseName(BaseConfiguration.GetIxName<User>(new string[] { nameof(User.AdAccount.SAMAccountName) }, unique: true)).IsUnique();
        });

        builder.Property<string>(LastSeenReleaseNotes).HasMaxLength(BaseConfiguration.Nvarchar_50);
        // PK
        builder.HasKey(u => u.Id).HasName(BaseConfiguration.GetPkName<User>(new string[] { nameof(User.Id) }));
        // IX
        // FK
        var userRole = $"{nameof(User)}{nameof(Role)}";
        var roleId = $"{nameof(Role)}{nameof(Role.Id)}";
        var userId = $"{nameof(User)}{nameof(User.Id)}";
        builder
            .HasMany(u => u.Roles)
            .WithMany(r => r.Users)
            .UsingEntity<Dictionary<string, object>>(
                userRole,
                ur => ur.HasOne<Role>().WithMany().HasForeignKey(roleId).HasConstraintName(BaseConfiguration.GetFkName<Role>(userRole, new string[] { roleId })),
                ur => ur.HasOne<User>().WithMany().HasForeignKey(userId).HasConstraintName(BaseConfiguration.GetFkName<User>(userRole, new string[] { userId })),
                ur =>
                {
                    ur.ToTable(userRole, BaseConfiguration.RelationSchema);
                    ur.HasKey(userId, roleId).HasName(BaseConfiguration.GetPkName(userRole, new string[] { userId, roleId }));
                }
            );

        var groupId = $"{nameof(Group)}{nameof(Group.Id)}";
        var userGroup = $"{nameof(User)}{nameof(Group)}";
        builder
            .HasMany(x => x.Groups)
            .WithMany(x => x.Users)
            .UsingEntity<Dictionary<string, object>>(
                userGroup,
                ur => ur.HasOne<Group>().WithMany().HasForeignKey(groupId).HasConstraintName(BaseConfiguration.GetFkName<Group>(userGroup, new string[] { groupId })),
                ur => ur.HasOne<User>().WithMany().HasForeignKey(userId).HasConstraintName(BaseConfiguration.GetFkName<User>(userGroup, new string[] { userId })),
                ur =>
                {
                    ur.ToTable(userGroup, BaseConfiguration.RelationSchema);
                    ur.HasKey(userId, groupId).HasName(BaseConfiguration.GetPkName(userGroup, new string[] { userId, groupId }));
                }
            );

        builder.HasOne(u => u.GridPreferences).WithOne().HasForeignKey(typeof(UserGridPreferences), userId).HasPrincipalKey(typeof(User), nameof(User.Id)).HasConstraintName(BaseConfiguration.GetFkName<User, UserGridPreferences>(new string[] { userId })).IsRequired();
    }

    #endregion

    #region --- INTERNAL METHODS ---

    internal async static Task<IList<(SeedMode[] SeedModes, User User)>> GetSeedData(SeedMode seedMode, ApplicationDbContext dbContext, CancellationToken cancellationToken = default)
    {
        var roles = await dbContext.Roles.ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
        return new List<(SeedMode[], User)>()
        {
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new User("Javier Marin", new AdAccount("JAVIER.MARIN"), roles: roles.Where(r => r.Name.EqualsICIC(Role.SuperAdminName)))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new User("Sandra Cervantes", new AdAccount("SANDRA.CERVANTES4"), roles: roles.Where(r => r.Name.EqualsICIC(Role.SuperAdminName)))),
            (new SeedMode[]{ SeedMode.UnitTesting, SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new User("Jorge Jimenez", new AdAccount("JORGE.JIMENEZ2"), roles: roles.Where(r => r.Name.EqualsICIC(Role.SuperAdminName)))),
            (new SeedMode[]{ SeedMode.Development, SeedMode.Staging, SeedMode.Production }, new User("Raul Alares", new AdAccount("RAUL.ALARES"), roles: roles.Where(r => !seedMode.Equals(SeedMode.Production) || !r.Name.EqualsICIC(Role.SuperAdminName)))),
            (new SeedMode[]{ SeedMode.Development, SeedMode.Staging }, new User("Lucas Muela Valenzuela", new AdAccount("L.MUELAVALENZUELA"), roles: roles.Where(r => r.Name.EqualsICIC(Role.AdminName))))
        };
    }

    internal async static Task SeedDatabase(ApplicationDbContext dbContext, SeedMode seedMode = SeedMode.Production, CancellationToken cancellationToken = default)
    {
        Guard.Argument(dbContext, nameof(dbContext)).IsNotNull();
        var objects = (await GetSeedData(seedMode, dbContext, cancellationToken: cancellationToken).ConfigureAwait(false)).Where(sd => sd.SeedModes.Any(sm => sm.Equals(seedMode)));
        if (objects.Any())
        {
            var dbItems = await dbContext.Set<User>().ToArrayAsync(cancellationToken: cancellationToken).ConfigureAwait(false);
            foreach (var (_, @object) in objects)
            {
                var dbItem = dbItems.FirstOrDefault(u => u.AdAccount.SAMAccountName.EqualsICIC(@object.AdAccount.SAMAccountName));
                if (dbItem == null) dbContext.Add(@object);
            }

            await dbContext.SaveChangesAsync(changeTracking: false, cancellationToken: cancellationToken).ConfigureAwait(false);
            if ((await dbContext.Set<User>().CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false)) < objects.Count()) throw new DbUpdateException($"Failed to seed \"{nameof(User)}\".");
        }
    }

    #endregion
}
