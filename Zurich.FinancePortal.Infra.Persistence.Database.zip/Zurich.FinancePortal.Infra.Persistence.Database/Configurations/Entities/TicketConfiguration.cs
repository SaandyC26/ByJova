﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Domain;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System;

    internal sealed class TicketConfiguration : IEntityTypeConfiguration<Ticket>
    {
        #region --- PROPERTIES ---

        private static string UserId => $"{nameof(User)}{nameof(User.Id)}";

        private static string TicketId => $"{nameof(Ticket)}{nameof(Ticket.Id)}";

        #endregion

        #region --- PUBLIC METHODS ---

        public void Configure(EntityTypeBuilder<Ticket> builder)
        {
            // Schema - Table
            builder.ToTable(nameof(Ticket), BaseConfiguration.EntitySchema);
            // Properties
            builder.Property(x => x.Id).IsRequired().ValueGeneratedNever();
            builder.Property(x => x.Summary).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(x => x.Description).IsRequired();
            builder.Property(x => x.Reference).HasMaxLength(BaseConfiguration.Nvarchar_255);
            builder.Property(x => x.Type).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50).HasConversion(x => x.ToString(), x => Enum.Parse<TicketType>(x, true));
            builder.Property(x => x.Status).IsRequired().HasMaxLength(BaseConfiguration.Nvarchar_50).HasConversion(x => x.ToString(), x => Enum.Parse<TicketStatus>(x, true));
            builder.Property(x => x.Notifications).IsRequired();
            builder.Property(x => x.Created).IsRequired();
            builder.Property(x => x.Updated).IsRequired();
            // PK
            builder.HasKey(x => x.Id).HasName(BaseConfiguration.GetPkName<Ticket>(new string[] { nameof(Ticket.Id) }));
            // IX
            // FK
            builder.HasOne(x => x.User).WithMany().IsRequired().HasPrincipalKey(x => x.Id).HasForeignKey(UserId).HasConstraintName(BaseConfiguration.GetFkName<Ticket, User>(new string[] { UserId })).OnDelete(DeleteBehavior.Restrict);
            var commentsField = $"_{nameof(Ticket.Comments).ToLowerInvariant()}";
            builder.Metadata.FindNavigation(nameof(Ticket.Comments)).SetField(commentsField);
            builder.HasMany(r => r.Comments).WithOne().HasForeignKey(TicketId).HasPrincipalKey(x => x.Id).OnDelete(DeleteBehavior.Cascade).HasConstraintName(BaseConfiguration.GetFkName<Ticket, TicketComment>(new string[] { TicketId }));
        }

        #endregion
    }
}
