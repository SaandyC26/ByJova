﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using AutoMapper;
using Domain;

public sealed class BusinessUnitAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public BusinessUnitAutoMapper()
    {
        // Entity -> Dto
        CreateMap<BusinessUnit, BusinessUnitDto>();
    }

    #endregion
}

public sealed class ChargingModelTypeAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ChargingModelTypeAutoMapper()
    {
        // Entity -> Dto
        CreateMap<ChargingModelType, ChargingModelTypeDto>();
    }

    #endregion
}

public sealed class ChargingModelAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ChargingModelAutoMapper()
    {
        // Entity -> Dto
        CreateMap<ChargingModel, ChargingModelDto>();
    }

    #endregion
}

public sealed class CostCenterAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public CostCenterAutoMapper()
    {
        // Entity -> Dto
        CreateMap<CostCenter, CostCenterDto>();
    }

    #endregion
}

public sealed class CurrencyAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public CurrencyAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Currency, CurrencyDto>();
    }

    #endregion
}

public sealed class TestingToolAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public TestingToolAutoMapper()
    {
        // Entity -> Dto
        CreateMap<TestingTool, TestingToolDto>();
    }

    #endregion
}

public sealed class CurrencyExchangeRateAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public CurrencyExchangeRateAutoMapper()
    {
        // Entity -> Dto
        CreateMap<CurrencyExchangeRate, CurrencyExchangeRateDto>()
            .ForMember(cer => cer.Month, opt => opt.MapFrom(x => x.Month.ToString()));
    }

    #endregion
}

public sealed class CustomerAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public CustomerAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Customer, CustomerDto>();
    }

    #endregion
}

public sealed class FunctionAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public FunctionAutoMapper()
    {
        // Entity -> Dto
        CreateMap<CustomerFunction, CustomerFunctionDto>();
    }

    #endregion
}

public sealed class LineOfBusinessAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public LineOfBusinessAutoMapper()
    {
        // Entity -> Dto
        CreateMap<LineOfBusiness, LineOfBusinessDto>();
    }

    #endregion
}

public sealed class ProductAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ProductAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Product, ProductDto>();
    }

    #endregion
}

public sealed class ProjectAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ProjectAutoMapper()
    {
        // Entity -> Dto
        CreateMap<Project, ProjectDto>();
    }

    #endregion
}

public sealed class PlanningItAppAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public PlanningItAppAutoMapper()
    {
        // Entity -> Dto
        CreateMap<PlanningItApp, PlanningItAppDto>();
    }

    #endregion
}

public sealed class TypeOfServiceAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public TypeOfServiceAutoMapper()
    {
        // Entity -> Dto
        CreateMap<TypeOfService, TypeOfServiceDto>();
    }

    #endregion
}

public sealed class ValueAddedTaxAutoMapper : Profile
{
    #region --- CONSTRUCTORS ---

    public ValueAddedTaxAutoMapper()
    {
        // Entity -> Dto
        CreateMap<ValueAddedTax, ValueAddedTaxDto>();
    }

    #endregion
}
