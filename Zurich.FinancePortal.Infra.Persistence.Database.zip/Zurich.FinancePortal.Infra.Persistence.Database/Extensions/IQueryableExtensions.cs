﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Dynamic.Core;
    using DevOps.CrossCutting;
    using System.Threading.Tasks;
    using System.Threading;

    public static class IQueryableExtensions
    {
        #region --- PUBLIC METHODS ---

        public static IQueryable<object> Set(this DbContext dbContext, Type type, IEnumerable<string> includeNavigationPropertyPaths = default, bool asNoTracking = false)
        {
            // Queryable
            var queryable = (IQueryable<object>)dbContext.GetType().GetMethod(nameof(DbContext.Set)).MakeGenericMethod(type).Invoke(dbContext, null);
            // Include
            if (includeNavigationPropertyPaths != null) foreach (var includeNavigationPropertyPath in includeNavigationPropertyPaths) queryable = queryable.Include(includeNavigationPropertyPath);
            // AsNoTracking
            if (asNoTracking) queryable = queryable.AsNoTracking();
            // Result
            return queryable;
        }

        public static IQueryable<T> Set<T>(this DbContext dbContext, IEnumerable<string> includeNavigationPropertyPaths = default, bool asNoTracking = false) where T : class
        {
            // Queryable
            var queryable = dbContext.Set<T>().AsQueryable();
            // Include
            if (includeNavigationPropertyPaths != null) foreach (var includeNavigationPropertyPath in includeNavigationPropertyPaths) queryable = queryable.Include(includeNavigationPropertyPath);
            // AsNoTracking
            if (asNoTracking) queryable = queryable.AsNoTracking();
            // Result
            return queryable;
        }

        internal async static Task<(int Count, IQueryable<T> Result)> HandleDataSourceRequestAsync<T>(this IQueryable<T> iqueryable, DataSourceRequest dataSourceRequest, bool countAsync = true, CancellationToken cancellationToken = default)
        {
            // Filter
            var result = iqueryable.HandleQueryFilters(dataSourceRequest);
            // Order By
            result = result.HandleQueryOrderBy(dataSourceRequest);
            // Count
            var count = countAsync ? await result.CountAsync(cancellationToken: cancellationToken).ConfigureAwait(false) : result.Count();
            // Take / Skipe
            result = result.HandleTakeSkip(dataSourceRequest);
            // Result
            return (count, result);
        }

        internal static IQueryable<T> HandleQueryFilters<T>(this IQueryable<T> iqueryable, DataSourceRequest dataSourceRequest)
        {
            if (dataSourceRequest == null || dataSourceRequest.Filter == null) return iqueryable;
            if (dataSourceRequest.Filter != null && dataSourceRequest.Filter.Logic != FilterLogic.@null)
            {
                var filters = dataSourceRequest.Filter.All();
                var values = filters.Select(f => new FilterOperator[] { FilterOperator.contains, FilterOperator.doesnotcontain, FilterOperator.startswith, FilterOperator.endswith }.Contains(f.Operator) ? f.Value.ToString().ToUpper() : f.Value).ToArray();
                var predicate = dataSourceRequest.Filter.ToExpression(filters);
                if (!string.IsNullOrWhiteSpace(predicate)) iqueryable = iqueryable.Where(predicate, values);
            }

            return iqueryable;
        }

        internal static IQueryable<T> HandleQueryOrderBy<T>(this IQueryable<T> iqueryable, DataSourceRequest dataSourceRequest)
        {
            if (dataSourceRequest == null || dataSourceRequest.Sort == null || !dataSourceRequest.Sort.Any()) return iqueryable;
            return iqueryable.OrderBy(string.Join(", ", dataSourceRequest.Sort.Select(s => s.ToExpression())));
        }

        #endregion

        #region --- PRIVATE METHODS ---

        private static IQueryable<T> HandleTakeSkip<T>(this IQueryable<T> iqueryable, DataSourceRequest dataSourceRequest)
        {
            if (dataSourceRequest?.Skip > 0) iqueryable = iqueryable.Skip(dataSourceRequest.Skip);
            if (dataSourceRequest?.Take > 0) iqueryable = iqueryable.Take(dataSourceRequest.Take);
            return iqueryable;
        }

        #endregion
    }
}
