﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using DevOps.CrossCutting;
    using Domain;
    using System.Collections.Generic;

    public abstract class BaseFinancialManagementModel
    {
        #region --- PROPERTIES ---

        public int Year { get; set; }

        public string CurrencyCode { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        protected BaseFinancialManagementModel() { }

        #endregion

        #region --- INTERNAL METHODS ---

        internal decimal? GetMonthFYFCLC(Month month, string toCurrencyCode, IEnumerable<CurrencyExchangeRate> currencyExchangeRates)
        {
            var amount = GetType().GetProperty($"{month}{nameof(MonthRevenue.Amount)}").GetValue(this) as decimal?;
            if (!amount.HasValue) return null;
            if (CurrencyCode.EqualsICIC(toCurrencyCode)) return amount;
            // Get CurrencyExchangeRate
            var rate = RevenueService.GetCurrencyExchangeRate(Year, month, CurrencyCode, toCurrencyCode, currencyExchangeRates);
            // Calculate
            if (rate != null) amount *= rate;
            // Result
            return RevenueService.Round(amount);
        }

        #endregion
    }
}
