﻿namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Domain;
using System;
using System.Collections.Generic;

public sealed class RevenueModel : BaseFinancialManagementModel
{
    #region --- PROPERTIES ---

    public long Id { get; set; }

    public string LineOfBusinessName { get; set; }

    public string CustomerName { get; set; }

    public string ProjectName { get; set; }

    public string ProjectType { get; set; }

    public string ProjectPlanningItAppsIds { get; set; }

    public string ProjectPlanningItAppsNames { get; set; }

    public string TypeOfServiceName { get; set; }

    public string ServiceDescription { get; set; }

    public string OwnerProjectManagerName { get; set; }

    public string GroupOwnerName { get; set; }

    public string BusinessUnitCode { get; set; }

    public string CustomerCostCenterCode { get; set; }

    public string ChargingModelCode { get; set; }

    public string ChargingModelType { get; set; }

    public string InternalCostCenterPerCostCode { get; set; }

    public string InternalCode { get; set; }

    public string ProductName { get; set; }

    public string CustomerFunctionName { get; set; }

    public string TestingToolName { get; set; }

    public string TestingToolProjectName { get; set; }

    public string TestingToolDetailedInfo { get; set; }

    public decimal? FYFCLC { get; set; }

    public decimal? FYFCCHF { get; set; }

    public decimal? FYFCCHFVAT { get; set; }

    public decimal? PlanLC { get; set; }

    public decimal? TransferLC { get; set; }

    public decimal? DifferenceLC { get; set; }

    private DateTime _plannedStartDate;
    public DateTime PlannedStartDate
    {
        get => _plannedStartDate;
        set => _plannedStartDate = new DateTime(value.Year, value.Month, value.Day, 0, 0, 0, DateTimeKind.Utc);
    }

    private DateTime _plannedEndDate;
    public DateTime PlannedEndDate
    {
        get => _plannedEndDate;
        set => _plannedEndDate = new DateTime(value.Year, value.Month, value.Day, 23, 59, 59, DateTimeKind.Utc);
    }

    public decimal? JanuaryAmount { get; set; }

    public decimal? FebruaryAmount { get; set; }

    public decimal? MarchAmount { get; set; }

    public decimal? AprilAmount { get; set; }

    public decimal? MayAmount { get; set; }

    public decimal? JuneAmount { get; set; }

    public decimal? JulyAmount { get; set; }

    public decimal? AugustAmount { get; set; }

    public decimal? SeptemberAmount { get; set; }

    public decimal? OctoberAmount { get; set; }

    public decimal? NovemberAmount { get; set; }

    public decimal? DecemberAmount { get; set; }

    #endregion

    #region --- REFERENCES ---

    // Comments
    public IEnumerable<RevenueComment> Comments { get; set; }

    #endregion
}
