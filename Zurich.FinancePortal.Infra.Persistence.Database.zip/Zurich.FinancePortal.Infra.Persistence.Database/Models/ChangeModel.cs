﻿namespace Zurich.FinancePortal.Infra.Persistence.Database
{
    using Microsoft.EntityFrameworkCore;
    using System;

    internal sealed class PropertyChange
    {
        #region --- PROPERTIES ---

        internal string PropertyName { get; set; }

        internal string OldValue { get; set; }

        internal string CurrentValue { get; set; }

        #endregion

        #region --- CONSTRUCTORS ---

        internal PropertyChange(string propertyName, string oldValue, string currentValue)
        {
            PropertyName = propertyName;
            OldValue = oldValue;
            CurrentValue = currentValue;
        }

        #endregion
    }

    internal abstract class Change
    { }

    internal sealed class ChangeModel : Change
    {
        #region --- PROPERTIES ---

        internal Guid Id { get; set; } = Guid.NewGuid();

        internal DateTime DateTime { get; set; }

        internal EntityState State { get; set; }

        internal string EntityId { get; set; }

        internal string EntityType { get; set; }

        internal string Username { get; set; }

        internal string RequestId { get; set; }

        internal string Changes { get; set; }

        #endregion
    }
}
