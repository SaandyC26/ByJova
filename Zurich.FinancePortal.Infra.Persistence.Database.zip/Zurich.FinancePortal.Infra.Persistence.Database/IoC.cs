﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Zurich.FinancePortal.Infra.Persistence.Database.Test")]
[assembly: InternalsVisibleTo("Zurich.FinancePortal.Application.Test")]
namespace Zurich.FinancePortal.Infra.Persistence.Database;

using Application;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public static class IoC
{
    #region --- PUBLIC METHODS ---

    public static IServiceCollection AddPersistenceDatabase(this IServiceCollection services, IConfiguration persistenceConfiguration, SqliteConnection sqliteConnection = null)
    {
        // Configuration
        services.Configure<PersistenceConfiguration>(persistenceConfiguration);
        var configuration = persistenceConfiguration.Get<PersistenceConfiguration>();
        // MemoryCache
        services.AddMemoryCache(x =>
        {
            x.SizeLimit = configuration.MemoryCacheSizeLimit;
        });
        // AutoMapper
        services.AddAutoMapper(typeof(IoC), typeof(Application.IoC));
        // Add SQLite
        if (sqliteConnection != null)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
            {
                options.UseSqlite(sqliteConnection);
            });
            // Ensure Created
            using var dbContext = services.BuildServiceProvider().GetService<ApplicationDbContext>();
            dbContext.Database.EnsureDeleted();
            dbContext.Database.EnsureCreated();
        }
        // Add PostgreSQL
        else
        {
            services.AddDbContext<ApplicationDbContext>(options =>
            {
                options.UseNpgsql(configuration.ConnectionString);
                options.ConfigureWarnings(x =>
                {
                    x.Ignore(RelationalEventId.MultipleCollectionIncludeWarning);
                    x.Ignore(CoreEventId.RowLimitingOperationWithoutOrderByWarning);
                });
            });
        }
        // DbContext
        services
            .AddScoped<IApplicationDbContext>(s => s.GetRequiredService<ApplicationDbContext>());
        // Repositories
        services
            .AddTransient<IApplicationConfigurationRepository, ApplicationConfigurationRepository>(s => new ApplicationConfigurationRepository(s))
            .AddTransient<IFieldRepository, FieldRepository>(s => new FieldRepository(s))
            .AddTransient<IMasterDataRepository, MasterDataRepository>(s => new MasterDataRepository(s))
            .AddTransient(s => new MasterDataRepository(s))
            .AddTransient<IMasterDataFrontEndRepository, MasterDataFrontEndRepository>(s => new MasterDataFrontEndRepository(s))
            .AddTransient<IRevenueRepository, RevenueRepository>(s => new RevenueRepository(s))
            .AddTransient(s => new RevenueRepository(s))
            .AddTransient<IRevenueFrontEndRepository, RevenueFrontEndRepository>(s => new RevenueFrontEndRepository(s))
            .AddTransient<IPrivateRevenueFrontEndRepository, RevenueFrontEndRepository>(s => new RevenueFrontEndRepository(s))
            .AddTransient<IRevenueODataRepository, RevenueODataRepository>(s => new RevenueODataRepository(s))
            .AddTransient<IRoleRepository, RoleRepository>(s => new RoleRepository(s))
            .AddTransient<ITicketRepository, TicketRepository>(s => new TicketRepository(s))
            .AddTransient<IUserRepository, UserRepository>(s => new UserRepository(s))
            .AddTransient<IGroupRepository, GroupRepository>(s => new GroupRepository(s));
        // Return services
        return services;
    }

    #endregion
}
