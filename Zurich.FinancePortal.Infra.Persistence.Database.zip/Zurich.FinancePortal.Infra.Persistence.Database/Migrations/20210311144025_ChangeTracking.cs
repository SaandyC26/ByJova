﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;
    using System;

    public partial class ChangeTracking : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Uuid-ossp
            migrationBuilder.Sql($"CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\" SCHEMA \"public\";");

            migrationBuilder.CreateTable(
                name: "Change",
                schema: "val",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    DateTime = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    State = table.Column<string>(type: "text", nullable: false),
                    EntityId = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    EntityType = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    Username = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    RequestId = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                    Changes = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Change_Id", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Uuid-ossp
            migrationBuilder.Sql($"DROP EXTENSION IF EXISTS \"uuid-ossp\";");

            migrationBuilder.DropTable(
                name: "Change",
                schema: "val");
        }
    }
}
