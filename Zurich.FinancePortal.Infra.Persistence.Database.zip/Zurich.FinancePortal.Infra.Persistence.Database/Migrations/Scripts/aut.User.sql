﻿ALTER TABLE "aut"."User" ALTER COLUMN "SAMAccountName" SET NOT NULL;
--Sqlite--