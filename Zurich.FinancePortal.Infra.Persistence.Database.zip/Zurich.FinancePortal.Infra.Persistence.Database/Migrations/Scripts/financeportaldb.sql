﻿--ALTER COLLATION "public"."case_insensitive" REFRESH VERSION
--Sqlite--