﻿DROP VIEW IF EXISTS "ent"."RevenueOData";
CREATE VIEW "ent"."RevenueOData"
	AS
		SELECT
			R.*,
			LoB."Name" AS "LineOfBusinessName",
			C."Name" AS "CustomerName",
			P."Name" AS "ProjectName",
			P."Type" AS "ProjectType",
			ToS."Name" AS "TypeOfServiceName",
			U."Name" AS "OwnerProjectManagerName",
			BU."Code" AS "BusinessUnitCode",
			CC1."Code" AS "CustomerCostCenterCode",
			CM."Code" AS "ChargingModelCode",
			CMT."Type" AS "ChargingModelType",
			CC2."Code" AS "InternalCostCenterPerCostCode",
			CURR."Code" AS "CurrencyCode",
			PR."Name" AS "ProductName",
			TT."Name" AS "TestingToolName",
			CF."Name" AS "CustomerFunctionName",
			G."Name" AS "GroupOwnerName",
			(SELECT STRING_AGG(CONCAT("Prefix", '-', "Id"), ', ') FROM "val"."ProjectPlanningItApp" PPIA WHERE PPIA."ProjectId" = P."Id") AS "ProjectPlanningItAppsIds",
			(SELECT STRING_AGG("Name", ', ') FROM "val"."ProjectPlanningItApp" PPIA WHERE PPIA."ProjectId" = P."Id") AS "ProjectPlanningItAppsNames"
		FROM
			"ent"."Revenue" R
		LEFT JOIN 
			"mdt"."LineOfBusiness" LoB ON LoB."Id" = R."LineOfBusinessId"
		LEFT JOIN
			"mdt"."Customer" C ON C."Id" = R."CustomerId"
		LEFT JOIN
			"mdt"."Project" P ON P."Id" = R."ProjectId"
		LEFT JOIN
			"mdt"."TypeOfService" ToS ON ToS."Id" = R."TypeOfServiceId"
		LEFT JOIN
			"aut"."User" U ON U."Id" = R."OwnerProjectManagerId"
		LEFT JOIN
			"mdt"."BusinessUnit" BU ON BU."Id" = R."BusinessUnitId"
		LEFT JOIN
			"mdt"."CostCenter" CC1 ON CC1."Id" = R."CustomerCostCenterId"
		LEFT JOIN
			"mdt"."ChargingModel" CM ON CM."Id" = R."ChargingModelId"
		LEFT JOIN
			"mdt"."ChargingModelType" CMT ON CMT."Id" = CM."ChargingModelTypeId"
		LEFT JOIN
			"mdt"."CostCenter" CC2 ON CC2."Id" = R."InternalCostCenterPerCostId"
		LEFT JOIN
			"mdt"."Currency" CURR ON CURR."Id" = R."CurrencyId"
		LEFT JOIN
			"mdt"."Product" PR ON PR."Id" = R."ProductId"
		LEFT JOIN
			"mdt"."TestingTool" TT ON TT."Id" = R."TestingToolId"
		LEFT JOIN
			"mdt"."CustomerFunction" CF ON CF."Id" = C."FunctionId"
		LEFT JOIN
			ent."Group" G ON G."Id" = R."GroupOwnerId"
--Sqlite--
CREATE VIEW [RevenueOData]
	AS
		SELECT
			[R].*,
			LoB.[Name] AS [LineOfBusinessName],
			C.[Name] AS [CustomerName],
			P.[Name] AS [ProjectName],
			P.[Type] AS [ProjectType],
			ToS.[Name] AS [TypeOfServiceName],
			U.[Name] AS [OwnerProjectManagerName],
			BU.[Code] AS [BusinessUnitCode],
			CC1.[Code] AS [CustomerCostCenterCode],
			CM.[Code] AS [ChargingModelCode],
			CMT.[Type] AS [ChargingModelType],
			CC2.[Code] AS [InternalCostCenterPerCostCode],
			CURR.[Code] AS [CurrencyCode],
			PR.[Name] AS [ProductName],
			TT.[Name] AS [TestingToolName],
			CF.[Name] AS [CustomerFunctionName],
			G.[Name] AS [GroupOwnerName],
			(SELECT GROUP_CONCAT([Prefix] || '-' || "Id", ', ') FROM [ProjectPlanningItApp] PPIA WHERE PPIA.[ProjectId] = P.[Id]) AS [ProjectPlanningItAppsIds],
			(SELECT GROUP_CONCAT([Name], ', ') FROM [ProjectPlanningItApp] PPIA WHERE PPIA.[ProjectId] = P.[Id]) AS [ProjectPlanningItAppsNames]
		FROM
			[Revenue] R
		LEFT JOIN 
			[LineOfBusiness] LoB ON LoB.[Id] = R.[LineOfBusinessId]
		LEFT JOIN
			[Customer] C ON C.[Id] = R.[CustomerId]
		LEFT JOIN
			[Project] P ON P.[Id] = R.[ProjectId]
		LEFT JOIN
			[TypeOfService] ToS ON ToS.[Id] = R.[TypeOfServiceId]
		LEFT JOIN
			[User] U ON U.[Id] = R.[OwnerProjectManagerId]
		LEFT JOIN
			[BusinessUnit] BU ON BU.[Id] = R.[BusinessUnitId]
		LEFT JOIN
			[CostCenter] CC1 ON CC1.[Id] = R.[CustomerCostCenterId]
		LEFT JOIN
			[ChargingModel] CM ON CM.[Id] = R.[ChargingModelId]
		LEFT JOIN
			[ChargingModelType] CMT ON CMT.[Id] = CM.[ChargingModelTypeId]
		LEFT JOIN
			[CostCenter] CC2 ON CC2.[Id] = R.[InternalCostCenterPerCostId]
		LEFT JOIN
			[Currency] CURR ON CURR.[Id] = R.[CurrencyId]
		LEFT JOIN
			[Product] PR ON PR.[Id] = R.[ProductId]
		LEFT JOIN
			[TestingTool] TT ON TT.[Id] = R.[TestingToolId]
		LEFT JOIN
			[CustomerFunction] CF ON CF.[Id] = C.[FunctionId]
		LEFT JOIN
			[Group] G ON G.[Id] = R.[GroupOwnerId]