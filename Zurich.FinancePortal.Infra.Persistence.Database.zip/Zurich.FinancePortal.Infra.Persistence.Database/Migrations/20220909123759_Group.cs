﻿#nullable disable

namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations;

using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

public partial class Group : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<int>(
            name: "GroupOwnerId",
            schema: "ent",
            table: "Revenue",
            type: "integer",
            nullable: true);

        migrationBuilder.CreateTable(
            name: "Group",
            schema: "ent",
            columns: table => new
            {
                Id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Group_Id", x => x.Id);
            });

        migrationBuilder.CreateTable(
            name: "UserGroup",
            schema: "rel",
            columns: table => new
            {
                UserId = table.Column<int>(type: "integer", nullable: false),
                GroupId = table.Column<int>(type: "integer", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_UserGroup_UserId_GroupId", x => new { x.UserId, x.GroupId });
                table.ForeignKey(
                    name: "FK_UserGroup_Group_GroupId",
                    column: x => x.GroupId,
                    principalSchema: "ent",
                    principalTable: "Group",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "FK_UserGroup_User_UserId",
                    column: x => x.UserId,
                    principalSchema: "aut",
                    principalTable: "User",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex(
            name: "IX_Revenue_GroupOwnerId",
            schema: "ent",
            table: "Revenue",
            column: "GroupOwnerId");

        migrationBuilder.CreateIndex(
            name: "AK_Group_Name",
            schema: "ent",
            table: "Group",
            column: "Name",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "IX_UserGroup_GroupId",
            schema: "rel",
            table: "UserGroup",
            column: "GroupId");

        migrationBuilder.AddForeignKey(
            name: "FK_Revenue_Group_GroupOwnerId",
            schema: "ent",
            table: "Revenue",
            column: "GroupOwnerId",
            principalSchema: "ent",
            principalTable: "Group",
            principalColumn: "Id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "FK_Revenue_Group_GroupOwnerId",
            schema: "ent",
            table: "Revenue");

        migrationBuilder.DropTable(
            name: "UserGroup",
            schema: "rel");

        migrationBuilder.DropTable(
            name: "Group",
            schema: "ent");

        migrationBuilder.DropIndex(
            name: "IX_Revenue_GroupOwnerId",
            schema: "ent",
            table: "Revenue");

        migrationBuilder.DropColumn(
            name: "GroupOwnerId",
            schema: "ent",
            table: "Revenue");
    }
}
