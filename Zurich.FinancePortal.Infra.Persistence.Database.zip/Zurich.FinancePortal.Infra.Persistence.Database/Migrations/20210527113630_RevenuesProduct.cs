﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Domain;
    using Microsoft.EntityFrameworkCore.Migrations;
    using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

    public partial class RevenuesProduct : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                schema: "ent",
                table: "Revenue",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Product",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product_Id", x => x.Id);
                });

            migrationBuilder.Sql($"INSERT INTO \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(Product)}\" (\"{nameof(Product.Name)}\") VALUES ('N/A');");
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.EntitySchema}\".\"{nameof(Revenue)}\" SET \"{nameof(Product)}{nameof(Product.Id)}\" = (SELECT \"{nameof(Product.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(Product)}\" WHERE \"{nameof(Product.Name)}\" = 'N/A')");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_ProductId",
                schema: "ent",
                table: "Revenue",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "AK_Product_Name",
                schema: "mdt",
                table: "Product",
                column: "Name",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Revenue_Product_ProductId",
                schema: "ent",
                table: "Revenue",
                column: "ProductId",
                principalSchema: "mdt",
                principalTable: "Product",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Revenue_Product_ProductId",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropTable(
                name: "Product",
                schema: "mdt");

            migrationBuilder.DropIndex(
                name: "IX_Revenue_ProductId",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "ProductId",
                schema: "ent",
                table: "Revenue");
        }
    }
}
