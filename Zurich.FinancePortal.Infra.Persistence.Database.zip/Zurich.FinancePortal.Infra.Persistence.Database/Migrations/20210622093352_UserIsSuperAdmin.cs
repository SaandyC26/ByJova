﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;

    public partial class UserIsSuperAdmin : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ReleaseNotesModel_Major_Minor_Revision",
                schema: "val",
                table: "ReleaseNotes");

            migrationBuilder.DropColumn(
                name: "IsSuperAdmin",
                schema: "aut",
                table: "User");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReleaseNotes_Major_Minor_Revision",
                schema: "val",
                table: "ReleaseNotes",
                columns: new[] { "Major", "Minor", "Revision" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ReleaseNotes_Major_Minor_Revision",
                schema: "val",
                table: "ReleaseNotes");

            migrationBuilder.AddColumn<bool>(
                name: "IsSuperAdmin",
                schema: "aut",
                table: "User",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReleaseNotesModel_Major_Minor_Revision",
                schema: "val",
                table: "ReleaseNotes",
                columns: new[] { "Major", "Minor", "Revision" });
        }
    }
}
