﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Domain;
    using Microsoft.EntityFrameworkCore.Migrations;
    using System.Text;

    public partial class MonthLock : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Revenue - Locks
            migrationBuilder.Sql($"DROP VIEW IF EXISTS \"{BaseConfiguration.EntitySchema}\".\"RevenueFrontEnd\";");
            // CurrencyExchangeRate - Month
            var sql = new StringBuilder();
            sql.Append($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(CurrencyExchangeRate)}\" ");
            sql.Append($"SET \"{nameof(CurrencyExchangeRate.Month)}\" = '{Month.None}' ");
            sql.Append($"WHERE \"{nameof(CurrencyExchangeRate.Month)}\" IS NULL;");
            migrationBuilder.Sql(sql.ToString());

            migrationBuilder.DropIndex(
                name: "AK_CurrencyExchangeRate_Year_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.DropIndex(
                name: "AK_CurrencyExchangeRate_Year_Month_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.DropColumn(
                name: "AprilLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "AugustLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "DecemberLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "FebruaryLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "JanuaryLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "JulyLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "JuneLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "MarchLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "MayLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "NovemberLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "OctoberLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "SeptemberLocked",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.AlterColumn<string>(
                name: "Month",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                type: "character varying(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "None",
                oldClrType: typeof(string),
                oldType: "character varying(10)",
                oldMaxLength: 10,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "MonthLock",
                schema: "val",
                columns: table => new
                {
                    Year = table.Column<int>(type: "integer", maxLength: 255, nullable: false),
                    Month = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonthLock_Year_Month", x => new { x.Year, x.Month });
                });

            migrationBuilder.CreateIndex(
                name: "AK_CurrencyExchangeRate_Year_Month_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                columns: new[] { "Year", "Month", "CurrencyIdFrom", "CurrencyIdTo" },
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MonthLock",
                schema: "val");

            migrationBuilder.DropIndex(
                name: "AK_CurrencyExchangeRate_Year_Month_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.AddColumn<bool>(
                name: "AprilLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "AugustLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "DecemberLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "FebruaryLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "JanuaryLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "JulyLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "JuneLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MarchLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MayLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "NovemberLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "OctoberLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "SeptemberLocked",
                schema: "ent",
                table: "Revenue",
                type: "boolean",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Month",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                type: "character varying(10)",
                maxLength: 10,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(10)",
                oldMaxLength: 10,
                oldDefaultValue: "None");

            migrationBuilder.CreateIndex(
                name: "AK_CurrencyExchangeRate_Year_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                columns: new[] { "Year", "CurrencyIdFrom", "CurrencyIdTo" },
                unique: true,
                filter: "\"Month\" IS NULL");

            migrationBuilder.CreateIndex(
                name: "AK_CurrencyExchangeRate_Year_Month_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                columns: new[] { "Year", "Month", "CurrencyIdFrom", "CurrencyIdTo" },
                unique: true,
                filter: "\"Month\" IS NOT NULL");

            // Revenue - Locks
            migrationBuilder.Sql($"DROP VIEW IF EXISTS \"{BaseConfiguration.EntitySchema}\".\"RevenueFrontEnd\";");
            // CurrencyExchangeRate - Month
            var sql = new StringBuilder();
            sql.Append($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(CurrencyExchangeRate)}\" ");
            sql.Append($"SET \"{nameof(CurrencyExchangeRate.Month)}\" = NULL ");
            sql.Append($"WHERE \"{nameof(CurrencyExchangeRate.Month)}\" = '{Month.None}';");
            migrationBuilder.Sql(sql.ToString());
        }
    }
}
