﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;

    public partial class ProjectPlanningItApp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Type",
                schema: "mdt",
                table: "Project",
                type: "character varying(10)",
                maxLength: 10,
                nullable: true,
                defaultValue: "");

            migrationBuilder.Sql("UPDATE \"mdt\".\"Project\" SET \"Type\" = 'NA'");

            migrationBuilder.AlterColumn<string>(
                name: "Type",
                schema: "mdt",
                table: "Project",
                nullable: false,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "ProjectPlanningItApp",
                schema: "val",
                columns: table => new
                {
                    Prefix = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    Id = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    ProjectId = table.Column<int>(type: "integer", nullable: false),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlanningItApp_Prefix_Id_ProjectId", x => new { x.Prefix, x.Id, x.ProjectId });
                    table.ForeignKey(
                        name: "FK_PlanningItApp_Project_Id",
                        column: x => x.ProjectId,
                        principalSchema: "mdt",
                        principalTable: "Project",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProjectPlanningItApp_ProjectId",
                schema: "val",
                table: "ProjectPlanningItApp",
                column: "ProjectId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProjectPlanningItApp",
                schema: "val");

            migrationBuilder.DropColumn(
                name: "Type",
                schema: "mdt",
                table: "Project");
        }
    }
}
