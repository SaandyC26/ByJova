﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;

    public partial class RevenueCommentUniqueId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "Id",
                schema: "val",
                table: "RevenueComment",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Id",
                schema: "val",
                table: "RevenueComment",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");
        }
    }
}
