﻿#nullable disable

namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations;

using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

public partial class CustomerFunction : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<int>(
            name: "FunctionId",
            schema: "mdt",
            table: "Customer",
            type: "integer",
            nullable: true);

        migrationBuilder.CreateTable(
            name: "CustomerFunction",
            schema: "mdt",
            columns: table => new
            {
                Id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CustomerFunction_Id", x => x.Id);
            });

        migrationBuilder.CreateIndex(
            name: "IX_Customer_FunctionId",
            schema: "mdt",
            table: "Customer",
            column: "FunctionId");

        migrationBuilder.CreateIndex(
            name: "AK_CustomerFunction_Name",
            schema: "mdt",
            table: "CustomerFunction",
            column: "Name",
            unique: true);

        migrationBuilder.AddForeignKey(
            name: "FK_Customer_CustomerFunction_FunctionId",
            schema: "mdt",
            table: "Customer",
            column: "FunctionId",
            principalSchema: "mdt",
            principalTable: "CustomerFunction",
            principalColumn: "Id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "FK_Customer_CustomerFunction_FunctionId",
            schema: "mdt",
            table: "Customer");

        migrationBuilder.DropTable(
            name: "CustomerFunction",
            schema: "mdt");

        migrationBuilder.DropIndex(
            name: "IX_Customer_FunctionId",
            schema: "mdt",
            table: "Customer");

        migrationBuilder.DropColumn(
            name: "FunctionId",
            schema: "mdt",
            table: "Customer");
    }
}
