﻿#nullable disable

namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations;

using Microsoft.EntityFrameworkCore.Migrations;

public partial class PlanTransferDifference : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<decimal>(
            name: "DifferenceLC",
            schema: "ent",
            table: "Revenue",
            type: "numeric(18,2)",
            nullable: true);

        migrationBuilder.AddColumn<decimal>(
            name: "PlanLC",
            schema: "ent",
            table: "Revenue",
            type: "numeric(18,2)",
            nullable: true);

        migrationBuilder.AddColumn<decimal>(
            name: "TransferLC",
            schema: "ent",
            table: "Revenue",
            type: "numeric(18,2)",
            nullable: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(
            name: "DifferenceLC",
            schema: "ent",
            table: "Revenue");

        migrationBuilder.DropColumn(
            name: "PlanLC",
            schema: "ent",
            table: "Revenue");

        migrationBuilder.DropColumn(
            name: "TransferLC",
            schema: "ent",
            table: "Revenue");
    }
}
