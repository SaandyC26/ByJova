﻿namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;
    using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "int");

            migrationBuilder.EnsureSchema(
                name: "mdt");

            migrationBuilder.EnsureSchema(
                name: "aut");

            migrationBuilder.EnsureSchema(
                name: "ent");

            migrationBuilder.EnsureSchema(
                name: "rel");

            migrationBuilder.EnsureSchema(
                name: "val");

            migrationBuilder.CreateTable(
                name: "ApplicationConfiguration",
                schema: "int",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationConfiguration_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BusinessUnit",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessUnit_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ChargingModel",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChargingModel_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CostCenter",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    Types = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CostCenter_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Currency",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Code = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    Symbol = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Currency_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customer",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Field",
                schema: "int",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Type = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Entity = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Required = table.Column<bool>(type: "boolean", nullable: false),
                    EntityReference = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    LabelOnFile = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    WorksheetOnFile = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Field_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LineOfBusiness",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Icon = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LineOfBusiness_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Permission",
                schema: "aut",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Description = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Permission_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Project",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                schema: "aut",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    Description = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    IsSuperAdmin = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TypeOfService",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TypeOfService_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "User",
                schema: "aut",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    IsSuperAdmin = table.Column<bool>(type: "boolean", nullable: false),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false),
                    SAMAccountName = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ValueAddedTax",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Country = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    PercentageAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ValueAddedTax_Id", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CurrencyExchangeRate",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Rate = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    Year = table.Column<int>(type: "integer", nullable: false),
                    Month = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: true),
                    CurrencyIdFrom = table.Column<int>(type: "integer", nullable: false),
                    CurrencyIdTo = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CurrencyExchangeRate_Id", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CurrencyExchangeRate_Currency_CurrencyIdFrom",
                        column: x => x.CurrencyIdFrom,
                        principalSchema: "mdt",
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CurrencyExchangeRate_Currency_CurrencyIdTo",
                        column: x => x.CurrencyIdTo,
                        principalSchema: "mdt",
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RolePermission",
                schema: "rel",
                columns: table => new
                {
                    RoleId = table.Column<int>(type: "integer", nullable: false),
                    PermissionId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RolePermission_RoleId_PermissionId", x => new { x.RoleId, x.PermissionId });
                    table.ForeignKey(
                        name: "FK_RolePermission_Permission_PermissionId",
                        column: x => x.PermissionId,
                        principalSchema: "aut",
                        principalTable: "Permission",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RolePermission_Role_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "aut",
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserGridPreferences",
                schema: "val",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    Revenues = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserGridPreferences_UserId", x => x.UserId);
                    table.ForeignKey(
                        name: "FK_User_UserGridPreferences_UserId",
                        column: x => x.UserId,
                        principalSchema: "aut",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserRole",
                schema: "rel",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    RoleId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRole_UserId_RoleId", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_UserRole_Role_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "aut",
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserRole_User_UserId",
                        column: x => x.UserId,
                        principalSchema: "aut",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Revenue",
                schema: "ent",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    InternalCode = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: true),
                    Year = table.Column<int>(type: "integer", nullable: false),
                    FYFCLC = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    FYFCCHF = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    FYFCCHFVAT = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    ServiceDescription = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    LineOfBusinessId = table.Column<int>(type: "integer", nullable: false),
                    CustomerId = table.Column<int>(type: "integer", nullable: false),
                    ProjectId = table.Column<int>(type: "integer", nullable: false),
                    TypeOfServiceId = table.Column<int>(type: "integer", nullable: false),
                    OwnerProjectManagerId = table.Column<int>(type: "integer", nullable: false),
                    BusinessUnitId = table.Column<int>(type: "integer", nullable: true),
                    CustomerCostCenterId = table.Column<int>(type: "integer", nullable: true),
                    ChargingModelId = table.Column<int>(type: "integer", nullable: false),
                    InternalCostCenterPerCostId = table.Column<int>(type: "integer", nullable: false),
                    CurrencyId = table.Column<int>(type: "integer", nullable: false),
                    ValueAddedTaxId = table.Column<int>(type: "integer", nullable: true),
                    JanuaryAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    JanuaryLocked = table.Column<bool>(type: "boolean", nullable: true),
                    FebruaryAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    FebruaryLocked = table.Column<bool>(type: "boolean", nullable: true),
                    MarchAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    MarchLocked = table.Column<bool>(type: "boolean", nullable: true),
                    AprilAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    AprilLocked = table.Column<bool>(type: "boolean", nullable: true),
                    MayAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    MayLocked = table.Column<bool>(type: "boolean", nullable: true),
                    JuneAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    JuneLocked = table.Column<bool>(type: "boolean", nullable: true),
                    JulyAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    JulyLocked = table.Column<bool>(type: "boolean", nullable: true),
                    AugustAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    AugustLocked = table.Column<bool>(type: "boolean", nullable: true),
                    SeptemberAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    SeptemberLocked = table.Column<bool>(type: "boolean", nullable: true),
                    OctoberAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    OctoberLocked = table.Column<bool>(type: "boolean", nullable: true),
                    NovemberAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    NovemberLocked = table.Column<bool>(type: "boolean", nullable: true),
                    DecemberAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: true),
                    DecemberLocked = table.Column<bool>(type: "boolean", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Revenue_Id", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Revenue_BusinessUnit_BusinessUnitId",
                        column: x => x.BusinessUnitId,
                        principalSchema: "mdt",
                        principalTable: "BusinessUnit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_ChargingModel_ChargingModelId",
                        column: x => x.ChargingModelId,
                        principalSchema: "mdt",
                        principalTable: "ChargingModel",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_CostCenter_CustomerCostCenterId",
                        column: x => x.CustomerCostCenterId,
                        principalSchema: "mdt",
                        principalTable: "CostCenter",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_CostCenter_InternalCostCenterPerCostId",
                        column: x => x.InternalCostCenterPerCostId,
                        principalSchema: "mdt",
                        principalTable: "CostCenter",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_Currency_CurrencyId",
                        column: x => x.CurrencyId,
                        principalSchema: "mdt",
                        principalTable: "Currency",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_Customer_CustomerId",
                        column: x => x.CustomerId,
                        principalSchema: "mdt",
                        principalTable: "Customer",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_LineOfBusiness_LineOfBusinessId",
                        column: x => x.LineOfBusinessId,
                        principalSchema: "mdt",
                        principalTable: "LineOfBusiness",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_Project_ProjectId",
                        column: x => x.ProjectId,
                        principalSchema: "mdt",
                        principalTable: "Project",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_TypeOfService_TypeOfServiceId",
                        column: x => x.TypeOfServiceId,
                        principalSchema: "mdt",
                        principalTable: "TypeOfService",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_User_OwnerProjectManagerId",
                        column: x => x.OwnerProjectManagerId,
                        principalSchema: "aut",
                        principalTable: "User",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Revenue_ValueAddedTax_ValueAddedTaxId",
                        column: x => x.ValueAddedTaxId,
                        principalSchema: "mdt",
                        principalTable: "ValueAddedTax",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "AK_ApplicationConfiguration_Name",
                schema: "int",
                table: "ApplicationConfiguration",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_BusinessUnit_Code",
                schema: "mdt",
                table: "BusinessUnit",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_ChargingModel_Code",
                schema: "mdt",
                table: "ChargingModel",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_CostCenter_Code",
                schema: "mdt",
                table: "CostCenter",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_Currency_Code",
                schema: "mdt",
                table: "Currency",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_CurrencyExchangeRate_Year_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                columns: new[] { "Year", "CurrencyIdFrom", "CurrencyIdTo" },
                unique: true,
                filter: "\"Month\" IS NULL");

            migrationBuilder.CreateIndex(
                name: "AK_CurrencyExchangeRate_Year_Month_CurrencyFrom_CurrencyTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                columns: new[] { "Year", "Month", "CurrencyIdFrom", "CurrencyIdTo" },
                unique: true,
                filter: "\"Month\" IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_CurrencyExchangeRate_CurrencyIdFrom",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdFrom");

            migrationBuilder.CreateIndex(
                name: "IX_CurrencyExchangeRate_CurrencyIdTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdTo");

            migrationBuilder.CreateIndex(
                name: "AK_Customer_Name",
                schema: "mdt",
                table: "Customer",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_Field_Entity_EntityReference",
                schema: "int",
                table: "Field",
                columns: new[] { "Entity", "EntityReference" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_LineOfBusiness_Name",
                schema: "mdt",
                table: "LineOfBusiness",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_Permission_Name",
                schema: "aut",
                table: "Permission",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_Project_Name",
                schema: "mdt",
                table: "Project",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_Revenue_Year_LoB_Customer_Project_ToS_ServiceDescription",
                schema: "ent",
                table: "Revenue",
                columns: new[] { "Year", "LineOfBusinessId", "CustomerId", "ProjectId", "TypeOfServiceId", "ServiceDescription" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_BusinessUnitId",
                schema: "ent",
                table: "Revenue",
                column: "BusinessUnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_ChargingModelId",
                schema: "ent",
                table: "Revenue",
                column: "ChargingModelId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_CurrencyId",
                schema: "ent",
                table: "Revenue",
                column: "CurrencyId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_CustomerCostCenterId",
                schema: "ent",
                table: "Revenue",
                column: "CustomerCostCenterId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_CustomerId",
                schema: "ent",
                table: "Revenue",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_InternalCostCenterPerCostId",
                schema: "ent",
                table: "Revenue",
                column: "InternalCostCenterPerCostId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_LineOfBusinessId",
                schema: "ent",
                table: "Revenue",
                column: "LineOfBusinessId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_OwnerProjectManagerId",
                schema: "ent",
                table: "Revenue",
                column: "OwnerProjectManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_ProjectId",
                schema: "ent",
                table: "Revenue",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_TypeOfServiceId",
                schema: "ent",
                table: "Revenue",
                column: "TypeOfServiceId");

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_ValueAddedTaxId",
                schema: "ent",
                table: "Revenue",
                column: "ValueAddedTaxId");

            migrationBuilder.CreateIndex(
                name: "AK_Role_Name",
                schema: "aut",
                table: "Role",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_RolePermission_PermissionId",
                schema: "rel",
                table: "RolePermission",
                column: "PermissionId");

            migrationBuilder.CreateIndex(
                name: "AK_TypeOfService_Name",
                schema: "mdt",
                table: "TypeOfService",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "AK_User_SAMAccountName",
                schema: "aut",
                table: "User",
                column: "SAMAccountName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserRole_RoleId",
                schema: "rel",
                table: "UserRole",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "AK_ValueAddedTax_Country",
                schema: "mdt",
                table: "ValueAddedTax",
                column: "Country",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ApplicationConfiguration",
                schema: "int");

            migrationBuilder.DropTable(
                name: "CurrencyExchangeRate",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "Field",
                schema: "int");

            migrationBuilder.DropTable(
                name: "Revenue",
                schema: "ent");

            migrationBuilder.DropTable(
                name: "RolePermission",
                schema: "rel");

            migrationBuilder.DropTable(
                name: "UserGridPreferences",
                schema: "val");

            migrationBuilder.DropTable(
                name: "UserRole",
                schema: "rel");

            migrationBuilder.DropTable(
                name: "BusinessUnit",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "ChargingModel",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "CostCenter",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "Currency",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "Customer",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "LineOfBusiness",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "Project",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "TypeOfService",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "ValueAddedTax",
                schema: "mdt");

            migrationBuilder.DropTable(
                name: "Permission",
                schema: "aut");

            migrationBuilder.DropTable(
                name: "Role",
                schema: "aut");

            migrationBuilder.DropTable(
                name: "User",
                schema: "aut");
        }
    }
}
