﻿#nullable disable

namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;
    using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
    using Domain;

    public partial class ChargingModelType_YearLocks : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ChargingModelType",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Type = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChargingModelType_Id", x => x.Id);
                });

            // BI
            migrationBuilder.Sql($"INSERT INTO \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" (\"{nameof(ChargingModelType.Type)}\") VALUES ('BI')");
            // RB
            migrationBuilder.Sql($"INSERT INTO \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" (\"{nameof(ChargingModelType.Type)}\") VALUES ('RB')");
            // CA
            migrationBuilder.Sql($"INSERT INTO \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" (\"{nameof(ChargingModelType.Type)}\") VALUES ('CA')");

            migrationBuilder.AddColumn<int>(
                name: "ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel",
                type: "integer",
                nullable: true,
                defaultValue: 0);

            // BI
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'BI') WHERE \"{nameof(ChargingModel.Code)}\" = 'BIC'");
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'BI') WHERE \"{nameof(ChargingModel.Code)}\" = 'BIE'");
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'BI') WHERE \"{nameof(ChargingModel.Code)}\" = 'MI'");
            // RB
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'RB') WHERE \"{nameof(ChargingModel.Code)}\" = 'RBI'");
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'RB') WHERE \"{nameof(ChargingModel.Code)}\" = 'RBD'");
            // CA
            migrationBuilder.Sql($"UPDATE \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModel)}\" SET \"{nameof(ChargingModelType)}{nameof(ChargingModel.Id)}\" = (SELECT \"{nameof(ChargingModelType.Id)}\" FROM \"{BaseConfiguration.MasterDataSchema}\".\"{nameof(ChargingModelType)}\" WHERE \"{nameof(ChargingModelType.Type)}\" = 'CA') WHERE \"{nameof(ChargingModel.Code)}\" NOT IN ('BIC', 'BIE', 'MI', 'RBI', 'RBD')");

            migrationBuilder.AlterColumn<int>(
                name: "ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "YearLocks",
                schema: "val",
                columns: table => new
                {
                    Year = table.Column<int>(type: "integer", maxLength: 255, nullable: false),
                    ChargingModelTypeId = table.Column<int>(type: "integer", nullable: false),
                    January = table.Column<bool>(type: "boolean", nullable: false),
                    February = table.Column<bool>(type: "boolean", nullable: false),
                    March = table.Column<bool>(type: "boolean", nullable: false),
                    April = table.Column<bool>(type: "boolean", nullable: false),
                    May = table.Column<bool>(type: "boolean", nullable: false),
                    June = table.Column<bool>(type: "boolean", nullable: false),
                    July = table.Column<bool>(type: "boolean", nullable: false),
                    August = table.Column<bool>(type: "boolean", nullable: false),
                    September = table.Column<bool>(type: "boolean", nullable: false),
                    October = table.Column<bool>(type: "boolean", nullable: false),
                    November = table.Column<bool>(type: "boolean", nullable: false),
                    December = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_YearLocks_Year_ChargingModelTypeId", x => new { x.Year, x.ChargingModelTypeId });
                    table.ForeignKey(
                        name: "FK_YearLocks_ChargingModelType_ChargingModelTypeId",
                        column: x => x.ChargingModelTypeId,
                        principalSchema: "mdt",
                        principalTable: "ChargingModelType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.DropTable(
                name: "MonthLock",
                schema: "val");

            migrationBuilder.CreateIndex(
                name: "IX_ChargingModel_ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel",
                column: "ChargingModelTypeId");

            migrationBuilder.CreateIndex(
                name: "AK_ChargingModelType_Type",
                schema: "mdt",
                table: "ChargingModelType",
                column: "Type",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_YearLocks_ChargingModelTypeId",
                schema: "val",
                table: "YearLocks",
                column: "ChargingModelTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_ChargingModel_ChargingModelType_ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel",
                column: "ChargingModelTypeId",
                principalSchema: "mdt",
                principalTable: "ChargingModelType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChargingModel_ChargingModelType_ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel");

            migrationBuilder.DropTable(
                name: "YearLocks",
                schema: "val");

            migrationBuilder.DropTable(
                name: "ChargingModelType",
                schema: "mdt");

            migrationBuilder.DropIndex(
                name: "IX_ChargingModel_ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel");

            migrationBuilder.DropColumn(
                name: "ChargingModelTypeId",
                schema: "mdt",
                table: "ChargingModel");

            migrationBuilder.CreateTable(
                name: "MonthLock",
                schema: "val",
                columns: table => new
                {
                    Year = table.Column<int>(type: "integer", maxLength: 255, nullable: false),
                    Month = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonthLock_Year_Month", x => new { x.Year, x.Month });
                });
        }
    }
}
