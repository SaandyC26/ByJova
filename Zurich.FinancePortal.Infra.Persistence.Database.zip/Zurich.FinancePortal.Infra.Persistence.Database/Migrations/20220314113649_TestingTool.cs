﻿#nullable disable

namespace Zurich.FinancePortal.Infra.Persistence.Database.Migrations
{
    using Microsoft.EntityFrameworkCore.Migrations;
    using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

    public partial class TestingTool : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdFrom",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.DropForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdTo",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.AddColumn<string>(
                name: "TestingToolDetailedInfo",
                schema: "ent",
                table: "Revenue",
                type: "character varying(255)",
                maxLength: 255,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TestingToolId",
                schema: "ent",
                table: "Revenue",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TestingToolProjectName",
                schema: "ent",
                table: "Revenue",
                type: "character varying(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "TestingTool",
                schema: "mdt",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    Name = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestingTool_Id", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Revenue_TestingToolId",
                schema: "ent",
                table: "Revenue",
                column: "TestingToolId");

            migrationBuilder.CreateIndex(
                name: "AK_TestingTool_Name",
                schema: "mdt",
                table: "TestingTool",
                column: "Name",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdFrom",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdFrom",
                principalSchema: "mdt",
                principalTable: "Currency",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdTo",
                principalSchema: "mdt",
                principalTable: "Currency",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Revenue_TestingTool_TestingToolId",
                schema: "ent",
                table: "Revenue",
                column: "TestingToolId",
                principalSchema: "mdt",
                principalTable: "TestingTool",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdFrom",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.DropForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdTo",
                schema: "mdt",
                table: "CurrencyExchangeRate");

            migrationBuilder.DropForeignKey(
                name: "FK_Revenue_TestingTool_TestingToolId",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropTable(
                name: "TestingTool",
                schema: "mdt");

            migrationBuilder.DropIndex(
                name: "IX_Revenue_TestingToolId",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "TestingToolDetailedInfo",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "TestingToolId",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.DropColumn(
                name: "TestingToolProjectName",
                schema: "ent",
                table: "Revenue");

            migrationBuilder.AddForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdFrom",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdFrom",
                principalSchema: "mdt",
                principalTable: "Currency",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CurrencyExchangeRate_Currency_CurrencyIdTo",
                schema: "mdt",
                table: "CurrencyExchangeRate",
                column: "CurrencyIdTo",
                principalSchema: "mdt",
                principalTable: "Currency",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
